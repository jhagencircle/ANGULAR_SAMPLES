﻿import moment = require("moment");
import { IdTextPair } from "select2";
import select2 = require("select2");

declare var components: Array<any>;

export module Site {

	let oneSecond = 1000;
	let oneMinute = oneSecond * 60;
	let refreshTimeout = oneMinute * 20;
	let refreshErrTimeout = oneMinute * 2;
	let refreshErrCount = 0;

	require(["inputmask", "timepicker"], () => {});

	export function loadSelect2ById(selectId: string, method: string = "get", fnTemplateSelection: Function = null, fnTemplateResult: Function = select2TemplateResult): void {
		loadSelect2($("#" + selectId), method, fnTemplateSelection, fnTemplateResult);
	}

	export function loadSelect2(select: JQuery<HTMLElement>, method: string = "get", fnTemplateSelection: Function = null, fnTemplateResult: Function = select2TemplateResult) {

		if (select.length == 0)
			return;

		let pageSize: number = 10;
		let pageSizeParam: string | undefined = select.attr("data-pageSize");
		if (pageSizeParam) {
			pageSize = parseInt(pageSizeParam);
		}

		let minInputLength: number = 3;
		let minInputLengthParam: string | undefined = select.attr("data-minInputLen");
		if (minInputLengthParam) {
			minInputLength = parseInt(minInputLengthParam);
		}

		let maxSelections: number = 5;
		let maxSelectionsParam: string | undefined = select.attr("data-max-selections");
		if (maxSelectionsParam) {
			maxSelections = parseInt(maxSelectionsParam);
		}

		let ajaxUrl: string = select.attr("data-url");
		let placeholder: string | undefined = select.attr("data-placeholder");

		select.select2({
			language: {
				inputTooShort: () => { return `Enter at least ${minInputLength} characters`; }
			},
			ajax: {
				url: function (params) {
					params.page = params.page || 1;
					return apiBase + ajaxUrl + `/${params.term}/${pageSize}/${params.page}`;
				},
				method: method,
				dataType: 'json',
				delay: 250,
				data: null,
				processResults: function (data, params) {
					params.page = params.page || 1;

					return {
						results: data.results,
						pagination: {
							more: (params.page * pageSize) < data.totalCount
						}
					};
				},
				cache: true
			},
			placeholder: placeholder,
			minimumInputLength: minInputLength,
			maximumSelectionLength: maxSelections,
			templateResult: function (repo) {
				if ((<any>repo).loading) {
					return repo.text;
				}
				return fnTemplateResult(repo);
			},
			templateSelection: function (repo) {
				if ($.isFunction(fnTemplateSelection)) {
					return fnTemplateSelection(repo);
				} else {
					return repo.text;
				}
			}
		});
	}

	export function reloadFormValidation(formString) {
		var form = $(formString);
		form.removeData("validator");
		form.removeData("unobtrusiveValidation");
		(<any>$.validator).unobtrusive.parse(form);
	}

	function select2TemplateResult(repo: IdTextPair): JQuery<HTMLElement> {
		return $(`<div id="${repo.id}">${repo.text}</div>`);
	}

	export type DatePickerOnSelectCallback = (dateStr: string) => void;
	export type DatePickerValidateCallback = (field: JQuery<any>) => void;

	export function initializeDatePicker(inputId: string, minSearchDate: Date, maxSearchDate: Date, fnOnSelect: DatePickerValidateCallback = null, dateFormat: string = "MM/DD/YYYY", inputMask: string = "99/99/9999") {

		$(inputId).datepicker({
			minDate: minSearchDate,
			maxDate: maxSearchDate,
			onSelect(dateStr: string) {

				$(inputId).val(moment(new Date(dateStr)).format(dateFormat));
				$(inputId).datepicker("hide");

				if (fnOnSelect) {
					fnOnSelect($(inputId));
				}
			}
		});

		$(inputId).inputmask(inputMask);
	}

	export function initializeTimePicker(inputId: string, className: string = "", appearAsSelect = false) {
		(<any>$(inputId)).timepicker({
			className: className,
			useSelect: appearAsSelect,
			timeFormat: "g:i a"
		});
	}

	export function isValidDate(value: any, element: HTMLElement): boolean {
		if (value) {
			return !((new Date(value)).toString() === "Invalid Date");
		} else {
			return false;
		}
	}

	export function isMinDateValid(value: any, element: HTMLElement): boolean {
		if (isValidDate(value, element)) {
			var minDateAttr: string = $(element).attr("data-min-date");
			if (minDateAttr) {
				return ((new Date(value)) >= (new Date(minDateAttr)));
			}
		} else {
			return true;
		}
	}

	export function isMaxDateValid(value: any, element: HTMLElement): boolean {
		if (isValidDate(value, element)) {
			var maxDateAttr: string = $(element).attr("data-max-date");
			if (maxDateAttr) {
				return ((new Date(value)) <= (new Date(maxDateAttr)));
			}
		} else {
			return true;
		}
	}

	export function requireOfficeHours(value: any, element: HTMLElement) {
		alert("Taco");
		console.log("Taco");
	}

	export function dateBefore(value: any, element: HTMLElement): boolean {
		if (isValidDate(value, element)) {
			var isBeforeDate = $(`#${$(element).attr("data-date-before-id")}`).val() as string;
			if (isBeforeDate) {
				return ((new Date(value)) >= new Date(isBeforeDate));
			}
			return true;
		} else {
			return true;
		}
	}
	export function dateAfter(value: any, element: HTMLElement): boolean {
		if (isValidDate(value, element)) {
			var isAfterDate = $(`#${$(element).attr("data-date-after-id")}`).val() as string;
			if (isAfterDate) {

				return ((new Date(value)) <= new Date(isAfterDate));
			}
			return true;
		} else {
			return true;
		}
	}

	let showLoadingCallCount: number = 0;
	let loadingContent: JQuery<HTMLElement> = null;

	export function showLoading() {
		showLoadingCallCount++;
		if (loadingContent == null) {
			loadingContent = $('<div id="loadingContent"><img src="/credentialing/images/loading-bar.gif" /></div>');
			loadingContent.appendTo(document.body);
		}
		loadingContent.show();
	}

	export function hideLoading() {
		showLoadingCallCount = showLoadingCallCount-- < 0 ? 0 : showLoadingCallCount;
		if (showLoadingCallCount === 0) {
			loadingContent.fadeOut(200);
		}
	}

	export function scrollToTop(element: JQuery<any> = null, duration: number = 100) {
		var offset = 0;

		if (element != null) {
			var elementOffset = element.offset();

			console.log(elementOffset);

			if (elementOffset)
				offset = element.offset().top - 100;
		}

		$('html, body').animate({ scrollTop: offset }, duration);
	}

	export function scrollErrorIntoView(durationEasing: number) {

		var errorMessages = $(".field-validation-error:visible");
		var firstError = errorMessages.first();
		var inputField = firstError.siblings("input");
		if (inputField.length === 0)
			inputField = firstError.siblings("textarea");

		scrollToTop(firstError, durationEasing);
		inputField.focus();
	}
}
