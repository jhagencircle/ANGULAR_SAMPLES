import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { WelcomeDialogService } from './welcome-dialog.service';

describe('WelcomeDialogService', () => {
  let service: WelcomeDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    service = TestBed.inject(WelcomeDialogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
