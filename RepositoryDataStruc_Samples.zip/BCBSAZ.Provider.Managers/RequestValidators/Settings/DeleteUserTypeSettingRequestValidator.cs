﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Settings;

namespace BCBSAZ.Provider.Managers.RequestValidators.Settings
{
	internal static class DeleteUserTypeSettingRequestValidator
	{
		public static void Validate(this DeleteUserTypeSettingRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(DeleteUserTypeSettingRequest request)
		{
			if (request.UserTypeSettingId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(DeleteUserTypeSettingRequest.UserTypeSettingId), new ArgumentException("UserTypeSettingId is not valid."));
		}
	}
}
