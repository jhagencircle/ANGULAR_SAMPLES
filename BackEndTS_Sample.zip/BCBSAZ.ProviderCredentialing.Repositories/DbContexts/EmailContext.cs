﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Repositories.DbContexts
{
	public interface IEmailContext : IDbContext
	{

	}

	public class EmailContext : DbContext, IEmailContext
	{
		/// <summary>
		/// Creates a new instance of the Eligibility DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public EmailContext(DbContextOptions<EmailContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
		}
	}
}
