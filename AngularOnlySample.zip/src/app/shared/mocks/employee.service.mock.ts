import { BehaviorSubject, Observable, of, Subject } from 'rxjs';
import { IState } from 'src/app/manage-benefits/shared/state';

export class EmployeeServiceMock {
  constructor() {}
  public _loading$ = new BehaviorSubject<boolean>(true);
  private _search$ = new Subject<void>();
  private _state: IState = {
    page: 1,
    pageSize: 10,
    searchTerm: '',
    planMedical: null,
    planDental: null,
    sortColumn: '',
    sortDirection: '',
  };
  public applyChange = new BehaviorSubject<boolean>(false);
  get loading$() {
    return this._loading$.asObservable();
  }
  get planMedical() {
    return this._state.planMedical;
  }
  get planDental() {
    return this._state.planDental;
  }

  set planMedical(planMedical: string | null) {
    this._set({ planMedical });
  }
  set planDental(planDental: string | null) {
    this._set({ planDental });
  }

  private _set(patch: Partial<IState>) {
    Object.assign(this._state, patch);
    this._search$.next();
  }

  get employees$(): Observable<any> {
    return of([
      {
        subscriberId: '000100',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Neil',
        lastName: 'Docker',
        employeeId: '000201',
        medicalId: 'ZZZZBP2021010803553TIER',
        dentalId: 'DM01',
        plans: [
          {
            id: 'ZZZZBP2021010803553TIER',
            name: '2002101 030855 NGF Triple Choice',
            type: 'Medical',
            specialtyType: 'null',
          },
        ],
        medicalPlanName: '',
        dentalPlanName: '',
        medicalPlanId: '',
        dentalPlanId: '',
      },
    ]);
  }

  update() {
    this.applyChange.next(true);
  }

  get(): Observable<any> {
    return of([
      {
        subscriberId: '000100',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Neil',
        lastName: 'Docker',
        employeeId: '000201',
        medicalId: 'ZZZZBP2021010803553TIER',
        dentalId: 'DM01',
        plans: [
          {
            id: 'ZZZZBP2021010803553TIER',
            name: '2002101 030855 NGF Triple Choice',
            type: 'Medical',
            specialtyType: null,
          },
        ],
      },
      {
        subscriberId: '000200',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Naresh',
        lastName: 'Davis',
        employeeId: '000301',
        medicalId: 'BM01',
        dentalId: 'DM01',
        plans: [],
      },
      {
        subscriberId: '000300',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Norah',
        lastName: 'Draper',
        employeeId: '000401',
        medicalId: 'BM01',
        dentalId: 'DM01',
        plans: [],
      },
      {
        subscriberId: '000400',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Nellie',
        lastName: 'Dabney',
        employeeId: '000501',
        medicalId: 'BM01',
        dentalId: 'DM01',
        plans: [],
      },
      {
        subscriberId: '000500',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Stacy',
        lastName: 'Nelson',
        employeeId: '000601',
        medicalId: 'BP202101080355HDHP',
        dentalId: 'DM01',
        plans: [
          {
            id: 'BP202101080355HDHP',
            name: '202101 030855 NGF BluePreferred HDHP',
            type: 'High Deductible Health Plan',
            specialtyType: null,
          },
        ],
      },
      {
        subscriberId: '000600',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Samuel',
        lastName: 'Campbell',
        employeeId: '000701',
        medicalId: '',
        dentalId: 'MVDTLDHMPN000051',
        plans: [
          {
            id: 'MVDTLDHMPN000051',
            name: 'BlueDental DHMO Plus North',
            type: 'Dental',
            specialtyType: null,
          },
        ],
      },
      {
        subscriberId: '000700',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Scott',
        lastName: 'Napoli',
        employeeId: '000801',
        medicalId: 'BM01',
        dentalId: 'DM01',
        plans: [],
      },
      {
        subscriberId: '000800',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Sage',
        lastName: 'Carter',
        employeeId: '000801',
        medicalId: 'BM01',
        dentalId: 'MVDTLDHMPN000051',
        plans: [
          {
            id: null,
            name: 'BlueDental DHMO Plus North',
            type: 'Dental',
            specialtyType: null,
          },
        ],
      },
      {
        subscriberId: '000900',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Stephen',
        lastName: 'Norwood',
        employeeId: '000901',
        medicalId: 'ZZZZBP2021010803553TIER',
        dentalId: 'DM01',
        plans: [
          {
            id: 'BP202101080355HDHP',
            name: '202101 030855 NGF BluePreferred HDHP',
            type: 'High Deductible Health Plan',
            specialtyType: null,
          },
        ],
      },
      {
        subscriberId: '001000',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Santiago',
        lastName: 'Calderone',
        employeeId: '001001',
        medicalId: 'BM01',
        dentalId: 'MVDTLDHMPN00005',
        plans: [
          {
            id: null,
            name: 'BlueDental DHMO Plus North',
            type: 'Dental',
            specialtyType: null,
          },
        ],
      },
      {
        subscriberId: '001100',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Shannon',
        lastName: 'Clark',
        employeeId: '001101',
        medicalId: 'BM01',
        dentalId: 'MVDTLDHMPN000051',
        plans: [
          {
            id: null,
            name: 'BlueDental DHMO Plus North',
            type: 'Dental',
            specialtyType: null,
          },
        ],
      },
      {
        subscriberId: '001200',
        amountBilled: 1430.0,
        adjustmentReason: 'No adjustment',
        firstName: 'Sally',
        lastName: 'Nathan',
        employeeId: '001201',
        medicalId: 'BM01',
        dentalId: 'BD01',
        plans: [],
      },
    ]);
  }

  getById(): Observable<any> {
    return of({
      subscriberId: '000100',
      memberId: '000101',
      accountId: '000312',
      subAccountId: '',
      firstName: 'Neil',
      lastName: 'Docker',
      employeeId: '000201',
      location: 'Arizona',
      dateOfBirth: '03-22-1965',
      ssn: '1234567891',
      maritalStatus: 'Single',
      gender: 'Male',
      effectiveDateOfPolicy: '06-30-2021',
      contactInformation: {
        address: '1313 Mockingbird Lane',
        emailAddress: 'mylittlepony@hotmail.com',
        phoneNumbers: [{ number: '6026398981', phoneType: 'Personal' }],
      },
      benefitSelection: {
        planSelection: [
          {
            id: 'ZZZZBP2021010803553TIER',
            name: '2002101 030855 NGF Triple Choice',
            type: 'Medical',
            coverageID: '2001',
          },
        ],
        eligibleForMedicare: false,
        medicareNumber: null,
        partAEffectiveDate: null,
        partBEffectiveDate: null,
        lifeInsuranceBenefit: null,
        flexibleSpendingSelection: true,
      },
      dependents: [
        {
          firstName: 'Tobias',
          middleName: '',
          lastName: 'Docker',
          dependentType: 'child',
          dateOfBirth: '07-23-2013',
          ssn: '4413745752',
          gender: 'Male',
          benefitSelection: {
            planSelection: [
              {
                id: 'ZZZZBP2021010803553TIER',
                name: '2002101 030855 NGF Triple Choice',
                type: 'Medical',
                coverageID: '4002',
              },
            ],
            eligibleForMedicare: false,
            medicareNumber: null,
            partAEffectiveDate: null,
            partBEffectiveDate: null,
            lifeInsuranceBenefit: null,
            flexibleSpendingSelection: false,
          },
          removalReason: null,
        },
      ],
      terminateCoverage: {
        subscriberId: '000100',
        accountNumber: '000312',
        products: [
          {
            effectiveDate: new Date(),
            planType: 'Medical',
            hccPlanId: null,
            subAccountNumber: '',
            requiredStartDate: new Date(),
          },
        ],
        terminationReason: 'Not Applicable',
        receivedDate: new Date(),
      },
    });
  }

  employee = {
    subscriberId: '000100',
    memberId: '000101',
    accountId: '000312',
    subAccountId: '',
    firstName: 'Neil',
    lastName: 'Docker',
    employeeId: '000201',
    location: 'Arizona',
    dateOfBirth: '03-22-1965',
    ssn: '1234567891',
    maritalStatus: 'Single',
    gender: 'Male',
    effectiveDateOfPolicy: '06-30-2021',
    contactInformation: {
      address: '1313 Mockingbird Lane',
      emailAddress: 'mylittlepony@hotmail.com',
      phoneNumbers: [{ number: '6026398981', phoneType: 'Personal' }],
    },
    benefitSelection: {
      planSelection: [
        {
          id: 'ZZZZBP2021010803553TIER',
          name: '2002101 030855 NGF Triple Choice',
          type: 'Medical',
          coverageID: '2001',
        },
      ],
      eligibleForMedicare: false,
      medicareNumber: null,
      partAEffectiveDate: null,
      partBEffectiveDate: null,
      lifeInsuranceBenefit: null,
      flexibleSpendingSelection: true,
    },
    dependents: [
      {
        firstName: 'Tobias',
        middleName: '',
        lastName: 'Docker',
        dependentType: 'child',
        dateOfBirth: '07-23-2013',
        ssn: '4413745752',
        gender: 'Male',
        benefitSelection: {
          planSelection: [
            {
              id: 'ZZZZBP2021010803553TIER',
              name: '2002101 030855 NGF Triple Choice',
              type: 'Medical',
              coverageID: '4002',
            },
          ],
          eligibleForMedicare: false,
          medicareNumber: null,
          partAEffectiveDate: null,
          partBEffectiveDate: null,
          lifeInsuranceBenefit: null,
          flexibleSpendingSelection: false,
        },
        removalReason: null,
      },
    ],
    terminateCoverage: {
      subscriberId: '000100',
      accountNumber: '000312',
      products: [
        {
          effectiveDate: new Date(),
          planType: 'Medical',
          hccPlanId: null,
          subAccountNumber: '',
          requiredStartDate: new Date(),
        },
      ],
      terminationReason: 'Not Applicable',
      receivedDate: new Date(),
    },
  };

  terminateCoverage = {
    subscriberId: '000100',
    accountNumber: '000312',
    products: [
      {
        effectiveDate: new Date(),
        planType: 'Medical',
        hccPlanId: null,
        subAccountNumber: '',
        requiredStartDate: new Date(),
      },
    ],
    terminationReason: 'Not Applicable',
    receivedDate: new Date(),
  };
}
