﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IPurgeManager
	{
		Task PurgeClaimsResultsAsync(int days);
		Task PurgeEligibilityResultsAsync(int days);
	}
}
