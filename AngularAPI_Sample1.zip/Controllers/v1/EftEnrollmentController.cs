﻿using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using Microsoft.AspNetCore.Mvc;

using System;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Reflection;
using System.Threading.Tasks;
using SelectPdf;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.ProviderAuxiliaryPortal.WebAPI.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class EftEnrollmentController : ControllerBase
    {

        private readonly IEftEnrollmentManager _eftEnrollmentManager;
        private string fileName;
        private string fullPath;
        private string fileNam;

        public EftEnrollmentController(IEftEnrollmentManager eftEnrollmentManager)
        {
            _eftEnrollmentManager = eftEnrollmentManager;
        }

        /// <summary>
        /// This is used to create Electronic Funds Transaction (EFT) Enrollment records.
        /// </summary>
        /// <param name="request">
        /// The request param contains properties who's values well be set by user then later validated when user submits final edited form.
        /// </param>

        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        [HttpPost("Create")]
        public async Task<ActionResult> CreateEftUserProfile([FromBody] EftEnrollmentRequest request)
        {
            try
            {   
                var result = await _eftEnrollmentManager.CreateEftUserProfileAsync(request);
                return StatusCode(201, "EFT User Profile successfully created.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }        

        /// <summary>
        /// This is used to update Electronic Funds Transaction (EFT) Enrollment records.
        /// </summary>        /// 
        /// <param name="request">
        /// The request param contains properties who's values well be set by user then later validated when user submits final edited form.
        /// </param>

        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        [HttpPost("Update")]
        public async Task<ActionResult> UpdateEftUserProfile([FromBody] EftEnrollmentRequest request)
        {
            try
            {
                var result = await _eftEnrollmentManager.UpdateEftUserProfileAsync(request);
                return StatusCode(200, "EFT User Profile successfully updated.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }


        //[HttpPost, DisableRequestSizeLimit] // Doesn't work from Postman
        [HttpPost("Upload")] //works from Postman
        //public IActionResult Upload(EftEnrollmentRequest request, IList<IFormFile> files)
        public IActionResult Upload()
        {

            try
            {
                IEnumerable<FileAttachment> attachments;

                //attachments = Request.Form.Files;

                var file = Request.Form.Files[0];
                var fileNm = Request.Form.Files;

                var folderName = Path.Combine("StaticFiles", "Images");
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);

                
                
                if (file.Length > 0)
                {
                    fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    fullPath = Path.Combine(pathToSave);
                    var dbPath = Path.Combine(folderName, fileName);


                        foreach (var item in Request.Form.Files)
                    {
                        fileNam = ContentDispositionHeaderValue.Parse(item.ContentDisposition).FileName.Trim('"');
                        using (var stream = new FileStream(fullPath + fileNam, FileMode.Create))
                        {
 
                            Path.Combine(pathToSave, fileNam);
                            file.CopyTo(stream);
                        }
                        }
                        //file.CopyTo(stream);
                    

                    return Ok(new { dbPath });
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex}");
            }


        }

        /// <summary>
        /// This is used to update Electronic Funds Transaction (EFT) Enrollment records and change the status to "Saved".
        /// This also converts the request object to a pdf and emails as an attachment.
        /// </summary>
        /// <param name="request">
        /// The request param contains properties who's values well be set by user then later validated when user submits final edited form.
        /// </param>

        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        [HttpPost("SaveFinal")]
        public async Task<IActionResult> SaveValidEftUserProfile([FromBody] EftEnrollmentRequest request)
        {            
            try
            {               
                                
                bool isAnyPropEmpty = request.GetType().GetProperties()
                     .Where(p => p.GetValue(request) is string) // selecting only string props
                     .Any(p => string.IsNullOrWhiteSpace((p.GetValue(request) as string)));
                
                if (isAnyPropEmpty)
                    return BadRequest("Invalid parameters");

                var result = await _eftEnrollmentManager.UpdateEftUserProfileAsync(request, ProviderEftStatusEnum.Saved);
                return StatusCode(200, "EFT User Profile successfully saved and submitted as PDF.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }
    }
}
