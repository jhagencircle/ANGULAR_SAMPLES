﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Text.RegularExpressions;

namespace System
{
	/// <summary>
	/// Extension methods for String
	/// </summary>
	public static class StringExtensions
	{
		/// <summary>
		/// Ensures the string ends with the specified character, if it does not, the character is added to the end of the string.
		/// </summary>
		/// <param name="value">The string value being evaluated.</param>
		/// <param name="endsWith">The character which should be at the end of the string.</param>
		/// <returns>
		/// Returns the string with the specified character at the end.
		/// If the original string was null, the return value will be a string containing the endsWith character.
		/// </returns>
		public static string EnsureEndsWith(this string value, char endsWith)
		{
			if (value == null) return new string(endsWith, 1);

			return value.EndsWith(endsWith) ? value : value + endsWith;
		}


		/// <summary>
		/// Converts a string to have a capitol first character and all remaning characters lower case.
		/// </summary>
		/// <param name="str"></param>
		/// <returns></returns>
		[SuppressMessage("Globalization", "CA1308:Normalize strings to uppercase", Justification = "Lowercasing is a required operation for this function.")]
		public static string CapitalizeFirstLetter(this string str)
		{
			if (str == null) throw new ArgumentNullException(nameof(str));
			if (string.IsNullOrWhiteSpace(str)) return str;

			var a = str.ToLowerInvariant().ToCharArray();
			a[0] = char.ToUpperInvariant(a[0]);
			return new string(a);
		}

		/// <summary>
		/// Checks the length of a string and trucates it if it is longer than the specified length.
		/// </summary>
		/// <param name="value"></param>
		/// <param name="length"></param>
		/// <returns></returns>
		public static string TruncateAt(this string value, int length)
		{
			if (value == null) return null;

			return (value.Length > length) ? value.Substring(0, length) : value;
		}

		private static readonly Regex _alphaNumeric = new Regex("[^a-zA-Z0-9 ]", RegexOptions.Compiled);
		/// <summary>
		/// Removes non-alpha-numeric characters (except spaces) from the string
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		/// <example>
		/// "This is #1." becomes "This is 1"
		/// </example>
		public static string RemoveNonAlphaNumeric(this string value)
		{
			if (value == null) return null;

			return _alphaNumeric.Replace(value, string.Empty);
		}

		/// <summary>
		/// Removes extra spaces from the string.
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		/// <example>
		/// "This  has  extra   spaces" becomes "This has extra spaces"
		/// </example>
		public static string RemoveExtraSpaces(this string value)
		{
			if (value == null) return null;

			var retVal = value.Trim();
			var len = 0;

			while (retVal.Length != len)
			{
				len = retVal.Length;
				retVal = retVal.Replace("  ", " ", StringComparison.Ordinal);
			}

			return retVal;
		}

		private static readonly TextInfo _usEnglish = new CultureInfo("en-US", false).TextInfo;
		private static readonly Dictionary<string, string> _titleCaseExceptions = new Dictionary<string, string>()
		{
			{ "Po ", "PO " },
			{ "Us ", "US " },
			{ "2Nd ", "2nd " },
			{ "Th ", "th " },
			{ "3Rd ", "3rd " },
			{ "1St ", "1st " },
			{ "Bcbsaz", "BCBSAZ" },
			{ "(Phs)", "(PHS)" },
			{ "(Lghp)", "(LGHP)" },
			{ "(Cobra)", "(COBRA)" },
			{ "(Pos)", "(POS)" },
			{ "(Tefra)", "(TEFRA)" },
			{ "(Hmo)", "(HMO)" },
			{ "(Ppo)", "(PPO)" }
		};

		/// <summary>
		/// Converts a string to Title Case (using U.S. English rules)
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static string ToTitleCase(this string value)
		{
			if (string.IsNullOrWhiteSpace(value)) return value;

			// NOTE: ToTitleCase does not convert strings that are all uppercase, so we must lowercase the value first.
			var retVal = _usEnglish.ToTitleCase(_usEnglish.ToLower(value));

			foreach (var exception in _titleCaseExceptions)
			{
				retVal = retVal.Replace(exception.Key, exception.Value, StringComparison.OrdinalIgnoreCase);
			}

			return retVal;
		}

		/// <summary>
		/// Converts a null or whitespace only string to "N/A" otherwise returns the string.
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static string NaIfNullOrWhitespace(this string value)
		{
			return string.IsNullOrWhiteSpace(value) ? "N/A" : value;
		}

		public static string ToStringNaIfNull<T>(this T? value, string format) where T : struct
		{
			return value.HasValue ? string.Format(G.IC, format, value.Value) : "N/A";
		}

		public static bool EqualsNullable(this string source, string target, StringComparison stringComparison)
		{
			if (string.IsNullOrWhiteSpace(source)) return string.IsNullOrWhiteSpace(target);
			return source.Equals(target, stringComparison);
		}
	}
}
