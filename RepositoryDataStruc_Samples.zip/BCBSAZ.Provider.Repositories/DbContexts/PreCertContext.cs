﻿using BCBSAZ.Provider.Models.Data.PreCert;
using Microsoft.EntityFrameworkCore;
using Medical = BCBSAZ.Provider.Models.Data.PreCert.Medical;
using Pharmacy = BCBSAZ.Provider.Models.Data.PreCert.Pharmacy;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IPreCertContext : IDbContext
	{

		#region Medical

		DbSet<Medical.MedicalPreCert> MedicalPreCerts { get; set; }

		DbSet<Medical.Status> MedicalStatuses { get; set; }

		DbSet<Medical.Form> MedicalForms { get; set; }

		DbSet<Medical.CPTCode> MedicalCPTCodes { get; set; }

		DbSet<Medical.DiagnosisCode> MedicalDiagnosisCodes { get; set; }

		DbSet<Medical.Attachment> MedicalAttachments { get; set; }

		DbSet<Medical.Comments> MedicalComments { get; set; }

		DbSet<Medical.Summary> MedicalSummaries { get; set; }

		#endregion

		#region Pharmacy

		DbSet<Pharmacy.PharmacyPreCert> PharmacyPreCerts { get; set; }

		DbSet<Pharmacy.Status> PharmacyStatuses { get; set; }

		DbSet<Pharmacy.Form> PharmacyForms { get; set; }

		DbSet<Pharmacy.Attachment> PharmacyAttachments { get; set; }

		DbSet<Pharmacy.Comments> PharmacyComments { get; set; }

		DbSet<Pharmacy.Summary> PharmacySummaries { get; set; }

		#endregion

		DbSet<UploadedFile> UploadedFiles { get; set; }

		DbSet<User> Users { get; set; }
	}

	public class PreCertContext : DbContext, IPreCertContext
	{
		/// <summary>
		/// Creates a new instance of the PreCert DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public PreCertContext(DbContextOptions<PreCertContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the PreCert database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<User>().HasNoKey();
			modelBuilder.Entity<Medical.Summary>().HasNoKey();
			modelBuilder.Entity<Pharmacy.Summary>().HasNoKey();

			/******************** Property Configs ********************/
		}

		#region Medical

		public DbSet<Medical.MedicalPreCert> MedicalPreCerts { get; set; }

		public DbSet<Medical.Status> MedicalStatuses { get; set; }

		public DbSet<Medical.Form> MedicalForms { get; set; }
		 			 
		public DbSet<Medical.CPTCode> MedicalCPTCodes { get; set; }
		 			 
		public DbSet<Medical.DiagnosisCode> MedicalDiagnosisCodes { get; set; }
		 			 
		public DbSet<Medical.Attachment> MedicalAttachments { get; set; }

		public DbSet<Medical.Comments> MedicalComments { get; set; }

		public DbSet<Medical.Summary> MedicalSummaries { get; set; }

		#endregion

		#region Pharmacy

		public DbSet<Pharmacy.PharmacyPreCert> PharmacyPreCerts { get; set; }

		public DbSet<Pharmacy.Status> PharmacyStatuses { get; set; }

		public DbSet<Pharmacy.Form> PharmacyForms { get; set; }

		public DbSet<Pharmacy.Attachment> PharmacyAttachments { get; set; }

		public DbSet<Pharmacy.Comments> PharmacyComments { get; set; }

		public DbSet<Pharmacy.Summary> PharmacySummaries { get; set; }

		#endregion

		public DbSet<UploadedFile> UploadedFiles { get; set; }

		public DbSet<User> Users { get; set; }
	}
}
