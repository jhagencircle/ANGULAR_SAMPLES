export class User {
  constructor(init?: Partial<User>) {
    Object.assign(this, init);
  }
  name?: string;
  accountId: string;
  isAuthenthicated: boolean;
}
