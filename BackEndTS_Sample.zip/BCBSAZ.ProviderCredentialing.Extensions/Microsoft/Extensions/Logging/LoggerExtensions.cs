﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Extensions.Logging
{
	public static class LoggerExtensions
	{
		/// <summary>
		/// Formats and writes an error log message.
		/// </summary>
		/// <param name="logger">The Microsoft.Extensions.Logging.ILogger to write to.</param>
		/// <param name="exception">The exception to log.</param>
		/// <param name="message">Format string of the log message in message template format. Example: "User {User} logged in from {Address}"</param>
		/// <param name="args">An object array that contains zero or more objects to format.</param>
		public static void LogError(this ILogger logger, Exception exception, HttpContext httpContext, string message, params object[] args) =>
			logger.LogError(new ExceptionWrapper(exception, httpContext), message, args);

		/// <summary>
		/// Formats and writes an error log message.
		/// </summary>
		/// <param name="logger">The Microsoft.Extensions.Logging.ILogger to write to.</param>
		/// <param name="eventId">The event id associated with the log.</param>
		/// <param name="exception">The exception to log.</param>
		/// <param name="message">Format string of the log message in message template format. Example: "User {User} logged in from {Address}"</param>
		/// <param name="args">An object array that contains zero or more objects to format.</param>
		public static void LogError(this ILogger logger, EventId eventId, Exception exception, HttpContext httpContext, string message, params object[] args) =>
			logger.LogError(eventId, new ExceptionWrapper(exception, httpContext), message, args);
	}
}
