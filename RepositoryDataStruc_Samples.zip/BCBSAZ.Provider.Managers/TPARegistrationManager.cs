﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Processors;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.TPA;
using BCBSAZ.Provider.Models.Responses.Common;
using BCBSAZ.Provider.Models.Responses.TPA;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Managers
{
	public class TPARegistrationManager : ITPARegistrationManager
	{
		private readonly ITPARegistrationRepository _tpaRegistrationRepository;
		private readonly ISecurityManager _securityManager;
		private readonly IEmailProcessor _emailProcessor;
		private readonly string _registrationFromAddress;

		public TPARegistrationManager(ITPARegistrationRepository tpaRegistrationRepository, ISecurityManager manager, IEmailProcessor emailProcessor, IConfiguration configuration)
		{
			_tpaRegistrationRepository = tpaRegistrationRepository;
			_securityManager = manager;
			_emailProcessor = emailProcessor;
			_registrationFromAddress = configuration.GetValue<string>("TpaRegistration_FromAddress");
		}

		public async Task<VoidResponse> AddTPARegistrationAsync(TPARegistrationRequest request)
		{
			var password = request.TpaRegistration.Password;

			if (password == password.ToLowerInvariant()) password += " (all lowercase)";

			request.TpaRegistration.Password = _securityManager.HashPassword(request.TpaRegistration.LoginId, request.TpaRegistration.Password);
			request.TpaRegistration.SecurityQuestionAnswer = _securityManager.HashString(request.TpaRegistration.SecurityQuestionAnswer.ToLower());

			await _tpaRegistrationRepository.AddTpaRegistrationAsync(request.TpaRegistration);
			await _emailProcessor.SendTpaRegistrationAsync(_registrationFromAddress, request.TpaRegistration.Email, request.TpaRegistration.LoginId, password);

			return new VoidResponse();
		}
	}
}
