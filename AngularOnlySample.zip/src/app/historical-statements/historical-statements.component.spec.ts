import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HistoricalStatementsComponent } from './historical-statements.component';
import { HistoricalStatementMock } from '../shared/mocks/historical-statement.mock';
import { StatementService } from './shared/statement.service';
import { NgbdSortableHeader } from '../shared/directives/sortable.directive';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppConstants } from '../shared/constants/app-constants';

describe('HistoricalStatementsComponent', () => {
  let component: HistoricalStatementsComponent;
  let fixture: ComponentFixture<HistoricalStatementsComponent>;
  //const viewChildrenHeader = jasmine.createSpyObj('NgbdSortableHeader',['rotate']);
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgbModule],
      declarations: [HistoricalStatementsComponent, NgbdSortableHeader],
      providers: [
        { provide: StatementService, useClass: HistoricalStatementMock },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoricalStatementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should make a call to statementService.get()', () => {
    spyOn(component.statementService, 'get').and.callThrough();

    component.statementService.get('01');

    expect(component.statementService.get).toHaveBeenCalledWith('01');
  });

  it('should have "statements" populated ', () => {
    expect(component.statements.length).toBeGreaterThan(0);
  });

  it(`should have the title ${AppConstants.HISTORICAL_STATEMENTS_TITLE}`, () => {
    expect(component.title).toEqual(AppConstants.HISTORICAL_STATEMENTS_TITLE);
  });

  it(`should have the informational message ${AppConstants.HISTORICAL_STATEMENTS_INFO_MESSAGE}`, () => {
    expect(component.informationalMessage).toEqual(
      AppConstants.HISTORICAL_STATEMENTS_INFO_MESSAGE
    );
  });
});
