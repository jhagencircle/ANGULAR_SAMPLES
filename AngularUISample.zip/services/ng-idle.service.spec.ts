import { NgZone } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { NgIdleService } from './ng-idle.service';

describe('NgIdleService', () => {
  let service: NgIdleService;
  let fakeNgZone: NgZone;
  beforeEach(() => {
    TestBed.configureTestingModule({
    });
    service = TestBed.inject(NgIdleService);
    fakeNgZone = TestBed.inject(NgZone);
  });
});
