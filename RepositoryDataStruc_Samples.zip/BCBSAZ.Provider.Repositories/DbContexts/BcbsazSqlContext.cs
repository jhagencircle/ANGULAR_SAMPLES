﻿using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IBcbsazSqlContext : IDbContext
	{
		DbSet<SuppressIDCard> CanViewIDCard { get; }
	}

	public class BcbsazSqlContext : DbContext, IBcbsazSqlContext
	{
		public BcbsazSqlContext(DbContextOptions<BcbsazSqlContext> options) : base(options) { }


		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<SuppressIDCard>().HasNoKey();
		}

		public DbSet<SuppressIDCard> CanViewIDCard { get; protected set; }
	}
}
