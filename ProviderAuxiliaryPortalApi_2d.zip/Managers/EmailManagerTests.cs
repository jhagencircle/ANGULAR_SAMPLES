using BCBSAZ.ProviderAuxiliaryPortal.Managers;
using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using FluentAssertions;
using NSubstitute;
using Xunit;

namespace BCBSAZ.ProviderAuxiliaryPortal.UnitTests.Managers
{
    public class EmailManagerTests
    {
        private readonly IEmailRepository _emailRepository;
        private readonly IEmailManager _emailManager;

        public EmailManagerTests()
        {
            _emailRepository = Substitute.For<IEmailRepository>();
            _emailManager = new EmailManager(_emailRepository);
        }

        [Theory]
        [InlineData("test@test.com", "test@test.com", "subject", "body")]
        [InlineData("test@test.com", "test@test.com", "subject", "")]
        [InlineData("test@test.com", "test@test.com", "", "body")]
        public async void SendInternalEmail_Success(string toAddress, string fromAddress, string subject, string body)
        {
            //Arrange
            _emailRepository.SendInternalEmailAsync(toAddress, fromAddress, subject, body, null).Returns(true);

            // Act
            var result = await _emailManager.SendInternalMessageAsync(toAddress, fromAddress, subject, body, null);

            // Assert
            result.Should().Be(true);
        }

        [Theory]
        [InlineData("test@test.com", "test@test.com", "subject", "body")]
        [InlineData("test@test.com", "test@test.com", "subject", "")]
        [InlineData("test@test.com", "test@test.com", "", "body")]
        public async void SendExternalEmail_Success(string toAddress, string fromAddress, string subject, string body)
        {
            //Arrange
            _emailRepository.SendExternalEmailAsync(toAddress, fromAddress, subject, body).Returns(true);

            // Act
            var result = await _emailManager.SendExternalMessageAsync(toAddress, fromAddress, subject, body);

            // Assert
            result.Should().Be(true);
        }
    }
}
