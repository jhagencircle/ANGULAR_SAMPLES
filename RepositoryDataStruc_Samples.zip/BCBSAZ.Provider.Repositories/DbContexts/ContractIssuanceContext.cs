﻿using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IContractIssuanceContext : IDbContext
	{
		DbSet<BenefitBooksDoc> BenefitBookDoc { get; }
	}

	public class ContractIssuanceContext : DbContext, IContractIssuanceContext
	{
		/// <summary>
		/// Creates a new instance of the ContractIssuance DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public ContractIssuanceContext(DbContextOptions<ContractIssuanceContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<BenefitBooksDoc>().HasNoKey();
		}

		public DbSet<BenefitBooksDoc> BenefitBookDoc { get; protected set; }

	}
}
