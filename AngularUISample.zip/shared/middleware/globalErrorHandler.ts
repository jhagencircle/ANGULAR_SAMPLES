import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { LoggerService } from "src/app/services/logger.service";

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
    // Error handling is important and needs to be loaded first.
    // Because of this we should manually inject the services with Injector.
    constructor(private injector: Injector) { }
    handleError(error: Error | HttpErrorResponse) {
        const logger = this.injector.get(LoggerService);
        let message: string;
        let stackTrace: any;
        let isFromLoggerApi: boolean = false;

        if (error instanceof HttpErrorResponse) {
            const httpError = error as HttpErrorResponse;
            message = error.message;
            stackTrace = {
                status: httpError.status,
                statusText: httpError.statusText,
                url: httpError.url,
                ok: httpError.ok,
                message: httpError.message,
                location: window.location.href
            };

            isFromLoggerApi = httpError.message.includes("/api/logging");
        } else {
            message = error.message ? error.message : error.toString();
            stackTrace = {
                stackTrace: error.stack,
                location: window.location.href
            }
        }

        if (!isFromLoggerApi) {
            logger.logError(message, 'GlobalErrorHandler', stackTrace);
        }
    }
}