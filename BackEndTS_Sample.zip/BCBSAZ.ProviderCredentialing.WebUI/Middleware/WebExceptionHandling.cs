﻿using BCBSAZ.ProviderCredentialing.WebUI.Models;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Responses.Common;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebUI
{
	/// <summary>
	/// Middleware class designed to provide Global Exception Handling
	/// </summary>
	internal class WebExceptionHandling
	{
		/// <summary>
		/// Creates a list of custom responses based on Exception type thrown.
		/// </summary>
		// Add your custom exceptions, status codes and messages here (leave message blank to use default)
		private static readonly List<ExceptionResponse> _responses = new List<ExceptionResponse>()
		{
			new ExceptionResponse(typeof(Exception), HttpStatusCode.InternalServerError),
			new ExceptionResponse(typeof(UnauthorizedAccessException), HttpStatusCode.Forbidden)
		};

		/// <summary>
		/// Creates a list of default error messages based on Http Status Code.
		/// </summary>
		// These are the default messages based on HttpStatusCode, in DEBUG, the actual exception message will be used instead
		private static readonly Dictionary<HttpStatusCode, string> _defaultMessages = new Dictionary<HttpStatusCode, string>()
		{
			{ HttpStatusCode.InternalServerError, "Internal Server Error"},
			{ HttpStatusCode.Forbidden, "Request is not Authorized"},
			{ HttpStatusCode.Unauthorized, "Request is not Authorized"},
			{ HttpStatusCode.BadRequest, "Invalid Request"}
		};

		private readonly RequestDelegate _next;
		private readonly IHostEnvironment _hostEnvironment;
		private readonly IConfiguration _configuration;
		private readonly ILogger _logger;

		public WebExceptionHandling(RequestDelegate next, IHostEnvironment hostEnvironment, IConfiguration configuration, ILogger<WebExceptionHandling> logger)
		{
			_next = next;
			_hostEnvironment = hostEnvironment;
			_configuration = configuration;
			_logger = logger;
		}

		/// <summary>
		/// Called by the MVC Pipeline during a request
		/// </summary>
		/// <param name="context">The http context of the current request</param>
		public async Task Invoke(HttpContext context)
		{
			try
			{
				await _next(context);
			}
			catch (Exception ex)
			{
				await HandleExceptionAsync(context, ex);
			}
		}

		/// <summary>
		/// Handles the exception caught by the global exception handling.
		/// </summary>
		/// <param name="context">The http context of the current request</param>
		/// <param name="exception">The exception which was thrown</param>
		private async Task HandleExceptionAsync(HttpContext context, Exception exception)
		{
			var response = GetExceptionResponse(context, exception);

			context.Response.StatusCode = (int)response.Code;
			if (context.Request.Path.ToUriComponent().Contains("/api/", StringComparison.OrdinalIgnoreCase))
			{
				context.Response.ContentType = "application/json";
				await context.Response.WriteAsync(JsonConvert.SerializeObject(response));
			}
			else
			{
				context.Response.ContentType = "text/html";
				await context.Response.WriteAsync(GenerateHtmlResponse(response));
			}
		}

		private string GenerateHtmlResponse(ExceptionResponse response)
		{
			var retVal = new StringBuilder();

			retVal.AppendLine("<div class=\"error-response\">");

			retVal.AppendFormat("<div class=\"error-code\">{0} - {1}</div>{2}", (int)response.Code, response.Code, Environment.NewLine);
			retVal.AppendFormat("<div class=\"error-message\">{1}{0}{1}</div>{1}", response.Message.Replace(Environment.NewLine, "<br />"), Environment.NewLine);

			retVal.AppendLine("</div>");

			return retVal.ToString();
		}

		/// <summary>
		/// Gets a response using the defined responses by Exception type.
		/// </summary>
		/// <param name="exception">The exception which was thrown</param>
		/// <returns>Returns an Exception Response object appropriate for the thrown exception</returns>
		private ExceptionResponse GetExceptionResponse(HttpContext context, Exception exception)
		{
			ExceptionResponse retVal;

			if (exception is InvalidApiResponseException apiException)
			{
				if (apiException.ContentType.MediaType == MediaTypeNames.Application.Json)
				{
					try
					{
						retVal = JsonConvert.DeserializeObject<ExceptionResponse>(apiException.Content);
						retVal.ExceptionType = typeof(InvalidApiResponseException);
					}
					catch (Exception)
					{
						retVal = GetDefaultResponse(apiException);
					}
				}
				else
				{
					retVal = GetDefaultResponse(apiException);
				}
			}
			else
			{
				retVal = (
					from r in _responses
					where r.ExceptionType == exception.GetType()
					select new ExceptionResponse(r)).FirstOrDefault() ?? new ExceptionResponse(_responses[0]);

				if (string.IsNullOrWhiteSpace(retVal.Message))
					SetDefaultMessage(retVal, exception);
			}

			_logger.LogError(-1, exception, context, retVal.Message);

			return retVal;

			static ExceptionResponse GetDefaultResponse(InvalidApiResponseException ex)
			{
				return new ExceptionResponse(typeof(InvalidApiResponseException), ex.StatusCode, ex.Content);
			}

		}

		/// <summary>
		/// Gets the default message for the Exception Response (in 'Debug' mode this will be the exception details)
		/// </summary>
		/// <param name="response">The Exception Response object which has been created based on the type of exception thrown</param>
		/// <param name="exception">The exception which was thrown</param>
		private void SetDefaultMessage(ExceptionResponse response, Exception exception)
		{
			if (_hostEnvironment.IsDevelopment(_configuration))
			{
				string message;

				if (response.ExceptionType == typeof(InvalidApiResponseException))
				{
					message = response.Message;
				}
				else
				{
					var msg = new StringBuilder();

					msg.AppendLine(_defaultMessages.ContainsKey(response.Code) ? _defaultMessages[response.Code] : _defaultMessages[HttpStatusCode.InternalServerError]);
					msg.AppendLine();

					msg.AppendLine("Exception:");

					var indent = "\t";
					var ex = exception;
					while (ex != null)
					{
						msg.AppendFormat("{0}{1}: {2}{3}", indent, ex.GetType().FullName, ex.Message, Environment.NewLine);
						ex = ex.InnerException;
						indent += "\t";
					}
					msg.AppendLine();
					msg.AppendLine(exception.StackTrace);

					message = msg.ToString();
				}

#if DEBUG
				System.Diagnostics.Debug.WriteLine(string.Empty);
				System.Diagnostics.Debug.WriteLine(message);
				System.Diagnostics.Debug.WriteLine(string.Empty);
#endif

				if (string.IsNullOrWhiteSpace(response.Message))
					response.Message = message;
			}
			else
			{
				if (string.IsNullOrWhiteSpace(response.Message))
					response.Message = _defaultMessages.ContainsKey(response.Code) ? _defaultMessages[response.Code] : _defaultMessages[HttpStatusCode.InternalServerError];
			}
		}
	}
}
