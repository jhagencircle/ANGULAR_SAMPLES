import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  constructor(private http: HttpClient) {}

  getTime(): Observable<Date> {
      return this.http.get<Date>(`${environment.apiBaseUrl}/v1/common/time`);
  }
}
