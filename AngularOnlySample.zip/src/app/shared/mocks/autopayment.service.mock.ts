import { Observable, of } from 'rxjs';
import { IAutoPayment } from 'src/app/autopay/shared/autopayment.model';

export class AutopaymentServiceMock {
  constructor() {}
  public static mockedAutopayments: any = [
    {
      draftDate: '2021-08-01T07:00:00Z',
      accountId: '000312',
      accountName: 'New Horizon Sales Inc',
      bankName: 'New Bank',
      paymentStatus: '',
    },
  ];

  get(): Observable<any> {
    return of(AutopaymentServiceMock.mockedAutopayments);
  }

  enroll(autopayment: IAutoPayment): Observable<any> {
    return of(true);
  }

  cancel(accountId: string): Observable<any> {
    return of(true);
  }
}
