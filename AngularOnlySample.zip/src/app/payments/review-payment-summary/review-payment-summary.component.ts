import { Component, Input, OnInit } from '@angular/core';
import { PaymentsService } from '../shared/payments.service';

@Component({
  selector: 'app-review-payment-summary',
  templateUrl: './review-payment-summary.component.html',
  styleUrls: ['./review-payment-summary.component.scss'],
})
export class ReviewPaymentSummaryComponent implements OnInit {
  @Input() data: any;

  constructor(private paymentsService: PaymentsService) {}

  ngOnInit(): void {}

  getTotal(amount: string): string {
    if (!isNaN(Number(amount))) {
      return this.paymentsService.parseCurrency(parseFloat(amount));
    } else {
      return amount;
    }
  }

  isDate(val: string) {
    var d = new Date(val);
    return !isNaN(d.valueOf());
  }
}
