﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Security;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories
{
	public class SecurityRepository : ISecurityRepository
	{
		private readonly IProviderInetContext _providerContext;

		public SecurityRepository(IProviderInetContext providerContext) =>
			_providerContext = providerContext;

		public WebUser GetUserAsync(string userId) =>
			_providerContext.ApiUsers.FromSqlRaw(DB.ProviderInet.StoredProcs.GetUser, userId).AsEnumerable().FirstOrDefault();

		public Role[] GetUserRolesAsync(string userId) =>
			_providerContext.Roles.FromSqlRaw(DB.ProviderInet.StoredProcs.GetUserRoles, userId).AsEnumerable().ToArray();

		public PortalUser SavePortalUserInfoAsync(PortalUser user)
		{
			return _providerContext.PrecertUsers.FromSqlRaw(
				DB.ProviderInet.StoredProcs.SaveUserInfo,
				user.UserId,
				user.LastName,
				user.FirstName,
				user.EmailAddress,
				user.Isinternal,
				user.NPI
			).AsEnumerable().FirstOrDefault();
		}
	}
}
