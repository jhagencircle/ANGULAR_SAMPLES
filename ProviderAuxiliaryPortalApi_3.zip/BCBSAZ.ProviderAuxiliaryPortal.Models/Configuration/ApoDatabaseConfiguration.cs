﻿namespace BCBSAZ.ProviderAuxiliaryPortal.Models.Configuration
{
    public class ApoDatabaseConfiguration
    {
        public string ConnectionString { get; set; }
        public string Environment { get; set; }
        public string[] InqueryDdNameList { get; set; }
    }
}
