﻿using BCBSAZ.ProviderAuxiliaryPortal.Extensions;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Configuration;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.ApiClient;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories.ApiClients
{
    public class EmailClient : IEmailClient
    {
        private readonly EmailConfiguration _emailConfiguration;

        public EmailClient(EmailConfiguration emailConfiguration)
        {
            _emailConfiguration = emailConfiguration;
        }

        public async Task<bool> SendEmailAsync(string toAddress, string fromAddress, string subject, string body, IEnumerable<Attachment> attachments = null, string cc = null, string bcc = null)
        {
            using (var client = new SmtpClient(_emailConfiguration.SmtpHost, _emailConfiguration.SmtpPort) { DeliveryMethod = SmtpDeliveryMethod.Network })
            {
                if (_emailConfiguration.UseCredential)
                {
                    var basicCredential = new NetworkCredential(_emailConfiguration.Username, _emailConfiguration.Password);
                    client.UseDefaultCredentials = false;
                    client.Credentials = basicCredential;
                    client.EnableSsl = true;
                }

                var mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(fromAddress);
                mailMessage.To.Add(new MailAddress(toAddress));
                mailMessage.Subject = subject;
                mailMessage.Body = body;

                if (cc != null)
                    mailMessage.CC.Add(new MailAddress(cc));

                if (bcc != null)
                    mailMessage.Bcc.Add(new MailAddress(bcc));

                foreach (var attachment in attachments.EmptyIfNull())
                {
                    mailMessage.Attachments.Add(attachment);
                }

                // Smtp mail server would not work locally
#if !DEBUG
                await client.SendMailAsync(mailMessage);            
#endif
                return true;
            }
        }
    }
}
