import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { Subscription } from 'rxjs';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { PaymentStatusEnum } from 'src/app/shared/enums/payment-status-enum';
import { ISummary } from 'src/app/shared/models/summary.model';
import { AccountService } from 'src/app/shared/services/account.service';
import { PaymentsService } from '../shared/payments.service';
import { IScheduledPayment } from '../shared/scheduled-payment.model';
import { ModalSize } from 'src/app/shared/enums/modal-size-enum';
import { ConfirmationDialogService } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.service';
import { DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { SpinnerService } from 'src/app/shared/components/spinner/spinner.service';
import {
  NgbdSortableHeader,
  SortEvent,
} from 'src/app/shared/directives/sortable.directive';
import { NotificationService } from 'src/app/shared/components/notification/notification.service';
import { NotificationType } from 'src/app/shared/enums/notification-type-enum';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

const compare = (
  v1: string | number | Date | boolean | any,
  v2: string | number | Date | boolean | any
) => (v1! < v2! ? -1 : v1! > v2! ? 1 : 0);

@Component({
  selector: 'app-scheduled-payment-list',
  templateUrl: './scheduled-payment-list.component.html',
  styleUrls: ['./scheduled-payment-list.component.scss'],
})
export class ScheduledPaymentListComponent implements OnInit {
  scheduledPayments: IScheduledPayment[] = [];
  paymentStatusEnum = PaymentStatusEnum;
  account: ISummary;
  subscriptions: Subscription[] = [];
  sortColumnsIco: any = {
    paymentTransactionDate: 'sort',
    accountName: 'sort',
  };
  showAlertSuccess: boolean = false;

  private _notificationServiceSubject$: Subject<void>;

  @ViewChildren(NgbdSortableHeader) headers: QueryList<NgbdSortableHeader>;

  constructor(
    public accountService: AccountService,
    public paymentsService: PaymentsService,
    private confirmationDialogService: ConfirmationDialogService,
    public spinnerService: SpinnerService,
    public notificationService: NotificationService
  ) {
    this._notificationServiceSubject$ = new Subject<void>();
  }

  ngOnInit(): void {
    this.notificationService
      .onNotificationVisibilityChange()
      .pipe(takeUntil(this._notificationServiceSubject$))
      .subscribe((visible: boolean) => {
        this.showAlertSuccess = visible;
      });
    this.loadScheduledPayments();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  loadScheduledPayments() {
    this.scheduledPayments = [];
    let subscription = this.accountService
      .get()
      .subscribe((account: ISummary) => {
        if (account) {
          this.account = account;
          this.paymentsService
            .getScheduledPayments(account.accountId)
            .subscribe((scheduledPayments) => {
              this.scheduledPayments = scheduledPayments;
            });
        }
      });
    this.subscriptions.push(subscription);
  }

  public openConfirmationDialog(payment: IScheduledPayment) {
    let modalHeader: string = AppConstants.CANCEL_SCHEDULED_PAYMENT_ALERT_TITLE;
    let modalbody: string =
      AppConstants.CANCEL_SCHEDULED_PAYMENT_ALERT_TEXT.replace(
        '${paymentAmount}',
        this.paymentsService.parseCurrency(payment.paymentAmount)
      )
        .replace('${bankAccountNickName}', payment.bankAccountNickname)
        .replace(
          '${TransactionDate}',
          new DatePipe('en-US').transform(
            new Date(payment.paymentTransactionDate),
            'MMM, dd'
          ) ?? new Date(payment.paymentTransactionDate).toString()
        );
    let btnOkText: string = AppConstants.CANCEL_SCHEDULED_PAYMENT_BUTTON_OK;
    let btnCancelText: string = AppConstants.CANCEL_SCHEDULED_PAYMENT_BUTTON_NO;
    let modalSize: string = ModalSize.MEDIUM;
    this.confirmationDialogService
      .confirm(modalHeader, modalbody, btnOkText, btnCancelText, modalSize)
      .then((confirmed) => {
        if (confirmed) {
          this.deleteScheduledPayment(payment);
        }
      });
  }

  deleteScheduledPayment(payment: IScheduledPayment) {
    this.spinnerService.show(true);
    this.paymentsService
      .deleteScheduledPayment(
        this.account.accountId,
        payment.transactionId.toString()
      )
      .subscribe(
        () => {
          this.loadScheduledPayments();
          this.notificationService.configNotification(
            AppConstants.CANCEL_SCHEDULED_PAYMENT_BUTTON_NOTIFICATION_SUCCESS,
            NotificationType.Success,
            true
          );
          this.spinnerService.show(false);
        },
        (error: HttpErrorResponse) => {
          this.notificationService.configNotification(
            AppConstants.CANCEL_SCHEDULED_PAYMENT_BUTTON_NOTIFICATION_FAILED,
            NotificationType.Error,
            true
          );
          this.spinnerService.show(false);
        }
      );
  }

  onSort({ column, direction }: SortEvent) {
    this.sortColumnsIco[column] = this.setDirectionIco(direction, column);
    // resetting other headers
    if (this.headers) {
      this.headers.forEach((header) => {
        if (header.sortable !== column) {
          header.direction = '';
        }
      });
    }
    // sorting statements
    if (direction === '' || column === '') {
      this.scheduledPayments;
    } else {
      this.scheduledPayments = [...this.scheduledPayments].sort(
        (a: any, b: any) => {
          const res = compare(a[column], b[column]);
          return direction === 'asc' ? res : -res;
        }
      );
    }
  }
  setDirectionIco(direction: string, column: string): string {
    if (direction !== '') {
      return 'sort-' + direction;
    } else {
      return 'sort';
    }
  }
}
