export enum HealthPlanTypeEnum {
  Medical = 'medical',
  Dental = 'dental',
  Life = 'life',
}
