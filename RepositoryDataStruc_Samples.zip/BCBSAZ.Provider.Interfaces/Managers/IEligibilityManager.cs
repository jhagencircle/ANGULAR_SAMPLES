﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;
using BCBSAZ.Provider.Models.Requests.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Responses.Common;
using BCBSAZ.Provider.Models.Responses.Eligibility.Details;
using BCBSAZ.Provider.Models.Responses.Eligibility.Inquiries;
using InquiryResult = BCBSAZ.Provider.Models.Xml271Processor.InquiryResult;
using Microsoft.AspNetCore.Http;
using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IEligibilityManager
	{
		Task<InquiryInfoResponse> GetInquiryAsync(InquiryInfoRequest request);

		Task<PatientDetailResponse> GetPatientDetailAsync(PatientDetailRequest request);

		Task<InsuranceInfoResponse> GetInsuranceInfoAsync(InsuranceInfoRequest request);

		Task<EligibilitySummaryResponse> GetEligibilitySummaryAsync(EligibilitySummaryRequest request);

		Task<COBResponse> GetCOBsAsync(COBRequest request);

		Task<DeductiblesResponse> GetDeductiblesAsync(DeductiblesRequest request);

		Task<ServiceTypeResponse> GetServiceTypeBenefitsAsync(ServiceTypeRequest request);

		Task<BooksRidersResponse> GetBooksAndRidersAsync(BooksRidersRequest request);

		Task<GeneralInformationResponse> GetGeneralInformationAsync(GeneralInformationRequest request);

		Task<ConvertEdiResponse> ProcessAndSaveEdiRequestAsync(ConvertEdiRequest request, WebUser user);

		Task<SubmitInquiriesTestResponse> SubmitInquiriesTestAsync(SubmitInquiriesRequest request, WebUser user);

		Task<SubmitInquiriesResponse> SubmitInquiriesAsync(SubmitInquiriesRequest request, WebUser user);

		Task<EligibilityResultsResponse> GetEligibilityResultsAsync(EligibilityResultsRequest request);

		Task<DisclaimerResponse> GetDisclaimer(DisclaimerRequest request);

		IsValidGroupNumberResponse IsValidGroupNumber(string groupNum);

		Select2Response GetDiagnosisCodes(Select2Request request);

		CanViewIDCardResponse CanViewIDCard(CanViewIDCardRequest request);

		Task<string> ConvertEdiToXml(string content);

		Task<InquiryResult> ConvertEdiOrXmlToJson(string content);

		Task<SaveInquiriesResponse> SaveInquiriesAsync(SaveInquiriesRequest request);

		Task DeleteInquiriesAsync(IEnumerable<long> requestIds);

		Task<InquiryRequest> GetInquiryRequestAsync(long requestId);

		Task<EligibilityResultListResponse> GetEligibilityResultsListAsync(int[] requestIds);

	}
}
