import { Injectable } from '@angular/core';
import { OktaAuthService } from '@okta/okta-angular';
import { AuthService } from 'src/app/core/auth/auth.service';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  user: User = new User();

  constructor(
    public authService: AuthService,
    public oktaAuth: OktaAuthService
  ) {}

  async get(): Promise<User> {
    if (this.authService.isLogged) {
      const userClaims = await this.oktaAuth.getUser();
      this.user.accountId = userClaims.accounts;
      this.user.name = userClaims.name;
      this.user.isAuthenthicated = true;
    }
    return this.user;
  }
}
