export enum BillStatusEnum{
    Due = 'due',
    Processing = 'processing',
    Paid = 'paid',
    Overdue = 'overdue'
}