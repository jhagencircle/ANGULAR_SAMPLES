import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthServiceMock {
  constructor() {}
  public static authenticatedMock: boolean = true;

  get isLogged(): boolean {
    return AuthServiceMock.authenticatedMock;
  }
  public isAuthenticated(): Observable<boolean> {
    return of(AuthServiceMock.authenticatedMock);
  }

  logOut(): Observable<boolean> {
    return of(true);
  }
}
