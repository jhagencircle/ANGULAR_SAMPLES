﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace Microsoft.Extensions.Logging
{
	public class LogMessage
	{
		public int ParentException { get; set; }
		public bool IsHandled { get; set; }
		public string UserId { get; set; }
		public string SessionId { get; set; }
		public string Source { get; set; }
		public string Member { get; set; }

		[SuppressMessage("Design", "CA1056:Uri properties should not be strings", Justification = "Expected value is not a well formed Uri.")]
		public string Url { get; set; }

		[SuppressMessage("Design", "CA1056:Uri properties should not be strings", Justification = "Expected value is not a well formed Uri.")]
		public string RefererUrl { get; set; }

		public string HttpUserAgent { get; set; }
		public string Form { get; set; }
		public string QueryString { get; set; }

		[Required]
		[StringLength(1)]
		public string Message { get; set; }
		public string StackTrace { get; set; }
		public string AdditionalInfo { get; set; }
	}
}
