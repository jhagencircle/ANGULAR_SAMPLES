﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using BCBSAZ.ProviderCredentialing.Models.Data;
using Newtonsoft.Json;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	public class ProviderCredentialForm
	{
		#region Shared Properties
		public IEnumerable<Address> Addresses { get; set; }
		public IEnumerable<Name> Names { get; set; }
		public IEnumerable<EmailAddress> EmailAddresses { get; set; }
		#endregion

		#region CAQH Information
		public bool IsRegisteredWithCaqh { get; set; }

		public string CaqhProviderId { get; set; }

		public bool UploadedSupportedDocumentInCaqhApplication { get; set; }

		public bool ConfirmedMyCertificateInCurrent { get; set; }

		public bool AttestedToCaqhApplication { get; set; }

		public bool VerifiedMyCredentialingInformation { get; set; }

		public bool AuthorizedBcbsazAccessToCaqh { get; set; }


		public string ContactPhoneNumber { get; set; }

		public string ContactPhoneNumberExtension { get; set; }

		public bool IsPhonePreferredContact { get; set; }


		public bool IsEmailPreferredContact { get; set; }
		#endregion

		#region Provider Information
		public DateTime? DateOfBirth { get; set; }
		public string SocialSecurityNumber { get; set; }
		public string Gender { get; set; }
		public string Degree { get; set; }

		public string OtherDegree { get; set; }


		public string SupervisingPhysicianDegree { get; set; }

		public string SupervisingPhysicianOtherDegree { get; set; }

		public string IndividualNpi { get; set; }

		public DateTime? EffectiveDate { get; set; }

		public string TaxId { get; set; }

		public DateTime? DateStartedBillingWithTaxId { get; set; }

		public string License { get; set; }

		public DateTime? DateLicensedWithAz { get; set; }

		public bool HasDeaRegistrationNumber { get; set; }

		public DeaRegistration DeaRegistration { get; set; }

		public string PracticingSpecialty { get; set; }

		public string[] OtherPracticingSpecialties { get; set; }
		public bool IsAcceptingNewPatients { get; set; }
		public bool IsPcpUnderTaxId { get; set; }
		public bool IsMedicationAssistedTreatmentCertified { get; set; }
		public bool IsParticipatingMedicareAdvantageNetwork { get; set; }

		public bool IsIndianHealthProvider { get; set; }

		public bool IsBilingual { get; set; }

		public IEnumerable<Language> Languages { get; set; }

		#endregion

		#region Practice Information
		public IEnumerable<Facility> Facilities { get; set; }

		public string GroupsLegalName { get; set; }

		public string GroupsDoingBusinessAsName { get; set; }

		public string GroupNpi { get; set; }

		public DateTime? GroupEffectiveDate { get; set; }

		public DateTime? GroupDateLicensedInAz { get; set; }

		public bool HasConciergePractice { get; set; }

		public string BusinessCorrespondenceContactName { get; set; }

		public string BusinessCorrespondencePhoneNumber { get; set; }

		public string BusinessCorrespondenceFaxNumber { get; set; }

		public string WebsiteAddress { get; set; }
		#endregion

		#region Primary Office Information

		public IEnumerable<OfficeHour> OfficeHours { get; set; }

		#endregion



		#region Additional Office Information
		public bool HasAdditionalAddress { get; set; }

		#endregion
		public ICollection<OfficeHour> AdditionalOfficeHours { get; set; }

		public string AdditionalInformation { get; set; }

		#region Authorized Provider Signature
		public bool HasVerifiedInformation { get; set; }

		public string Signature { get; set; }

		public DateTime? DateTimeSigned { get; set; }
		#endregion

	}
}
