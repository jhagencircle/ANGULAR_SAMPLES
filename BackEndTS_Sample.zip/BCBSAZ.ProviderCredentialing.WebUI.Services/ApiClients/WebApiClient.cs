﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.ApiClients;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace BCBSAZ.ProviderCredentialing.WebUI.Services.ApiClients
{
	public class WebApiClient : HttpClient, IWebApiClient
	{
		public WebApiClient(IConfiguration configuration)
		{
			var serviceUrl = configuration.GetValue<string>(Constants.Configuration.WebApiUrl);

			if (string.IsNullOrWhiteSpace(serviceUrl))
				throw new ArgumentException("Invalid Service Url specified for Provider Web API.");

			BaseAddress = new Uri(serviceUrl.EnsureEndsWith('/'));

			DefaultRequestHeaders.Clear();
			DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
		}

		/// <summary>
		/// Sends the request provided to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestMessage">The request message for the Provider Web Api method</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		public async Task<TResult> SendRequestAsync<TResult>(HttpRequestMessage requestMessage) where TResult : class
		{
			var response = await SendAsync(requestMessage);

			// Shortcut, if the caller is requesting the HttpResponseMessage as the result, just return it
			// (consuming code is responsible for checking status code & response content)
			if (response is TResult)
				return response as TResult;

			var content = await response.Content.ReadAsStringAsync();

			if (response.IsSuccessStatusCode)
			{
				return JsonConvert.DeserializeObject<TResult>(content);
			}
			else
			{
				throw new InvalidApiResponseException(response.StatusCode, response.ReasonPhrase, response.Content.Headers.ContentType, content, "Provider API");
			}
		}

		/// <summary>
		/// Gets the content provided by the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		/// <exception cref="InvalidApiResponseException">If the response from the Web Api is not a Success status code (200) this exception will be thrown containing the details of the non-success response from the WebApi</exception>
		public Task<TResult> GetAsync<TResult>(string requestUri) where TResult : class => 
			SendRequestAsync<TResult>(new HttpRequestMessage(HttpMethod.Get, requestUri));

		/// <summary>
		/// Post the content provided by the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		/// <exception cref="InvalidApiResponseException">If the response from the Web Api is not a Success status code (200) this exception will be thrown containing the details of the non-success response from the WebApi</exception>
		public Task<TResult> PostAsync<TResult>(string requestUri, object body) where TResult : class
		{
			var requestMessage = new HttpRequestMessage(HttpMethod.Post, requestUri);

			if (body != null)
			{
				var jsonData = JsonConvert.SerializeObject(body);
				requestMessage.Content = new StringContent(jsonData, Encoding.UTF8, "application/json");
			}

			return SendRequestAsync<TResult>(requestMessage);
		}

		/// <summary>
		/// Submits a Delete Request to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		public Task<TResult> DeleteAsync<TResult>(string requestUri) where TResult : class => 
			SendRequestAsync<TResult>(new HttpRequestMessage(HttpMethod.Delete, requestUri));
	}
}
