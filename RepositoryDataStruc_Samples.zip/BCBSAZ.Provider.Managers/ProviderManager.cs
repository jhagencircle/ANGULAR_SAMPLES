﻿using System;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Managers.RequestValidators.Provider;
using BCBSAZ.Provider.Models.Requests.Provider;
using BCBSAZ.Provider.Models.Responses.Common;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers
{
	public class ProviderManager : IProviderManager
	{
		private readonly IProviderRepository _providerRepository;

		public ProviderManager(IProviderRepository providerRepository)
		{
			_providerRepository = providerRepository;
		}

		public TaxIdsForOrgResponse GetTaxIdsForOrg(TaxIdsForOrgRequest request)
		{
			request.Validate();

			return new TaxIdsForOrgResponse()
			{
				ProviderTaxIds = _providerRepository.GetTaxIdsForOrg(request.OrgId)
			};
		}

		public ProviderInfoResponse GetProviderInfoForCurrentUser(WebUser user)
		{
			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var provider = _providerRepository.GetProviderInfo(null, null, user.OrgId, user.UserId);

			return new ProviderInfoResponse()
			{
				Provider = provider ?? _providerRepository.GetProviderInfo(null, null, user.OrgId, null)
			};
		}

		public ProviderInfoResponse GetProviderInfo(string providerId, string taxId, WebUser user)
		{
			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var provider = _providerRepository.GetProviderInfo(providerId, taxId, user.OrgId, user.UserId);

			return new ProviderInfoResponse()
			{
				Provider = provider ?? _providerRepository.GetProviderInfo(providerId, taxId, user.OrgId, null)
			};
		}
	}
}
