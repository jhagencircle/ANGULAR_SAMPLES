import { SortDirection } from '../../shared/directives/sortable.directive';

export interface IPaymentState {
  page: number;
  pageSize: number;
  sortColumn: string;
  sortDirection: SortDirection;
}
