﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.Interfaces.Repositories
{
	public interface IEmailRepository
	{
		Task QueueEmailAsync(string toAddress, string fromAddress, string subject, string body);
	}
}
