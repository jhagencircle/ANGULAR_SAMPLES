import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OverlaySidePanelService } from 'src/app/shared/../shared/components/overlay-side-panel/overlay-side-panel.service';
import { EmployeeProfileComponent } from './employee-profile.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmployeeServiceMock } from '../../shared/mocks/employee.service.mock';
import { EmployeeService } from '../shared/employee.service';
import { of } from 'rxjs';
import { AccountService } from 'src/app/shared/services/account.service';
import { AccountMock } from '../../shared/mocks/account.mock';

describe('EmployeeProfileComponent', () => {
  let component: EmployeeProfileComponent;
  let fixture: ComponentFixture<EmployeeProfileComponent>;
  let overlaySidePanelServiceSpy: {
    close: jasmine.Spy;
    reportChanges: jasmine.Spy;
  };
  let employeeProfileServiceSpy: { cancel: jasmine.Spy };
  let mockEmployeeService: any = new EmployeeServiceMock();
  let mockAccountService: any = new AccountMock();

  beforeEach(async () => {
    overlaySidePanelServiceSpy = {
      close: jasmine.createSpy('close').and.returnValue(of(true)),
      reportChanges: jasmine
        .createSpy('reportChanges')
        .and.returnValue(of(true)),
    };
    employeeProfileServiceSpy = {
      cancel: jasmine.createSpy('cancel').and.returnValue(of(true)),
    };
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [EmployeeProfileComponent],
      providers: [
        {
          provide: AccountService,
          useValue: mockAccountService,
        },
        { provide: EmployeeService, useValue: mockEmployeeService },
        {
          provide: OverlaySidePanelService,
          useValue: overlaySidePanelServiceSpy,
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeProfileComponent);
    component = fixture.componentInstance;

    var store = { account: { billId: '000312' } };
    var storeSintringify = JSON.stringify(store);
    spyOn(localStorage, 'getItem').and.callFake((key: string): any => {
      return storeSintringify;
    });

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close panel', () => {
    component.closePanel();
    expect(overlaySidePanelServiceSpy.close.calls.count()).toBe(1);
  });

  it('should save employee', () => {
    component.save();
    expect(overlaySidePanelServiceSpy.reportChanges.calls.count()).toBe(1);
  });
});
