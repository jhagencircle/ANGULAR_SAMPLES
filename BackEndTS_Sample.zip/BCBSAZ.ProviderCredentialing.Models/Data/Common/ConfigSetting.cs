﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Common
{
	[Table("utb_ConfigSettings")]
	public class ConfigSetting
	{
		public string Environment { get; set; }

		public string Name { get; set; }

		public string Value { get; set; }

		public int Protection { get; set; }
	}
}
