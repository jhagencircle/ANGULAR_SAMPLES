import { IProducts } from '.';

export interface ISubscriber {
  isDependent: boolean;
  memberId: string | null;
  lastName: string;
  dependentType: string | null;
  middleName: string | null;
  firstName: string;
  dateOfBirth: Date;
  ssn: string;
  itin: string | null;
  foreignDocumentNumber: string | null;
  gender: string;
  medicareInformation: {
    medicareNumber?: string | null;
    partAEffectiveDate?: string | null;
    partBEffectiveDate?: string | null;
    isElegible: boolean | null;
  };
  products: IProducts[];
  otherHealthPlanCoverage: {
    effectiveDate: string | null;
    groupNumber: string | null;
    productName: string | null;
    productId: string | null;
    policyHolderName: string | null;
    carrierPhone: string | null;
  };
  tobaccoUsage: boolean | null;
  lastTobaccoUseDate: string | null;
  preferredContactMethod: string | null;
  preferredLanguage: string | null;
  autoWithdrawalEnabled: boolean | null;
  maritalStatus: string | null;
  rateAreaId: string | null;
  rateCountyCode: string | null;
  dependent: boolean | null;
  operation: number | null;
  isSuccessOperation: boolean | null;
  removalReason: string | null;
}
