﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace BCBSAZ.ProviderAuxiliaryPortal.Extensions
{
    public static class ConfigureServicesExtensions
    {
        public static void AddConfiguration<TConfigurationItem>(this IServiceCollection services, IConfiguration configuration, string section = null) where TConfigurationItem : class, new()
        {
            section = section ?? typeof(TConfigurationItem).Name;
            services.Configure<TConfigurationItem>(configuration.GetSection(section));
            services.AddSingleton(sp => sp.GetRequiredService<IOptions<TConfigurationItem>>().Value);
        }

        public static void AddDbContext<TDbContext>(this IServiceCollection services, string connString) where TDbContext : DbContext
        {
            services.AddDbContext<TDbContext>(options => options
                            .UseSqlServer(connString, providerOptions => providerOptions.CommandTimeout(60))
                            .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));
        }
    }
}
