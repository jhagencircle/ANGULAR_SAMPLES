﻿using System;
using System.Collections.Generic;
using System.Text;
using BCBSAZ.Provider.Interfaces.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BCBSAZ.Provider.Repositories
{
	public static class RepositoriesStartup
	{
		public static void AddRepositories(this IServiceCollection services, IConfiguration configuration)
		{
			services.AddDbContexts(configuration);

			services.AddScoped<IRemitsRepository, RemitsRepository>();
			services.AddScoped<IClaimsRepository, ClaimsRepository>();
			services.AddScoped<ICommonRepository, CommonRepository>();
			services.AddScoped<ISettingsRepository, SettingsRepository>();
			services.AddScoped<IEligibilityRepository, EligibilityRepository>();
			services.AddScoped<IFeatureToggleRepository, FeatureToggleRepository>();
			services.AddScoped<IFeeScheduleRepository, FeeScheduleRepository>();
			services.AddScoped<IPreCertRepository, PreCertRepository>();
			services.AddScoped<IProviderRepository, ProviderRepository>();
			services.AddScoped<ISecurityRepository, SecurityRepository>();
			services.AddScoped<ISubscriberRepository, SubscriberRepository>();
			services.AddScoped<ITransactionLogRepository, TransactionLogRepository>();
			services.AddScoped<ITPARegistrationRepository, TPARegistrationRepository>();
			services.AddScoped<ITPAFeeScheduleRepository, TPAFeeScheduleRepository>();
			services.AddScoped<ITpaProviderRepository, TpaProviderRepository>();
			services.AddScoped<IOfficeUserManagementRepository, OfficeUserManagementRepository>();
			services.AddScoped<IPatientRepository, PatientRepository>();

			services.AddSingleton<ISystemLogsRepository, SystemLogsRepository>();
			services.AddSingleton<IPurgeResultsRepository, PurgeResultsRepository>();
			services.AddSingleton<IEmailRepository, EmailRepository>();
		}
	}
}
