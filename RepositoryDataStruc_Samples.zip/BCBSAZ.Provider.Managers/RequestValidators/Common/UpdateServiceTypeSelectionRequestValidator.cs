﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Common;

namespace BCBSAZ.Provider.Managers.RequestValidators.Common
{
	public static class UpdateServiceTypeSelectionRequestValidator
	{
		public static IEnumerable<InvalidModelExceptionDetail> ValidateRequest(this UpdateServiceTypeSelectionRequest request)
		{
			if (string.IsNullOrEmpty(request.UserId))
				yield return new InvalidModelExceptionDetail(nameof(UpdateServiceTypeSelectionRequest.UserId), new ArgumentException("User Id is missing."));

			if (!request.ServiceTypes.Any())
				yield return new InvalidModelExceptionDetail(nameof(UpdateServiceTypeSelectionRequest.ServiceTypes), new ArgumentException("Service Types are missing."));

			if (request.ServiceTypes.Count() > 5)
				yield return new InvalidModelExceptionDetail(nameof(UpdateServiceTypeSelectionRequest.ServiceTypes), new ArgumentException("There can only be a max of 5 service types to save"));
		}
	}
}
