import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  Validators,
  AbstractControl,
  FormBuilder,
} from '@angular/forms';
import { IBenefit } from '../shared/models/benefit.model';
import { IDependent } from '../shared/models/dependent.model';
import { IPlan } from '../shared/models/plan.model';
import { IRelationship } from '../shared/models/relationship.model';
import { RelationshipService } from '../shared/relationship.service';
import { ITerminationReason } from '../shared/models/termination-reason.model';
import { TerminationReasonService } from '../shared/termination-reason.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-employee-dependent-add',
  templateUrl: './employee-dependent-add.component.html',
  styleUrls: ['./employee-dependent-add.component.scss'],
})
export class EmployeeDependentAddComponent implements OnInit, OnDestroy {
  @Output() close: EventEmitter<any> = new EventEmitter();
  @Output() onSuccessfulAdd: EventEmitter<any> = new EventEmitter();
  @Input() benefitSelection: IBenefit;

  dependentInformation: IDependent;
  relationshipList: IRelationship[];
  terminationReasonList: ITerminationReason[];
  healthPlan: IPlan | undefined;
  healthInsurancePlanOptions: any[] = [];
  form: FormGroup;
  subscriptions: Subscription[] = [];

  get f() {
    return this.form.controls;
  }

  constructor(
    public fb: FormBuilder,
    private relationshipService: RelationshipService,
    private terminationReasonService: TerminationReasonService
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.getFormListsData();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  cancel() {
    this.form.reset(this.getFormDefaultValues());
    this.close.emit(null);
  }

  createForm() {
    this.form = this.fb.group(this.getFormDefaultValues());
  }

  getFormListsData() {
    //get relationship list
    let relationshipSubs = this.relationshipService.get().subscribe((data) => {
      this.relationshipList = data;
    });

    //get reason for removal list
    let reasonForRemovalSubs = this.terminationReasonService
      .get()
      .subscribe((data) => {
        this.terminationReasonList = data;
      });

    //get medical plan list
    this.healthPlan = this.benefitSelection?.planSelection.find((p) => {
      if (p.type.toLowerCase().includes('medical')) {
        return p;
      } else return null;
    });
    if (this.healthPlan) {
      this.healthInsurancePlanOptions.push(this.healthPlan);
    }
    this.subscriptions.push(relationshipSubs);
    this.subscriptions.push(reasonForRemovalSubs);
  }

  getFormDefaultValues() {
    return {
      lastName: ['', [Validators.required]],
      firstName: ['', [Validators.required]],
      ssn: [''],
      relationship: ['', [Validators.required]],
      dateOfBirth: ['', [Validators.required]],
      gender: [''],
      heatlthInsurancePlan: ['', [Validators.required]],
    };
  }

  getField(fieldName: string): AbstractControl | null {
    return this.form.get(fieldName);
  }

  getRandomNumberBetween(min: number, max: number) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

  setDependentValues() {
    let dateOfBirth = this.getField('dateOfBirth')?.value;
    let dependentPlanSelection: IPlan[] = [];
    let healthPlanSelection: IPlan = this.healthInsurancePlanOptions
      ? this.healthInsurancePlanOptions.find(
          (p) => p.id == this.getField('heatlthInsurancePlan')?.value
        )!
      : null;
    if (healthPlanSelection) {
      dependentPlanSelection.push(healthPlanSelection);
    }
    let dependentBenefitSelection: IBenefit = {
      planSelection: dependentPlanSelection,
      eligibleForMedicare: false,
      lifeInsuranceBenefit: '',
      medicareNumber: undefined,
      partAEffectiveDate: undefined,
      partBEffectiveDate: undefined,
    };

    this.dependentInformation = {
      firstName: this.getField('firstName')?.value,
      lastName: this.getField('lastName')?.value,
      ssn: this.getField('ssn')?.value,
      dateOfBirth: dateOfBirth,
      gender: this.getField('gender')?.value,
      middleName: '',
      dependentType: this.getField('relationship')?.value,
      benefitSelection: dependentBenefitSelection, //here is the medicare information, base on response structure...
      removalReason: '',
      isEdit: false,
      isRemoved: false,
      effectiveDate: null,
    };
  }

  save() {
    if (this.form.valid) {
      this.setDependentValues();
      this.onSuccessfulAdd.emit(this.dependentInformation);
      this.close.emit(null);
    }
  }
}
