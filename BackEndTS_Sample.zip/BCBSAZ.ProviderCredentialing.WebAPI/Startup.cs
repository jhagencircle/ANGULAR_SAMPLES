#define DEBUG_LOGGER
using BCBSAZ.ProviderCredentialing.WebAPI.Middleware;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

#if !DEBUG || DEBUG_LOGGER
using BCBSAZ.ProviderCredentialing.Managers;
using Microsoft.Extensions.Logging;
#endif

namespace BCBSAZ.ProviderCredentialing.WebAPI
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			services.AddControllers();
			services.AddManagers(Configuration);
			services.AddRepositories(Configuration);
			services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

#if !DEBUG || DEBUG_LOGGER
			services.AddSingleton<ILogMessageStorage, SystemLogsManager>();
#endif
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}

			app.UseHttpsRedirection();
			app.UseMiddleware<ApiExceptionHandling>();
			app.UseRouting();

			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllers();
			});
		}
	}
}
