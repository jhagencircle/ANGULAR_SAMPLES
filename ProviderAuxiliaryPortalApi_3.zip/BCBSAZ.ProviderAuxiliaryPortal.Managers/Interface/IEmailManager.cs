﻿using System.Collections.Generic;
using System.Net.Mail;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface
{
    public interface IEmailManager
    {
        Task<bool> SendExternalMessageAsync(string fromAddress, string toAddress, string subject, string body);
        Task<bool> SendInternalMessageAsync(string fromAddress, string toAddress, string subject, string body, IEnumerable<Attachment> attachments);
    }
}
