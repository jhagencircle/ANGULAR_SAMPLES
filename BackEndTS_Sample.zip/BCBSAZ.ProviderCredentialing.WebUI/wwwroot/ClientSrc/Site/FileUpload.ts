﻿export type ProcessUploadedFile = (file: any) => void;

export class FileUpload {
	private fileIndex: number;

	private id_UploadFileInput: string;
	private id_UploadFileButton: string;

	private addNewFile: ProcessUploadedFile;

	constructor(addNewFileCallback: ProcessUploadedFile, index: number) {
		this.fileIndex = index;
		this.id_UploadFileInput = `#fileInput_${this.fileIndex}`;
		this.id_UploadFileButton = `#fileUpload`;
		this.addNewFile = addNewFileCallback;


		$(this.id_UploadFileInput).change(this.selectFiles);
		$(this.id_UploadFileButton).click(this.showFilePicker);
	};

	public showFilePicker = (): void => {
		event.preventDefault();
		$(this.id_UploadFileInput).click();
	};

	public updateAddFilesButton = (): void => {
		++this.fileIndex;
		this.id_UploadFileInput = `#fileInput_${this.fileIndex}`;
		$(this.id_UploadFileInput).change(this.selectFiles);
	};

	private selectFiles = () => {
		const files = $(this.id_UploadFileInput).prop("files");
		this.addNewFileToInput(files);
	};

	private addNewFileToInput = (files) => {
		this.addNewFile(files);
	};
}
