import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmployeeBenefitSelectionEditComponent } from './employee-benefit-selection-edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { EmployeeMock } from '../../shared/mocks/employee.mock';
import { AccountService } from 'src/app/shared/services/account.service';
import { AccountMock } from '../../shared/mocks/account.mock';
import { PlanServiceMock } from 'src/app/shared/mocks/plan.service.mock';
import { PlanService } from '../shared/plan.service';

describe('EmployeeBenefitSelectionEditComponent', () => {
  let component: EmployeeBenefitSelectionEditComponent;
  let fixture: ComponentFixture<EmployeeBenefitSelectionEditComponent>;
  let mockEmployeeService: EmployeeMock;
  let mockAccountService: any = new AccountMock();
  let planServiceMock: any = new PlanServiceMock();

  beforeEach(async () => {
    mockEmployeeService = new EmployeeMock();
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        HttpClientTestingModule,
        NgbModule,
      ],
      declarations: [EmployeeBenefitSelectionEditComponent],
      providers: [
        { provide: AccountService, useValue: mockAccountService },
        { provide: PlanService, useValue: planServiceMock },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeBenefitSelectionEditComponent);
    component = fixture.componentInstance;
    mockEmployeeService
      .get()
      .subscribe(
        (data) => (component.benefitSelection = data.benefitSelection)
      );
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get benefit list', () => {
    component.getBenefitLists();
    expect(component.healthInsurancePlans).not.toBeNull();
    expect(component.dentalInsurancePlans).not.toBeNull();
    expect(component.lifeInsurancePlans).not.toBeNull();
  });

  it('should save', () => {
    spyOn(component.sendForm, 'emit');
    component.save();
    expect(component.sendForm.emit).toHaveBeenCalledWith({
      benefitSelection: component.benefitSelection,
    });
  });

  it('should close', () => {
    spyOn(component.showBenefitEdit, 'emit');
    component.close();
    expect(component.showBenefitEdit.emit).toHaveBeenCalledWith(false);
  });

  it('should hide Medicare', () => {
    component.changeMedicare({ target: { value: 'false' } });
    expect(component.f.medicareNumber.value).toEqual('');
    expect(component.f.medicareType.value).toEqual('');
    expect(component.f.partAEffectiveDate.value).toBeNull;
    expect(component.f.partBEffectiveDate.value).toBeNull;
  });
});
