import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { PaymentConfirmationAccountComponent } from './payment-confirmation-account.component';
import { DecimalPipe } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';

describe('PaymentConfirmationAccountComponent', () => {
  let component: PaymentConfirmationAccountComponent;
  let fixture: ComponentFixture<PaymentConfirmationAccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],

      declarations: [PaymentConfirmationAccountComponent, DecimalPipe],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentConfirmationAccountComponent);
    component = fixture.componentInstance;
    var store = [
      {
        transactionId: null,
        accountId: '000312',
        paymentTransactionNumber: 'RXMBND90KRUOUYZM',
        paymentAmount: 45000,
        paymentTransactionDate: '2021-08-27T07:00:00Z',
        paymentTransactionOrigin: 'Web',
        paymentTokenId: 25181,
        statusName: 'Scheduled',
        invoiceNumber: 1,
        account: 'Top Account A',
        bankAccount: 'TEST,1706',
      },
    ];
    var storeSintringify = JSON.stringify(store);
    spyOn(localStorage, 'getItem').and.callFake((key: string): any => {
      return storeSintringify;
    });

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
