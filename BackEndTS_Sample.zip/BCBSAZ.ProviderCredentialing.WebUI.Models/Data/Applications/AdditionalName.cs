﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class AdditionalName : IName
	{
		public AdditionalName() =>
			Types = new List<NameType>() { NameType.Additional };

		public AdditionalName(params NameType[] nameTypes) =>
			Types = new List<NameType>(nameTypes);

		[MaxLength(50)]
		[DisplayName("First Name")]
		[RegularExpression("^[A-Za-z-A-Za-zA-Za-z A-Za-zA-Za-z'A-Za-z]*[A-Za-z]+$", ErrorMessage = "Please enter a valid First Name")]
		public string FirstName { get; set; }

		[MaxLength(50)]
		[DisplayName("Last Name")]
		[RegularExpression("^[A-Za-z-A-Za-zA-Za-z A-Za-zA-Za-z'A-Za-z]*[A-Za-z]+$", ErrorMessage = "Please enter a valid Last Name")]
		public string LastName { get; set; }

		[MaxLength(50)]
		[DisplayName("Middle Initial")]
		[RegularExpression("^[A-Za-z. -]*", ErrorMessage = "Please enter a valid Middle Initial")]
		public string MiddleInitial { get; set; }

		public ICollection<NameType> Types { get; set; } 

	}
}
