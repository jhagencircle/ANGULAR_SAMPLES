﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Enums;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface ICommonRepository
	{
		string GetDatabaseServerName();

		ConfigSetting GetConfigSetting(string settingName);

		int GetMessageCount(string userId);

		string[] GetAlphaPrefixes(LOB areaPrefix);
	}
}
