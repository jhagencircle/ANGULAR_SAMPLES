﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	public class OfficeHour
	{
		[JsonConverter(typeof(StringEnumConverter))]
		public DayOfWeek DayOfWeek { get; set; }

		public string OpenTime { get; set; }

		public string CloseTime { get; set; }
	}
}
