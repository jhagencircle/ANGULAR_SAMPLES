﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Settings;
using BCBSAZ.Provider.Models.Requests.Settings;
using BCBSAZ.Provider.Models.Responses.Settings;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface ISettingsManager
	{

		#region Setting Values
		Task<SettingValue> GetSettingValueAsync(string settingName, string defaultValue, WebUser webUser);

		Task<SettingValueResponse> GetSettingValueAsync(SettingValueRequest request);

		Task<FeatureToggleResponse> IsFeatureEnabledAsync(SettingValueRequest request);

		Task<FeatureToggleResponse> IsBetaLinkEnabledAsync(SettingValueRequest request);
		#endregion

		#region Settings
		Task<AllSettingsResponse> GetSettingsForApplicationAsync(AllSettingsRequest request);

		Task<SettingResponse> GetSettingAsync(GetSettingRequest request);

		Task<SettingResponse> AddSettingAsync(AddSettingRequest request);

		Task<SettingResponse> UpdateSettingsAsync(UpdateSettingRequest request);

		Task<DeleteSettingResponse> DeleteSettingAsync(DeleteSettingRequest request);
		#endregion

		#region User Type Settings
		Task<AllUserTypeSettingsResponse> GetAllUserTypeSettingsAsync(GetAllUserTypeSettingsRequest request);

		Task<UserTypeSettingResponse> GetUserTypeSettingAsync(GetUserTypeSettingRequest request);

		Task<UserTypeSettingResponse> AddUserTypeSettingAsync(AddUserTypeSettingRequest request);

		Task<UserTypeSettingResponse> UpdateUserTypeSettingsAsync(UpdateUserTypeSettingRequest request);

		Task<DeleteUserTypeSettingResponse> DeleteUserTypeSettingAsync(DeleteUserTypeSettingRequest request);
		#endregion

		#region User Settings
		Task<AllUserSettingsResponse> GetAllUserSettingsAsync(GetAllUserSettingsRequest request);

		Task<UserSettingResponse> GetUserSettingAsync(GetUserSettingRequest request);

		Task<UserSettingResponse> AddUserSettingAsync(AddUserSettingRequest request);

		Task<UserSettingResponse> UpdateUserSettingsAsync(UpdateUserSettingRequest request);

		Task<DeleteUserSettingResponse> DeleteUserSettingAsync(DeleteUserSettingRequest request);
		#endregion

		#region Setting Types
		Task<AllSettingTypesResponse> GetSettingTypesAsync();
		#endregion

		#region Setting Applications
		Task<AllSettingApplicationsResponse> GetSettingApplicationsAsync();

		Task<SettingApplicationResponse> UpdateSettingApplicationAsync(UpdateSettingApplicationRequest request);
		#endregion

	}
}
