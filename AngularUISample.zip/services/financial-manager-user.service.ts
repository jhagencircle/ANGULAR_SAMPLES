import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, Subject } from 'rxjs';
import { IFinancialManagerUser } from '../models/financial-manager-user/financial-manager-user.interface';
import {debounceTime, delay, switchMap, tap} from 'rxjs/operators';
import { SortColumn, SortDirection } from '../common/directives/sortable.directive';

interface SearchResult {
  financialManagerUsers: IFinancialManagerUser[];
  total: number;
}

interface State {
  page: number;
  pageSize: number;
  searchTerm: string;
  sortColumn: SortColumn;
  sortDirection: SortDirection;
}

// v1 < v2 return -1
// v1 > v2 return 1
// v1 = v2 return 0
const compare = (v1: string | number, v2: string | number) => v1 < v2 ? -1 : v1 > v2 ? 1 : 0;

function sort(financialManagerUsers: IFinancialManagerUser[], column: SortColumn, direction: string): IFinancialManagerUser[] {
  if (direction === '' || column === '') {
    return financialManagerUsers;
  } else {
    return [...financialManagerUsers].sort((a, b) => {
      const res = compare(a[column], b[column]);
      return direction === 'asc' ? res : -res;
    });
  }
}

function matches(financialManagerUser: IFinancialManagerUser, term: string): boolean {
  return financialManagerUser.userId.toLowerCase().includes(term.toLowerCase())
    || financialManagerUser.subOrganization.toLowerCase().includes(term.toLowerCase())
    || `${financialManagerUser.firstName} ${financialManagerUser.lastName}`.toLowerCase().includes(term.toLowerCase());
}


@Injectable({
  providedIn: 'root'
})
export class FinancialManagerUserService {
  private loadingObs$ = new BehaviorSubject<boolean>(true);
  private searchObs$ = new Subject<void>();
  private financialManagerUsersObs$ = new BehaviorSubject<IFinancialManagerUser[]>([]);
  private totalObs$ = new BehaviorSubject<number>(0);

  private financialManagerUsers: IFinancialManagerUser[] = [];

  private state: State = {
    page: 1,
    pageSize: 10,
    searchTerm: '',
    sortColumn: '',
    sortDirection: ''
  };

  constructor() {
    this.financialManagerUsers = FINANCIAL_MANAGE_USERS_MOCK;

    this.searchObs$.pipe(
      tap(() => this.loadingObs$.next(true)),
      debounceTime(200),
      switchMap(() => this.search()),
      delay(200),
      tap(() => this.loadingObs$.next(false))
    ).subscribe(result => {
      this.financialManagerUsersObs$.next(result.financialManagerUsers);
      this.totalObs$.next(result.total);
    });

    this.searchObs$.next();
  }

  get users$(): Observable<IFinancialManagerUser[]> { return this.financialManagerUsersObs$.asObservable(); }
  get total$(): Observable<number> { return this.totalObs$.asObservable(); }
  get loading$(): Observable<boolean> { return this.loadingObs$.asObservable(); }

  get page(): number { return this.state.page; }
  set page(page: number) { this.set({page}); }

  get pageSize(): number { return this.state.pageSize; }
  set pageSize(pageSize: number) { this.set({pageSize}); }

  get searchTerm(): string { return this.state.searchTerm; }
  set searchTerm(searchTerm: string) { this.set({searchTerm}); }

  set sortColumn(sortColumn: SortColumn) { this.set({sortColumn}); }
  set sortDirection(sortDirection: SortDirection) { this.set({sortDirection}); }

  private set(patch: Partial<State>): void {
    Object.assign(this.state, patch);
    this.searchObs$.next();
  }

  public refreshResearchResult(): void{
    this.searchObs$.next();
  }

  private search(): Observable<SearchResult> {
    const {sortColumn, sortDirection, pageSize, page, searchTerm} = this.state;

    // 1. sort
    let financialManagerUsers = sort(this.financialManagerUsers, sortColumn, sortDirection);

    // 2. filter
    financialManagerUsers = financialManagerUsers.filter(financialManagerUser => matches(financialManagerUser, searchTerm));
    const total = financialManagerUsers.length;

    // 3. paginate
    financialManagerUsers = financialManagerUsers.slice((page - 1) * pageSize, (page - 1) * pageSize + pageSize);
    return of({financialManagerUsers, total});
  }

  // TODO: need to hookup with acutal API
  public deleteUser(user: IFinancialManagerUser): Observable<boolean> {
    this.financialManagerUsers.forEach((item, index) => {
      if (item === user) {
        this.financialManagerUsers.splice(index, 1);
      }
    });
    return of(true);
  }
}

const FINANCIAL_MANAGE_USERS_MOCK: IFinancialManagerUser[] = [
    {
      userId: 'Test1',
      lastName: 'Rest',
      firstName: 'Jest',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 1'
    },
    {
      userId: 'Test2',
      lastName: 'Crest',
      firstName: 'Jest',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 1'
    },
    {
      userId: 'Test3',
      lastName: 'Best',
      firstName: 'Jest',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 1'
    },
    {
      userId: 'Test4',
      lastName: 'Chest',
      firstName: 'Jest',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 2'
    },
    {
      userId: 'Test5',
      lastName: 'Hest',
      firstName: 'Jest',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 1'
    },
    {
      userId: 'Test6',
      lastName: 'Lest',
      firstName: 'Jest',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 3'
    },
    {
      userId: 'Test7',
      lastName: 'Rest',
      firstName: 'Jet',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 2'
    },
    {
      userId: 'Test8',
      lastName: 'Jones',
      firstName: 'Jest',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 5'
    },
    {
      userId: 'Test9',
      lastName: 'Major',
      firstName: 'Padrig',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 4'
    },
    {
      userId: 'Test10',
      lastName: 'Braken',
      firstName: 'Speedy',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 4'
    },
    {
      userId: 'Test11',
      lastName: 'Lakely',
      firstName: 'Cramer',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 5'
    },
    {
      userId: 'Test12',
      lastName: 'Kraven',
      firstName: 'Rush',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 3'
    },
    {
      userId: 'Test13',
      lastName: 'Kraken',
      firstName: 'Seal',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 2'
    },
    {
      userId: 'Test14',
      lastName: 'Homer',
      firstName: 'Hern',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 1'
    },
    {
      userId: 'Test15',
      lastName: 'Jiffy',
      firstName: 'Loufy',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 5'
    },
    {
      userId: 'Test16',
      lastName: 'Bogusz',
      firstName: 'Daid',
      phone: '8648648406',
      email: 'test1@me@you.com',
      userName: 'jesttest',
      password: 'ThisIsPass1',
      securityQuestion: '',
      securityQuestionAnswer: '',
      subOrganization: 'Test Org 2'
    }
  ];
