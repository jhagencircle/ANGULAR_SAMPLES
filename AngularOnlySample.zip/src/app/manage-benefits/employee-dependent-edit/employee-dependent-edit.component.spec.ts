import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeDependentEditComponent } from './employee-dependent-edit.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmployeeMock } from '../../shared/mocks/employee.mock';
import { DependentMock } from 'src/app/shared/mocks/dependent.mock';

describe('EmployeeDependentEditComponent', () => {
  let component: EmployeeDependentEditComponent;
  let fixture: ComponentFixture<EmployeeDependentEditComponent>;
  let mockEmployeeService: EmployeeMock;
  let dependentMock: DependentMock;

  beforeEach(async () => {
    mockEmployeeService = new EmployeeMock();
    dependentMock = new DependentMock();
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        NgbModule,
        HttpClientTestingModule,
      ],
      declarations: [EmployeeDependentEditComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeDependentEditComponent);
    component = fixture.componentInstance;
    mockEmployeeService.get().subscribe((data) => {
      component.benefitSelection = data.benefitSelection;
    });
    dependentMock.get().subscribe((data) => {
      component.dependentInformation = data;
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should save', () => {
    component.form.setValue({
      firstName: 'test',
      lastName: 'test',
      ssn: '123456789',
      relationship: 'spouse',
      dateOfBirth: '12/12/12',
      gender: 'male',
      elegibleForMedicare: false,
      medicareNumber: '123456789',
      partAEffectiveDate: '12/12/12',
      partBEffectiveDate: '12/12/12',
      effectiveDate: '12/12/12',
      healthInsurancePlan: 'T',
      dentalInsurancePlan: 'T',
      reasonForRemoval: '0',
      medicareType: 'Both',
    });

    spyOn(component.onSuccessfulEdit, 'emit');
    component.save();
    expect(component.onSuccessfulEdit.emit).toHaveBeenCalledWith({
      dependentInformation: Object({
        isEdit: false,
        firstName: 'test',
        middleName: '',
        lastName: 'test',
        dependentType: 'spouse',
        dateOfBirth: '12/12/12',
        ssn: '123456789',
        gender: 'male',
        benefitSelection: Object({
          eligibleForMedicare: false,
          medicareNumber: '123456789',
          partAEffectiveDate: '12/12/12',
          partBEffectiveDate: '12/12/12',
          planSelection: [],
        }),
        isRemoved: true,
        removalReason: '0',
        effectiveDate: '12/12/12',
        healthInsurancePlan: Object({}),
      }),
    });
  });

  it('should cancel', () => {
    component.cancel();
    expect(component.dependentInformation.isEdit).toBeFalse;
  });

  it('should detect changes', () => {
    component.onChanges();
  });
});
