﻿using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using SelectPdf;

namespace BCBSAZ.ProviderAuxiliaryPortal.Managers
{
    public class EftEnrollmentManager : IEftEnrollmentManager
    {
        private readonly IEftEnrollmentRepository _eftEnrollmentRepository;
        private readonly IEmailRepository _emailRepository;

        public EftEnrollmentManager(IEftEnrollmentRepository eftEnrollmentRepsitory, IEmailRepository emailRepository)
        {
            _eftEnrollmentRepository = eftEnrollmentRepsitory;
            _emailRepository = emailRepository;
        }

        public async Task<bool> CreateEftUserProfileAsync(EftEnrollmentRequest request)
        {
            await _eftEnrollmentRepository.SaveEftEnrollmentRequestAsync(request);
                
            return true;

        }        

        public async Task<bool> UpdateEftUserProfileAsync(EftEnrollmentRequest request, ProviderEftStatusEnum status)
        {
            request.Status = status;
  
            if (status == ProviderEftStatusEnum.Saved)
            {
                SendEmail(request);
            }
            
            await _eftEnrollmentRepository.UpdateEftEnrollmentRequestAsync(request);
            
            return true;
        }

        private async void SendEmail(EftEnrollmentRequest request)
        {

            PdfDocument doc = new PdfDocument();
            PdfPage page = doc.AddPage();
            PdfFont font = doc.AddFont(PdfStandardFont.Helvetica);
            font.Size = 10;

            MemoryStream pdfStream = new MemoryStream();
            PdfTextElement text = new PdfTextElement(50, 50, "First Name: " + request.FinInstitutionName + "\n" + "Last Name: " + request.FinInstitutionState, font);
            page.Add(text);

            // Save local
#if DEBUG
            doc.Save(@"C:\Local\test.pdf");
#endif

            doc.Save(pdfStream);
            doc.Close();

            pdfStream.Position = 0;
            MailMessage msg = new MailMessage();
            msg.Attachments.Add(new Attachment(pdfStream, "Document.pdf"));
            doc.Close();

            #region From Emp Portal


            //var view = View("PdfForm", request);
            //var htmlForm = await view.ToHtmlAsync(HttpContext, RouteData);

            //var converter = new HtmlToPdf();

            //converter.Options.PdfPageSize = PdfPageSize.Letter;
            //converter.Options.MarginTop = 20;
            //converter.Options.MarginBottom = 20;
            //converter.Options.MarginLeft = 0;
            //converter.Options.MarginRight = 0;
            //converter.Options.WebPageWidth = 1200;

            //var doc = converter.ConvertHtmlString(htmlForm);

            #endregion

            #region Html Sample 1

            //Sample
            //string url = @"http://localhost/MobileDeviceManagement/Form.aspx?id=";
            string url = @"http://localhost/4200/eft";

            string pdf_page_size = "A4";
            PdfPageSize pageSize = (PdfPageSize)Enum.Parse(typeof(PdfPageSize),
                pdf_page_size, true);

            string pdf_orientation = "Portrait";
            PdfPageOrientation pdfOrientation = (PdfPageOrientation)Enum.Parse(typeof(PdfPageOrientation),pdf_orientation, true);


            // instantiate a html to pdf converter object
            HtmlToPdf converter = new HtmlToPdf();

            // set converter options
            converter.Options.PdfPageSize = pageSize;
            converter.Options.PdfPageOrientation = pdfOrientation;
            converter.Options.WebPageWidth = 1200;           

            // create a new pdf document converting an url
            PdfDocument doc2 = converter.ConvertUrl(url);

            // save pdf document
            doc2.Save(@"C:\Local\htmlTest.pdf");

            // close pdf document
            doc2.Close();
            #endregion

            #region Html Sample 2
            //MemoryStream pdfStreamH = new MemoryStream();
            //HtmlToPdf converter = new HtmlToPdf();

            //converter.Options.InternalLinksEnabled = true;// ChkInternalLinks.Checked;
            //converter.Options.ExternalLinksEnabled = true;

            //// create a new pdf document converting an url
            //PdfDocument docH = converter.ConvertUrl("https://provider.test.secure.azblue.com/auxiliary/eft");

            //// save pdf document
            //docH.Save(@"C:\Local\testH.pdf");

            //// close pdf document
            //docH.Close();

            //await _emailRepository.SendInternalEmailAsync("test@test.com", "test@test.com", "Testing", "Testing", msg.Attachments);
            #endregion
        }

 
    }
}
