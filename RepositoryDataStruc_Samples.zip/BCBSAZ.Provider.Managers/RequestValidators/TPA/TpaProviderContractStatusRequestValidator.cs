﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.TPA;

namespace BCBSAZ.Provider.Managers.RequestValidators.TPA
{
	public static class TpaProviderContractStatusRequestValidator
	{
		public static void Validate(this TpaProviderContractStatusRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetVoilations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetVoilations(TpaProviderContractStatusRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.TaxId))
				yield return new InvalidModelExceptionDetail(nameof(TpaProviderContractStatusRequest.TaxId), new ArgumentException("TaxId is missing."));

			if (string.IsNullOrWhiteSpace(request.ProviderId))
				yield return new InvalidModelExceptionDetail(nameof(TpaProviderContractStatusRequest.ProviderId), new ArgumentException("ProviderId is missing."));

			if (string.IsNullOrWhiteSpace(request.Network))
				yield return new InvalidModelExceptionDetail(nameof(TpaProviderContractStatusRequest.Network), new ArgumentException("Network is missing."));

			if (String.IsNullOrWhiteSpace(request.EndDateLaterThan) || DateTime.Parse(request.EndDateLaterThan).CompareTo(DateTime.UtcNow) > 0)
				yield return new InvalidModelExceptionDetail(nameof(TpaProviderInfoRequest.Network), new ArgumentException("Invalid EndDateLaterthan."));
		}
	}
}
