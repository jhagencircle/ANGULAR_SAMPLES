import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(public oktaAuth: OktaAuthService, private router: Router) { }

  async ngOnInit() {
    await this.signIn();
  }

  async signIn() {
    if (environment.useSilentLogin) {
      if (await this.isUserLogged()) {
        await this.signInWithRedirect();
      } else {
        window.location.href = environment.externalLoginUrl;
      }
    }
    else {
      await this.signInWithRedirect();
    }
  }

  private async signInWithRedirect() {
    this.oktaAuth.signInWithRedirect({
      originalUri: '/home',
    });
  }

  private async isUserLogged() {
    const scopes = this.oktaAuth.options.scopes;
    const params = Object.assign({ scopes: scopes }, this.oktaAuth.options);
    try {
      await this.oktaAuth.token.getWithoutPrompt(params);
      return true;
    } catch {
      return false;
    }
  }

}
