﻿using System;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.API.Claims.Request;
using BCBSAZ.Provider.Models.API.Claims.Response;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface IClaimsApiClient
	{
		Task<ClaimsApiResponse> GetClaims(ClaimsApiRequest request);
	}
}
