﻿using System;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.Logger;
using BCBSAZ.Provider.Models.Responses.Common;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface ISystemLogsManager
	{
		VoidResponse InsertLogMessage(InsertLogMessageRequest request);
	}
}
