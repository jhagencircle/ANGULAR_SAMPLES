﻿using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface ICodesContext : IDbContext
	{
		DbSet<DiagnosisCodes> DiagnosisCodes { get; }
	}

	public class CodesContext : DbContext, ICodesContext
	{
		public CodesContext(DbContextOptions<CodesContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<DiagnosisCodes>().HasNoKey();
		}

		public DbSet<DiagnosisCodes> DiagnosisCodes { get; protected set; }

	}
}
