﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.PreCert;
using BCBSAZ.Provider.Models.Responses.PreCert;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IPreCertManager
	{
		Task<DownloadFileResponse> GetMedicalFileContentsAsync(DownloadFileRequest request);
		Task<DownloadFileResponse> GetPharmacyFileContentsAsync(DownloadFileRequest request);

		Task<SaveFileResponse> SaveFileAsync(SaveFileRequest request, WebUser user);


		Task<GetMedicalPreCertResponse> GetMedicalPreCertAsync(GetMedicalPreCertRequest request, WebUser webUser);

		Task<SaveMedicalPreCertResponse> SaveMedicalPreCertAsync(SaveMedicalPreCertRequest request, WebUser webUser);

		Task<CancelMedicalPreCertResponse> CancelMedicalPreCertAsync(CancelMedicalPreCertRequest request, WebUser webUser);

		ViewMedicalPreCertsResponse ViewMedicalPreCertResults(ViewMedicalPreCertsRequest request, WebUser user);
		

		Task<GetPharmacyPreCertResponse> GetPharmacyPreCertAsync(GetPharmacyPreCertRequest request, WebUser webUser);

		Task<SavePharmacyPreCertResponse> SavePharmacyPreCertAsync(SavePharmacyPreCertRequest request, WebUser webUser);

		Task<CancelPharmacyPreCertResponse> CancelPharmacyPreCertAsync(CancelPharmacyPreCertRequest request, WebUser webUser);

		ViewPharmacyPreCertsResponse ViewPharmacyPreCertResults(ViewPharmacyPreCertsRequest request, WebUser webUser);

	}
}
