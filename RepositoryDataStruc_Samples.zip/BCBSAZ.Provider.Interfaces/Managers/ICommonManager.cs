﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Responses.Common;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface ICommonManager
	{
		MessageCountResponse GetMessageCount(MessageCountRequest request);

		ServiceTypesResponse GetServiceTypes(ServiceTypesRequest request);

		Select2Response GetNpisByOrgId(Select2Request request, string orgId, string userId);

		Select2Response GetNpisByOrgIdForTpa(Select2Request request);

		PreviouslySelectedServiceTypeResponse GetPreviouslySelectedServiceTypes(PreviouslySelectedServiceTypeRequest request);

		void UpdateSelectedServiceTypes(UpdateServiceTypeSelectionRequest request);

		DoesUsernameExistResponse CheckUsername(DoesUsernameExistRequest username);
		string GetDatabaseServerName();
	}
}
