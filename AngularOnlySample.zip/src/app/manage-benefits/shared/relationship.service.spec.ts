import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RelationshipService } from './relationship.service';
import { IRelationship } from './models/relationship.model';
import { RelationshipServiceMock } from 'src/app/shared/mocks/relationship.service.mock';
import { of } from 'rxjs';

describe('RelationshipService', () => {
  let service: RelationshipService;

  let httpClientSpy: {
    get: jasmine.Spy;
  };
  let mockedRelationshipsList: IRelationship[] = [];
  let mockRelationshipService = new RelationshipServiceMock();
  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [HttpClientTestingModule] });
    service = TestBed.inject(RelationshipService);
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    mockRelationshipService
      .get()
      .subscribe((data) => (mockedRelationshipsList = data));
    service = new RelationshipService(httpClientSpy as any);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return relationships mockList', () => {
    httpClientSpy.get.and.returnValue(of(mockedRelationshipsList));
    service
      .get()
      .subscribe(
        (items) =>
          expect(items).toEqual(
            mockedRelationshipsList,
            'expected relationships'
          ),
        fail
      );
    expect(httpClientSpy.get.calls.count()).toBe(1);
  });

  it('should return relationships by coverage mockList', () => {
    httpClientSpy.get.and.returnValue(
      of(RelationshipServiceMock.mockedRelationshipsByCoverage)
    );
    service
      .getByCoverage('2001')
      .subscribe(
        (items) =>
          expect(items).toEqual(
            RelationshipServiceMock.mockedRelationshipsByCoverage,
            'expected relationships by coverage'
          ),
        fail
      );
    expect(httpClientSpy.get.calls.count()).toBe(1);
  });
});
