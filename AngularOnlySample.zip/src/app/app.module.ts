import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { NavbarComponent } from './shared/components/navbar/navbar.component';
import { AuthGuard } from './core/auth/auth.guard';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { OKTA_CONFIG, OktaAuthModule } from '@okta/okta-angular';
import { LogInCallbackComponent } from './log-in-callback/log-in-callback.component';
import { environment } from 'src/environments/environment';
import { CommonModule, DecimalPipe } from '@angular/common';
import { HttpMiddleware } from './shared/middleware/httpMiddleware';
import { SessionComponent } from './shared/components/session/session.component';
import { ConfirmationDialogModule } from './shared/components/confirmation-dialog/confirmation-dialog.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ValidationDirectivesModule } from './shared/modules/validation-directives.Module';
import { WelcomeDialogComponent } from './shared/components/welcome-dialog/welcome-dialog.component';
import { GlobalErrorHandler } from './shared/middleware/globalErrorHandler';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const config = {
  clientId: '0oawz7tbfddFmuqu70h7',
  issuer: 'https://evalext.azblue.com/oauth2/ausieumlspeeWM4P70h7',
  redirectUri: environment.oktaRedirectCallbackUrl,
  scopes: ['openid', 'profile', 'email', 'employer', 'offline_access'],
  postLogoutRedirectUri: environment.oktaPostLogoutRedirectUri,
  pkce: true,
};

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavbarComponent,
    LogInCallbackComponent,
    SessionComponent,
    WelcomeDialogComponent,
    PageNotFoundComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgbModule,
    OktaAuthModule,
    CommonModule,
    ConfirmationDialogModule,
    BrowserAnimationsModule,
    ValidationDirectivesModule,
  ],
  providers: [
    AuthGuard,
    {
      provide: ErrorHandler,
      useClass: GlobalErrorHandler,
    },
    { provide: OKTA_CONFIG, useValue: config },
    DecimalPipe,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpMiddleware,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
