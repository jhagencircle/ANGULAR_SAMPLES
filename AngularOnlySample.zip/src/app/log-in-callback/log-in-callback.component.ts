import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-log-in-callback',
  templateUrl: './log-in-callback.component.html',
  styleUrls: ['./log-in-callback.component.scss'],
})
export class LogInCallbackComponent implements OnInit {
  errorDescription: string;

  constructor(private activatedRoute: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe((params) => {
      if (params.error) {
        this.errorDescription = params.error_description;
      } else {
        this.router.navigate(['/landing-page']);
      }
    });
  }
}
