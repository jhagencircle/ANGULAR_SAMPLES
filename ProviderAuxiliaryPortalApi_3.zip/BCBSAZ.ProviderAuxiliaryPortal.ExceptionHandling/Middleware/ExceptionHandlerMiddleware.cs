﻿using BCBSAZ.ProviderAuxiliaryPortal.ExceptionHandling.CustomException;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using Microsoft.AspNetCore.Http;
using Serilog;
using System;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.ExceptionHandling.Middleware
{
    public class ExceptionHandlerMiddleware
    {
        private const string CONTENT_TYPE = "text";
        private const string DEFAULT_ERROR_MESSAGE = "An error occurred.";
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;

        public ExceptionHandlerMiddleware(RequestDelegate next, ILogger logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception e)
            {
                if (e.InnerException is BaseException)
                    await HandleException(e.InnerException, context);

                await HandleException(e, context);
            }
        }

        private async Task HandleException(Exception exception, HttpContext context)
        {
            var displayMessage = DEFAULT_ERROR_MESSAGE;
            context.Response.ContentType = CONTENT_TYPE;
            context.Response.StatusCode = 500;

            if (exception is BaseException baseException)
            {
                context.Response.StatusCode = baseException.StatusCode;
                displayMessage = baseException.Message;
                Log(baseException);
            }
            else
            {
                _logger.Error(exception, exception.Message);
            }

            await context.Response.WriteAsync(displayMessage);
        }

        private void Log(BaseException exception)
        {
            switch (exception.EventLevel)
            {
                case LogLevelEnum.Information:
                    _logger.ForContext<ExceptionHandlerMiddleware>().Information(exception.Message, exception);
                    break;
                case LogLevelEnum.Fatal:
                    _logger.ForContext<ExceptionHandlerMiddleware>().Fatal(exception.Message, exception);
                    break;
                case LogLevelEnum.Warning:
                    _logger.ForContext<ExceptionHandlerMiddleware>().Warning(exception.Message, exception);
                    break;
                default:
                    _logger.ForContext<ExceptionHandlerMiddleware>().Error(exception, exception.Message);
                    break;
            }
        }

    }
}