import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ClaimsInvoicePaymentAddComponent } from './claims-invoice-payment-add.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccountService } from 'src/app/shared/services/account.service';
import { AccountMock } from '../../shared/mocks/account.mock';
import { BankAccountMock } from 'src/app/shared/mocks/bank-account.mock';
import { BankAccountService } from '../../bank-account/shared/bank-account.service';
import { Router } from '@angular/router';
import { MockSubAccount } from '../../shared/mocks/sub-account.mock';
import { SubAccountService } from '../../shared/services/sub-account.service';

describe('ClaimsInvoicePaymentAddComponent', () => {
  let component: ClaimsInvoicePaymentAddComponent;
  let fixture: ComponentFixture<ClaimsInvoicePaymentAddComponent>;
  let mockAccountService: any = new AccountMock();
  let mockBankAccountModel: BankAccountMock = new BankAccountMock();
  let router = { navigate: jasmine.createSpy('navigate') };
  let mockSubAccount: any = new MockSubAccount();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        ReactiveFormsModule,
        FormsModule,
        HttpClientTestingModule,
      ],
      declarations: [ClaimsInvoicePaymentAddComponent],
      providers: [
        {
          provide: AccountService,
          useValue: mockAccountService,
        },
        { provide: SubAccountService, useValue: mockSubAccount },
        { provide: Router, useValue: router },
        { provide: BankAccountService, useValue: mockBankAccountModel },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsInvoicePaymentAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should cancel', () => {
    component.cancel();
    expect(router.navigate).toHaveBeenCalledWith(['/landing-page']);
  });
});
