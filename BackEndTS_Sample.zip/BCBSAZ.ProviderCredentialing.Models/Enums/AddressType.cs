﻿namespace BCBSAZ.ProviderCredentialing.WebAPI.Models.Enums
{
	public enum AddressType
	{
		OfficeAddress,
		BillingAddress,
		MailingAddress,
		MedicalRecords, 
		Credentialing,
		Additional
	}
}
