﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Responses.Okta;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface IOktaApiClient
	{
		AccessTokenResponse GetApiToken();
	}
}
