﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;


namespace BCBSAZ.Provider.Managers.RequestValidators.Eligibility
{
	internal static class BooksRidersRequestValidator
	{
		public static void Validate(this BooksRidersRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(BooksRidersRequest request)
		{
			if (request.ResponseId == 0)
				yield return new InvalidModelExceptionDetail(nameof(BooksRidersRequest.ResponseId), new ArgumentException("Response Id is missing."));
		}
	}
}
