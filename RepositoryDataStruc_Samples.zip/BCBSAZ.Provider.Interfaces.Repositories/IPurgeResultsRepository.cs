﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IPurgeResultsRepository
	{
		Task PurgeClaimsResultsAsync(int days);
		Task PurgeEligibilityInquiryResultsAsync(int days);
	}
}
