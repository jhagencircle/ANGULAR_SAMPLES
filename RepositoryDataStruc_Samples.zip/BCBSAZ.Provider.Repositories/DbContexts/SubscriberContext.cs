﻿using BCBSAZ.Provider.Models.Data.ClaimsDetails;
using BCBSAZ.Provider.Models.Data.Subscriber;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface ISubscriberContext : IDbContext
	{
		/// <summary>
		/// Gets the DbSet object for Provider Tax Ids
		/// </summary>
		DbSet<ValidatePatient> Patient { get; }
		DbSet<PatientInfo> GetPatientAddress { get; }
	}

	public class SubscriberContext : DbContext, ISubscriberContext
	{
		/// <summary>
		/// Creates a new instance of the FeeSched DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public SubscriberContext(DbContextOptions<SubscriberContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			/******************** Property Configs ********************/
			modelBuilder.Entity<ValidatePatient>().HasNoKey();
			modelBuilder.Entity<PatientInfo>().HasNoKey();
		}

		/// <summary>
		/// Gets the DbSet object for Provider Tax Ids
		/// </summary>
		public DbSet<ValidatePatient> Patient { get; protected set; }

		public DbSet<PatientInfo> GetPatientAddress { get; protected set; }
	}
}
