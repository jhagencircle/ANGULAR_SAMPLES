﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Security;

namespace BCBSAZ.Provider.Managers.RequestValidators.Security
{
	internal static class AuthenticateUserRequestValidator
	{
		public static void Validate(this AuthenticateUserRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetVoilations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetVoilations(AuthenticateUserRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.UserId))
				yield return new InvalidModelExceptionDetail(nameof(AuthenticateUserRequest.UserId), new ArgumentException("User Id is missing."));
		}
	}
}
