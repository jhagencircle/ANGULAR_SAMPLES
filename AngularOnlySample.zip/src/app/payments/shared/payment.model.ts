export interface IPayment {
  tokenId: number;
  accountId: string;
  billId?: number;
  paymentTransactionDate: string;
  paymentAmount: number;
  billFromDate: string;
  billToDate: string;
}
