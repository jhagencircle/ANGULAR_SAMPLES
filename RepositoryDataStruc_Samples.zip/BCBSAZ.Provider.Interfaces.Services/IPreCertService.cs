﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.PreCert;
using BCBSAZ.Provider.Models.Requests.PreCert;
using BCBSAZ.Provider.Models.Responses.PreCert;
using BCBSAZ.Provider.WebUI.Models.Responses.PreCert;
using Microsoft.AspNetCore.Mvc;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface IPreCertService
	{

		Task<SaveFileResponse> SaveFileAsync(UploadedFile file);

		Task<GetMedicalPreCertResponseUI> GetMedicalPreCertAsync(long preCertId);

		Task<SaveMedicalPreCertResponse> SaveMedicalPreCertAsync(SaveMedicalPreCertRequest request);

		Task<CancelMedicalPreCertResponse> CancelMedicalPreCert(long preCertId);


		Task<GetPharmacyPreCertResponseUI> GetPharmacyPreCertAsync(long preCertId);

		Task<SavePharmacyPreCertResponse> SavePharmacyPreCertAsync(SavePharmacyPreCertRequest request);

		Task<CancelPharmacyPreCertResponse> CancelPharmacyPreCert(long preCertId);

		Task<ViewMedicalPreCertsResponse> ViewMedicalPrecertsAsync(int status, DateTime fromDate, DateTime toDate);

		Task<ViewPharmacyPreCertsResponse> ViewPharmacyPrecertsAsync(int status, DateTime fromDate, DateTime toDate);

		Task<DownloadFileResponse> MedicalDownloadFile(DownloadFileRequest request);
		Task<DownloadFileResponse> PharmacyDownloadFile(DownloadFileRequest request);
	}
}
