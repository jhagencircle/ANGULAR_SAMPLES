export class Autopay {
  constructor(init?: Partial<Autopay>) {
    Object.assign(this, init);
  }
  paymentToken: string;
  accountId: string;
  accountName: string;
  bankName: string;
  paymentAmont: string;
  paymentDate: string;
  paymentStatus: string;
  isForAutopay: boolean;
  status: string;
  isEdit?: boolean;
}
