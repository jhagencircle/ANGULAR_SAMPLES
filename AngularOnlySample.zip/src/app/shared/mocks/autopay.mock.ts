import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class AutopayMock {
  private autopayments = new BehaviorSubject<any>(null);
  constructor() {}
  public static mockedAutoPayList = [
    {
      draftDate: '2021-06-01T07:00:00Z',
      accountId: '030855',
      accountName: 'State of Arizona',
      bankName: 'Wells Fargo',
      paymentStatus: 'Pending',
      paymentAmont: 'Total Billed',
      paymentDate: 'Statement Date',
    },
    {
      draftDate: '2021-06-01T07:00:00Z',
      accountId: '030855-001',
      accountName: 'State of Arizona Active',
      bankName: 'Bank of Springfield',
      paymentStatus: 'Processing',
      paymentAmont: 'Total Billed',
      paymentDate: 'Statement Date',
    },
    {
      draftDate: '2021-06-01T07:00:00Z',
      accountId: '030855-003',
      accountName: 'State of Arizona Retiree',
      bankName: 'Bank of Springfield',
      paymentStatus: '',
      paymentAmont: 'Total Billed',
      paymentDate: 'Statement Date',
    },
    {
      draftDate: '2021-06-01T07:00:00Z',
      accountId: '030855-003-001',
      accountName: '01 State of Arizona Retiree No Medicare',
      bankName: 'Mesa Verde',
      paymentStatus: '',
      paymentAmont: 'Total Billed',
      paymentDate: 'Statement Date',
    },
    {
      draftDate: '2021-06-01T07:00:00Z',
      accountId: '030855-001-003',
      accountName: 'State of Arizona UA',
      bankName: 'Bank of Springfield',
      paymentStatus: '',
      paymentAmont: 'Total Billed',
      paymentDate: 'Statement Date',
    },
  ];

  getList(): Observable<any[]> {
    return of(AutopayMock.mockedAutoPayList);
  }
  delete(): Observable<boolean> {
    return of(true);
  }
  enroll(autopayment: any): Observable<any> {
    return of(true);
  }

  cancel(accountId: string): Observable<any> {
    return of(true);
  }
  get(): Observable<any[]> {
    return this.autopayments.asObservable();
  }
  update(autopayments: any[]) {
    this.autopayments.next(autopayments);
  }
}
