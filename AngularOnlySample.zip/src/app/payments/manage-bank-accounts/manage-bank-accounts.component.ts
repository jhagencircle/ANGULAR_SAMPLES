import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-bank-accounts',
  templateUrl: './manage-bank-accounts.component.html',
  styleUrls: ['./manage-bank-accounts.component.scss'],
})
export class ManageBankAccountsComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
