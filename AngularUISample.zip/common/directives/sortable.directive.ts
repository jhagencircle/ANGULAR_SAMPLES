import { Directive, EventEmitter, HostBinding, HostListener, Input, Output } from '@angular/core';
import { IFinancialManagerUser } from 'src/app/models/financial-manager-user/financial-manager-user.interface';


export type SortColumn = keyof IFinancialManagerUser | '';
export type SortDirection = 'asc' | 'desc' | '';
const rotate: {[key: string]: SortDirection} = { asc: 'desc', desc: '', '': 'asc' };


export interface SortEvent {
  column: SortColumn;
  direction: SortDirection;
}

@Directive({
  selector: '[appSortable]',
  host: {
    '[class.asc]': 'direction === "asc"',
    '[class.desc]': 'direction === "desc"'
  }
})
export class SortableDirective {

  @Input() appSortable: SortColumn = '';
  @Input() direction: SortDirection = '';
  @Output() sort = new EventEmitter<SortEvent>();

  @HostListener('click') onClick(): void{
    this.rotate();
  }

  rotate(): void {
    this.direction = rotate[this.direction];
    this.sort.emit({column: this.appSortable, direction: this.direction});
  }
}
