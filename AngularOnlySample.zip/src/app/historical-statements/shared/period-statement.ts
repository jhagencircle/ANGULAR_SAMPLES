import { IStatement } from './statement.model';

export interface IPeriodStatement {
  billingPeriodFromDate: Date;
  billingPeriodToDate: Date;
  statements: IStatement[];
  expanded: boolean;
}
