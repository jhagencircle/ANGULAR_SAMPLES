export class ValidationRegex {
    public static readonly TEN_DIGITS_PHONE_NUMBER: RegExp = /^[0-9]{10}$/;
    public static readonly NUMERIC_ONLY: RegExp = /^[0-9]*$/;
    public static readonly ALPHA_NUMERIC_SPACE_APOSTROPHE: RegExp = /^[A-Za-z-A-Za-zA-Za-z0-9 A-Za-zA-Za-z'A-Za-z0-9]*[A-Za-z0-9]+$/;
}
