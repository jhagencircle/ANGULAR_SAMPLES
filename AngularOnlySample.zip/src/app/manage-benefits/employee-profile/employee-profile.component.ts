import { Component, OnDestroy, OnInit } from '@angular/core';
import { OverlaySidePanelService } from 'src/app/shared/components/overlay-side-panel/overlay-side-panel.service';
import { IEmployee } from '../shared/models/employee.model';
import { EmployeeService } from '../shared/employee.service';
import { SpinnerService } from '../../shared/components/spinner/spinner.service';
import { EmployeeProfileService } from '../shared/employee-profile.service';
import {
  ISubscriber,
  IProducts,
  IContactInformation,
  IAddress,
} from '../shared/models';
import { IProfileRoster } from '../shared/models/profile-roster.model';
import { AppConstants } from '../../shared/constants/app-constants';
import { Subscription } from 'rxjs';
import { ISummary } from 'src/app/shared/models/summary.model';
import { AccountService } from 'src/app/shared/services/account.service';
import { AccountLevelEnum } from 'src/app/shared/enums/account-level-enum';

@Component({
  selector: 'app-employee-profile',
  templateUrl: './employee-profile.component.html',
  styleUrls: ['./employee-profile.component.scss'],
})
export class EmployeeProfileComponent implements OnInit, OnDestroy {
  employee: IEmployee;
  pendingChanges: boolean;
  changeBox: any = [];
  loading: boolean = false;
  subscriber: ISubscriber;
  products: IProducts[] = [];
  membreProfile: IProfileRoster;
  contactInformation: IContactInformation;
  address: IAddress[] = [];
  subscriptions: Subscription[] = [];
  account: ISummary;
  mainAccount: ISummary;

  constructor(
    public overlaySidePanelService: OverlaySidePanelService,
    public employeeService: EmployeeService,
    private _spinnerService: SpinnerService,
    private employeeProfileService: EmployeeProfileService,
    private accountService: AccountService
  ) {
    this.pendingChanges = false;
  }

  ngOnInit(): void {
    document.body.style.overflow = 'hidden';

    this.employee = this.employeeService.employee;
    let hasChangedSubscription = this.employeeProfileService
      .hasChanged()
      .subscribe((hasChanged) => (this.pendingChanges = hasChanged));

    let profileSubscription = this.employeeProfileService
      .get()
      .subscribe((data) => {
        this.membreProfile = data;
      });
    this.getEmployeeRosterAccount();
    this.getMainAccount();
    this.subscriptions.push(hasChangedSubscription);
    this.subscriptions.push(profileSubscription);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  getEmployeeRosterAccount() {
    const account = localStorage.getItem(
      AppConstants.EMPLOYEE_ROSTER_ACCOUNT_LOCAL_STORAGE_KEY
    );
    if (account) {
      this.account = JSON.parse(account);
    }
  }

  getMainAccount() {
    //it is the user account
    let subscription = this.accountService
      .get()
      .subscribe((account: ISummary) => {
        if (account) {
          this.mainAccount = account;
        }
      });
    this.subscriptions.push(subscription);
  }

  public closePanel(): void {
    this.employeeProfileService.cancel();
    document.body.style.removeProperty('overflow');
    this.overlaySidePanelService.close();
  }

  save() {
    this.membreProfile.topAccountId = this.mainAccount.accountId;
    this.membreProfile.billId = this.account.billId;
    this.membreProfile.receivedDate = new Date();
    if (this.membreProfile.terminateCoverage === null) {
      this.setSubscriber();
      this.setContact();
      this.membreProfile.subscriber = this.subscriber;
      this.membreProfile.contact = this.contactInformation;
      this.membreProfile.receivedDate = new Date();
      this.employeeProfileService.update(this.membreProfile);
    }

    let subscription = this.employeeProfileService
      .save()
      .subscribe((response) => {
        console.log(response);
      });
    this.overlaySidePanelService.reportChanges(true);
    this.closePanel();
    this._spinnerService.show(true);
    setTimeout(
      (spinnerService: SpinnerService) => {
        spinnerService.show(false);
      },
      2000,
      this._spinnerService
    );
    this.subscriptions.push(subscription);
  }

  setSubscriber() {
    let subAccount = JSON.parse(
      localStorage.getItem(
        AppConstants.EMPLOYEE_ROSTER_ACCOUNT_LOCAL_STORAGE_KEY
      ) || ''
    );
    this.employee.benefitSelection.planSelection.forEach((item) => {
      this.products.push({
        effectiveDate: null,
        planType: item.type,
        hccPlanId: null,
        subAccountNumber: subAccount.accountId,
        requiredStartDate: new Date(),
      });
    });
    this.subscriber = {
      isDependent: false,
      memberId: this.employee.memberId,
      lastName: this.employee.lastName,
      dependentType: null,
      middleName: null,
      firstName: this.employee.firstName,
      dateOfBirth: new Date(this.employee.dateOfBirth),
      ssn: this.employee.ssn,
      itin: null,
      foreignDocumentNumber: null,
      gender: this.employee.gender,
      medicareInformation: {
        medicareNumber: null,
        partAEffectiveDate: null,
        partBEffectiveDate: null,
        isElegible: null,
      },
      products: this.products,
      otherHealthPlanCoverage: {
        effectiveDate: null,
        groupNumber: null,
        productName: null,
        productId: null,
        policyHolderName: null,
        carrierPhone: null,
      },
      tobaccoUsage: false,
      lastTobaccoUseDate: null,
      preferredContactMethod: null,
      preferredLanguage: null,
      autoWithdrawalEnabled: false,
      maritalStatus: null,
      rateAreaId: null,
      rateCountyCode: null,
      dependent: this.employee.dependents.length > 0 ? true : false,
      operation: null,
      isSuccessOperation: null,
      removalReason: null,
    };
  }

  setContact() {
    if (this.employee.contactInformation.address !== null) {
      this.address.push({
        addressType: null,
        address1: null,
        address2: null,
        city: null,
        state: null,
        zip: null,
        county: null,
      });
    }

    this.contactInformation = {
      addresses: this.address,
      phoneNumbers: this.employee.contactInformation.phoneNumbers,
      email: this.employee.contactInformation.emailAddress,
    };
  }
}
