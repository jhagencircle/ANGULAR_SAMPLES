﻿using BCBSAZ.ProviderAuxiliaryPortal.Extensions;
using BCBSAZ.ProviderAuxiliaryPortal.Managers;
using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Configuration;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.ApiClients;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.ApiClient;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BCBSAZ.ProviderAuxiliaryPortal.WebAPI
{
    public static class ConfigureServicesStartup
    {
        public static void AddConfigurations(this IServiceCollection services, IConfiguration configuration)
        {
            // Configurations
            ConfigureAppSettings(services, configuration);


            // DBContexts        
            ConfigureDbContexts(services, configuration);


            // Api Clients
            ConfigureApiClients(services);


            // Repositories
            ConfigureRepositories(services);


            // Managers
            ConfigureManagers(services);
        }

        private static void ConfigureDbContexts(IServiceCollection services, IConfiguration configuration)
        {
            var connectionStrs = GetConnectionStrDictionary(configuration);

            services.AddDbContext<EmailContext>(connectionStrs["Email"]);
            services.AddDbContext<ProviderInetContext>(connectionStrs["ProviderInet"]);
            services.AddDbContext<ProviderEftDbContext>(connectionStrs["ProviderEFT"]); //Change to ProviderEFT
        }


        private static void ConfigureAppSettings(IServiceCollection services, IConfiguration configuration)
        {
            services.AddConfiguration<ApoDatabaseConfiguration>(configuration);
            services.AddConfiguration<EmailConfiguration>(configuration);
            services.AddConfiguration<ProviderEftConfiguration>(configuration);


        }


        private static void ConfigureRepositories(IServiceCollection services)
        {
            services.AddScoped<IEmailRepository, EmailRepository>();
            services.AddScoped<IUserProfileRepository, UserProfileRepository>();            
            services.AddScoped<IEftEnrollmentRepository, EftEnrollmentRepository>();
        }


        private static void ConfigureManagers(IServiceCollection services)
        {
            services.AddScoped<IEmailManager, EmailManager>();
            services.AddScoped<IUserProfileManager, UserProfileManager>();            
            services.AddScoped<IEftEnrollmentManager, EftEnrollmentManager>();
            services.AddScoped<ILoggingManager, LoggingManager>();
        }

        private static void ConfigureApiClients(IServiceCollection services)
        {
            services.AddScoped<IEmailClient, EmailClient>();
        }

        private static Dictionary<string, string> GetConnectionStrDictionary(IConfiguration configuration)
        {
            var connectionStrDictionary = new Dictionary<string, string>();

            var apoDbConfiguration = configuration.GetSection(nameof(ApoDatabaseConfiguration)).Get<ApoDatabaseConfiguration>();
            
            var providerEftConfiguration = configuration.GetSection(nameof(ProviderEftConfiguration)).Get<ProviderEftConfiguration>();

            using var context = ApoContext.CreateContextInstance(apoDbConfiguration.ConnectionString);            
                        
            var connectionStrs = context.ConfigSettings.Where(x => x.Environment == apoDbConfiguration.Environment && apoDbConfiguration.InqueryDdNameList.EmptyIfNull().Contains(x.Name)).ToList();

            connectionStrs.ForEach(x => connectionStrDictionary.Add(x.Name, x.Value));

            connectionStrDictionary.Add(providerEftConfiguration.InqueryDdNameList[0], providerEftConfiguration.ConnectionString);

            return connectionStrDictionary;
        }
    }
}
