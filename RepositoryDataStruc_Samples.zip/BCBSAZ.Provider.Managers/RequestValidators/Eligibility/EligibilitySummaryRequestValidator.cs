﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;

namespace BCBSAZ.Provider.Managers.RequestValidators.Eligibility
{
	internal static class EligibilitySummaryRequestValidator
	{
		public static void Validate(this EligibilitySummaryRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(EligibilitySummaryRequest request)
		{
			if (request.ResponseId == 0)
				yield return new InvalidModelExceptionDetail(nameof(EligibilitySummaryRequest.ResponseId), new ArgumentException("Response Id is missing."));
		}
	}
}
