﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Settings;
using BCBSAZ.Provider.Models.Exceptions;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Repositories
{
	public class SettingsRepository : ISettingsRepository
	{
		private readonly ISettingsContext _settingsContext;
		private readonly ILogger _logger;
		private readonly IHttpContextAccessor _contextAccessor;

		public SettingsRepository(ISettingsContext settingsContext, ILogger<SettingsRepository> logger, IHttpContextAccessor contextAccessor)
		{
			_settingsContext = settingsContext;
			_logger = logger;
			_contextAccessor = contextAccessor;
		}

		#region Application Lookup

		private static readonly Dictionary<string, int> _applications = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

		private async Task<int> LookupApplicationIdAsync(string applicationName)
		{
			if (_applications.ContainsKey(applicationName))
				return _applications[applicationName];

			var application = await (
				from sa in _settingsContext.SettingApplications
				where sa.Name == applicationName
				select sa
				).FirstOrDefaultAsync();

			if (application == null)
			{
				application = new SettingApplication()
				{
					Name = applicationName,
					Description = applicationName
				};

				await _settingsContext.SettingApplications.AddAsync(application);
				await _settingsContext.SaveChangesAsync();
			}

			_applications[application.Name] = application.SettingApplicationId;

			return application.SettingApplicationId;
		}

		#endregion

		#region Setting Values

		public async Task<SettingValue> GetSettingValueAsync(string applicationName, string settingName, string fieldName, string fieldValue, string userId, string defaultValue)
		{
			try
			{
				var settingApplicationId = await LookupApplicationIdAsync(applicationName);

				var setting = await (
					from s in _settingsContext.Settings
					where
						s.Name == settingName &&
						s.SettingApplicationId == settingApplicationId
					select s).FirstOrDefaultAsync();

				if (setting == null)
				{
					setting = new Setting()
					{
						SettingApplicationId = settingApplicationId,
						Name = settingName,
						Description = settingName,
						SettingTypeId = Constants.Settings.DefaultSettingType,
						DefaultValue = defaultValue
					};

					await _settingsContext.Settings.AddAsync(setting);
					await _settingsContext.SaveChangesAsync();
				}

				var userSetting = string.IsNullOrWhiteSpace(userId) ? null : (
					from u in setting.UserSettings
					where u.UserId.Equals(userId, StringComparison.OrdinalIgnoreCase)
					select u).FirstOrDefault();

				var userTypeSetting = string.IsNullOrWhiteSpace(fieldName) ? null : (
					from ut in setting.UserTypeSettings
					where
						ut.FieldName.Equals(fieldName, StringComparison.OrdinalIgnoreCase) &&
						ut.FieldValue.Equals(fieldValue, StringComparison.OrdinalIgnoreCase)
					select ut).FirstOrDefault();

				return new SettingValue()
				{
					SettingId = setting.SettingId,
					Name = setting.Name,
					Value = userSetting?.Value ?? userTypeSetting?.SettingValue ?? setting.DefaultValue
				};
			}
			catch(Exception ex)
			{
				_logger.LogError(-1, ex, _contextAccessor?.HttpContext, $"Error retrieving setting '{settingName}': {ex.Message}");

				return new SettingValue()
				{
					Name = settingName,
					Value = defaultValue
				};
			}
		}

		#endregion

		#region Settings

		public async Task<IEnumerable<Setting>> GetSettingsForApplicationAsync(string applicationName, int settingTypeId)
		{
			var settingApplicationId = await LookupApplicationIdAsync(applicationName);

			return await (
				from setting in _settingsContext.Settings
				where
					setting.SettingApplicationId == settingApplicationId &&
					((settingTypeId == 0) || (setting.SettingTypeId == settingTypeId))
				select setting
				).ToArrayAsync();
		}

		public async Task<Setting> GetSettingAsync(int settingId) =>
			await (
				from setting in _settingsContext.Settings
				where setting.SettingId == settingId
				select setting).FirstOrDefaultAsync();

		public async Task<Setting> AddSettingAsync(Setting setting)
		{
			await _settingsContext.Settings.AddAsync(setting);
			await _settingsContext.SaveChangesAsync();

			return setting;
		}

		public async Task<Setting> UpateSettingAsync(Setting setting)
		{
			var existing = await GetSettingAsync(setting.SettingId);

			if (existing == null)
				throw new RecordNotFoundException();

			existing.Name = setting.Name;
			existing.Description = setting.Description;
			existing.SettingTypeId = setting.SettingTypeId;
			existing.DefaultValue = setting.DefaultValue;

			await _settingsContext.SaveChangesAsync();

			return existing;
		}

		public async Task DeleteSettingAsync(int settingId)
		{
			var existing = await GetSettingAsync(settingId);

			if (existing == null)
				throw new RecordNotFoundException();

			_settingsContext.UserSettings.RemoveRange(existing.UserSettings);
			_settingsContext.UserTypeSettings.RemoveRange(existing.UserTypeSettings);
			_settingsContext.Settings.Remove(existing);

			await _settingsContext.SaveChangesAsync();
		}

		#endregion

		#region User Type Settings

		public async Task<IEnumerable<UserTypeSetting>> GetAllUserTypeSettingsAsync(int settingId) =>
			await (
				from uts in _settingsContext.UserTypeSettings
				where uts.SettingId == settingId
				select uts).ToArrayAsync();

		public async Task<UserTypeSetting> GetUserTypeSettingAsync(int userTypeSettingId) =>
			await (
			from uts in _settingsContext.UserTypeSettings
			where uts.UserTypeSettingId == userTypeSettingId
			select uts).FirstOrDefaultAsync();

		public async Task<UserTypeSetting> AddUserTypeSettingAsync(UserTypeSetting userTypeSetting)
		{
			await _settingsContext.UserTypeSettings.AddAsync(userTypeSetting);
			await _settingsContext.SaveChangesAsync();

			return userTypeSetting;
		}

		public async Task<UserTypeSetting> UpdateUserTypeSettingsAsync(UserTypeSetting userTypeSetting)
		{
			var existing = await GetUserTypeSettingAsync(userTypeSetting.UserTypeSettingId);

			if (existing == null)
				throw new RecordNotFoundException();

			existing.FieldName = userTypeSetting.FieldName;
			existing.FieldValue = userTypeSetting.FieldValue;
			existing.SettingValue = userTypeSetting.SettingValue;

			await _settingsContext.SaveChangesAsync();

			return existing;
		}

		public async Task DeleteUserTypeSettingAsync(int userTypeSettingId)
		{
			var existing = await GetUserTypeSettingAsync(userTypeSettingId);

			if (existing == null)
				throw new RecordNotFoundException();

			_settingsContext.UserTypeSettings.Remove(existing);
			await _settingsContext.SaveChangesAsync();
		}

		#endregion

		#region User Settings

		public async Task<IEnumerable<UserSetting>> GetAllUserSettingsAsync(int settingId) =>
			await (
				from us in _settingsContext.UserSettings
				where us.SettingId == settingId
				select us).ToArrayAsync();


		public async Task<UserSetting> GetUserSettingAsync(int userSettingId) =>
			await (
			from us in _settingsContext.UserSettings
			where us.UserSettingId == userSettingId
			select us).FirstOrDefaultAsync();

		public async Task<UserSetting> AddUserSettingAsync(UserSetting userSetting)
		{
			await _settingsContext.UserSettings.AddAsync(userSetting);
			await _settingsContext.SaveChangesAsync();

			return userSetting;
		}

		public async Task<UserSetting> UpdateUserSettingsAsync(UserSetting userSetting)
		{
			var existing = await GetUserSettingAsync(userSetting.UserSettingId);

			if (existing == null)
				throw new RecordNotFoundException();

			existing.UserId = userSetting.UserId;
			existing.Value = userSetting.Value;

			await _settingsContext.SaveChangesAsync();

			return existing;
		}

		public async Task DeleteUserSettingAsync(int userSettingId)
		{
			var existing = await GetUserSettingAsync(userSettingId);

			if (existing == null)
				throw new RecordNotFoundException();

			_settingsContext.UserSettings.Remove(existing);
			await _settingsContext.SaveChangesAsync();
		}

		#endregion

		#region Setting Types

		public async Task<IEnumerable<SettingType>> GetSettingTypesAsync() =>
			await (
				from st in _settingsContext.SettingTypes
				select st).ToArrayAsync();

		#endregion

		#region Setting Applications

		public async Task<IEnumerable<SettingApplication>> GetSettingApplicationsAsync() =>
			await (
				from sa in _settingsContext.SettingApplications
				select sa).ToArrayAsync();

		public async Task<SettingApplication> UpdateSettingApplicationAsync(SettingApplication application)
		{
			var existing = await (
				from sa in _settingsContext.SettingApplications
				where sa.SettingApplicationId == application.SettingApplicationId
				select sa).FirstOrDefaultAsync();

			if (existing == null)
				throw new RecordNotFoundException();

			existing.Description = application.Name;
			await _settingsContext.SaveChangesAsync();

			return existing;
		}

		#endregion


	}
}
