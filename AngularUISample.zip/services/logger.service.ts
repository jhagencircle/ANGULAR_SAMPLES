import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OktaAuthService } from '@okta/okta-angular';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {

  constructor(public oktaAuth: OktaAuthService, private http: HttpClient) {
  }

  url = `${environment.apiBaseUrl}/logging`;

  logInformation(message: string, source: string, additionalInformation?: any) {
    this.log(message, LogLevel.Information, source, additionalInformation);
  }

  logWarning(message: string, source: string, additionalInformation?: any) {
    this.log(message, LogLevel.Warning, source, additionalInformation);
  }

  logError(message: string, source: string, additionalInformation?: any) {
    this.log(message, LogLevel.Error, source, additionalInformation);
  }

  logFatal(message: string, source: string, additionalInformation?: any) {
    this.log(message, LogLevel.Fatal, source, additionalInformation);
  }

  private log(message: string, level: LogLevel, source: string, additionalInformation?: any) {
    this.getUserDetails().then((user) => {
      let request: ILoggerRequest = {
        message: message,
        level: level,
        additionalInformation: this.getAdditionalInformation(additionalInformation),
        userId: user,
        source: `Provider.AuxiliaryPortal.UI.${source}`
      };

      this.post(request).subscribe();
    });
  }

  private async getUserDetails() {
    let user: string = 'Anonymous';
    const isAuthenticated = await this.oktaAuth.isAuthenticated();
    const accessTokenExists = this.oktaAuth.getAccessToken() !== undefined;

    if (isAuthenticated && accessTokenExists) {
      var userInfo = await this.oktaAuth.getUser();
      user = `Name:${userInfo.name} Email:${userInfo.email} sub:${userInfo.sub}`
    }

    return user;
  }

  private getAdditionalInformation(additionalInformation?: any): string {
    let additional = '';
    if (additionalInformation !== undefined)
      additional = JSON.stringify(additionalInformation);
    return additional;
  }

  private post(request: ILoggerRequest): Observable<any> {
    return this.http.post(this.url, request);
  }
}

export interface ILoggerRequest {
  level: LogLevel;
  message: string;
  additionalInformation: string;
  userId: string;
  source: string;
}

enum LogLevel {
  Information = 0,
  Warning = 1,
  Error = 2,
  Fatal = 3
}
