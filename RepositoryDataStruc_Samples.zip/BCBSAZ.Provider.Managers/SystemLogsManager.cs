﻿using System;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Managers.RequestValidators.SystemLogsManager;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.Logger;
using BCBSAZ.Provider.Models.Responses.Common;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Managers
{
	public class SystemLogsManager : ISystemLogsManager, ILogMessageStorage
	{
		private readonly ISystemLogsRepository _repository;
		private readonly LogMessageQueue _logMessages;

		public SystemLogsManager(ISystemLogsRepository repository, LogMessageQueue logMessages)
		{
			_repository = repository;
			_logMessages = logMessages;
		}

		public VoidResponse InsertLogMessage(InsertLogMessageRequest request)
		{
			request.Validate();

			// Use the LogMessageQueue to avoid issues with multiple threads hitting the SystemLogsDbContext
			_logMessages.Enqueue(request.Message);

			return new VoidResponse();
		}

		public Task StoreAsync(LogMessage logMessage)
		{
			try
			{
				return _repository.InsertLogMessageAsync(logMessage);
			}
			catch
			{
				return Task.CompletedTask;
			}
		}
	}
}
