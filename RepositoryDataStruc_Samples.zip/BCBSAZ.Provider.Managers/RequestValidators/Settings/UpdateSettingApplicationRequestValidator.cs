﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Settings;

namespace BCBSAZ.Provider.Managers.RequestValidators.Settings
{
	internal static class UpdateSettingApplicationRequestValidator
	{
		public static void Validate(this UpdateSettingApplicationRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(UpdateSettingApplicationRequest request)
		{
			if (request.Application == null)
				yield return new InvalidModelExceptionDetail(nameof(UpdateSettingApplicationRequest.Application), new ArgumentException("Setting is missing."));

			if (request.Application.SettingApplicationId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(UpdateSettingApplicationRequest.Application.SettingApplicationId), new ArgumentException("Invalid SettingApplicationId specified."));

			var context = new ValidationContext(request.Application);
			var results = new List<ValidationResult>();

			if (!Validator.TryValidateObject(request.Application, context, results))
			{
				foreach (var result in results)
				{
					yield return new InvalidModelExceptionDetail(result.MemberNames.FirstOrDefault() ?? nameof(UpdateSettingApplicationRequest.Application), new ArgumentException(result.ErrorMessage));
				}
			}
		}
	}
}
