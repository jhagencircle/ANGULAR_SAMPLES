﻿/// <binding AfterBuild='default' ProjectOpened='watch' />

var gulp = require("gulp"),
	concat = require("gulp-concat"),
	print = require("gulp-print").default,
	sass = require("gulp-sass");


gulp.task("default", function () {
	return gulp.src("wwwroot/ClientSrc/**/*.scss")
		.pipe(print())
		.pipe(sass())
		.pipe(concat("provider_cred.css"))
		.pipe(gulp.dest("wwwroot/css/gen"));
});


//run this task to tell gulp to compile css when you save any .scss file in wwwroot, it is set up to run when the project first opens
gulp.task('watch', function () {
	gulp.watch('wwwroot/ClientSrc/**/*.scss', gulp.series('default'));
});