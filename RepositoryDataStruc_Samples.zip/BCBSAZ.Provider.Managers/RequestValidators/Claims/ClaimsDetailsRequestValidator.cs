﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.ClaimsDetails;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.Claims
{
	internal static class ClaimsDetailsRequestValidator
	{
		public static void Validate(this ClaimDetailsHeaderRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new UnauthorizedAccessException();

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(ClaimDetailsHeaderRequest request)
		{
			if (request.RequestId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(ClaimDetailsHeaderRequest), new ArgumentException("Not a Valid RequestId."));
		}
	}
}
