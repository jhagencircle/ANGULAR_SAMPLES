﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IPatientRepository
	{
		Task<IEnumerable<Patient>> SearchPatientsAsync(string orgId, string subscriberId, int pageNumber, int pageSize);

		Task<int> GetPatientsCountAsync(string orgId, string subscriberId);
	}
}
