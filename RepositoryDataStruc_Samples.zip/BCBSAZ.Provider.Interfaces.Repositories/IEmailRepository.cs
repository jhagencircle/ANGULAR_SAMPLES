﻿using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IEmailRepository
	{
		Task QueueEmailAsync(string toAddress, string fromAddress, string subject, string body);
	}
}
