import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { ISummary } from 'src/app/shared/models/summary.model';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { AccountLevelEnum } from 'src/app/shared/enums/account-level-enum';

@Component({
  selector: 'app-account-banner',
  templateUrl: './account-banner.component.html',
  styleUrls: ['./account-banner.component.scss'],
})
export class AccountBannerComponent implements OnInit {
  @Input() account: ISummary;
  @Input() checkAll: boolean;
  @Input() accountLevel: string;
  @Input() billingLevel: string;
  @Input() subscriptionLevel: string;
  accountLevelEnum = AccountLevelEnum;

  @Output() selectedSubaccounts = new EventEmitter<any>();

  constructor(private router: Router) {}

  ngOnInit(): void {}

  onSelectChange() {
    this.account.isChecked =
      this.account.isChecked === undefined ? true : !this.account.isChecked;
    this.selectedSubaccounts.emit(this.account);
  }

  displaySubSubAccounts() {
    this.account.isSubSubAccountsDisplayed =
      !this.account.isSubSubAccountsDisplayed;
  }

  goToHistoricalStatements() {
    this.router.navigate(['/historical-statements']);
  }
  goToEmployeeRoster(account: ISummary) {
    if (account) {
      localStorage.setItem(
        AppConstants.EMPLOYEE_ROSTER_ACCOUNT_LOCAL_STORAGE_KEY,
        JSON.stringify(account)
      );
      this.router.navigate(['/manage-benefits']);
    }
  }
}
