import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { EmployeeProfileService } from './employee-profile.service';
import { IProfileRoster } from './models/profile-roster.model';

describe('EmployeeProfileService', () => {
  let service: EmployeeProfileService;
  let httpClientSpy: {
    get: jasmine.Spy;
    delete: jasmine.Spy;
    post: jasmine.Spy;
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });

    service = TestBed.inject(EmployeeProfileService);
    httpClientSpy = jasmine.createSpyObj('HttpClient', [
      'get',
      'delete',
      'post',
    ]);

    service = new EmployeeProfileService(httpClientSpy as any);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should add', () => {
    httpClientSpy.post.and.returnValue(of(true));

    service.save().subscribe((result) => expect(result).toBeTruthy, fail);
    expect(httpClientSpy.post.calls.count()).toBe(1);
  });
});
