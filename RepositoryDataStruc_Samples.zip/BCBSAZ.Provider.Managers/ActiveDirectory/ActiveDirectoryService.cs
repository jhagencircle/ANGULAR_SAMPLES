﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using BCBSAZ.Provider.Interfaces.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Managers.ActiveDirectory
{
	public class ActiveDirectoryService : IActiveDirectoryService
	{
		private readonly GroupConfig _configuration;
		private const string _configSection = "Groups";

		public ActiveDirectoryService(IConfiguration configuration)
		{
			_configuration = configuration.GetSection(_configSection).Get<GroupConfig>();
		}

		public Role[] GetInternalUserInfoAndRoles(WebUser webUser, ref string email)
		{
			if (webUser == null)
				throw new ArgumentNullException(nameof(webUser));

			if (webUser.UserType != UserType.Internal)
				return new Role[0];

#if DEBUG
			if (webUser.UserId.Equals("CORP\\Internal", StringComparison.OrdinalIgnoreCase))
			{
				return new Role[]
				{
					Constants.ADGroup.Roles.PreCertMedical,
					Constants.ADGroup.Roles.PreCertPharmacy
				};
			}
#endif

			using (var context = new PrincipalContext(ContextType.Domain))
			{
				var userPrincipal = UserPrincipal.FindByIdentity(context, webUser.UserId);

				if (userPrincipal != null)
				{
					if (string.IsNullOrWhiteSpace(webUser.FirstName))
						webUser.FirstName = userPrincipal.GivenName;

					if (string.IsNullOrWhiteSpace(webUser.LastName))
						webUser.LastName = userPrincipal.Surname;

					if (string.IsNullOrWhiteSpace(email))
						email = userPrincipal.EmailAddress;

					return GetRoles(webUser, userPrincipal.GetAuthorizationGroups()).ToArray();
				}
			}

			return new Role[0];
		}

		private IEnumerable<Role> GetRoles(WebUser webUser, PrincipalSearchResult<Principal> groupPrincipals)
		{
			if ((
			from gp in groupPrincipals
			where gp.Guid.HasValue && gp.Guid.Value == _configuration.TeamPhoenix
			select gp).Any())
			{
				webUser.UserType = UserType.TeamPhoenix;
				yield return Constants.ADGroup.Roles.PreCertMedical;
				yield return Constants.ADGroup.Roles.PreCertPharmacy;
			}
			else
			{
				if ((
					from gp in groupPrincipals
					where gp.Guid.HasValue && _configuration.Medical.Contains(gp.Guid.Value)
					select gp).Any())
				{
					yield return Constants.ADGroup.Roles.PreCertMedical;
				}

				if ((
					from gp in groupPrincipals
					where gp.Guid.HasValue && _configuration.Pharmacy.Contains(gp.Guid.Value)
					select gp).Any())
				{
					yield return Constants.ADGroup.Roles.PreCertPharmacy;
				}
			}
		}
	}
}
