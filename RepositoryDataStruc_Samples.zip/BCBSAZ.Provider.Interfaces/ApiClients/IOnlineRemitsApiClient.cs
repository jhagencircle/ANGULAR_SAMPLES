﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Remits;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface IOnlineRemitsApiClient
	{
		Task<IEnumerable<ProviderRemittance>> GetRemitsAsync(RemitSearchRequest request);
	}
}
