import { IProducts } from './products.model';

export interface ITerminationCoverage {
  subscriberId: string;
  accountNumber: string;
  products: IProducts[];
  terminationReason: string;
  receivedDate: string;
}
