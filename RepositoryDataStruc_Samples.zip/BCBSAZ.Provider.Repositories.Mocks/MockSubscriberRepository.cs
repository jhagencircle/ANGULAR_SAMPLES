﻿using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Subscriber;
using BCBSAZ.Provider.Models.Requests.Subscriber;
using BCBSAZ.Provider.Models.Responses.Subscriber;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Repositories.Mocks
{
	public class MockSubscriberRepository : Mock<ISubscriberRepository>, ISubscriberRepository
	{
		public MockSubscriberRepository() : this(GetIsMemberDelegatedMockData, GetIsPrefixOOAMockData) { }


		public MockSubscriberRepository(IEnumerable<bool> IsMemberDelegatedMockFunc, IEnumerable<bool> IsPrefixOOAMockFunc)
		{
			if (IsMemberDelegatedMockFunc != null)

			{

				Setup(mock => mock
						.IsMemberDelegatedAsync(It.Is<string>(r => r == "850187930")))
						.Returns(Task.FromResult(true));

				Setup(mock => mock
						.IsMemberDelegatedAsync(It.Is<string>(r => r == "456567678")))
						.Returns(Task.FromResult(false));
			}

			if (IsPrefixOOAMockFunc != null)

			{

				Setup(mock => mock
						.IsPrefixOOAAsync(It.Is<string>(r => r == "NNJ")))
						.Returns(Task.FromResult(false));

				Setup(mock => mock
						.IsPrefixOOAAsync(It.Is<string>(r => r == "RBX")))
						.Returns(Task.FromResult(true));

				Setup(mock => mock
						.IsPrefixOOAAsync(It.Is<string>(r => r == "R34")))
						.Returns(Task.FromResult(false));
			}


		}



		public Task<bool> IsMemberDelegatedAsync(string subscriberId)
		{
			return Object.IsMemberDelegatedAsync(subscriberId);
		}

		public Task<bool> IsPrefixOOAAsync(string subPrefix)
		{
			return Object.IsPrefixOOAAsync(subPrefix);//Task.FromResult((from p in MockIsPrefixOOA where p == subPrefix select p).FirstOrDefault());
		}

		public Patient[] GetPatients(string subscriberId, string firstName, string lastName, string ssn, DateTime dateOfBirth)
		{
			throw new NotImplementedException();
		}

		private static IEnumerable<bool> GetIsMemberDelegatedMockData
		{
			get
			{
				yield return true;
				yield return false;

			}
		}



		private static IEnumerable<bool> GetIsPrefixOOAMockData
		{
			get
			{
				yield return true;
				yield return false;

			}
		}

	}
}
