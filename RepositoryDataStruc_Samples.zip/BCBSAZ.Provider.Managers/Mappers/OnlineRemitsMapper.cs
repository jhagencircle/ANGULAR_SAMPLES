﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Remits;

namespace BCBSAZ.Provider.Managers.Mappers
{
	public class OnlineRemitsMapper
	{
		private const int FIRST_NAME_TOKEN_INDEX = 1;
		private const int LAST_NAME_TOKEN_INDEX = 0;

		internal static ProviderRemittanceRequest ConvertAPIRequest(RemitSearchRequest request)
		{
			ProviderRemittanceRequest convertedRequest = new ProviderRemittanceRequest();

			convertedRequest.PaymentStartDate = request.StatementStartDate;
			convertedRequest.PaymentEndDate = request.StatementEndDate;
			convertedRequest.ServiceStartDate = request.ServiceStartDate;
			convertedRequest.ServiceEndDate = request.ServiceEndDate;
			convertedRequest.TaxIds = GetTaxIds(request);
			convertedRequest.MemberId = request.ProviderMemberID ?? String.Empty;
			convertedRequest.PatientLastName = request.ProviderPatientLastName ?? String.Empty;
			convertedRequest.ClaimNumber = request.ProviderClaimNumber ?? String.Empty;
			convertedRequest.CheckNumber = String.Empty;
			convertedRequest.ClaimAmount = request.ClaimAmount?.ToString() ?? String.Empty;
			convertedRequest.CheckAmount = request.CheckAmount?.ToString() ?? String.Empty;
			
			return convertedRequest;
		}

		private static string[] GetTaxIds(RemitSearchRequest request)
		{
			var taxIdsString = String.IsNullOrWhiteSpace(request.TaxId) ? request.AvailableTaxIDs : request.TaxId;

			if (String.IsNullOrWhiteSpace(taxIdsString)) return new string[] { };

			var taxIds = taxIdsString.Split(',', StringSplitOptions.RemoveEmptyEntries);

			//format the taxId. The valid TaxID format for bridge API: 27-0036484
			for (int i = 0; i < taxIds.Length; i++)
			{
				taxIds[i] = taxIds[i].Trim().Insert(2, "-");
			}

			return taxIds;	
		}


		public static IEnumerable<ProviderRemittance> ConvertApiResponse(IEnumerable<ProviderRemittanceResponse> response)
		{
			if (response != null)
			{
				foreach (ProviderRemittanceResponse item in response)
				{
					ProviderRemittance remit = new ProviderRemittance();
					remit.ProviderTaxId = item.TaxId.Replace("-", String.Empty);
					remit.RemitSource = Models.Enums.RemitSource.VelocityApi;
					remit.StatementDate = CheckDateValue(item.PaymentDate);
					remit.StatementNumber = String.Empty;
					remit.CheckAmount = GetDecmimal(item.CheckAmount);
					remit.DocumentId = String.Empty;
					remit.FileName = String.Empty;
					remit.FileOffset = String.Empty;
					remit.RemitSource = Models.Enums.RemitSource.VelocityApi;
					remit.TransactionNumber = item.TransactionNumber;
					remit.CheckNumber = item.CheckNumber;

					foreach (RelatedClaim claim in item.RelatedClaims.EmptyIfNull().OrderBy(x=> x.ClaimNumber))
					{
						RemitClaim remitClaim = new RemitClaim();
						remitClaim.ClaimNumber = claim.ClaimNumber;
						remitClaim.MemberId = claim.SubscriberId;

						remitClaim.PatientFirstName = GetNameTokenByIndex(claim.PatientName, FIRST_NAME_TOKEN_INDEX);
						remitClaim.PatientLastName = GetNameTokenByIndex(claim.PatientName, LAST_NAME_TOKEN_INDEX);
						remitClaim.PatientName = claim.PatientName;
						remitClaim.ServiceDate = Convert.ToDateTime(claim.DateOfService, CultureInfo.CurrentCulture);
						remitClaim.ServiceProvider = claim.ServiceProviderFullName;
						remitClaim.ServiceProviderName = claim.ServiceProviderFullName;
						remitClaim.AmountPaid = GetDecmimal(claim.AmountPaid);
						remit.RemittanceClaimList.Add(remitClaim);
					}

					remit.TotalSumAmount = remit.RemittanceClaimList.IsNullOrEmpty() ? 0.00M : remit.RemittanceClaimList.Sum(x => x.AmountPaid);

					yield return remit;
				}
			}
		}
		
		#region Private Helper Methods

		private static string FormatDate(DateTime? providedDate)
		{
			if (providedDate.HasValue)
				return providedDate.Value.ToString("yyyy-MM-ddT00:00:00.000Z");

			return String.Empty;
		}

		private static string GetNameTokenByIndex(string patientName, int nameTokenIndex)
		{
			//PatientName come back last, first MI, Example: "LATSKO JR, JOHN J"

			if (String.IsNullOrWhiteSpace(patientName)) return String.Empty;

			var firstAndMiddleName = patientName.Contains(',') ? patientName.Split(',')[nameTokenIndex].Trim() : String.Empty;

			return firstAndMiddleName.Split(' ').First().Trim();
		}


		private static decimal GetDecmimal(string amount)
		{

			if (Decimal.TryParse(amount, out var number))
				return number;

			return 0.00M;
		}

		private static DateTime CheckDateValue(string itemDate)
		{
			if (DateTime.TryParse(itemDate, out var date))
				return date;

			return DateTime.MinValue;
		} 
		#endregion
	}
}
