﻿namespace BCBSAZ.ProviderCredentialing.Models.Data.Common
{
	public class VoidResult
	{
		// Purposefully Empty.
	}
}
