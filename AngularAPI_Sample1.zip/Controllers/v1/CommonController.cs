﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.WebAPI.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
        public readonly IWebHostEnvironment _webHostEnvironment;

        public CommonController(IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
        }

        [HttpGet("Environment")]
        public ActionResult GetEnvironment()
        {
            return Ok(_webHostEnvironment.EnvironmentName);
        }

        [HttpGet("Time")]
        public ActionResult GetTime()
        {
            return Ok(DateTime.Now);
        }


        [HttpGet("Version")]
        public ActionResult GetVersion()
        {
            return Ok(GetAssemblyVersion());
        }

        private string GetAssemblyVersion()
        {
            var assembly = typeof(CommonController).Assembly;
            var attr = CustomAttributeExtensions.GetCustomAttribute<AssemblyFileVersionAttribute>(assembly);

            return attr?.Version ?? string.Empty;
        }
    }
}
