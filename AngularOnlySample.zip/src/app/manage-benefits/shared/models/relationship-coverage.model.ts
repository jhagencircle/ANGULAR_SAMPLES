export interface IRelationshipCoverage {
  coverageID: string;
  coverage: any;
}
