﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.OfficeUserManagement;

namespace BCBSAZ.Provider.Managers.RequestValidators.OfficeUserManagement
{
	internal static class SetUserProviderRequestValidator
	{
		public static void Validate(this SetUserProvidersRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(SetUserProvidersRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.OrgId))
				yield return new InvalidModelExceptionDetail(nameof(SetUserProvidersRequest.OrgId), new ArgumentException("Invalid OrgId specified."));

			if (string.IsNullOrWhiteSpace(request.SubOrg))
				yield return new InvalidModelExceptionDetail(nameof(SetUserProvidersRequest.SubOrg), new ArgumentException("Invalid Sub Org specified."));

			if (string.IsNullOrWhiteSpace(request.UserId))
				yield return new InvalidModelExceptionDetail(nameof(SetUserProvidersRequest.UserId), new ArgumentException("Invalid UserId specified."));
		}
	}
}
