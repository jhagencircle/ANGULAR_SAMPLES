import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ITerminationReason } from './models/termination-reason.model';

@Injectable({
  providedIn: 'root',
})
export class TerminationReasonService {
  url = `${environment.apiUrl}/api/Employer`;
  constructor(private http: HttpClient) {}
  get() {
    return this.http.get<ITerminationReason[]>(
      `${this.url}/terminationReasons`
    );
  }
}
