﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Remits;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface IVelocityApiClient
	{
		Task<Byte[]> GetRemitDocumentAsync(int documentId);

		Task<IEnumerable<SearchVelocityRemitDocumentResponse>> SearchRemitDocumentAsync(SearchVelocityRemitDocumentRequest request);
		Task<bool> IsMemberInHrpAsync(string subscriberId);
	}
}
