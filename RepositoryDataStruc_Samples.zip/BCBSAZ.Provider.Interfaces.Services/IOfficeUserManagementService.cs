﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.WebUI.Models.Data.OfficeUserManagement;
using BCBSAZ.Provider.WebUI.Models.Requests.OfficeUserManagement;
using BCBSAZ.Provider.WebUI.Models.Responses.OfficeUserManagement;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface IOfficeUserManagementService
	{
		IEnumerable<UserRoleSelection> GetUserRoleSelections(string assignedRole);



		Task<OrgUsersResponse> GetOrgUsers(WebUser webUser);

		Task<GetUserProvidersResponse> GetAssignedProvidersForUser(string subOrg, string userId);

		Task<UserProfileResponse> GetUserProfile(string userId);

		Task<DeleteUserProfileResponse> DeleteUserProfile(string userId);

		Task<SaveUserProfileResponse> InsertUserProfile(BCBSAZ.Provider.Models.Requests.OfficeUserManagement.SaveUserProfileRequest request);

		Task<SaveUserProfileResponse> UpdateUserProfile(BCBSAZ.Provider.Models.Requests.OfficeUserManagement.SaveUserProfileRequest request);


		Task<SubOrgResponse> GetSubOrg(string subOrg);

		Task<GetSubOrgProvidersResponse> GetAssignedProvidersForSubOrg(string subOrg);

		Task<SaveSubOrgResponse> InsertSubOrg(SaveSubOrgRequest request);

		Task<SaveSubOrgResponse> UpdateSubOrg(SaveSubOrgRequest request);

		SubOrgListResponse GetSubOrgList();

		Task<SubOrgUsersResponse> GetSubOrgUsers(string subOrg);

		Task<DeleteSubOrgResponse> DeleteSubOrg(string subOrg);
	}
}
