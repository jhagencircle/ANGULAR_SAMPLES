import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-financial-manager-user-delete-confirmation',
  templateUrl: './financial-manager-user-delete-confirmation.component.html',
  styleUrls: ['./financial-manager-user-delete-confirmation.component.scss']
})
export class FinancialManagerUserDeleteConfirmationComponent implements OnInit {

  constructor(public modal: NgbActiveModal) { }

  ngOnInit(): void {
  }

}
