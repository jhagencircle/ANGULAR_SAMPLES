﻿//#define ENTITY_DESIGN

#if ENTITY_DESIGN
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace BCBSAZ.Provider.Repositories
{
	//public class EntityFrameworkStartUp : IDesignTimeDbContextFactory<EligibilityContext>
	//{
	//	public EligibilityContext CreateDbContext(string[] args)
	//	{
	//		var builder = new DbContextOptionsBuilder<EligibilityContext>();

	//		builder.UseSqlServer("Server=ETSDevWebData.aif.bcbsaz.com,8513;database=ProviderInet;Trusted_Connection=true;");

	//		return new EligibilityContext(builder.Options);
	//	}
	//}

	//public class EntityFrameworkStartUp : IDesignTimeDbContextFactory<PreCertContext>
	//{
	//	public PreCertContext CreateDbContext(string[] args)
	//	{
	//		var builder = new DbContextOptionsBuilder<PreCertContext>();

	//		builder.UseSqlServer("Server=ETSDevWebData.aif.bcbsaz.com,8513;database=ProviderInet;Trusted_Connection=true;");

	//		return new PreCertContext(builder.Options);
	//	}
	//}

	public class EntityFrameworkStartUp : IDesignTimeDbContextFactory<ClaimsContext>
	{
		public ClaimsContext CreateDbContext(string[] args)
		{
			var builder = new DbContextOptionsBuilder<ClaimsContext>();

			builder.UseSqlServer("Server=ETSDevWebData.aif.bcbsaz.com,8513;database=ProviderInet;Trusted_Connection=true;");

			return new ClaimsContext(builder.Options);
		}
	}
}
#endif

/*
 
1. Uncomment top line in this file to enable ENTITY_DESIGN definition (build solution afterwards)

2. Add a new (or uncomment the) EntityFrameworkStartUp class for the context to be migrated (comment out all others)
    Use a "Trusted Connection" connection string as the service accounts do not have Db Object creation permissions.

3. Open Package Manager Console

4. Set "Default Project" at the top of Package Manager Console (WebApi\BCBSAZ.Provider.Repositories)

5. Exec:
	Add-Migration [migration name] -Context [context name]
	e.g. Add-Migration PreCert_V1 -Context PreCertContext

6. Verify Migration has been added to Migrations folder

7. Exec:
	Update-Database -Context [context name]
	e.g. Update-Database -Context PreCertContext


	Reference: https://coding.abel.nu/2012/03/ef-migrations-command-reference/

 */
