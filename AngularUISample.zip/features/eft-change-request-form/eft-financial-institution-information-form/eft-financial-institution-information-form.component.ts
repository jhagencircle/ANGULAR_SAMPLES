import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { STATES } from 'src/app/models/data/states';
import { ValidationRegex } from 'src/app/models/data/validation-regex';

@Component({
  selector: 'app-eft-financial-institution-information-form',
  templateUrl: './eft-financial-institution-information-form.component.html',
  styleUrls: ['./eft-financial-institution-information-form.component.scss', '../eft-change-request-form.component.scss'],
})
export class EftFinancialInstitutionInformationFormComponent implements OnInit {
  public financialInstitutionInformationForm: FormGroup;
  financialInstitutionAccounts: FormArray;
  accountTypes = ['Checking', 'Savings'];
  states = STATES;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.financialInstitutionInformationForm = this.formBuilder.group({
      financialInstitutionName: ['', { updateOn: 'change', validators: [Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)] }],
      financialInstitutionAddress: ['', { updateOn: 'change', validators: [Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)] }],
      financialInstitutionCity: ['', { updateOn: 'change', validators: [Validators.required, Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)] }],
      financialInstitutionState: ['', { updateOn: 'change', validators: [Validators.required] }],
      financialInstitutionZipCode: ['', { updateOn: 'change', validators: [Validators.required, Validators.minLength(5), Validators.pattern(ValidationRegex.NUMERIC_ONLY)] }],
      financialInstitutionRoutingNumber: ['', { updateOn: 'change', validators: [Validators.required, Validators.minLength(9), Validators.pattern(ValidationRegex.NUMERIC_ONLY)] }],
      financialInstitutionAccountType: ['', { updateOn: 'change', validators: [Validators.required] }],
      financialInstitutionAccountNumber: ['', { updateOn: 'change', validators: [Validators.required, Validators.pattern(ValidationRegex.NUMERIC_ONLY)] }],
      financialInstitutionConfirmAccountNumber: ['', { updateOn: 'change', validators: [Validators.required] }],
      financialInstitutionAccounts: this.formBuilder.array([ this.createAccount() ])
    }, { validator: this.matchAccount('financialInstitutionAccountNumber', 'financialInstitutionConfirmAccountNumber')});
  }

  public isInvalid(control: AbstractControl): boolean{
    if(!control) return false;

    return control.invalid && (control.touched || control.dirty);
  }

  public createAccount(): FormGroup {
    return this.formBuilder.group({
      financialInstitutionProviderIdentifier: ['TIN', { validators: [Validators.required] }],
      financialInstitutionTin: ['', { updateOn: 'change', validators: [ Validators.minLength(9), Validators.pattern(ValidationRegex.NUMERIC_ONLY)] }],
      financialInstitutionNpi: ['', { updateOn: 'change', validators: [ Validators.minLength(10), Validators.pattern(ValidationRegex.NUMERIC_ONLY)] }]
    });
  }

  public addAccount(): void {
    this.financialInstitutionAccounts = this.financialInstitutionAccountsFormArray;
    this.financialInstitutionAccounts.push(this.createAccount());
  }

  public removeAccount(index: number): void {
    this.financialInstitutionAccounts.removeAt(index);
  }

  public verifyAccountMatch(): void {
    if (this.financialInstitutionInfoFormControl.financialInstitutionConfirmAccountNumber.value === '') {
      this.financialInstitutionInfoFormControl.financialInstitutionConfirmAccountNumber.setErrors({ required: true });
    }
    else if (this.financialInstitutionInfoFormControl.financialInstitutionAccountNumber.value === this.financialInstitutionInfoFormControl.financialInstitutionConfirmAccountNumber.value)
      this.financialInstitutionInfoFormControl.financialInstitutionConfirmAccountNumber.setErrors(null);
  }

  matchAccount(account: string, confirmationAccount: string){
      return (formGroup: FormGroup) => {
        const accountControl = formGroup.controls[account];
        const confirmationAccountControl = formGroup.controls[confirmationAccount]

            if(!accountControl || !confirmationAccountControl) 
            return null;

          if(confirmationAccountControl.errors && confirmationAccountControl.errors.accountMismatch) 
            return null;

          if(accountControl.value != confirmationAccountControl.value){
            confirmationAccountControl.setErrors({ accountMismatch: true });
          }
          else{
            confirmationAccountControl.setErrors(null);
          }
          return null;
      }
  }

  public save(): void{
    this.setFormDirty();
  }


  private setFormDirty(): void{
    for (var control in this.financialInstitutionInformationForm.controls){
      this.financialInstitutionInformationForm.controls[control].markAsDirty();
    }
  }

  /******************************** GETTERS **************************************/
  
  public get financialInstitutionInfoFormControl() { return this.financialInstitutionInformationForm.controls; }

  public get accountFormGroupControl() { return this.financialInstitutionAccountsFormArray.controls; }

  public get financialInstitutionAccountsFormArray() { return this.financialInstitutionInformationForm.get('financialInstitutionAccounts') as FormArray; }
  
  /*****************************************************************************/

}
