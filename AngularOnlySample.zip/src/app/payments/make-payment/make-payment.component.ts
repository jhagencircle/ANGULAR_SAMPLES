import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/shared/services/account.service';
import { ISummary } from 'src/app/shared/models/summary.model';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { PaymentSectionEnum } from 'src/app/shared/enums/payment-section-enum';

@Component({
  selector: 'app-make-payment',
  templateUrl: './make-payment.component.html',
  styleUrls: ['./make-payment.component.scss'],
})
export class MakePaymentComponent implements OnInit {
  paymentComponent: string | null;
  account: ISummary;
  accounts: any;
  reviewTitle: string = AppConstants.REVIEW_ACCOUNT_PAYMENT_TITLE;
  reviewSubmitText: string = AppConstants.REVIEW_SUBMIT_TEXT;
  accountBilling: string;

  constructor(private accountService: AccountService) {
    this.paymentComponent = localStorage.getItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );

    this.accountService.get().subscribe((account: ISummary) => {
      if (account) {
        this.account = account;
        this.accountBilling = account.billingLevel;
      }
    });
  }

  ngOnInit(): void {
    let subAcountsJson: string | null = localStorage.getItem(
      AppConstants.PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY
    );
    if (subAcountsJson !== null) {
      this.accounts = JSON.parse(subAcountsJson);
    }
  }

  ngOnDestroy(): void {
    localStorage.removeItem(AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY);
    localStorage.removeItem(
      AppConstants.PAYMENT_SUBSECTION_ACCOUNTS_LOCAL_STORAGE_KEY
    );
  }
}
