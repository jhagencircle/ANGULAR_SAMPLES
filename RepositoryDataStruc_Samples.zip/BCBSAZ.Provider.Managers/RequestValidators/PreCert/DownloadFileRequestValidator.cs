﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.PreCert;

namespace BCBSAZ.Provider.Managers.RequestValidators.PreCert
{
	internal static class DownloadFileRequestValidator
	{
		public static void Validate(this DownloadFileRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(DownloadFileRequest request)
		{
			if (request.AttachmentId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(DownloadFileRequest.AttachmentId), new ArgumentException("Invalid Attachment Id specified."));

			if (string.IsNullOrWhiteSpace(request.UserId))
				yield return new InvalidModelExceptionDetail(nameof(DownloadFileRequest.UserId), new ArgumentException("Invalid User Id specified."));

			if (string.IsNullOrWhiteSpace(request.DownloadHash))
				yield return new InvalidModelExceptionDetail(nameof(DownloadFileRequest.DownloadHash), new ArgumentException("Invalid Download Hash specified."));
		}
	}
}
