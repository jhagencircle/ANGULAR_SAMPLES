﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.Security
{
	internal static class WebUserSecurityValidator
	{
		public static void Validate(this WebUser webUser)
		{
			if (webUser == null)
				throw new ArgumentNullException(nameof(webUser));

			var violations = GetViolations(webUser);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(WebUser webUser)
		{
			if (webUser.UserType == UserType.Internal)
			{
				if (!webUser.Roles.Any())
				{
					yield return new InvalidModelExceptionDetail(nameof(webUser), new ArgumentException("User is denied access to this page."));
				}
			}
		}
	}
}
