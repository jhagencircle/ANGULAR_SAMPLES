﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.OfficeUserManagement;
using BCBSAZ.Provider.Models.Responses.OfficeUserManagement;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IOfficeUserManagementManager
	{
		OrgUsersResponse GetOrgUsers(WebUser webUser);
		UserProfileResponse GetUserProfile(string userId);
		SaveUserProfileResponse InsertUserProfile(WebUser user, SaveUserProfileRequest request);
		SaveUserProfileResponse UpdateUserProfile(WebUser user, SaveUserProfileRequest request);
		DeleteUserProfileResponse DeleteUserProfile(WebUser user, string userId);
		GetUserProvidersResponse GetUserProviders(WebUser webUser, string subOrg, string userId);
		SetUserProviderResponse SetUserProviders(SetUserProvidersRequest request);


		SubOrgListResponse GetSubOrgList(WebUser webUser);
		SubOrgResponse GetSubOrg(WebUser webUser, string subOrg);
		SaveSubOrgResponse InsertSubOrg(WebUser webUser, SaveSubOrgRequest request);
		SaveSubOrgResponse UpdateSubOrg(WebUser webUser, SaveSubOrgRequest request);
		DeleteSubOrgResponse DeleteSubOrg(WebUser user, string subOrg);
		SubOrgUsersResponse GetSubOrgUsers(WebUser webUser, string subOrg);
		GetSubOrgProvidersResponse GetSuborgProviders(WebUser user, string subOrg);
		SetSubOrgProvidersResponse SetSuborgProviders(SetSubOrgProvidersRequest request);
	}
}
