import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
  TestRequest,
} from '@angular/common/http/testing';
import { BillService } from './bill.service';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ICurrentBill } from '../models/current-bill.model';
import { CurrentBillMock } from '../mocks/current-bill.mock';

describe('BillService', () => {
  let service: BillService;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let testUrl: string = '';
  let baseUrl: string = '';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    // Inject the http service and test controller for each test
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
    service = TestBed.inject(BillService);
    baseUrl = `${environment.apiUrl}/api`;
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get current bill', () => {
    const testData: ICurrentBill = CurrentBillMock.mockedCurrentBill;
    const accountId = '1234';
    testUrl = `${baseUrl}/Employer/${accountId}/currentbill`;

    httpClient
      .get<ICurrentBill>(testUrl)
      .subscribe((data) => expect(data).toEqual(testData));

    const req = httpTestingController.expectOne(testUrl);

    expect(req.request.method).toEqual('GET');

    req.flush(testData);
  });

  it('should recalculate bill', () => {
    const expectedResponse = new HttpResponse({
      status: 200,
      statusText: 'Success',
    });

    const accountId = '1234';
    const billId = '0';
    let response: any;
    let errResponse: any;
    testUrl = `${baseUrl}/Employer/${accountId}/${billId}/recalculate`;

    httpClient
      .post<any>(testUrl, null)
      .subscribe((res) => expect(res).toEqual(null));

    const req = httpTestingController.expectOne(testUrl);

    expect(req.request.method).toEqual('POST');

    req.event(expectedResponse);
  });
});
