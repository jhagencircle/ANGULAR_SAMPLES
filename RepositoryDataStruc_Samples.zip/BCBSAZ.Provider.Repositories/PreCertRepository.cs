﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.PreCert;
using BCBSAZ.Provider.Models.Exceptions;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Medical = BCBSAZ.Provider.Models.Data.PreCert.Medical;
using Pharmacy = BCBSAZ.Provider.Models.Data.PreCert.Pharmacy;

namespace BCBSAZ.Provider.Repositories
{
	public partial class PreCertRepository : IPreCertRepository
	{
		private readonly IPreCertContext _preCertContext;

		public PreCertRepository(IPreCertContext preCertContext) => _preCertContext = preCertContext;

		public Task SaveFileAsync(UploadedFile file)
		{
			_preCertContext.UploadedFiles.Add(file);
			return _preCertContext.SaveChangesAsync();
		}

		public Task<Medical.MedicalPreCert> GetMedicalPreCertByIdAsync(long preCertId)
		{
			if (preCertId == 0)
			{
				var preCert = new Medical.MedicalPreCert();
				_preCertContext.MedicalPreCerts.Add(preCert);
				return Task.FromResult(preCert);
			}
			else
			{
				return (
					from p in _preCertContext.MedicalPreCerts
					where p.MedicalPreCertId == preCertId
					select p).FirstOrDefaultAsync() ?? throw new RecordNotFoundException("The specified Medical PreCert was not found.");
			}
		}

		public Task<Medical.Attachment> GetMedicalAttachmentByIdAsync(long medicalAttachmentId)
		{
			if (medicalAttachmentId == 0)
				throw new ArgumentNullException(nameof(medicalAttachmentId));

			return (from x in _preCertContext.MedicalAttachments
							where x.AttachmentId == medicalAttachmentId
							select x).FirstAsync();
		}
		public Task<Pharmacy.Attachment> GetPharmacyAttachmentByIdAsync(long medicalAttachmentId)
		{
			if (medicalAttachmentId == 0)
				throw new ArgumentNullException(nameof(medicalAttachmentId));

			return (from x in _preCertContext.PharmacyAttachments
							where x.AttachmentId == medicalAttachmentId
							select x).FirstAsync();
		}

		public Task<UploadedFile> GetUploadedFileByIdAsync(long fileId)
		{
			if (fileId == 0)
				throw new ArgumentNullException(nameof(fileId));

			return (from x in _preCertContext.UploadedFiles
							where x.FileId == fileId
							select x).FirstAsync();
		}

		public Task<string> GetUploadedFileHashAsync(long fileId)
		{
			if (fileId == 0)
				throw new ArgumentNullException(nameof(fileId));

			return (
				from f in _preCertContext.UploadedFiles
				where f.FileId == fileId
				select f.FileHash).FirstAsync();
		}

		public Task SavePharmacyPreCertAsync(Pharmacy.PharmacyPreCert preCert) => _preCertContext.SaveChangesAsync();

		public Task<Pharmacy.PharmacyPreCert> GetPharmacyPreCertByIdAsync(long preCertId)
		{
			if (preCertId == 0)
			{
				var preCert = new Pharmacy.PharmacyPreCert();
				_preCertContext.PharmacyPreCerts.Add(preCert);
				return Task.FromResult(preCert);
			}
			else
			{
				return (
					from p in _preCertContext.PharmacyPreCerts
					where p.PharmacyPreCertId == preCertId
					select p).FirstOrDefaultAsync() ?? throw new RecordNotFoundException("The specified Pharmacy PreCert was not found.");
			}
		}

		public Task SaveAllChangesAsync() => _preCertContext.SaveChangesAsync();

		public async Task<string> GetEmailAddressForUserAsync(string userId)
		{
			// NOTE: Because we are dealing with a Stored Proc which uses an Output Parameter, we must use SqlParameters
			var returnCodeParam = new SqlParameter()
			{
				ParameterName = "@EMailAddress",
				DbType = System.Data.DbType.AnsiString,
				Size = 255,
				Direction = System.Data.ParameterDirection.Output
			};

			var userIdParam = new SqlParameter("@UserId", userId);

			await _preCertContext.Database.ExecuteSqlRawAsync(DB.ProviderInet.StoredProcs.PreCert_GetUserEmailAddress, returnCodeParam, userIdParam);

			return returnCodeParam.Value as string;
		}

		public Medical.Summary[] ViewMedicalPreCertResults(string userId, string orgId, PreCertStatus status, DateTime fromDate, DateTime toDate, bool isInternal) =>
			_preCertContext.MedicalSummaries.FromSqlRaw(DB.ProviderInet.StoredProcs.ViewMedicalPrecerts, userId, orgId, (int)status, fromDate, toDate, isInternal).AsEnumerable().ToArray();

		public Pharmacy.Summary[] ViewPharmacyPreCertResults(string userId, string orgId, PreCertStatus status, DateTime fromDate, DateTime toDate, bool isInternal) =>
			_preCertContext.PharmacySummaries.FromSqlRaw(DB.ProviderInet.StoredProcs.ViewPharmacyPrecerts, userId, orgId, (int)status, fromDate, toDate, isInternal).AsEnumerable().ToArray();

		public User[] GetUserNameByUserId(params string[] userIds) =>
			_preCertContext.Users.FromSqlRaw(DB.ProviderInet.StoredProcs.GetUserInfo, string.Join(",", userIds)).AsEnumerable().ToArray();

	}
}
