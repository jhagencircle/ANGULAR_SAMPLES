﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Managers.RequestValidators;
using BCBSAZ.Provider.Managers.RequestValidators.FeatureToggle;
using BCBSAZ.Provider.Models.Data.FeatureToggles;
using BCBSAZ.Provider.Models.Requests.FeatureToggles;
using BCBSAZ.Provider.Models.Responses.FeatureToggles;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Managers
{
	public class FeatureToggleManager : IFeatureToggleManager
	{
		private IFeatureToggleRepository _repository;
		private int _storeExpiresMinutes;

		public FeatureToggleManager(IFeatureToggleRepository repository, IConfiguration configuration)
		{
			_repository = repository;
			_storeExpiresMinutes = configuration.GetValue<int>("FeatureToggleStoreExpire");
		}

		public FeatureToggleResponse GetStatus(FeatureToggleRequest request)
		{
			request.Validate();

			var store = GetFeatureToggleStore(request.ApplicationName, request.EnvironmentName);
			var record = (
				from r in store
				where
					r.ApplicationName.Equals(request.ApplicationName, StringComparison.OrdinalIgnoreCase) &&
					r.EnvironmentName.Equals(request.EnvironmentName, StringComparison.OrdinalIgnoreCase) &&
					r.FeatureName.Equals(request.FeatureName, StringComparison.OrdinalIgnoreCase)
				select r).FirstOrDefault() ?? new FeatureToggle()
				{
					ApplicationName = request.ApplicationName,
					EnvironmentName = request.EnvironmentName,
					FeatureName = request.FeatureName,
					IsFeatureActive = false // If feature not found, it's not active!
				};

			return new FeatureToggleResponse()
			{
				FeatureToggle = record
			};
		}

		private static List<FeatureToggleCollection> _stores = new List<FeatureToggleCollection>();

		private FeatureToggleCollection GetFeatureToggleStore(string applicationName, string environmentName)
		{
			var store = (from s in _stores
									 where s.ApplicationName.Equals(applicationName, StringComparison.OrdinalIgnoreCase) &&
												 s.EnvironmentName.Equals(environmentName, StringComparison.OrdinalIgnoreCase)
									 select s).FirstOrDefault();

			if ((store == null) || (store.IsExpired))
			{
				if (store != null)
					_stores.Remove(store);

				var records = _repository.GetFeatureToggles(applicationName, environmentName);
				store = new FeatureToggleCollection(applicationName, environmentName, DateTime.Now.AddMinutes(_storeExpiresMinutes), records);

				_stores.Add(store);
			}

			return store;
		}
	}
}
