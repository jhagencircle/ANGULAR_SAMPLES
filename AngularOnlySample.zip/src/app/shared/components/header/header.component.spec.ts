import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HeaderComponent } from './header.component';
import { OktaAuthModule, OKTA_CONFIG } from '@okta/okta-angular';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { routes } from 'src/app/app-routing.module';
import { AuthGuard } from 'src/app/core/auth/auth.guard';
import { BillService } from '../../services/bill.service';
import { CurrentBillMock } from '../../mocks/current-bill.mock';
import { AuthServiceMock } from '../../mocks/auth.service.mock';
import { AuthService } from 'src/app/core/auth/auth.service';
import { AccountMock } from '../../mocks/account.mock';
import { AccountService } from '../../services/account.service';
import { AppConstants } from '../../constants/app-constants';
describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let location: Location;
  let router: Router;
  let authServiceMock = new AuthServiceMock();
  let accountServiceMock = new AccountMock();
  const oktaConfig = {
    issuer: 'https://not-real.okta.com',
    clientId: 'fake-client-id',
    redirectUri: 'http://localhost:4200',
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        OktaAuthModule,
        HttpClientModule,
      ],
      declarations: [HeaderComponent],
      providers: [
        AuthGuard,
        { provide: OKTA_CONFIG, useValue: oktaConfig },
        { provide: AccountService, useValue: accountServiceMock },
        { provide: AuthService, useValue: authServiceMock },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    router = TestBed.inject(Router);
    location = TestBed.inject(Location);
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    router.initialNavigation();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set image logo path as expected', () => {
    const imgLogo =
      fixture.debugElement.nativeElement.querySelector('img.logo');
    expect(imgLogo['src']).toContain('/assets/icons/bcbslogo.svg');
  });

  it(`should have the header ${AppConstants.HEADER_TITLE}`, () => {
    expect(component.title).toEqual(AppConstants.HEADER_TITLE);
  });

  it('the logo renders the correct routerLink attribute', () => {
    const logoLink =
      fixture.debugElement.nativeElement.querySelector('#logoLink');
    expect(logoLink['href']).toContain('/landing-page');
  });
  it('should make a call to accountService.get()', () => {
    spyOn(component.accountService, 'get').and.callThrough();

    component.getAccontName();

    expect(component.accountService.get).toHaveBeenCalled();
  });

  it('should get account name value ', () => {
    expect(component.accountName).toEqual(
      AccountMock.mockedAccount.accountName
    );
  });

  it('should display drop down menu with user icon, account name and log out option', () => {
    AuthServiceMock.authenticatedMock = true;
    fixture.detectChanges();
    spyOn(component.authService, 'isAuthenticated').and.callThrough();

    const imgUser = fixture.debugElement.nativeElement.querySelector('#user');
    const accountNameLink =
      fixture.debugElement.nativeElement.querySelector('#dropdownMenuLink');
    const logOutLink =
      fixture.debugElement.nativeElement.querySelector('#logOutLink');
    expect(accountNameLink).toBeTruthy();
    expect(logOutLink).toBeTruthy();
    expect(imgUser['src']).toContain('/icons/user.svg');
  });
});
