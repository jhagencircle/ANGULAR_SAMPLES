﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Interfaces.WCFClients;
using BCBSAZ.Provider.Managers.RequestValidators.Claims;
using BCBSAZ.Provider.Models.Data.Claims;
using NPI = BCBSAZ.Provider.Models.Data.Common.NPI;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Requests.Claims;
using BCBSAZ.Provider.Models.Responses.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Text;
using BCBSAZ.Provider.Models.Exceptions;
using BCBSAZ.Provider.Service.WCF.Clients.BizTalk271EDI;
using System.IO;
using BCBSAZ.Provider.Managers.Mappers;
using BCBSAZ.Provider.Models.API.Claims.Response;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Models.Responses.Claims.Test;
using BCBSAZ.Provider.Models.Requests.ClaimsDetails;
using BCBSAZ.Provider.Models.Responses.ClaimDetails;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using BCBSAZ.Provider.Models.API.Claims.Request;
using BCBSAZ.Provider.Utilities;
using BCBSAZ.Provider.Models.Data.Common;

namespace BCBSAZ.Provider.Managers
{
	public class ClaimsManager : IClaimsManager
	{
		private readonly IWCFClientFactory _wcfClientFactory;
		private readonly IClaimsRepository _claimsRepository;
		private readonly IProviderRepository _providerRepository;
		private readonly IClaimsApiClient _claimsApiClient;
		private readonly IOktaApiClient _oktaApiClient;
		private readonly ISettingsManager _settingsManager;
		private readonly IMemoryCache _memoryCache;
		private readonly ITransactionLogRepository _transactionLogRepository;
		private readonly ILogger _logger;
		private readonly IHttpContextAccessor _contextAccessor;
		private readonly IPlanProfileApiClient _planProfileApiClient;
		private readonly IPlanProfileManager _planProfileManager;

		private static readonly JsonSerializerSettings _serializerSettings = GetJsonSerializerSettings();

		public ClaimsManager(IWCFClientFactory wcfClientFactory, IClaimsRepository claimsRepository, IProviderRepository providerRepository, ISettingsManager settingsManager, IClaimsApiClient claimsApiClient, IOktaApiClient oktaApiClient,
			IMemoryCache memoryCache, ITransactionLogRepository transactionLogRepository, IHttpContextAccessor contextAccessor, ILogger<ClaimsManager> logger, IPlanProfileApiClient planProfileApiClient,
			 IPlanProfileManager planProfileManager)
		{
			_wcfClientFactory = wcfClientFactory;
			_claimsRepository = claimsRepository;
			_providerRepository = providerRepository;
			_settingsManager = settingsManager;
			_claimsApiClient = claimsApiClient;
			_oktaApiClient = oktaApiClient;
			_memoryCache = memoryCache;
			_transactionLogRepository = transactionLogRepository;
			_logger = logger;
			_contextAccessor = contextAccessor;
			_planProfileApiClient = planProfileApiClient;
			_planProfileManager = planProfileManager;
		}

		#region Save Claims Inquiry -- for Performance Testing
		public Task<ClaimsInquiryResponse> SaveClaimsInquiryAsync(ClaimsInquiryRequest request, WebUser webUser)
		{
			var perfInfo = new ClaimsPerformanceInfo();

			request.Validate(webUser);
			request.ClaimsRequest.UserId = webUser.UserId;

			var sb = new StringBuilder();

			var claimStatusCodes = GetClaimStatusCodesByLob(request.ClaimsRequest.LOB, true, true, true);

			sb.AppendLine("Saving Claims Inquiry Test Data.");
			return SaveClaimRequest(request, webUser, false, perfInfo, claimStatusCodes, sb);
		}
		#endregion


		private static JsonSerializerSettings GetJsonSerializerSettings() =>
					 new JsonSerializerSettings()
					 {
						 DateFormatString = "yyyy-MM-dd",
						 Formatting = Formatting.Indented,
						 NullValueHandling = NullValueHandling.Ignore,
						 ContractResolver = new CamelCasePropertyNamesContractResolver()
					 };


		public async Task<TestResponse> TestClaimsApiResponseAsync(ClaimsInquiryRequest request)
		{
			var response = new TestResponse();

			var claimStatusCodes = GetClaimStatusCodesByLob(request.ClaimsRequest.LOB, request.ClaimsRequest.ProcessedClaims, request.ClaimsRequest.PendingClaims, request.ClaimsRequest.DeniedClaims);

			var task1 = Task.Run(async () =>
			{
				var sw1 = Stopwatch.StartNew();
				try
				{
					using (var _client = _wcfClientFactory.GetClaims5010ServiceClient())
					{
						response.WCF.ClaimResponse = await _client.GetClaims(request);
					}

					response.WCF.ClaimResponse.ProviderClaims = FilterProviderClaims(response.WCF.ClaimResponse.ProviderClaims, claimStatusCodes, request);
				}
				catch (Exception ex)
				{
					response.WCF.Failed = true;
					response.WCF.ExceptionType = ex.GetType().FullName;
					response.WCF.ExceptionMessage = ex.Message;
				}
				finally
				{
					sw1.Stop();
					response.WCF.ProcessTime = sw1.ElapsedMilliseconds / 1000m;
				}
			});

			var task2 = Task.Run(async () =>
			{
				var sw2 = Stopwatch.StartNew();
				try
				{
					var apiRequests = request.MapToClaimsApiRequest().ToArray();
					var apiTasks = new Task<ClaimsApiResponse>[apiRequests.Length];

					for (var idx = 0; idx < apiRequests.Length; idx++)
						apiTasks[idx] = _claimsApiClient.GetClaims(apiRequests[idx]);

					await Task.WhenAll(apiTasks);

					response.API.ClaimResponse = apiTasks.Select(t => t.Result).MapToClaimsResponse(claimStatusCodes, ClaimStatusMessages);
					response.API.ClaimResponse.ProviderClaims = FilterProviderClaims(response.API.ClaimResponse.ProviderClaims, claimStatusCodes, request);
					response.API.ClaimResponse.RequestEDI = JsonConvert.SerializeObject(apiRequests, _serializerSettings);
				}
				catch (Exception ex)
				{
					response.API.Failed = true;
					response.API.ExceptionType = ex.GetType().FullName;
					response.API.ExceptionMessage = ex.Message;
					response.API.Content = (ex as InvalidApiResponseException)?.Content;
				}
				finally
				{
					sw2.Stop();
					response.API.ProcessTime = sw2.ElapsedMilliseconds / 1000m;
				}
			});

			await Task.WhenAll(task1, task2);

			var sw3 = Stopwatch.StartNew();
			try
			{
				response.Token.TokenResponse = _oktaApiClient.GetApiToken();
			}
			catch (Exception ex)
			{
				response.Token.Failed = true;
				response.Token.ExceptionType = ex.GetType().FullName;
				response.Token.ExceptionMessage = ex.Message;
			}
			finally
			{
				sw3.Stop();
				response.Token.ProcessTime = sw3.ElapsedMilliseconds / 1000m;
			}

			return response;
		}

		#region Submit Claims Inquiry
		public async Task<ClaimsInquiryResponse> SubmitClaimsInquiryAsync(ClaimsInquiryRequest request, WebUser webUser)
		{
			try
			{
				var perfInfo = new ClaimsPerformanceInfo();
				request.Validate(webUser);

				var sb = new StringBuilder();				

				
				request.ClaimsRequest.MemberGender = (request.ClaimsRequest.IsDependent) ? GenderType.Unknown : request.ClaimsRequest.PatientGender;
				request.ClaimsRequest.UserId = webUser.UserId;
				request.ClaimsRequest.OrgId = webUser.OrgId;
				request.ClaimsRequest.ProvidersList.ForEach(CheckProviderInfo, sb);

				if (String.IsNullOrEmpty(request.ClaimsRequest.MemberLastName))
				{
					request.ClaimsRequest.MemberLastName = request.ClaimsRequest.PatientLastName;
					request.ClaimsRequest.MemberFirstName = request.ClaimsRequest.PatientFirstName;
				}
				
				var claimStatusCodes = GetClaimStatusCodesByLob(request.ClaimsRequest.LOB, request.ClaimsRequest.ProcessedClaims, request.ClaimsRequest.PendingClaims, request.ClaimsRequest.DeniedClaims);
				var failure = (!(await PerformInquiry(request, perfInfo, claimStatusCodes, webUser, sb)) || !FilterClaimsResponse(request, claimStatusCodes, sb));

				request.ClaimsRequest.ClaimsFound = failure ? null : GetClaimCount(request.ClaimsRequest.ClaimResponse?.ProviderClaims);

				return await SaveClaimRequest(request, webUser, failure, perfInfo, claimStatusCodes, sb);
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error with Claims Request");
				return new ClaimsInquiryResponse()
				{
					ResponseType = ClaimInquiryResponseType.Error,
					ErrorMessage = ex.Message
				};
			}
		}

		private async Task CreateOrUpdatePatientListAsync(WebUser user, ClaimsInquiryRequest request)
		{
			var patient = new Patient()
			{
				SubscriberId = request.ClaimsRequest.SubscriberId,
				PatientFirstName = request.ClaimsRequest.PatientFirstName,
				PatientLastName = request.ClaimsRequest.PatientLastName,
				DateOfBirth = request.ClaimsRequest.DateOfBirth.Date,
				IsDependent = request.ClaimsRequest.IsDependent,
				SubscriberFirstName = request.ClaimsRequest.MemberFirstName,
				SubscriberLastName = request.ClaimsRequest.MemberLastName,
				PatientGender = request.ClaimsRequest.PatientGender.ToString().Substring(0, 1),
				LOB = (int)request.ClaimsRequest.LOB
			};

			var record = await _claimsRepository.GetOrCreatePatientAsync(patient);

			var orgPatient = (
					from o in record.Orgs
					where o.OrgId.Equals(user.OrgId, StringComparison.OrdinalIgnoreCase)
					select o
					).FirstOrDefault();

			var userPatient = (
						from u in record.Users
						where u.UserId.Equals(user.UserId, StringComparison.OrdinalIgnoreCase)
						select u
			).FirstOrDefault();

			if (orgPatient == null)
			{
				orgPatient = new PatientOrg()
				{
					PatientId = record.PatientId,
					OrgId = user.OrgId,
					LastUsed = DateTime.Now
				};

				record.Orgs.Add(orgPatient);
			}
			else
			{
				orgPatient.LastUsed = DateTime.Now;
			}

			if (userPatient == null)
			{
				userPatient = new PatientUser()
				{
					PatientId = record.PatientId,
					UserId = user.UserId,
					LastUsed = DateTime.Now
				};

				record.Users.Add(userPatient);
			}
			else
			{
				userPatient.LastUsed = DateTime.Now;
			}

			await _claimsRepository.SaveChangesAsync();
		}

		private static int? GetClaimCount(ProviderClaim[] claims)
		{
			if (claims.IsNullOrEmpty() || (
				from n in claims
				from s in n.Claims
				where s.Status.StartsWith("E", StringComparison.OrdinalIgnoreCase)
				select s.Status).Any()) 
			{
				return null;
			}						
			
			var notFoundStatus = (
				from n in claims
				from s in n.Claims
					where s.Status.StartsWith("A4", StringComparison.OrdinalIgnoreCase)
				select s.Status).Any();

			if (notFoundStatus)
			{
				return 0;
			}
			else
			{
				return (
					from pc in claims
					from c in pc.Claims
					select c).Count();
									
			}
		}

		#region Claims Performance Info
		private class ClaimsPerformanceInfo
		{
			public ClaimsPerformanceInfo() =>
				_stopwatch = Stopwatch.StartNew();

			private readonly Stopwatch _stopwatch;

			public double PreprocessTime { get; private set; }
			public void SetPreprocessTime()
			{
				PreprocessTime = _stopwatch.Elapsed.TotalSeconds;
				_stopwatch.Restart();
			}

			public double EdiProcessTime { get; private set; }
			public void SetEdiProcessTime()
			{
				EdiProcessTime = _stopwatch.Elapsed.TotalSeconds;
				_stopwatch.Restart();
			}

			public double PostProcessTime { get; private set; }
			public void SetPostProcesTime()
			{
				_stopwatch.Stop();
				PostProcessTime = _stopwatch.Elapsed.TotalSeconds;
			}

			public double TotalProcessTime { get => PreprocessTime + EdiProcessTime + PostProcessTime; }

		}
		#endregion

		private async Task<bool> PerformInquiry(ClaimsInquiryRequest request, ClaimsPerformanceInfo perfInfo, ClaimStatusCode[] claimStatusCodes, WebUser webUser, StringBuilder sb)
		{
			var correlationIds = "";
			ClaimsApiRequest[] apiRequests = null;
			try
			{
				perfInfo.SetPreprocessTime();

				var toggle = await Use5010BridgeAsync(request.ClaimsRequest.SubscriberId, webUser);

				if (toggle)
				{
					sb.AppendLine($"Using Claims 5010 Bridge");
					using (var _client = _wcfClientFactory.GetClaims5010ServiceClient())
					{
						request.ClaimsRequest.ClaimResponse = await _client.GetClaims(request);
					}
				}
				else
				{
					sb.AppendLine($"Using Claims Velocity");
					apiRequests = request.MapToClaimsApiRequest().ToArray();
					var apiTasks = new Task<ClaimsApiResponse>[apiRequests.Length];
					var ids = new List<string>();

					for (var idx = 0; idx < apiRequests.Length; idx++)
					{
						apiRequests[idx].CorrelationId = RandomGenerator.GenerateCorrelationId();
						ids.Add(apiRequests[idx].CorrelationId);
						apiTasks[idx] = _claimsApiClient.GetClaims(apiRequests[idx]);
					}

					correlationIds = string.Join(", ", ids);
					sb.Insert(0, correlationIds + ": ");

					await Task.WhenAll(apiTasks);

					request.ClaimsRequest.ClaimResponse = apiTasks.Select(t => t.Result).MapToClaimsResponse(claimStatusCodes, ClaimStatusMessages);
					request.ClaimsRequest.ClaimResponse.RequestEDI = JsonConvert.SerializeObject(apiRequests, _serializerSettings);
					request.ClaimsRequest.ClaimResponse.CorrelationIds = correlationIds.ToString();
				}

				return true;
			}
			catch (Exception ex)
			{
				request.SetErrorInfo(ex);
				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Submitting Claims Request");
				sb.AppendLine($"Error Submitting Request: {ex.GetType().FullName} - {ex.Message}");
				if (!apiRequests.IsNullOrEmpty())
					sb.AppendLine(JsonConvert.SerializeObject(apiRequests, _serializerSettings));
				return false;
			}
			finally
			{
				if (request.ClaimsRequest.ClaimResponse == null)
					request.ClaimsRequest.ClaimResponse = new ClaimsResponse();

				request.ClaimsRequest.ClaimResponse.CorrelationIds = correlationIds;
				perfInfo.SetEdiProcessTime();
			}
		}

		private async Task<bool> Use5010BridgeAsync(string subscriberId, WebUser webUser)
		{
			if (string.IsNullOrWhiteSpace(subscriberId) || subscriberId.Length < 3) return true; // Use 5010, with an invalid SubId it'll fail either way.

			// Feature Toggle:
			// 0 = Use 5010 Bridge for all requests
			// 1 = Do not Use 5010 Bridge for ITS MA, SoAZ, IU65 (by prefix), Use 5010 for all other requests
			// 2 = Do not Use 5010 Bridge for any request.

			var toggle = await _settingsManager.GetSettingValueAsync(Constants.Settings.Names.Use5010Bridge, Constants.Settings.Defaults.Use5010Bridge, webUser);
			var prefix = subscriberId.Substring(0, 3);

			return (toggle.AsInt()) switch
			{
				1 => !_planProfileManager.GetItsMaAllPrefixes().Result.Contains(prefix), // use 5010 if NOT an HRP Prefix (return true), otherwise use Connect API (return false)
				2 => false,
				// 0 and all others
				_ => true,
			};
		}

		private bool FilterClaimsResponse(ClaimsInquiryRequest request, ClaimStatusCode[] claimStatusCodes, StringBuilder sb)
		{
			try
			{
				string message;
				if (request.ClaimsRequest.ClaimResponse == null)
				{
					request.ClaimsRequest.ClaimResponse = new ClaimsResponse();
					message = "No Response";
				}
				else
				{
					request.ClaimsRequest.ClaimResponse.ProviderClaims = FilterProviderClaims(request.ClaimsRequest.ClaimResponse.ProviderClaims, claimStatusCodes, request);
					message = "No Results";
				}

				if (request.ClaimsRequest.ClaimResponse.ProviderClaims.IsNullOrEmpty())
				{
					request.ClaimsRequest.ClaimResponse.ProviderClaims = new ProviderClaim[] { CreateClaimNotFound(request.ClaimsRequest, message) };
				}

				return true;
			}
			catch (Exception ex)
			{
				request.SetErrorInfo(ex);
				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Filtering Claim Results");
				sb.AppendLine($"Error Filtering Results: {ex.GetType().FullName} - {ex.Message}");
				return false;
			}
		}

		private async Task<ClaimsInquiryResponse> SaveClaimRequest(ClaimsInquiryRequest request, WebUser webUser, bool failure, ClaimsPerformanceInfo perfInfo, ClaimStatusCode[] claimStatusCodes, StringBuilder sb)
		{
			var responseType = failure ? ClaimInquiryResponseType.Error : DetermineResponseType(request.ClaimsRequest, claimStatusCodes);

			try
			{
				if (responseType == ClaimInquiryResponseType.Success || responseType == ClaimInquiryResponseType.NotFound)
				{
					await CreateOrUpdatePatientListAsync(webUser, request);
				}
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Saving Patient List");
			}

			try
			{
				await _claimsRepository.SaveClaimsRequestAsync(request.ClaimsRequest);

				return new ClaimsInquiryResponse()
				{
					RequestId = request.ClaimsRequest.RequestId,
					ResponseType = responseType										
				};
			}
			catch (Exception ex)
			{
				failure = true;
				request.SetErrorInfo(ex);
				responseType = ClaimInquiryResponseType.Error;

				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Saving Claims Request/Response");
				sb.AppendLine($"Error Saving Request/Response: {ex.GetType().FullName} - {ex.Message}");

				return new ClaimsInquiryResponse() { ResponseType = responseType };
			}
			finally
			{
				perfInfo.SetPostProcesTime();
				sb.AppendLine($"RequestId: {request.ClaimsRequest.RequestId}, ResponseId: {request.ClaimsRequest.ClaimResponse?.ResponseId}, ResponseType: {responseType}");
				await CreateTransactionLog(failure, request, perfInfo, responseType, sb.ToString());
			}
		}

		private async Task CreateTransactionLog(bool failure, ClaimsInquiryRequest request, ClaimsPerformanceInfo perfInfo, ClaimInquiryResponseType responseType, string info)
		{
			try
			{
				if (failure)
				{
					await _transactionLogRepository.LogTransactionAsync(Environment.MachineName, "P_ClaimSum", request.ErrorInfo, responseType.ToString().TruncateAt(10),
						DateTime.Now, perfInfo.TotalProcessTime, perfInfo.EdiProcessTime, perfInfo.PostProcessTime, request.ClaimsRequest.UserId, info);
				}
				else
				{
					var errorCodes = (request.ClaimsRequest.ClaimResponse?.ProviderClaims).IsNullOrEmpty() ? string.Empty : string.Join(", ", (
						from pc in request.ClaimsRequest.ClaimResponse.ProviderClaims
						where !string.IsNullOrWhiteSpace(pc.ErrorCodes)
						select pc.ErrorCodes));

					if (!string.IsNullOrWhiteSpace(errorCodes))
						info = $"Error Codes: {errorCodes}. Info: {info}";

					var requestString = request.ClaimsRequest.ClaimResponse?.FirstEDI ?? "Unknown";

					await _transactionLogRepository.LogTransactionAsync(Environment.MachineName, "P_ClaimSum", requestString, responseType.ToString().TruncateAt(10),
						DateTime.Now, perfInfo.TotalProcessTime, perfInfo.EdiProcessTime, perfInfo.PostProcessTime, request.ClaimsRequest.UserId, info);
				}
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Saving Claims Transaction Log");
			}
		}

		private ClaimInquiryResponseType DetermineResponseType(ClaimsRequest request, ClaimStatusCode[] claimStatusCodes)
		{
			try
			{
				if ((request == null) || (request.ClaimResponse == null)) return ClaimInquiryResponseType.Error;
				if (request.ClaimResponse.ProviderClaims.IsNullOrEmpty()) return ClaimInquiryResponseType.NotFound;
				if (!request.ClaimResponse.ProviderClaims.Any(HasClaims)) return ClaimInquiryResponseType.NotFound;

				var statuses = (
					from pc in request.ClaimResponse.ProviderClaims
					from c in pc.Claims
					from sc in claimStatusCodes
					where sc.IsMatch(c.Status)
					select sc.StatusDisplay).Distinct();

				if (statuses.Any(s => !_errorStatuses.Contains(s, StringComparer.OrdinalIgnoreCase))) return ClaimInquiryResponseType.Success;
				if (statuses.Contains(StatusTimeOut, StringComparer.OrdinalIgnoreCase)) return ClaimInquiryResponseType.Timeout;
				if (statuses.Contains(StatusInvalidReq, StringComparer.OrdinalIgnoreCase)) return ClaimInquiryResponseType.InvalidRequest;

				return ClaimInquiryResponseType.NotFound;
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Determining ClaimRequest's Response Type");
				return ClaimInquiryResponseType.Error;
			}
		}

		private bool HasClaims(ProviderClaim providerClaim)
		{
			return !providerClaim.Claims.IsNullOrEmpty();
		}

		private void CheckProviderInfo(Models.Data.Claims.ProviderInfo provider, StringBuilder sb)
		{
			if (string.IsNullOrWhiteSpace(provider.NPI) || string.IsNullOrWhiteSpace(provider.TaxId) ||
				(string.IsNullOrWhiteSpace(provider.FirstName) && string.IsNullOrWhiteSpace(provider.LastName)))
			{
				sb.AppendLine($"Missing information for NPI: '{provider.NPI}', TaxId: '{provider.TaxId}', Name: '{provider.FirstName}' '{provider.LastName}'");
				var sw = Stopwatch.StartNew();
				try
				{
					var npi = string.IsNullOrWhiteSpace(provider.NPI) ? null : provider.NPI;
					var taxId = string.IsNullOrWhiteSpace(provider.TaxId) ? null : provider.TaxId;

					// Purposefully passing in null for Org and UserId, for the Cheat-Tool we do not care if the provider is assigned to the Org.
					var providerInfo = _providerRepository.GetProviderInfo(npi, taxId, null, null);

					if (providerInfo == null)
					{
						// Since this is for the "cheat tool" anyway (actual providers use the NPI Dropdown and the request will not end up here)
						// and since the Connect API only uses the F/LName to determine if the provider is a Doctor or an Institution
						// and since we were unable to lookup the actual provider info (likely this is a lower environment)
						// we are just going to hardcode a F/LName if missing.

						// Make sure both FName and LName are empty, if we have only LName then it is an institutional
						if (string.IsNullOrWhiteSpace(provider.FirstName) && string.IsNullOrWhiteSpace(provider.LastName))
							provider.FirstName = "A";

						// We'll do the Provider LastName separate just in case we have it.
						if (string.IsNullOrWhiteSpace(provider.LastName))
							provider.LastName = "A";
					}
					else
					{
						provider.NPI = providerInfo.ProviderId;
						provider.TaxId = providerInfo.TaxId;
						provider.FirstName = providerInfo.FirstName;
						provider.LastName = providerInfo.LastName;
					}
				}
				catch (Exception ex)
				{
					sb.AppendLine($"Error retrieving Provider Information: {ex.GetType().FullName} - {ex.Message}");
					_logger.LogError(ex, _contextAccessor?.HttpContext, "Error retrieving missing Provider Information.");
				}
				finally
				{
					sw.Stop();
					sb.AppendLine($"Total time to get missing Provider information: {sw.Elapsed.TotalSeconds} seconds");
				}
			}
		}

		private static ProviderClaim CreateClaimNotFound(ClaimsRequest request, string message)
		{
			return new ProviderClaim(CreateClaimHeaderNotFound(request, message));
		}

		private static IEnumerable<ClaimHeader> CreateClaimHeaderNotFound(ClaimsRequest request, string message)
		{
			yield return new ClaimHeader()
			{
				Status = "A4:35:::::::",
				StatusDisplay = message,
				DatOfService = $"{request.StartDate:yyyMMdd} - {request.EndDate:yyyMMdd}"
			};
		}

		private ProviderClaim[] FilterProviderClaims(IEnumerable<ProviderClaim> providerClaims, ClaimStatusCode[] claimStatusCodes, ClaimsInquiryRequest request)
		{
			providerClaims.ForEach(FilterProviderClaim, claimStatusCodes, request);

			return (
				from pc in providerClaims
				where pc.Claims.Any()
				select pc).ToArray();
		}

		private const string StatusTimeOut = "TIMEOUT";
		private const string StatusInvalidReq = "INVALIDREQ";
		private const string StatusNotFound = "NOTFND";

		private static readonly string[] _errorStatuses = new string[] { StatusTimeOut, StatusInvalidReq, StatusNotFound };

		private void FilterProviderClaim(ProviderClaim providerClaim, ClaimStatusCode[] claimStatusCodes, ClaimsInquiryRequest request)
		{
			var filteredClaims = (
				from statusCode in claimStatusCodes
				from claim in providerClaim.Claims
				where statusCode.IsMatch(claim.Status)
				select FilterClaimHeader(claim, statusCode, request)).ToArray();

			providerClaim.Claims = (
				from claim in filteredClaims
				where
					(claim.Lines.Any()) ||
					(_errorStatuses.Contains(claim.StatusDisplay, StringComparer.OrdinalIgnoreCase))
				select claim);
		}

		private ClaimHeader FilterClaimHeader(ClaimHeader claimHeader, ClaimStatusCode headerStatusCode, ClaimsInquiryRequest request)
		{
			// Per Product Owner, we should use headerStatusCode.Status instead of headerStatusCode.StatusDisplay.
			claimHeader.StatusDisplay = headerStatusCode.StatusDisplay;

			if (!(claimHeader.TPANumber.IsNullOrEmpty()))
				claimHeader.TPAInfo = _claimsRepository.GetTPAInfo(claimHeader.TPANumber);


			if (claimHeader.Messages.IsNullOrEmpty())
				claimHeader.Messages = GetStatusMessages(claimHeader.Status);

			var claimStatusCodes = GetClaimStatusCodesByLob(request.ClaimsRequest.LOB, true, true, true);

			var lines = (
				from statusCode in claimStatusCodes
				from line in claimHeader.Lines
				where statusCode.IsMatch(line.Status)
				select GetClaimLine(line, statusCode)).ToArray();

			claimHeader.Lines = lines;

			return claimHeader;
		}

		private ClaimLine GetClaimLine(ClaimLine claimLine, ClaimStatusCode lineStatusCode)
		{
			claimLine.StatusDisplay = lineStatusCode.StatusDisplay;

			if (claimLine.Messages.IsNullOrEmpty())
				claimLine.Messages = GetStatusMessages(claimLine.Status);

			return claimLine;
		}

		private ClaimMessage[] GetStatusMessages(string status) =>
			string.IsNullOrWhiteSpace(status) ? new ClaimMessage[0] :
				new ClaimMessage[] { new ClaimMessage() { Code = status, MessageValue = string.Join(" - ", GetStatusMessageDescription(status)) } };

		private IEnumerable<string> GetStatusMessageDescription(string status)
		{
			var tokens = status.Split(':', StringSplitOptions.None);

			if (tokens.Length >= 1)
			{
				var code507 = (
					from sm in ClaimStatusMessages
					where
						sm.EntityName.Equals("507Codes", StringComparison.OrdinalIgnoreCase) &&
						sm.Id.Equals(tokens[0], StringComparison.OrdinalIgnoreCase)
					select sm.Description).FirstOrDefault();

				if (!string.IsNullOrWhiteSpace(code507))
					yield return code507;
			}

			if (tokens.Length >= 2)
			{
				var code508 = (
					from sm in ClaimStatusMessages
					where
						sm.EntityName.Equals("508Codes", StringComparison.OrdinalIgnoreCase) &&
						sm.Id.Equals(tokens[1], StringComparison.OrdinalIgnoreCase)
					select sm.Description).FirstOrDefault();

				if (!string.IsNullOrWhiteSpace(code508))
					yield return code508;
			}

			if (tokens.Length >= 3)
			{
				var codeE = (
					from sm in ClaimStatusMessages
					where
						sm.EntityName.Equals("EntityCodes", StringComparison.OrdinalIgnoreCase) &&
						sm.Id.Equals(tokens[2], StringComparison.OrdinalIgnoreCase)
					select sm.Description).FirstOrDefault();

				if (!string.IsNullOrWhiteSpace(codeE))
					yield return codeE;
			}
		}

		private ClaimStatusCode[] GetClaimStatusCodesByLob(LOB lob, bool processed, bool pending, bool denied)
		{
			var statusCodes = _claimsRepository.GetStatusCodes();

			return (
				from statusCode in statusCodes
				where
					statusCode.AreaPrefix.Equals(lob.ToString(), StringComparison.OrdinalIgnoreCase) &&
					(
						(statusCode.Status.Equals("TIMEOUT", StringComparison.OrdinalIgnoreCase)) ||
						(statusCode.Status.Equals("INVALIDREQ", StringComparison.OrdinalIgnoreCase)) ||
						(statusCode.Status.Equals("NOTFND", StringComparison.OrdinalIgnoreCase)) ||
						(processed && statusCode.StatusDisplay.Equals("Processed", StringComparison.OrdinalIgnoreCase)) ||
						(pending && statusCode.StatusDisplay.Equals("Pending", StringComparison.OrdinalIgnoreCase)) ||
						(denied && statusCode.StatusDisplay.Equals("Denied", StringComparison.OrdinalIgnoreCase)) ||
						(string.IsNullOrWhiteSpace(statusCode.StatusDisplay))
					)
				select CheckStatusDisplay(statusCode)
				).ToArray();
		}

		private ClaimStatusCode CheckStatusDisplay(ClaimStatusCode code)
		{
			if (string.IsNullOrWhiteSpace(code.StatusDisplay))
				code.StatusDisplay = code.Status;

			return code;
		}
		#endregion

		#region Get Claim
		public async Task<GetClaimResponse> GetClaimAsync(GetClaimRequest request, WebUser user)
		{
			
			request.Validate(user);

			var claimRequest = await _claimsRepository.GetClaimsAsync(request.RequestId);

			if (claimRequest == null)
				throw new RecordNotFoundException("The specified Claim Inquiry was not found");

			if (!claimRequest.UserId.Equals(user.UserId, System.StringComparison.OrdinalIgnoreCase))
				throw new UnauthorizedAccessException();

			return new GetClaimResponse()
			{
				Request = claimRequest
			};
		}
		#endregion

		#region Get Claim Status Messages
		public ClaimStatusMessagesResponse GetClaimStatusMessages(ClaimStatusMessagesRequest request)
		{
			request.Validate();

			return new ClaimStatusMessagesResponse()
			{
				StatusMessages = ClaimStatusMessages
			};
		}

		private ClaimStatusMessage[] ClaimStatusMessages
		{
			get => _memoryCache.GetOrCreate(Constants.CacheKeys.ClaimStatusMessages, Constants.Cache.SlidingFourHours(), _claimsRepository.GetMessages);
		}
		#endregion

		#region Get Claim Status Codes
		public ClaimStatusCodesResponse GetClaimStatusCodes(ClaimStatusCodesRequest request)
		{
			request.Validate();

			return new ClaimStatusCodesResponse()
			{
				StatusCodes = ClaimStatusCodes
			};
		}

		private ClaimStatusCode[] ClaimStatusCodes
		{
			get => _memoryCache.GetOrCreate(Constants.CacheKeys.ClaimsStatusCodes, Constants.Cache.SlidingFourHours(), _claimsRepository.GetStatusCodes);
		}

		#endregion

		#region Claim Details
		private DateTime GetDateOfService(string dates, bool isFirstDate)
		{
			try
			{
				var splitDates = dates.Split("-");
				var spot = isFirstDate ? 0 : 1;

				return new DateTime(int.Parse(splitDates[spot].Substring(0, 4)), int.Parse(splitDates[spot].Substring(4, 2)), int.Parse(splitDates[spot].Substring(6, 2)));

			}
			catch
			{
				return new DateTime();
			}
		}

		public async Task<ClaimDetailsHeaderResponse> GetClaimDetailsHeader(ClaimDetailsHeaderRequest request, WebUser user)
		{
			request.Validate(user);
			var claimRequest = await _claimsRepository.GetClaimsAsync(request.RequestId);

			if (claimRequest == null)
				throw new RecordNotFoundException("The specified Claim Inquiry was not found");

			if (!claimRequest.UserId.Equals(user.UserId, StringComparison.OrdinalIgnoreCase))
				throw new UnauthorizedAccessException();

			var lines = (from pc in claimRequest.ClaimResponse.ProviderClaims
									 from c in pc.Claims
									 from l in c.Lines
									 where c.ICN == request.ClaimsNumber
									 select l);

			var claims = (from pc in claimRequest.ClaimResponse.ProviderClaims
										from c in pc.Claims
										where c.ICN == request.ClaimsNumber
										select pc).FirstOrDefault();
			var claim = (from pc in claimRequest.ClaimResponse.ProviderClaims
									 from c in pc.Claims
									 where c.ICN == request.ClaimsNumber
									 select c).FirstOrDefault();

			var patient = _claimsRepository.GetPatientAddress(claims.MemberId, claimRequest.DateOfBirth.ToString("yyyy-MM-dd"));

			foreach (var line in lines)
			{
				var startDate = GetDateOfService(line.DateOfService, true).ToString("MM/dd/yyyy");
				var endDate = GetDateOfService(line.DateOfService, false).ToString("MM/dd/yyyy");

				line.DateOfService = (startDate == endDate) ? startDate : $"{startDate} - {endDate}";
			}

			return new ClaimDetailsHeaderResponse()
			{
				Header = new Models.Data.ClaimsDetails.ClaimsHeader()
				{
					PatientName = claims.DependentFirstName.IsNullOrEmpty() ? $"{claims.MemberFirstName.ToTitleCase()} {claims.MemberLastName.ToTitleCase()}" : $"{claims.DependentFirstName.ToTitleCase()} {claims.DependentLastName.ToTitleCase()}",
					MemberName = $"{claims.MemberFirstName.ToTitleCase()} {claims.MemberLastName.ToTitleCase()}",
					MemberDateOfBirth = claimRequest.DateOfBirth,
					MemberID = claimRequest.SubscriberId,
					Gender = claimRequest.PatientGender, // claims response always returns gender as 0 (male), so use the gender from the request object
					Relationship = patient?.Relationship,
					Address = patient == null ? null : new Models.Data.ClaimsDetails.Address()
					{
						Street1 = patient?.Street1.ToTitleCase(),
						Street2 = patient?.Street2.ToTitleCase(),
						City = patient?.City.ToTitleCase(),
						AddressState = patient?.AddressState,
						Zip = patient?.Zip,
						ZipExtension = patient?.ZipExtension
					},
					ClaimStatus = claim.StatusDisplay,
					ClaimNumber = claim.ICN,
					ClaimReceived = claim.ReceivedDate,
					StartDateOfService = GetDateOfService(claim.DatOfService, true),
					EndDateOfService = GetDateOfService(claim.DatOfService, false),
					ProcessedDate = (claim.PaymentDate != DateTime.MinValue) ? claim.PaymentDate : (DateTime?)null,
					StatusEffectiveDate = (claim.ClaimStatusDate != DateTime.MinValue) ? claim.ClaimStatusDate : (DateTime?)null,
					PriceForwardTo = claim.TPANumber.IsNullOrEmpty() ? null : claim.TPAInfo,
					ProviderName = $"{claims.ProviderFirstName.ToTitleCase()} {claims.ProviderLastName.ToTitleCase()}",
					PatientAccountNumber = claim.PatientAccount,
					HasRemit = true,   // TODO: Replace this with the Remit API when it's ready
					Lines = lines
				}
			};
		}
		#endregion

		#region Get Claims Status History		
		public async Task<ClaimsHistoryResponse> GetClaimsHistoryResultsAsync(WebUser webUser)
		{
			if (webUser == null) throw new ArgumentNullException(nameof(webUser));
			
			var days = (await _settingsManager.GetSettingValueAsync(Constants.Settings.Names.ClaimsHistoryNumOfDays, Constants.Settings.Defaults.ClaimsHistoryNumOfDays, webUser)).AsInt();
			
			return new ClaimsHistoryResponse()
			{
				Requests = await _claimsRepository.GetClaimsHistoryResultsAsync(webUser.OrgId, days),
				Days = days
			};
		}
		#endregion
	}
}

