﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories
{
	public class PatientRepository : IPatientRepository
	{
		private readonly IPatientsContext _patientsContext;

		public PatientRepository(IPatientsContext patientsContext)
		{
			_patientsContext = patientsContext;
		}

		public async Task<int> GetPatientsCountAsync(string orgId, string subscriberId)
		{

			var patients = from o in _patientsContext.PatientOrg
										 join p in _patientsContext.Patients
										 on o.PatientId equals p.PatientId
										 where o.OrgId.Equals(orgId) && (p.SubscriberId.StartsWith(subscriberId) || p.PatientLastName.StartsWith(subscriberId) || p.PatientFirstName.StartsWith(subscriberId))
										 select new Patient()
										 {
											 PatientLastName = p.PatientLastName,
											 PatientFirstName = p.PatientFirstName,
											 PatientGender = p.PatientGender,
											 SubscriberFirstName = p.SubscriberFirstName,
											 SubscriberLastName = p.SubscriberLastName,
											 DateOfBirth = p.DateOfBirth,
											 IsDependent = p.IsDependent,
											 LOB = p.LOB,
											 PatientId = p.PatientId,
											 SubscriberId = p.SubscriberId
										 };

			return await patients.CountAsync();
		}

		public async Task<IEnumerable<Patient>> SearchPatientsAsync(string orgId, string subscriberId, int pageNumber, int pageSize)
		{
			var patients = from o in _patientsContext.PatientOrg
										 join p in _patientsContext.Patients
										 on o.PatientId equals p.PatientId
										 where o.OrgId.Equals(orgId) && (p.SubscriberId.StartsWith(subscriberId) || p.PatientLastName.StartsWith(subscriberId) || p.PatientFirstName.StartsWith(subscriberId))
										 select new Patient() { 
											 PatientLastName = p.PatientLastName,
											 PatientFirstName = p.PatientFirstName,
											 PatientGender = p.PatientGender,
											 SubscriberFirstName = p.SubscriberFirstName,
											 SubscriberLastName = p.SubscriberLastName,
											 DateOfBirth = p.DateOfBirth,
											 IsDependent = p.IsDependent,
											 LOB = p.LOB,
											 PatientId = p.PatientId,
											 SubscriberId = p.SubscriberId
										 };

			return await patients.OrderBy(x=> x.SubscriberId).Skip((pageNumber - 1) * pageSize).Take(pageSize).ToListAsync();
		}
	}
}
