import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, AbstractControl, FormsModule } from '@angular/forms';
import { AngularMaterialSharedModule } from 'src/app/common/shared/angular-material-shared.module';
import { SharedModule } from 'src/app/common/shared/shared.module';
import { EftChangeRequestFormModule } from '../eft-change-request-form.module';

import { EftFinancialInstitutionInformationFormComponent } from './eft-financial-institution-information-form.component';

xdescribe('EftFinancialInstitutionInformationFormComponent', () => {
  let component: EftFinancialInstitutionInformationFormComponent;
  let fixture: ComponentFixture<EftFinancialInstitutionInformationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EftFinancialInstitutionInformationFormComponent ],
      imports: [ SharedModule, AngularMaterialSharedModule, FormsModule, EftChangeRequestFormModule ],
      providers: [ FormBuilder]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EftFinancialInstitutionInformationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
