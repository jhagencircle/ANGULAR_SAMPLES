﻿using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;
using BCBSAZ.Provider.Models.Requests.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Requests.Eligibility.Results;
using BCBSAZ.Provider.Models.Responses.Common;
using BCBSAZ.Provider.Models.Responses.Eligibility.Details;
using BCBSAZ.Provider.Models.Responses.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Responses.Eligibility.Results;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface IEligibilityService
	{
		Task<InquiryInfo> GetInquiryAsync(int responseId);

		Task<PatientDetail> GetPatientDetailAsync(int responseId);

		Task<EligibilitySummary> GetEligibilitySummaryAsync(int responseId);

		Task<InsuranceInfo> GetInsuranceInfoAsync(int responseId);

		Task<IEnumerable<CoordinationOfBenefits>> GetCoordinationOfBenefits(int responseId);

		Task<Dictionary<string, Dictionary<string, IEnumerable<Cost>>>> GetDeductiblesAsync(int responseId);

		Task<IEnumerable<BooksRiders>> GetBenefitBooksRidersAsync(int responseId);

		Task<Dictionary<string, ServiceTypeBenefitDictionary>> GetServiceTypeBenefitsAsync(int responseId);

		Task<Dictionary<string, IEnumerable<GeneralInformation>>> GetGeneralInformationAsync(int responseId);

		Task<IEnumerable<IdCard>> GetIdCardAsync(string subscriberId);

		Task<IEnumerable<IdCard>> GetNewIdCardAsync(string subscriberId);

		Task<ConvertEdiResponse> ConvertEdi(TestTool edi);

		Task<SubmitInquiriesResponse> SubmitInquiriesAsync(SubmitInquiriesRequest request);

		Task<IsValidGroupNumberResponse> IsValidCHSGroup(string GroupNum);
		
		Task<ServiceTypesResponse> GetServiceTypes();

		Task<PreviouslySelectedServiceTypeResponse> GetPreviouslySelectedServiceTypesAsync(string userId);

		Task<Select2Response> GetDiagnosisCodes(Select2Request request);

		Task<DisclaimerResponse> GetDisclaimer(int responseId);

		Task<EligibilityResultsResponse> GetEligibilityResultsAsync(EligibilityResultsRequest request);

		Task<DeleteInquiriesResponse> DeleteEligibilityInquiriesAsync(DeleteInquiriesRequest requestIds);
	}
}
