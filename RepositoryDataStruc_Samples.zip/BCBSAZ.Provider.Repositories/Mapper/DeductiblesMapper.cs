﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Xml271Processor.Codes;
using BCBSAZ.Provider.Models.Xml271Processor.Interfaces;

namespace BCBSAZ.Provider.Repositories.Mapper
{
	public class DeductiblesMapper : IBenefitMapper<Cost>
	{
		public IEnumerable<Cost> Map(IEligibilityBenefit[] limitArr, IEligibilityBenefit[] remainingArr)
		{

			for (var i = 0; i < limitArr.Length; i++)
			{
				var limitBenefitInfo = limitArr.ElementAtOrDefault(i)?.BenefitInformation;
				var limitAdditionalBenefitInfo = limitArr.ElementAtOrDefault(i)?.AdditionalBenefitInformation;
				var remaining = remainingArr.ElementAtOrDefault(i);
				var isIndividual = limitBenefitInfo.CoverageLevel == CoverageLevel.Individual;
				var messages = new List<string>(from x in limitArr[i].Messages select x.Text);

				if (remaining != null)
					messages.AddRangeIfNotNullOrEmpty(from x in remaining.Messages select x.Text);

				yield return new Cost
				{
					Type = isIndividual ? "Individual" : "Family",
					PlaceOfService = limitAdditionalBenefitInfo.GetPlaceOfService(),
					LimitAuthorizationStatus = limitBenefitInfo.GetAuthorizationStatus(),
					RemainingAuthorizationStatus = remaining?.BenefitInformation.GetAuthorizationStatus(),
					Remaining = decimal.TryParse(remaining?.BenefitInformation.BenefitAmount, out var remainingAmt) ? (decimal?)remainingAmt : null,
					Limit = decimal.TryParse(limitBenefitInfo?.BenefitAmount, out var limitAmt) ? (decimal?)limitAmt : null,
					TimePeriod = (limitBenefitInfo.TimePeriodQualifier != null) ? TimePeriod.I.Find(x => x.Code == limitBenefitInfo.TimePeriodQualifier).Name : Constants.Eligibility.DefaultServiceTypeDisplayString,
					AdditionalInfo = messages.Distinct()
				};
			}
		}
	}
}
