import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { IRelationship } from './models/relationship.model';

@Injectable({
  providedIn: 'root',
})
export class RelationshipService {
  url = `${environment.apiUrl}/api/Employer`;
  constructor(private http: HttpClient) {}
  get() {
    return this.http.get<IRelationship[]>(`${this.url}/relationships`);
  }
  getByCoverage(coverageId: string) {
    return this.http.get<any>(`${this.url}/${coverageId}/RelationShipCoverage`);
  }
}
