﻿using BCBSAZ.Provider.Models.Data.FeatureToggles;
using Microsoft.EntityFrameworkCore;
using TogEnviron = BCBSAZ.Provider.Models.Data.FeatureToggles.Environment;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IMemberFeaturesContext : IDbContext
	{
		/// <summary>
		/// Gets the DbSet object for Feature Toggles
		/// </summary>
		DbSet<FeatureToggle> FeatureToggles { get; }

		/// <summary>
		/// Gets the DbSet object for Applications
		/// </summary>
		DbSet<Application> Applications { get; }

		/// <summary>
		/// Gets the DbSet object for Environments
		/// </summary>
		DbSet<TogEnviron> Environments { get; }
	}

	public class MemberFeaturesContext : DbContext, IMemberFeaturesContext
	{
		/// <summary>
		/// Creates a new instance of the MemberFeatures DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public MemberFeaturesContext(DbContextOptions<MemberFeaturesContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<FeatureToggle>().HasNoKey();
			modelBuilder.Entity<Application>().HasNoKey();
			modelBuilder.Entity<TogEnviron>().HasNoKey();
		}

		/// <summary>
		/// Gets the DbSet object for Feature Toggles
		/// </summary>
		public DbSet<FeatureToggle> FeatureToggles { get; protected set; }

		/// <summary>
		/// Gets the DbSet object for Applications
		/// </summary>
		public DbSet<Application> Applications { get; protected set; }

		/// <summary>
		/// Gets the DbSet object for Environments
		/// </summary>
		public DbSet<TogEnviron> Environments { get; protected set; }

	}
}
