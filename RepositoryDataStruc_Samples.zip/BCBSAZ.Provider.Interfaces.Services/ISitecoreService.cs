﻿using BCBSAZ.Provider.Models.Data.Sitecore;
using BCBSAZ.Provider.Models.Data.NavigationMenu;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.WebUI.Models.Security;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.TPA;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface ISitecoreService
	{
		Task<IEnumerable<SitecoreAlert>> GetProviderAlertsAsync();

		Task<IEnumerable<SitecoreAlert>> GetTpaAlertsAsync();

		Task<SitecoreItem> GetSitecoreItemByGuidAsync(string guid);

		Task<IEnumerable<TopMenuItem>> GetNavigationMenu(WebUser user, NavMenuType menuType);

		Task<MenuItem> GetNavigationMenuItem(WebUser user, NavMenuType menuType, string itemGuid, string sectionName, string catName);

		Task<IEnumerable<SitecoreSecurityQuestion>> GetSecurityQuestionsAsync();

		NavigationMenuData GetNavigationMenuData(WebUser user);

		Task<string> GetPcmhTabAsync(HttpRequest request);

		Task<TpaHomePageContent> GetTpaHomePageContent(string guid);

		Task<SitecoreContentItem> GetRawContentByGuidAsync(string guid);
	}
}
