﻿using BCBSAZ.ProviderCredentialing.Interfaces.Repositories;
using BCBSAZ.ProviderCredentialing.Models.Data.Applications;
using BCBSAZ.ProviderCredentialing.Repositories.DbContexts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.Repositories
{
	public class ApplicationRepository : IApplicationRepository
	{
		private readonly ICredentialingContext _context;

		public ApplicationRepository(ICredentialingContext context) =>
			_context = context;


		public async Task SaveApplicationAsync(Application application)
		{
			await _context.Applications.AddAsync(application);
			await _context.SaveChangesAsync();
		}
	}
}
