﻿using BCBSAZ.Provider.Models.Data.Settings;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface ISettingsContext : IDbContext
	{
		DbSet<SettingType> SettingTypes { get; }

		DbSet<SettingApplication> SettingApplications { get; }

		DbSet<Setting> Settings { get; }

		DbSet<UserTypeSetting> UserTypeSettings { get; }

		DbSet<UserSetting> UserSettings { get; }

	}

	/// <summary>
	/// Defines the Entity Framework DbContext object for the FeeSched database
	/// </summary>
	public class SettingsContext : DbContext, ISettingsContext
	{
		/// <summary>
		/// Creates a new instance of the FeeSched DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public SettingsContext(DbContextOptions<SettingsContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the ProviderInet database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
		}

		public DbSet<SettingType> SettingTypes { get; protected set; }

		public DbSet<SettingApplication> SettingApplications { get; protected set; }

		public DbSet<Setting> Settings { get; protected set; }

		public DbSet<UserTypeSetting> UserTypeSettings { get; protected set; }

		public DbSet<UserSetting> UserSettings { get; protected set; }

	}
}
