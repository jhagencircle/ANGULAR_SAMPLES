import {
  Component,
  EventEmitter,
  OnInit,
  Input,
  ViewChild,
  Output,
} from '@angular/core';
import { BankAccountService } from 'src/app/bank-account/shared/bank-account.service';
import { AccountService } from 'src/app/shared/services/account.service';
import { ISummary } from 'src/app/shared/models/summary.model';
import { BankAccount } from 'src/app/bank-account/shared/bank-account.model';
import { FormBuilder, Validators } from '@angular/forms';
import { PaymentsService } from '../shared/payments.service';
import { Subject, Subscription } from 'rxjs';
import { IScheduledPayment } from '../shared/scheduled-payment.model';
import { AppConstants } from 'src/app/shared/constants/app-constants';

@Component({
  selector: 'app-scheduled-payment-edit',
  templateUrl: './scheduled-payment-edit.component.html',
  styleUrls: ['./scheduled-payment-edit.component.scss'],
})
export class ScheduledPaymentEditComponent implements OnInit {
  @Input() paymentInfo: IScheduledPayment;
  @Output() refreshScheduledPayments = new EventEmitter<any>();

  account: ISummary;
  bankAccounts: BankAccount[];
  amount: string;
  sendPaymentForm: Subject<void> = new Subject<void>();
  minDate: Date;
  maxDate: Date;
  futureDate: Date;
  subscriptions: Subscription[] = [];

  constructor(
    private accountService: AccountService,
    private bankAccountService: BankAccountService,
    public fb: FormBuilder,
    private paymentsService: PaymentsService
  ) {
    this.minDate = new Date();
    this.futureDate = new Date();
    this.futureDate.setDate(
      this.futureDate.getDate() +
        AppConstants.ADD_DAYS_MAX_PAYMENT_DATE_SMALL_ACCOUNT
    );
    this.maxDate = this.futureDate;
    if (!this.account) {
      this.accountService.get().subscribe((account: ISummary) => {
        if (account) {
          this.account = account;
          if (this.account.asc) {
            this.futureDate = new Date();
            this.futureDate.setDate(
              this.futureDate.getDate() +
                AppConstants.ADD_DAYS_MAX_PAYMENT_DATE_LARGE_ACCOUNT
            );
            this.maxDate = this.futureDate;
          }
        }
      });
    }
  }

  scheduledPaymentForm = this.fb.group({
    date: ['', [Validators.required]],
    bankAccount: ['', [Validators.required]],
  });

  get f() {
    return this.scheduledPaymentForm.controls;
  }

  ngOnInit(): void {
    this.f.date.setValue(new Date(this.paymentInfo?.paymentTransactionDate));
    this.amount = this.paymentsService.parseCurrency(
      this.paymentInfo?.paymentAmount
    );
    this.bankAccountService.get(this.account?.accountId).subscribe((data) => {
      this.bankAccounts = data;
      this.f.bankAccount.setValue(this.paymentInfo?.paymentTokenId);
    });
  }

  onCancel() {
    this.paymentInfo.isEdit = false;
  }

  onFormSubmit() {
    if (this.scheduledPaymentForm.valid) {
      this.setScheduledPaymentChanges();
      this.paymentsService
        .updateScheduledPayment(this.account?.accountId, this.paymentInfo)
        .subscribe(() => {
          this.paymentInfo.isEdit = false;
        });
    }
  }

  onClick() {
    this.amount = this.paymentsService.parseNumber(this.amount).toString();
  }

  onFocusOut() {
    this.amount = this.paymentsService.parseCurrency(parseFloat(this.amount));
  }

  setScheduledPaymentChanges() {
    this.paymentInfo.paymentTransactionDate = this.f.date.value
      ? this.f.date.value
      : '';
    this.paymentInfo.paymentAmount = this.paymentsService.parseNumber(
      this.amount
    );
    this.paymentInfo.paymentTokenId =
      this.bankAccounts.find(
        (element: any) => element.id === parseInt(this.f.bankAccount.value)
      )?.id ?? '';
  }
}
