﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models.Data.Eligibility;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Xml271Processor;
using BCBSAZ.Provider.Models.Xml271Processor.Codes;
using BCBSAZ.Provider.Models.Xml271Processor.Interfaces;
using BCBSAZ.Provider.Repositories.Mapper;
using ModelAddress = BCBSAZ.Provider.Models.Data.Eligibility.Details.Address;

namespace BCBSAZ.Provider.Repositories
{
	internal static class Xml271DataExtensions
	{
		public static SubscriberRecord GetSubscriber(this InquiryResult inquiry)
		{
			if (inquiry == null) return null;

			return (
				from info in inquiry.Transaction.Information
				where !info.Receivers.IsNullOrEmpty()
				from r in info.Receivers
				where !r.Subscribers.IsNullOrEmpty()
				from s in r.Subscribers
				select s.Subscriber).FirstOrDefault();
		}

		public static DependentRecord GetDependent(this InquiryResult inquiry)
		{
			if (inquiry == null) return null;

			return (
				from info in inquiry.Transaction.Information
				where !info.Receivers.IsNullOrEmpty()
				from r in info.Receivers
				where !r.Subscribers.IsNullOrEmpty()
				from s in r.Subscribers
				where !s.Dependents.IsNullOrEmpty()
				from d in s.Dependents
				select d.Dependent).FirstOrDefault();
		}

		public static IInsuredEntity GetInsuredEntity(this InquiryResult inquiry)
		{
			if (inquiry == null) return null;

			if (inquiry.IsDependentInquiry())
				return inquiry.GetDependent();

			return inquiry.GetSubscriber();
		}

		public static IEnumerable<string> GetServiceTypes(this InquiryResult inquiry)
		{
			if (string.IsNullOrWhiteSpace(inquiry?.ServiceType))
				return new[] { "N/A" };

			var serviceType = inquiry.ServiceType.Trim();
			return (
				from st in ServiceTypes.I
				where st.Code.Equals(serviceType, StringComparison.OrdinalIgnoreCase)
				select st.Name.ToTitleCase());
		}

		public static bool IsTieredDeductibles(this IInsuredEntity insuredEntity, int tierLevel = -1)
		{
			if ((insuredEntity?.EligibilityBenefits).IsNullOrEmpty()) return false;

			foreach (var benefit in insuredEntity.EligibilityBenefits)
			{
				// First check if REF segment contians Tier information.
				if (benefit.AdditionalIdentification.EmptyIfNull().Any(r => TierInformation.GetTierLevel(r.InformationReceiverAdditionalIdentifierState, null) > 0))
				{
					// REF segment contains Tier information, look for tier match.
					if (benefit.AdditionalIdentification.EmptyIfNull().Any(r => isTierMatch(TierInformation.GetTierLevel(r.InformationReceiverAdditionalIdentifierState, null), tierLevel)))
						return true;
				}
				else
				{
					// Tier information is in MSG segment, look for tier match.
					if (benefit.Messages.EmptyIfNull().Any(m => isTierMatch(TierInformation.GetTierLevel(null, m.Text), tierLevel)))
						return true;
				}
			}

			return false;

			static bool isTierMatch(int actual, int expected) =>
				(expected == -1) ? actual > 0 : expected == actual;
		}

		public static Dictionary<string, IEnumerable<Cost>> GetDeductibles(this IInsuredEntity insured, int tierLevel, string networkType, string serviceType)
		{
			if (insured == null) return null;

			var deductibles = new Dictionary<string, IEnumerable<Cost>>
			{
				{ "Deductible", insured.GetDeductiblesByCoverageLevel(BenefitInfoTypes.Deductible, networkType, serviceType, tierLevel)},
				{ "Out Of Pocket", insured.GetDeductiblesByCoverageLevel(BenefitInfoTypes.Out_of_Pocket_Stop_Loss_, networkType, serviceType, tierLevel)}
			};

			deductibles = new Dictionary<string, IEnumerable<Cost>>(
				from x in deductibles
				where x.Value.Any()
				select x
			);

			return deductibles.Values.Any(list => list.Any()) ? deductibles : null;
		}

		public static Dictionary<string, IEnumerable<Cost>> GetTieredRegularInNetworkDeductibles(this IInsuredEntity insured, string networkType, string serviceType)
		{
			var deductiblesLibrary = new Dictionary<string, IEnumerable<Cost>>();

			if (insured != null) 
			{
				var deductibles = insured.GetDeductiblesByCoverageLevel(BenefitInfoTypes.Deductible, networkType, serviceType);
				var outOfPockets = insured.GetDeductiblesByCoverageLevel(BenefitInfoTypes.Out_of_Pocket_Stop_Loss_, networkType, serviceType);

				if (deductibles.Any())
				{
					deductiblesLibrary.Add("Deductible", deductibles);
				}

				if (outOfPockets.Any())
				{
					deductiblesLibrary.Add("Out Of Pocket", outOfPockets);
				}
			}
			var deductiblesResult = new Dictionary<string, IEnumerable<Cost>>(
				from x in deductiblesLibrary
				where x.Value.Any()
				select x
			);

			return deductiblesResult.Values.Any() ? deductiblesResult : null;
		}

		public static IEnumerable<Cost> GetDeductiblesByCoverageLevel(this IInsuredEntity insured, string benefitInfoType, string networkType, string serviceType, int tierLevel = -1)
		{
			if ((insured?.EligibilityBenefits).IsNullOrEmpty())
				return Enumerable.Empty<Cost>();

			IEnumerable<IEligibilityBenefit> benefits;
			if (tierLevel == 0)
			{
				benefits = (
					from e in insured.EligibilityBenefits
					where
						e.BenefitInformation != null &&
						string.Equals(e.BenefitInformation.InPlanNetwork, networkType, StringComparison.OrdinalIgnoreCase) &&
						string.Equals(e.BenefitInformation.EligibilityOrBenefitInformation, benefitInfoType, StringComparison.OrdinalIgnoreCase) &&
						e.BenefitInformation.ServiceTypeCodes.Contains(ServiceTypes.Health_Benefit_Plan_Coverage, StringComparer.OrdinalIgnoreCase) &&
						e.BenefitInformation.TimePeriodQualifier != TimePeriod.Year_to_Date
					select e);
			}
			else if (tierLevel == -1)
			{
				var benefitsByServiceCode = insured.EligibilityBenefits.GetBenefitsByServiceCode(serviceType);

				if (benefitsByServiceCode.IsNullOrEmpty())
					return null;

				List<IEligibilityBenefit> services = new List<IEligibilityBenefit>();

				foreach (var benefit in benefitsByServiceCode)
				{
					if (!networkType.Equals(benefit.BenefitInformation.InPlanNetwork, StringComparison.OrdinalIgnoreCase))
					{
						continue;
					}

					if (string.Equals(benefit.BenefitInformation.EligibilityOrBenefitInformation, benefitInfoType, StringComparison.OrdinalIgnoreCase) && benefit.BenefitInformation.TimePeriodQualifier != TimePeriod.Year_to_Date)
					{
						var refLevel = benefit.AdditionalIdentification.EmptyIfNull().Select(r => TierInformation.GetTierLevel(r.InformationReceiverAdditionalIdentifierState, null)).Max(0);
						var msgLevel = benefit.Messages.EmptyIfNull().Select(m => TierInformation.GetTierLevel(null, m.Text)).Max(0);

						if ((refLevel <= 0) && (msgLevel <= 0))
						{
							services.Add(benefit);
						}
					}
				}

				benefits = services;
			}
			else
			{
				benefits = (
					from e in insured.EligibilityBenefits
					from msg in e.Messages.DefaultIfEmpty(new Message())
					from add in e.AdditionalIdentification.DefaultIfEmpty(new AdditionalIdentification())
					where
						e.BenefitInformation != null &&
						string.Equals(e.BenefitInformation.InPlanNetwork, networkType, StringComparison.OrdinalIgnoreCase) &&
						string.Equals(e.BenefitInformation.EligibilityOrBenefitInformation, benefitInfoType, StringComparison.OrdinalIgnoreCase) &&
						e.BenefitInformation.ServiceTypeCodes.Contains(ServiceTypes.Health_Benefit_Plan_Coverage, StringComparer.OrdinalIgnoreCase) &&
						TierInformation.GetTierLevel(add?.InformationReceiverAdditionalIdentifierState, msg?.Text) == tierLevel &&
						e.BenefitInformation.TimePeriodQualifier != TimePeriod.Year_to_Date
					select e);
			}

			if (!benefits.Any())
				return Enumerable.Empty<Cost>();

			return benefits.GetDeductibleBalances(networkType, new DeductiblesMapper());
		}

		/// <summary>
		/// Takes a collection of ElgibilityBenefit objects and maps them to T
		/// </summary>
		/// <param name="benefits">Collection to return Deductible Balance objects from</param>
		/// <param name="networkType"></param>
		/// <param name="mapper">Mapper </param>
		/// <returns>A new Collection of Cost objects</returns>
		public static IEnumerable<T> GetDeductibleBalances<T>(this IEnumerable<IEligibilityBenefit> benefits, string networkType, IBenefitMapper<T> mapper)
		{
			if (benefits == null) benefits = Enumerable.Empty<IEligibilityBenefit>();

			var limit = (
				from x in benefits
				where
					string.Equals(x.BenefitInformation.InPlanNetwork, networkType, StringComparison.OrdinalIgnoreCase) &&
					(TimePeriod.LimitPeriod.Contains(x?.BenefitInformation?.TimePeriodQualifier ?? string.Empty, StringComparer.OrdinalIgnoreCase) || x?.BenefitInformation?.TimePeriodQualifier == null)
				select x).ToArray();

			var remaining = (
				from x in benefits
				where
					string.Equals(x.BenefitInformation.InPlanNetwork, networkType, StringComparison.OrdinalIgnoreCase) &&
					TimePeriod.RemainingPeriod.Contains(x?.BenefitInformation?.TimePeriodQualifier ?? string.Empty, StringComparer.OrdinalIgnoreCase)
				select x).ToArray();

			return mapper.Map(limit, remaining);
		}

		#region Service Types
		public static IEnumerable<Limitation> GetVisitLimits(this IEnumerable<IEligibilityBenefit> limitationBenefits, string networkType, IBenefitMapper<Limitation> mapper)
		{
			var limit = (
				from x in limitationBenefits
				where
					x.BenefitInformation.TimePeriodQualifier != null &&
					!TimePeriod.Remaining.Equals(x.BenefitInformation.TimePeriodQualifier, StringComparison.OrdinalIgnoreCase) &&
					string.Equals(x.BenefitInformation.InPlanNetwork, networkType, StringComparison.OrdinalIgnoreCase)
				select x).ToArray();

			var remaining = (
				from x in limitationBenefits
				where TimePeriod.Remaining.Equals(x.BenefitInformation.TimePeriodQualifier, StringComparison.OrdinalIgnoreCase)
				select x).ToArray();

			return mapper.Map(limit, remaining);
		}

		public static ServiceTypeBenefit GetServiceTypeBenefits(this IInsuredEntity entity, int tierLevel = 0, string networkType = NetworkType.In_Network, string serviceType = "")
		{
			try
			{
				var benefitsByServiceCode = (entity?.EligibilityBenefits == null) ? null : entity.EligibilityBenefits.GetBenefitsByServiceCode(serviceType);

				var activeSatus = (
					from x in benefitsByServiceCode
					from y in x.BenefitInformation.EligibilityOrBenefitInformation //where x.BenefitInformation.EligibilityOrBenefitInformation == "1"
					select y);

				IEnumerable<IEligibilityBenefit> serviceTypeList = null;

				if (!benefitsByServiceCode.IsNullOrEmpty())
				{
					if (tierLevel == 0)
					{
						serviceTypeList = (
							from x in benefitsByServiceCode
							where
								string.Equals(x.BenefitInformation.InPlanNetwork, networkType, StringComparison.OrdinalIgnoreCase) &&
								BenefitInfoTypes.AllServiceTypeRowFilters.Contains(x.BenefitInformation.EligibilityOrBenefitInformation, StringComparer.OrdinalIgnoreCase) &&
								x.BenefitInformation.TimePeriodQualifier != TimePeriod.Year_to_Date
							select x);

						if (networkType == NetworkType.Network_Unknown)
						{
							serviceTypeList = serviceTypeList.Union(
								from x in benefitsByServiceCode
								where
									x.BenefitInformation.InPlanNetwork == null &&
									x.BenefitInformation.TimePeriodQualifier != TimePeriod.Year_to_Date
								select x);
						}

						serviceTypeList = serviceTypeList.Union(
							from x in benefitsByServiceCode
							where
							 string.Equals(x.BenefitInformation?.InPlanNetwork, networkType, StringComparison.OrdinalIgnoreCase) &&// && !x.Messages.IsNullOrEmpty()
								x.BenefitInformation.TimePeriodQualifier != TimePeriod.Year_to_Date
							select x);
					}
					else
					{
						List<IEligibilityBenefit> services = new List<IEligibilityBenefit>();

						foreach (var benefit in benefitsByServiceCode)
						{
							if ((!string.Equals(benefit.BenefitInformation.InPlanNetwork, networkType, StringComparison.OrdinalIgnoreCase)) ||
								(!BenefitInfoTypes.AllServiceTypeRowFilters.Contains(benefit.BenefitInformation.EligibilityOrBenefitInformation, StringComparer.OrdinalIgnoreCase)))
							{
								continue;
							}

							if (benefit.BenefitInformation.TimePeriodQualifier != TimePeriod.Year_to_Date)
							{
								var refLevel = benefit.AdditionalIdentification.EmptyIfNull().Select(r => TierInformation.GetTierLevel(r.InformationReceiverAdditionalIdentifierState, null)).Max(0);
								var msgLevel = benefit.Messages.EmptyIfNull().Select(m => TierInformation.GetTierLevel(null, m.Text)).Max(0);

								if (refLevel > 0)
								{
									if (refLevel == tierLevel)
									{
										services.Add(benefit);
									}
								}
								else if (msgLevel == tierLevel)
								{
									services.Add(benefit);
								}
							}							
						}

						serviceTypeList = services.AsEnumerable();
					}
				}

				if (serviceTypeList.IsNullOrEmpty())
					return new ServiceTypeBenefit()
					{
						Deductibles = Enumerable.Empty<ServiceTypeDeductible>(),
						ServiceTypeRows = Enumerable.Empty<ServiceTypeRow>(),
						Limitations = Enumerable.Empty<Limitation>(),
					};

				return serviceTypeList.MapToServiceTypeBenefits(networkType);
			}
			catch (Exception ex)
			{
				var message = $"Error reading Service Type Benefit information for {tierLevel} {networkType} {serviceType}: {ex.Message}";
				return new ServiceTypeBenefit($"{message}: ");
			}
		}

		public static ServiceTypeBenefit GetTieredRegularInNetwork(this IInsuredEntity entity, string networkType, string serviceType = "")
		{
			try
			{
				var benefitsByServiceCode = entity.EligibilityBenefits.GetBenefitsByServiceCode(serviceType);

				if (benefitsByServiceCode.IsNullOrEmpty())
					return null;

				List<IEligibilityBenefit> services = new List<IEligibilityBenefit>();

				foreach (var benefit in benefitsByServiceCode)
				{
					if (!networkType.Equals(benefit.BenefitInformation.InPlanNetwork, StringComparison.OrdinalIgnoreCase))
					{
						continue;
					}

					if (benefit.BenefitInformation.TimePeriodQualifier != TimePeriod.Year_to_Date)
					{
						var refLevel = benefit.AdditionalIdentification.EmptyIfNull().Select(r => TierInformation.GetTierLevel(r.InformationReceiverAdditionalIdentifierState, null)).Max(0);
						var msgLevel = benefit.Messages.EmptyIfNull().Select(m => TierInformation.GetTierLevel(null, m.Text)).Max(0);

						if ((refLevel <= 0) && (msgLevel <= 0))
						{
							services.Add(benefit);
						}
					}
				}

				var benefits = services;

				if (benefits.IsNullOrEmpty())
					return null;

				return benefits.MapToServiceTypeBenefits(networkType);
			}
			catch (Exception ex)
			{
				var message = $"Error reading Tiered Regular In Network information for {serviceType}: {ex.Message}";
				return new ServiceTypeBenefit($"{message}: ");
			}

		}

		public static ServiceTypeBenefit MapToServiceTypeBenefits(this IEnumerable<IEligibilityBenefit> benefits, string networkType)
		{
			if (benefits == null)
				benefits = Enumerable.Empty<IEligibilityBenefit>();

			var serviceTypeBenefit = new ServiceTypeBenefit();

			var deductibles = (
				from x in benefits
				where BenefitInfoTypes.ServiceTypeDeductibleRowFilters.Contains(x.BenefitInformation?.EligibilityOrBenefitInformation, StringComparer.OrdinalIgnoreCase)
				select x);

			serviceTypeBenefit.Deductibles = deductibles.GetDeductibleBalances(networkType, new ServiceTypeMapper());


			var limitedBenefits = (
			from x in benefits
			where BenefitInfoTypes.VisitLimitRowFilters.Contains(x.BenefitInformation?.EligibilityOrBenefitInformation, StringComparer.OrdinalIgnoreCase)
			select x);

			serviceTypeBenefit.Limitations = limitedBenefits.GetVisitLimits(networkType, new LimitationsMapper());

			var serviceTypeRows = (
				from x in benefits
				where
					x.BenefitInformation != null &&
					BenefitInfoTypes.ServiceTypeRowFilters.Contains(x.BenefitInformation.EligibilityOrBenefitInformation, StringComparer.OrdinalIgnoreCase)
				select GetServiceTypeRow(benefits, x));


			serviceTypeRows = serviceTypeRows.Union(
				from x in benefits
				where
				x.BenefitInformation != null &&
				BenefitInfoTypes.EligibilityStatusActive.Contains(x.BenefitInformation.EligibilityOrBenefitInformation, StringComparer.OrdinalIgnoreCase)
				select GetServiceTypeRow(benefits, x, true));

			serviceTypeBenefit.ServiceTypeRows = serviceTypeRows;

			if (serviceTypeBenefit.Deductibles.IsNullOrEmpty()  && serviceTypeBenefit.ServiceTypeRows.IsNullOrEmpty() && serviceTypeBenefit.Limitations.IsNullOrEmpty())
				return null;

			return serviceTypeBenefit;
		}

		private static ServiceTypeRow GetServiceTypeRow(IEnumerable<IEligibilityBenefit> benefits, IEligibilityBenefit x, bool isActive = false)
		{
			return new ServiceTypeRow
			{
#if DEBUG
				EbLoopSegment = x.BenefitInformation.EligibilityOrBenefitInformation,
#endif

				EligibilityStatus = isActive ? benefits.GetEligibilityStatus() : EligibilityStatus.Unknown,
				PlaceOfService = x.AdditionalBenefitInformation.GetPlaceOfService(),
				CoverageLevel = x.BenefitInformation.TranslateCoverageLevel(),
				CoPay = new CoPay
				{
					Amount = double.TryParse(x.BenefitInformation.BenefitAmount, out var copay) ? (double?)copay : null,
					AuthorizationStatus = x.BenefitInformation.GetAuthorizationStatus(),
					TimePeriod = new TimePeriodQual()
					{
						Code = x.BenefitInformation.TimePeriodQualifier,
						Name = (
											from tp in TimePeriodQualifiers.TimePeriods()
											where tp.Code.Equals(x.BenefitInformation.TimePeriodQualifier, StringComparison.OrdinalIgnoreCase)
											select tp.Name).FirstOrDefault(),
						DisplayText = (
											from tp in TimePeriodQualifiers.TimePeriods()
											where tp.Code.Equals(x.BenefitInformation.TimePeriodQualifier, StringComparison.OrdinalIgnoreCase)
											select tp.DisplayText).FirstOrDefault()
					}
				},
				CoInsurance = new CoInsurance
				{
					Amount = double.TryParse(x.BenefitInformation.BenefitPercentage, out var coinsurance) ? (double?)coinsurance : null,
					AuthorizationStatus = x.BenefitInformation.GetAuthorizationStatus()
				},
				AdditionalInformation = new AdditionalInformation
				{
					Other = x.Messages.IsNullOrEmpty() ? Enumerable.Empty<string>() : x.Messages.Select(y => y.Text),
					NonCovered = x.TranslateToNonCovered(),
					Exclusions = x.GetExclusions(),
					EntityContacts = x.GetContractedServiceProvider(),
					HealthCareServiceDeliveries = x.GetHealthCareServicesDelivery()
				}
			};
		}


		public static IEnumerable<Exclusion> GetExclusions(this IEligibilityBenefit benefit)
		{
			if (BenefitInfoTypes.Exclusions.Equals(benefit?.BenefitInformation?.EligibilityOrBenefitInformation, StringComparison.OrdinalIgnoreCase))
			{
				yield return new Exclusion
				{
					Messages = benefit.Messages.IsNullOrEmpty() ? Enumerable.Empty<string>() : benefit.Messages.Select(m => m.Text),
					QuantityQualifier = QuantityQualifier.I.Find(x => x.Code.Equals(benefit.BenefitInformation.QuantityQualifier, StringComparison.OrdinalIgnoreCase))?.Name,
					Quantity = benefit.BenefitInformation.BenefitQuantity
				};
			}
		}

		public static IEnumerable<NonCovered> TranslateToNonCovered(this IEligibilityBenefit benefit)
		{
			if (BenefitInfoTypes.Non_Covered.Equals(benefit?.BenefitInformation?.EligibilityOrBenefitInformation, StringComparison.OrdinalIgnoreCase))
			{
				yield return new NonCovered
				{
					Amount = decimal.TryParse(benefit.BenefitInformation.BenefitAmount, out var amount) ? amount : null as decimal?,
					PlanCoverageDescription = benefit.BenefitInformation.PlanCoverageDescription,
					PlaceOfService = benefit.AdditionalBenefitInformation.GetPlaceOfService(),
					Messages = benefit.Messages.IsNullOrEmpty() ? Enumerable.Empty<string>() : benefit.Messages.Select(m => m.Text)
				};
			}
		}

		public static IEnumerable<BenefitRelatedEntityProvider> GetContractedServiceProvider(this IEligibilityBenefit benefit)
		{
			if (benefit.BenefitRelatedEntity == null)
				return Enumerable.Empty<BenefitRelatedEntityProvider>();

			return (
				from rec in benefit.BenefitRelatedEntity.Records
				where !rec.Contacts.IsNullOrEmpty()
				from con in rec.Contacts
				select new BenefitRelatedEntityProvider()
				{
					Entity = new Entity
					{
						Name = rec.Name.LastName,
						IdentifierCode = NameTypes.I.Find(nt => nt.Code == rec.Name.EntityCode)?.Name
					},
					ServiceProvider = new ContractedServiceProvider
					{
						FunctionCode = FunctionCodes.I.Find(fc => fc.Code == con.Function)?.Name,
						Name = con.Name,
						CommunicationNumbers = con.Numbers.Where(num => num.code != null || num.number != null),
					}
				});
		}

		//public static IEnumerable<ContractedServiceProvider> 

		public static bool HasExclusions(this IEnumerable<IEligibilityBenefit> benefits)
		{
			if (benefits.IsNullOrEmpty()) return false;

			return (
				from x in benefits
				where BenefitInfoTypes.Exclusions.Equals(x.BenefitInformation?.EligibilityOrBenefitInformation, StringComparison.OrdinalIgnoreCase)
				select x).Any();
		}

		public static bool HasHsd(this IEligibilityBenefit benefit)
		{
			return !(benefit?.ServicesDeliveries).IsNullOrEmpty();
		}

		public static string GetPlaceOfService(this List<AdditionalBenefitInformationLoop> additionalBenefitInformation)
		{
			//TODO: move this to LookupCodes
			var tempCodeListQualifier = new[] { "GR", "NI", "ZZ" };

			var taco = (from x in additionalBenefitInformation
									where x.EligibilityorBenefitAdditionalInformation.CodeListQualifier != null ||
												tempCodeListQualifier.Contains(x.EligibilityorBenefitAdditionalInformation.CodeListQualifier)
									select x.EligibilityorBenefitAdditionalInformation.Industry).FirstOrDefault();


			return IndustryCode.I.Find(x => x.Code.Equals(taco, StringComparison.OrdinalIgnoreCase))?.Name ?? Constants.Eligibility.DefaultServiceTypeDisplayString;
		}

		public static string TranslateCoverageLevel(this BenefitInformation benefitInfo)
		{
			return CoverageLevel.I.Find(x => x.Code.Equals(benefitInfo?.CoverageLevel, StringComparison.OrdinalIgnoreCase))?.Name ?? Constants.Eligibility.DefaultServiceTypeDisplayString;
		}

		public static IEnumerable<HealthCareServicesDelivery> GetHealthCareServicesDelivery(this IEligibilityBenefit benefit)
		{
			if (!benefit.HasHsd())
				return Enumerable.Empty<HealthCareServicesDelivery>();

			return (
				from service in benefit.ServicesDeliveries
				select new HealthCareServicesDelivery
				{
					QuantityQualifier = HealthServicesDeliveryQuantityQualifier.I.Find(x => x.Code.Equals(service.QuantityQualifier, StringComparison.OrdinalIgnoreCase))?.Name,
					Quantity = int.TryParse(service.Quantity, out var quantity) ? (int?)quantity : null,
					TimePeriod = HealthServicesDeliveryTimePeriod.I.Find(x => x.Code.Equals(service.TimePeriodQualifier, StringComparison.OrdinalIgnoreCase))?.Name
				});
		}

		public static IEnumerable<IEligibilityBenefit> GetBenefitsByServiceCode(this IEnumerable<IEligibilityBenefit> benefits, string serviceCode)
		{
			return (
				from x in benefits
				where
					x.BenefitInformation != null &&
					!x.BenefitInformation.ServiceTypeCodes.IsNullOrEmpty()
				from code in x.BenefitInformation.ServiceTypeCodes
				where code.Equals(serviceCode, StringComparison.OrdinalIgnoreCase)
				select x);
		}

		public static AuthorizationStatus GetAuthorizationStatus(this BenefitInformation benefit)
		{
			return benefit.AuthorizationorCertificationIndicator switch
			{
				"Y" => AuthorizationStatus.Required,
				"N" => AuthorizationStatus.NotRequired,
				"U" => AuthorizationStatus.Unknown,
				_ => AuthorizationStatus.NotProvided,
			};
		}

		public static EligibilityStatus GetEligibilityStatus(this IEnumerable<IEligibilityBenefit> benefits)
		{
			var eligStatus = benefits.IsNullOrEmpty() ? string.Empty : (
				from x in benefits
				where
					BenefitInfoTypes.EligibilityStatusActive.Contains(x.BenefitInformation.EligibilityOrBenefitInformation) ||
					BenefitInfoTypes.EligibilityStatusInactive.Contains(x.BenefitInformation.EligibilityOrBenefitInformation)
				select x.BenefitInformation.EligibilityOrBenefitInformation).FirstOrDefault();

			if (BenefitInfoTypes.EligibilityStatusActive.Contains(eligStatus, StringComparer.OrdinalIgnoreCase))
				return EligibilityStatus.Active;

			if (BenefitInfoTypes.EligibilityStatusInactive.Contains(eligStatus, StringComparer.OrdinalIgnoreCase))
				return EligibilityStatus.Inactive;

			return EligibilityStatus.Unknown;
		}
		#endregion

		public static Dictionary<string, T> GetEligibilityTabs<T>(this InquiryResult inquiry,
				Func<int, string, string, T> getInNetworkTabs = null,
				Func<string, string, T> getTieredRegularInNetwork = null,
				Func<int, string, string, T> getOutOfNetworkTabs = null,
				Func<int, string, string, T> getNetworkUnknownTabs = null,
				Func<int, string, string, T> getNetworkNotApplicableTabs = null,
				Func<string, string, T> getTieredRegularNotApplicable = null,
				string serviceType = "Health Benefit Plan Coverage"
				)
		{
			var memberId = inquiry.GetMemberId();
			var insured = inquiry.GetInsuredEntity();
			var tabs = new Dictionary<string, T>();

			var stCode = (
				from x in ServiceTypes.I
				where string.Equals(x.Name, serviceType, StringComparison.OrdinalIgnoreCase)
				select x).FirstOrDefault()?.Code;

			if (getInNetworkTabs != null)
			{
				if (insured.IsTieredDeductibles() && !Constants.Eligibility.NonTieredPrefixes.Contains(memberId.Substring(0, 3)))
				{
					if (getTieredRegularInNetwork != null)
						tabs.Add("In Network", getTieredRegularInNetwork(NetworkType.In_Network, stCode));

					for (var i = 1; i <= Constants.Eligibility.MaxDeductibleTiers; i++)
					{
						if (insured.IsTieredDeductibles(i))
							tabs.Add($"Tier {i} In Network", getInNetworkTabs(i, NetworkType.In_Network, stCode));
					}
				}
				else
					tabs.Add("In Network", getInNetworkTabs(0, NetworkType.In_Network, stCode));
			}

			if (getOutOfNetworkTabs != null)
				tabs.Add("Out Of Network", getOutOfNetworkTabs(0, NetworkType.Out_of_Network, stCode));


			if (getNetworkNotApplicableTabs != null)
			{
				if (insured.IsTieredDeductibles() && !Constants.Eligibility.NonTieredPrefixes.Contains(memberId.Substring(0, 3)))
				{
					if (getTieredRegularNotApplicable != null)
						tabs.Add("Network Not Applicable", getTieredRegularNotApplicable(NetworkType.Network_Not_Applicable, stCode));

					for (var i = 1; i <= Constants.Eligibility.MaxDeductibleTiers; i++)
					{
						if (insured.IsTieredDeductibles(i))
							tabs.Add($"Tier {i} Network Not Applicable", getNetworkNotApplicableTabs(i, NetworkType.Network_Not_Applicable, stCode));
					}
				}
				else
					tabs.Add("Network Not Applicable", getNetworkNotApplicableTabs(0, NetworkType.Network_Not_Applicable, stCode));
			}

			if (getNetworkUnknownTabs != null)
				tabs.Add("Network Unknown", getNetworkUnknownTabs(0, NetworkType.Network_Unknown, stCode));

			return new Dictionary<string, T>(
				from x in tabs
				where x.Value != null
				select x);
		}

		public static string GetMemberId(this InquiryResult inquiry) =>
			inquiry.GetSubscriber()?.Name?.PrimaryId.NaIfNullOrWhitespace();

		public static (string groupId, string groupName) GetGroupInformation(this IInsuredEntity entity) =>
			(entity?.AdditionalIdentification).IsNullOrEmpty() ? (string.Empty, string.Empty) :
			(from addinfo in entity.AdditionalIdentification
			 where ReferenceTypes.Group_Number.Equals(addinfo.ReferenceIdentificationQualifier, StringComparison.OrdinalIgnoreCase)
			 select (addinfo.InformationReceiverAdditionalIdentifier, addinfo.InformationReceiverAdditionalIdentifierState)).FirstOrDefault();

		public static string GetPlanNumber(this IInsuredEntity entity) => (
			(entity?.AdditionalIdentification).IsNullOrEmpty() ? string.Empty :
			(from addinfo in entity.AdditionalIdentification
			 where ReferenceTypes.Plan_Number.Contains(addinfo.ReferenceIdentificationQualifier, StringComparison.OrdinalIgnoreCase)
			 select (addinfo.InformationReceiverAdditionalIdentifier)).FirstOrDefault()
		).NaIfNullOrWhitespace();

		public static string GetIssueNumber(this IInsuredEntity entity) => (
		(entity?.AdditionalIdentification).IsNullOrEmpty() ? string.Empty :
		(from addinfo in entity.AdditionalIdentification
		 where ReferenceTypes.Issue_Number.Contains(addinfo.ReferenceIdentificationQualifier, StringComparison.OrdinalIgnoreCase)
		 select (addinfo.InformationReceiverAdditionalIdentifier)).FirstOrDefault()
		);

		public static string GetPriorIdentificationNumber(this IInsuredEntity entity) => (
			(entity?.AdditionalIdentification).IsNullOrEmpty() ? string.Empty :
			(from addinfo in entity.AdditionalIdentification
			 where ReferenceTypes.Prior_Identifier_Number.Contains(addinfo.ReferenceIdentificationQualifier, StringComparison.OrdinalIgnoreCase)
			 select (addinfo.InformationReceiverAdditionalIdentifier)).FirstOrDefault()
			).NaIfNullOrWhitespace();

		public static string GetPrimaryPayerInformation(this IInsuredEntity entity) => (
			(entity?.EligibilityBenefits).IsNullOrEmpty() ? string.Empty :
			(from eligibilityBen in entity.EligibilityBenefits
			 where !(eligibilityBen.BenefitRelatedEntity?.Records).IsNullOrEmpty()
			 from record in eligibilityBen.BenefitRelatedEntity.Records
			 where NameTypes.Primary_Payer.Equals(record.Name.EntityCode, StringComparison.OrdinalIgnoreCase)
			 select record.Name.LastName).FirstOrDefault()
			).NaIfNullOrWhitespace();

		public static bool IsDependentInquiry(this InquiryResult inquiry)
		{
			return (inquiry.Transaction?.Information).IsNullOrEmpty() ? false : (
				from info in inquiry.Transaction.Information
				where !info.Receivers.IsNullOrEmpty()
				from r in info.Receivers
				where !r.Subscribers.IsNullOrEmpty()
				from s in r.Subscribers
				where !s.Dependents.IsNullOrEmpty()
				from d in s.Dependents
				select d).IsEmpty();
		}

		public static DateTime? GetDateWithQualifier(this IEntityWithDates entity, string qualifier)
		{
			if (entity == null) return null;

			return (
				from date in entity.Dates
				where date.Qualifier.Equals(qualifier, StringComparison.OrdinalIgnoreCase)
				select date.Period).FirstOrDefault().Parse271Date();
		}

		public static DateTime? GetDateWithQualifierAndDateType(this IEntityWithDates entity, string qualifier, IEnumerable<string> qualifierDate)
		{
			if (entity == null) return null;
			return (from d in qualifierDate select d).FirstOrDefault().Parse271Date();

		}

		public static DateTime? GetBenefitDateWithQualifier(this IEligibilityBenefit entity, string qualifier)
		{
			if (entity == null) return null;

			return (
				from date in entity.BenefitDates
				where date.Qualifier.Equals(qualifier, StringComparison.OrdinalIgnoreCase)
				select date.Period).FirstOrDefault().Parse271Date();
		}

		public static string GetPrimaryId(this IEntityWithName entity) =>
			(entity?.Name?.PrimaryId).NaIfNullOrWhitespace();

		public static string GetFirstName(this IEntityWithName entity) =>
			(entity?.Name?.FirstName).ToTitleCase();

		public static string GetMiddleName(this IEntityWithName entity) =>
			(entity?.Name?.MiddleName).ToTitleCase();

		public static string GetLastName(this IEntityWithName entity) =>
			(entity?.Name?.LastName).ToTitleCase();

		public static ModelAddress GetAddress(this IEntityWithAddress entity) =>
			new ModelAddress()
			{
				Street1 = entity?.Address?.AddressLine.ToTitleCase(),
				Street2 = entity?.Address?.AdditionalAddressLine.ToTitleCase(),
				City = entity?.CityStatePostal?.City.ToTitleCase(),
				State = entity?.CityStatePostal?.State,
				Zip = entity?.CityStatePostal?.PostalCode.SplitZipCode()
			};


		public static string GetCobFirstName(this IEligibilityBenefit benefit) => (
			(benefit?.BenefitRelatedEntity?.Records).IsNullOrEmpty() ? string.Empty : (
				from record in benefit.BenefitRelatedEntity.Records
				where record.Name.EntityCode == NameTypes.Insured_or_Subscriber
				select record.Name.FirstName).FirstOrDefault().ToTitleCase()
			).NaIfNullOrWhitespace();

		public static string GetCobLastName(this IEligibilityBenefit benefit) => (
			(benefit?.BenefitRelatedEntity?.Records).IsNullOrEmpty() ? string.Empty : (
				from record in benefit.BenefitRelatedEntity.Records
				where record.Name.EntityCode == NameTypes.Insured_or_Subscriber
				select record.Name.LastName).FirstOrDefault().ToTitleCase()
			).NaIfNullOrWhitespace();

		public static string GetCobMemberId(this IEligibilityBenefit benefit) => (
			(benefit?.BenefitRelatedEntity?.Records).IsNullOrEmpty() ? string.Empty : (
				from record in benefit.BenefitRelatedEntity.Records
				where record.Name.EntityCode == NameTypes.Insured_or_Subscriber
				select record.Name.PrimaryId).FirstOrDefault()
			).NaIfNullOrWhitespace();


		public static PrimaryCareProvider GetPrimaryCareProvider(this IEnumerable<IEntityWithBenefitRelatedEntity> entity, DateTime? pcpFromDate, DateTime? pcpToDate) =>
			entity == null ? new PrimaryCareProvider() : (
				from benefit in entity
				where !(benefit.BenefitRelatedEntity?.Records).IsNullOrEmpty()
				from record in benefit.BenefitRelatedEntity.Records
				where NameTypes.Primary_Care_Provider.Equals(record.Name.EntityCode, StringComparison.OrdinalIgnoreCase)
				select new PrimaryCareProvider
				{
					FirstName = record.GetFirstName().ToTitleCase(),
					LastName = record.GetLastName().ToTitleCase(),
					Npi = record.GetPrimaryId(),
					TaxId = "N/A",
					TaxonomyCode = "N/A",
					Address = new ModelAddress()
					{
						Street1 = record?.Address?.AddressLine.ToTitleCase(),
						Street2 = record?.Address?.AdditionalAddressLine.ToTitleCase(),
						City = record?.CityStatePostal?.City.ToTitleCase(),
						State = record?.CityStatePostal?.State.ToTitleCase(),
						Zip = record?.CityStatePostal?.PostalCode.ToTitleCase(),
					},
					EmailAddress = "N/A",
					PhoneNumber = (record.Contacts.IsNullOrEmpty() ? null : (
						from number in record.Contacts
						where ContactTypes.Telephone.Equals(number.Qualifier, StringComparison.OrdinalIgnoreCase)
						select number.Number.ToPhoneNumber()).FirstOrDefault()).NaIfNullOrWhitespace(),
					FaxNumber = "N/A",

					PrimaryCareProviderDate = new NullableRange<DateTime>()
					{
						From = pcpFromDate,
						To = pcpToDate
					},

					ElectronicPayor = "N/A",
					PharmacyProcessor = "N/A"
				}).FirstOrDefault();

		public static string GetRelationship(this IEntityWithRelationship entity) => (
			from r in RelationshipToMember.I
			where r.Code.Equals(entity?.Relationship?.Code, StringComparison.OrdinalIgnoreCase)
			select r.Name).FirstOrDefault().ToTitleCase().NaIfNullOrWhitespace();

		public static IEnumerable<ValueEnteredReturned> GetValueEnteredReturned(this InquiryResult entity, ValuesEntered valuesEntered)
		{
			if ((entity == null) || (valuesEntered is null))
				yield break;

			var patient = entity.GetInsuredEntity();
			var memberId = entity.GetMemberId();

			if (!string.Equals(valuesEntered?.SubscriberId, memberId, StringComparison.OrdinalIgnoreCase))
			{
				yield return new ValueEnteredReturned
				{
					Key = "Member ID",
					ValueEntered = valuesEntered.SubscriberId,
					ValueReturned = memberId
				};
			}

			var subFirstName = entity.GetSubscriber().Name.FirstName;
			if (!string.Equals(valuesEntered?.SubscriberFirstName, subFirstName, StringComparison.OrdinalIgnoreCase))
			{
				yield return new ValueEnteredReturned
				{
					Key = "Member First Name",
					ValueEntered = valuesEntered.SubscriberFirstName,
					ValueReturned = subFirstName
				};
			}

			var subLastName = entity.GetSubscriber().Name.LastName;
			if (!string.Equals(valuesEntered?.SubscriberLastName, subLastName, StringComparison.OrdinalIgnoreCase))
			{
				yield return new ValueEnteredReturned
				{
					Key = "Member Last Name",
					ValueEntered = valuesEntered.SubscriberLastName,
					ValueReturned = subLastName
				};
			}

			var patientFirstName = patient.GetFirstName();
			if (!string.Equals(valuesEntered?.PatientFirstName, patientFirstName, StringComparison.OrdinalIgnoreCase))
			{
				yield return new ValueEnteredReturned
				{
					Key = "Patient First Name",
					ValueEntered = valuesEntered.PatientFirstName,
					ValueReturned = patientFirstName
				};
			}

			var patientLastName = patient.GetLastName();
			if (!string.Equals(valuesEntered?.PatientLastName, patientLastName, StringComparison.OrdinalIgnoreCase))
			{
				yield return new ValueEnteredReturned
				{
					Key = "Patient Last Name",
					ValueEntered = valuesEntered.PatientLastName,
					ValueReturned = patientLastName
				};
			}

			var patientDob = patient.Demographic.BirthDate?.Parse271Date();
			if (!Equals(valuesEntered?.PatientDateOfBirth, patientDob))
			{
				yield return new ValueEnteredReturned
				{
					Key = "Patient Date of Birth",
					ValueEntered = valuesEntered.PatientDateOfBirth.ToShortDateString(),
					ValueReturned = patientDob?.ToShortDateString()
				};
			}
		}

		public static DateTime? GetEffectiveDate(this IEntityWithDates entity) =>
			entity?.Dates == null ? null : (
				from d in entity.Dates
				where DateTypes.EffectiveQualifiers.Contains(d.Qualifier)
				select d.Period).FirstOrDefault().Parse271Date();

		public static DateTime? GetTerminationDate(this IEntityWithDates entity) =>
			entity?.Dates == null ? null : (
				from d in entity.Dates
				where
					((DateTypes.Plan.Equals(d.Qualifier, StringComparison.OrdinalIgnoreCase)) && (DateFormats.Range_of_Dates_Expressed_in_Format_CCYYMMDDCCYYMMDD.Equals(d.Format, StringComparison.OrdinalIgnoreCase))) ||
					((DateTypes.Eligibility.Equals(d.Qualifier, StringComparison.OrdinalIgnoreCase)) && (DateFormats.Range_of_Dates_Expressed_in_Format_CCYYMMDDCCYYMMDD.Equals(d.Format, StringComparison.OrdinalIgnoreCase))) ||
					(DateTypes.TerminationQualifiers.Contains(d.Qualifier))
				select d.Period).FirstOrDefault().Parse271Date(false);

		public static string GetPhoneNumber(this IEntityWithContacts entity) => (
			entity?.Contacts == null ? string.Empty : (
				from number in entity.Contacts
				where number.Qualifier == ContactTypes.Telephone
				select number.Number.ToPhoneNumber()).FirstOrDefault()
			).NaIfNullOrWhitespace();

		public static DateTime? Parse271Date(this string dateString, bool isStartDate = true)
		{
			if (string.IsNullOrWhiteSpace(dateString) || dateString.Length < 8)
				return null;

			if (isStartDate || dateString.Length == 8)
			{
				return Get271Date(dateString.Substring(0, 8));
			}
			else if (dateString.Length == 17)
			{
				return Get271Date(dateString.Substring(9, 8));
			}
			else
			{
				return null;
			}
		}

		private const string Min271Date = "00000101";
		private const string Max271Date = "99991231";
		private static DateTime? Get271Date(string value)
		{
			if (string.IsNullOrWhiteSpace(value) || value.Length != 8) return null;
			if (value == Min271Date) return DateTime.MinValue;
			if (value == Max271Date) return DateTime.MaxValue;

			return new DateTime(int.Parse(value.Substring(0, 4)), int.Parse(value.Substring(4, 2)), int.Parse(value.Substring(6, 2)));
		}

		private static string SplitZipCode(this string zip)
		{
			if (string.IsNullOrWhiteSpace(zip))
				return null;

			return zip.Length <= 5 ? zip : $"{zip.Substring(0, 5)}-{zip.Substring(5)}";
		}

		private static string ToPhoneNumber(this string str)
		{
			var phoneNumber = string.IsNullOrWhiteSpace(str) ? null : $"({str.Substring(0, 3)}) {str.Substring(3, 3)}-{str.Substring(6)}";
			return phoneNumber.ConvertToReadablePhoneNumber();
		}
	}
}
