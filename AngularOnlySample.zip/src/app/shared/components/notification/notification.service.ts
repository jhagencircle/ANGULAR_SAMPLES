import { Injectable } from '@angular/core';
import { NotificationType } from 'src/app/shared/enums/notification-type-enum';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  private visible = new BehaviorSubject<boolean>(false);
  private config = new BehaviorSubject<any>({ message: '', type: '' });

  public isVsible: boolean = false;

  constructor() {}

  public onNotificationVisibilityChange(): Observable<boolean> {
    return this.visible.asObservable();
  }

  public configNotification(
    message: string,
    type: NotificationType,
    showNotification: boolean
  ) {
    this.config.next({ message: message, type: type });
    this.visible.next(showNotification);
  }

  public onConfigNotificationChange() {
    return this.config.asObservable();
  }

  public showNotification() {
    this.visible.next(true);
  }

  public closeNotification() {
    this.visible.next(false);
  }
}
