﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;

namespace BCBSAZ.Provider.Managers.RequestValidators.Eligibility
{
	internal static class CanViewIDCardRequestValidator
	{
		public static void Validate(this CanViewIDCardRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(CanViewIDCardRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.SubscriberId))
				yield return new InvalidModelExceptionDetail(nameof(CanViewIDCardRequest.SubscriberId), new ArgumentException("Invalid Subscriber Id Specified."));

			if (string.IsNullOrWhiteSpace(request.LastName))
				yield return new InvalidModelExceptionDetail(nameof(CanViewIDCardRequest.LastName), new ArgumentException("Invalid Last Name Specified."));

			if (string.IsNullOrWhiteSpace(request.FirstName))
				yield return new InvalidModelExceptionDetail(nameof(CanViewIDCardRequest.FirstName), new ArgumentException("Invalid First Name Specified."));

			if ((request.DateOfService > DateTime.Today.AddYears(1)) || (request.DateOfService < DateTime.Today.AddYears(-2)))
				yield return new InvalidModelExceptionDetail(nameof(CanViewIDCardRequest.DateOfService), new ArgumentException("Invalid Date of Service Specified."));

			if (request.DateOfBirth.HasValue && ((request.DateOfBirth.Value > DateTime.Today) || (request.DateOfBirth.Value < DateTime.Today.AddYears(-150))))
				yield return new InvalidModelExceptionDetail(nameof(CanViewIDCardRequest.DateOfBirth), new ArgumentException("Invalid Date of Birth Specified."));
		}
	}
}
