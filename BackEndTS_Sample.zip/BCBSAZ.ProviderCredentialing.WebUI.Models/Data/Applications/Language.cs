﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class Language
	{
		[RegularExpression("^[A-Za-z A-Za-z]*[A-Za-z]*$", ErrorMessage = "Please enter valid Language")]
		public string Name { get; set; }
	}
}
