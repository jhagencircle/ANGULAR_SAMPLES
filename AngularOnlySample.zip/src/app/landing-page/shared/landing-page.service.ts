import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ISummary } from 'src/app/shared/models/summary.model';
import { IAdjustment } from '../../shared/models/adjustment.model';
import { AppConstants } from 'src/app/shared/constants/app-constants';

@Injectable({
  providedIn: 'root',
})
export class LandingPageService {
  constructor(private http: HttpClient) {}

  export(subAccountSummaryList: ISummary[]) {
    let nowDate = new Date();
    let filename = `SubAccountSummary-${nowDate.toISOString()}`;
    let csvData = this.ConvertToCSV(subAccountSummaryList);
    let blob = new Blob(['\ufeff' + csvData], {
      type: 'text/csv;charset=utf-8;',
    });
    let dwldLink = document.createElement('a');
    let url = URL.createObjectURL(blob);
    let isSafariBrowser =
      navigator.userAgent.indexOf('Safari') != -1 &&
      navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute('target', '_blank');
    }
    dwldLink.setAttribute('href', url);
    dwldLink.setAttribute('download', filename + '.csv');
    dwldLink.style.visibility = 'hidden';
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  private ConvertToCSV(subAccountSummaryList: ISummary[]) {
    let columnList = Object.keys(subAccountSummaryList[0]);
    const separator = ',';

    //get columns to ignore
    let ignoreColumns = AppConstants.IGNORE_COLUMNS_EXPORT_LANDING_PAGE;
    let cellsIgnore = ignoreColumns.split(',');

    //add headers
    let headers = columnList.filter((c) => !cellsIgnore.includes(c));

    let csvContent = `${headers.join(separator)}\r\n`;
    //add rows
    subAccountSummaryList.forEach((subAccountSumary) => {
      let row = '';
      for (const [key, value] of Object.entries(subAccountSumary)) {
        for (const k of headers) {
          if (k == key) {
            row += value + separator;
          }
        }
      }
      if (row.length > 0) {
        let editedRow = row.slice(0, -1);

        csvContent += `${editedRow}\r\n`;
      }
    });

    return csvContent;
  }

  private GetAdjustmentsFormatted(adjustments?: IAdjustment[]) {
    let line = '';
    if (!adjustments) return line;

    adjustments.forEach((adjustment) => {
      line += `Reason: ${adjustment.adjustmentReason} - Amount:${adjustment.adjustmentAmount}|`;
    });

    return line.slice(0, -1);
  }
}
