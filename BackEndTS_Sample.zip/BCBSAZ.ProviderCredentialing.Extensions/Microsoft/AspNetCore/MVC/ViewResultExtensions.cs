﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Microsoft.AspNetCore.Mvc
{
	public static class ViewResultExtensions
	{
		public static async Task<string> ToHtmlAsync(this ViewResult result, HttpContext httpContext, RouteData routeData)
		{
			if (result == null) throw new ArgumentNullException(nameof(result));
			if (httpContext == null) throw new ArgumentNullException(nameof(httpContext));

			var actionContext = new ActionContext(httpContext, routeData, new ControllerActionDescriptor());
			var options = httpContext.RequestServices.GetRequiredService<IOptions<MvcViewOptions>>().Value;

			var view = (
				from ve in options.ViewEngines
				select ve.FindView(actionContext, result.ViewName, true)?.View
				).FirstOrDefault(v => v != null);

			var builder = new StringBuilder();

			using (var output = new StringWriter(builder))
			{
				var viewContext = new ViewContext(actionContext, view, result.ViewData, result.TempData, output, options.HtmlHelperOptions);

				await view.RenderAsync(viewContext);
			}

			return builder.ToString();
		}
	}
}
