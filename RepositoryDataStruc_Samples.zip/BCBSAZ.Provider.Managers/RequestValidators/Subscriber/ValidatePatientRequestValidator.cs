﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Subscriber;
namespace BCBSAZ.Provider.Managers.RequestValidators.Subscriber
{
	internal static class ValidatePatientRequestValidator
	{
		public static void Validate(this ValidatePatientRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(ValidatePatientRequest request)
		{
			if (request.DateOfBirth < new DateTime(1880, 1, 1))
				yield return new InvalidModelExceptionDetail(nameof(ValidatePatientRequest.DateOfBirth), new ArgumentException("Date Of Birth is not valid."));

			if (request.DateOfBirth > DateTime.Today)
				yield return new InvalidModelExceptionDetail(nameof(ValidatePatientRequest.DateOfBirth), new ArgumentException("Date Of Birth is not valid."));

			if (!string.IsNullOrWhiteSpace(request.SubscriberId) && request.SubscriberId.Length < 3)
				yield return new InvalidModelExceptionDetail(nameof(ValidatePatientRequest.SubscriberId), new ArgumentException("SubscriberId is not valid."));

			if (
					(string.IsNullOrWhiteSpace(request.SubscriberId)) &&
					(string.IsNullOrWhiteSpace(request.FirstName) || string.IsNullOrWhiteSpace(request.LastName)) &&
					(string.IsNullOrWhiteSpace(request.SSN))
				)
			{
				yield return new InvalidModelExceptionDetail(nameof(request), new ArgumentException("Must provide SubscriberId, First & Last Name, or SSN."));
			}
		}
	}
}
