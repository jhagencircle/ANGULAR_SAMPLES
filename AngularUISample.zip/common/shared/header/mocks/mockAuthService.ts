export class MockAuthService {

}