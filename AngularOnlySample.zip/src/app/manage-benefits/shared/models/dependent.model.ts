import { IBenefit } from './benefit.model';

export interface IDependent {
  isEdit: boolean;
  firstName: string;
  middleName: string;
  lastName: string;
  dependentType: string;
  dateOfBirth: string;
  ssn: string;
  gender: string;
  benefitSelection: IBenefit;
  isRemoved: boolean;
  removalReason: string;
  effectiveDate: string | null;
}
