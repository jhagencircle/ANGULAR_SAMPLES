export const environment = {
  production: false,
  apiUrl: 'https://olbp.dev.services.azblue.com:8593',
  oktaRedirectCallbackUrl: 'https://olbp.dev.secure.azblue.com/login/callback',
  oktaPostLogoutRedirectUri: 'https://olbp.dev.secure.azblue.com',
  loginUrl: 'https://employer.test.secure.azblue.com/log-in'
};
