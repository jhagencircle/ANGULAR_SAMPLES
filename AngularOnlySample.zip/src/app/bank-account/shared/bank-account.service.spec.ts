import { BankAccountService } from './bank-account.service';
import { of } from 'rxjs';
import { BankAccount } from './bank-account.model';
import { BankAccountMock } from '../../shared/mocks/bank-account.mock';

describe('BankAccountService', () => {
  let service: BankAccountService;
  let httpClientSpy: {
    get: jasmine.Spy;
    delete: jasmine.Spy;
    post: jasmine.Spy;
  };
  let bankAccount: BankAccount[];
  let mockBankAccountModel: BankAccountMock = new BankAccountMock();
  beforeEach(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', [
      'get',
      'delete',
      'post',
    ]);
    mockBankAccountModel.get().subscribe((data) => (bankAccount = data));
    service = new BankAccountService(httpClientSpy as any);
  });

  it('should return mockList', () => {
    httpClientSpy.get.and.returnValue(of(bankAccount));
    service
      .get('10000')
      .subscribe(
        (items) => expect(items).toEqual(bankAccount, 'expected bankAccounts'),
        fail
      );
    expect(httpClientSpy.get.calls.count()).toBe(1);
  });

  it('should delete', () => {
    httpClientSpy.delete.and.returnValue(of(true));
    service
      .delete('1', '1')
      .subscribe((result) => expect(result).toBeTruthy, fail);
    expect(httpClientSpy.delete.calls.count()).toBe(1);
  });

  it('should add', () => {
    httpClientSpy.post.and.returnValue(of(true));
    service
      .save(bankAccount[0])
      .subscribe((result) => expect(result).toBeTruthy, fail);
    expect(httpClientSpy.post.calls.count()).toBe(1);
  });
});
