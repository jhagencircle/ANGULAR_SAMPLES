﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface ISecurityClient : IDisposable
	{
		
			Task<bool> ChangePasswordAsync(string userName, string oldPassword, string newPassword);
			Task<bool> ResetOtherUserPasswordAsync(string userName, string oldPassword, string newPassword);
			//bool ResetOtherUserPassword(string userName, string oldPassword, string newPassword);
	}
}
