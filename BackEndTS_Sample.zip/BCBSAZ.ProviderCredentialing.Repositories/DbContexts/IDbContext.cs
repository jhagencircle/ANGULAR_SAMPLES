﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace BCBSAZ.ProviderCredentialing.Repositories.DbContexts
{
	public interface IDbContext
	{
		/// <summary>
		/// Provides access to database related information and operations for this context.
		/// </summary>
		DatabaseFacade Database { get; }

		/// <summary>
		/// Asynchronously saves all changes made in this context to the database.
		/// </summary>
		/// <param name="cancellationToken">A System.Threading.CancellationToken to observe while waiting for the task to complete.</param>
		/// <exception cref="Microsoft.EntityFrameworkCore.DbUpdateException">An error is encountered while saving to the database.</exception>
		/// <exception cref="Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException">
		///		A concurrency violation is encountered while saving to the database. A concurrency violation occurs when an unexpected number of
		///		rows are affected during save. This is usually because the data in the database has been modified since it was loaded into memory.
		///	</exception>
		///	<remarks>
		///   This method will automatically call Microsoft.EntityFrameworkCore.ChangeTracking.ChangeTracker.DetectChanges
		///   to discover any changes to entity instances before saving to the underlying database.
		///   This can be disabled via Microsoft.EntityFrameworkCore.ChangeTracking.ChangeTracker.AutoDetectChangesEnabled.
		///   Multiple active operations on the same context instance are not supported. Use
		///   'await' to ensure that any asynchronous operations have completed before calling
		///   another method on this context.
		///	</remarks>
		/// <returns>
		///		A task that represents the asynchronous save operation. The task result contains the number of state entries written to the database.
		///	</returns>
		Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

		/// <summary>
		/// Asynchronously saves all changes made in this context to the database.
		/// </summary>
		/// <param name="acceptAllChangesOnSuccess">
		///		Indicates whether Microsoft.EntityFrameworkCore.ChangeTracking.ChangeTracker.AcceptAllChanges is called after the changes have
		///		been sent successfully to the database.
		///	</param>
		/// <param name="cancellationToken">A System.Threading.CancellationToken to observe while waiting for the task to complete.</param>
		/// <exception cref="Microsoft.EntityFrameworkCore.DbUpdateException">An error is encountered while saving to the database.</exception>
		/// <exception cref="Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException">
		///		A concurrency violation is encountered while saving to the database. A concurrency violation occurs when an unexpected number of
		///		rows are affected during save. This is usually because the data in the database has been modified since it was loaded into memory.
		///	</exception>
		///	<remarks>
		///   This method will automatically call Microsoft.EntityFrameworkCore.ChangeTracking.ChangeTracker.DetectChanges
		///   to discover any changes to entity instances before saving to the underlying database.
		///   This can be disabled via Microsoft.EntityFrameworkCore.ChangeTracking.ChangeTracker.AutoDetectChangesEnabled.
		///   Multiple active operations on the same context instance are not supported. Use
		///   'await' to ensure that any asynchronous operations have completed before calling
		///   another method on this context.
		///	</remarks>
		/// <returns>
		///		A task that represents the asynchronous save operation. The task result contains the number of state entries written to the database.
		///	</returns>
		Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default);
	}
}
