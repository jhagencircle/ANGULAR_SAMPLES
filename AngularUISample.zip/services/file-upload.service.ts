import { HttpClient } from '@angular/common/http';
import { ElementRef, Injectable, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Subject, Subscription } from 'rxjs';
import { FileUpload } from '../models/data/file-upload.model';

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {
  selectedFile: any;  
  selected_files: FileUpload[] = [];
  
  @ViewChild("fileSelector", {static: false}) file_selector!: ElementRef;

  file_selection_form: FormGroup;
  fileIds: Array<Number>=[];

  constructor(private http: HttpClient) { 
    this.file_selection_form = new FormGroup({
      file_selection: new FormControl()
    });
  }

saveIds(fileNames:any){
  this.fileIds = fileNames;
}
retrieveIDs(){
    return this.fileIds;
}

  private file_selection_sub!: Subscription;  

  openFileSelector(){
    const file_selection = this.file_selector.nativeElement;
    file_selection.click();
  }

  trackFileSelection(){
    this.file_selection_sub = this.file_selection_form.get('file_selection')?.valueChanges.subscribe(
      ()=>{

        const file_selection = this.file_selector.nativeElement;
        this.selectFiles(file_selection.files) ;
        this.file_selector.nativeElement.value = '';
      }
    ) as Subscription;
  }
  
  selectFiles(incoming_files: any[]){
    
    const jpgRegEx : RegExp = /.+\.jpg$/;
    const pdfRegEx : RegExp = /.+\.pdf$/;
    const formData = new FormData();
    

    let incoming_file_count  = incoming_files.length;
    let maxNumberFiles = incoming_file_count + this.selected_files.length;  

    //formData.append('file', fileToUpload, fileToUpload.name);

    if(maxNumberFiles <=3){      
      for(let i = 0; i < incoming_file_count; i++){             
        let incoming_file = incoming_files[i];   
          let selected_file = {
            file: incoming_file,
            is_upload_in_progress: false,
            upload_result: null
          };
          let fileToUpload = <File>incoming_files[i];
          if(jpgRegEx.test(incoming_file.name) || pdfRegEx.test(incoming_file.name)){
            this.selected_files.push(selected_file);
            formData.append('file', fileToUpload, fileToUpload.name);            
          }
           //return this.http.post((`${environment.apiBaseUrl}/v1/common/time`);
      } 
      //works here
/*       this.http.post('https://localhost:44339/api/v1/EftEnrollment/Upload', formData, {reportProgress: true, observe: 'events'})
      .subscribe(event => {              
      }); */  
    }
  } 

  uploadAll(){
    let selected_file_count  = this.selected_files.length;
    for(let i = 0; i < selected_file_count; i++){
      let selected_file = this.selected_files[i];
      // Checking if the file can be uploaded
      if(!selected_file.is_upload_in_progress && selected_file.upload_result!='success'){
        this.uploadFile(i);
      }
    }
  }
  
  uploadFile(index: number){
    let file_for_upload = this.selected_files[index];

    const form_data = new FormData();
    form_data.append('file', file_for_upload.file);

    // For other fields, we have to use append() as well
    // E.g. form_data.append('thikana', 'Bishadbari Lane');

    file_for_upload.is_upload_in_progress = true;
    file_for_upload.upload_result = null;

    this.http.post('https://localhost:44339/api/v1/EftEnrollment/Upload', form_data, {reportProgress: true, observe: 'events'})
      .subscribe(event => {              
      });  
    }

}
