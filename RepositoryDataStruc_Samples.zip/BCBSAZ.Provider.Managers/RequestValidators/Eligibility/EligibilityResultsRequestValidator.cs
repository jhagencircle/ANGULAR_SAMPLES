﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;

namespace BCBSAZ.Provider.Managers.RequestValidators.Eligibility
{
	internal static class EligibilityResultsRequestValidator
	{
		public static void Validate(this EligibilityResultsRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(EligibilityResultsRequest request)
		{
			if (request.Days <= 0)
				yield return new InvalidModelExceptionDetail(nameof(EligibilityResultsRequest.Days), new ArgumentException("The property Days is not valid. Must be greater than 0."));

			if (request.Days >= 367)
				yield return new InvalidModelExceptionDetail(nameof(EligibilityResultsRequest.Days), new ArgumentException("The property Days is not valid. Must be less than 367."));

			if (string.IsNullOrWhiteSpace(request.OrgId))
				yield return new InvalidModelExceptionDetail(nameof(EligibilityResultsRequest.OrgId), new ArgumentException("OrgId is missing."));
		}
	}
}
