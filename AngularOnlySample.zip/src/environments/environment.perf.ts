export const environment = {
  production: false,
  apiUrl: 'https://olbp.perf.services.azblue.com:8993',
  oktaRedirectCallbackUrl: 'https://olbp.perf.secure.azblue.com/login/callback',
  oktaPostLogoutRedirectUri: 'https://olbp.perf.secure.azblue.com/',
  loginUrl: 'https://employer.perf.secure.azblue.com/log-in'
};
