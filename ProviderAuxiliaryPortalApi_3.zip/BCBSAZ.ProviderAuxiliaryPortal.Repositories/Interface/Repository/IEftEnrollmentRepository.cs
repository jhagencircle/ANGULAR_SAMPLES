﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository
{
    public interface IEftEnrollmentRepository
    {
        Task SaveEftEnrollmentRequestAsync(EftEnrollmentRequest request);
        Task UpdateEftEnrollmentRequestAsync(EftEnrollmentRequest request);
    }
}
