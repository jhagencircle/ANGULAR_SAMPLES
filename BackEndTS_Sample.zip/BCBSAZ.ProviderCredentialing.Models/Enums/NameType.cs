﻿namespace BCBSAZ.ProviderCredentialing.WebAPI.Models.Enums
{
	public enum NameType
	{
		ProviderInformation,
		SupervisingPhysician,
		CAQHName,
		ApplicationContactInformation,
		BusinessCorrespondence,
		Additional
	}
}
