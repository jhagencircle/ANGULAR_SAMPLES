﻿using System.Threading.Tasks;

namespace Microsoft.Extensions.Logging
{
	public interface ILogMessageStorage
	{
		Task StoreAsync(LogMessage logMessage);
	}
}
