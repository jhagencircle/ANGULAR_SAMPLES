﻿using System.Collections.Generic;
using System.Linq;

namespace BCBSAZ.ProviderAuxiliaryPortal.Extensions
{
    public static class EnumerableExtensions
    {
        public static IEnumerable<T> EmptyIfNull<T>(this IEnumerable<T> iEnumerable)
            => iEnumerable ?? Enumerable.Empty<T>();
    }
}
