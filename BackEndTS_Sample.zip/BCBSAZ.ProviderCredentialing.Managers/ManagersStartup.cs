﻿using BCBSAZ.ProviderCredentialing.Interfaces.Managers;
using BCBSAZ.ProviderCredentialing.Interfaces.Processors;
using BCBSAZ.ProviderCredentialing.Managers;
using BCBSAZ.ProviderCredentialing.Managers.Email;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing
{
	public static class ManagersStartup
	{
		public static void AddManagers(this IServiceCollection services, IConfiguration configuration)
		{
#if !DEBUG
			services.AddScoped<ILogMessageStorage, SystemLogsManager>();
#endif

			services.AddScoped<IEmailProcessor, EmailProcessor>();
			services.AddScoped<IApplicationManager, ApplicationManager>();

			// Because this is used by Logging, it needs to be a singleton, most other managers will be scoped.
			services.AddSingleton<ISystemLogsManager, SystemLogsManager>();
		}
	}
}
