﻿using System;
using System.Security.Cryptography;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Processors;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Managers.RequestValidators.PreCert;
using BCBSAZ.Provider.Models.Requests.PreCert;
using BCBSAZ.Provider.Models.Responses.PreCert;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Managers
{
	public partial class PreCertManager : IPreCertManager
	{

		private readonly IPreCertRepository _preCertRepository;
		private readonly IEmailProcessor _emailProcessor;

		private readonly string _providerPortalUrl;

		public PreCertManager(IPreCertRepository preCertRepository, IEmailProcessor emailProcessor, IConfiguration configuration)
		{
			_preCertRepository = preCertRepository;
			_emailProcessor = emailProcessor;

			_providerPortalUrl = configuration.GetValue<string>("ProviderPortalUrl");

			if (!_providerPortalUrl.EndsWith("/"))
				_providerPortalUrl += "/";

			InitializeMedical(configuration);
			InitializePharmacy(configuration);
		}

		private static bool IsInternal(WebUser webUser) =>
			(webUser.UserType == UserType.Internal) || (webUser.UserType == UserType.TeamPhoenix);


		public async Task<SaveFileResponse> SaveFileAsync(SaveFileRequest request, WebUser user)
		{
			request.Validate(user);

			request.File.UserId = user.UserId;
			request.File.InsertDate = DateTime.Now;

			using (var sha = SHA256.Create())
			{
				// Generate a unique hash that will be used to identify this file.  This hash in addition to the UserId will
				// be used to create a "downloadhash" (a validation hash that verifies the user has not attempted to alter the URL to
				// retrieve a different file).
				request.File.FileHash = sha.GenerateHashBase64String($"{request.File.InsertDate:s}|{request.File.Contents}");
			}

			await _preCertRepository.SaveFileAsync(request.File);

			return new SaveFileResponse()
			{
				FileId = request.File.FileId
			};
		}


	}
}
