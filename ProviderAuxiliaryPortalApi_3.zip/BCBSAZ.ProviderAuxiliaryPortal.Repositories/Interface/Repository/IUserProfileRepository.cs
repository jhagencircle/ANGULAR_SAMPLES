﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.UserProfile;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository
{
    public interface IUserProfileRepository
    {
        Task<UserProfile> GetUserProfileAsync(string userId);
        Task InsertUserProfileAsync(string createdBy, string orgId, UserProfile userProfile, string passwordHash, string answerHash);
        Task SetProvidersForUserAsync(string orgId, string subOrg, string userId, IEnumerable<AssignedProvider> providers);
        Task UpdateUserProfileAsync(UserProfile userProfile, string passwordHash);
        Task DeleteUserProfileAsync(string orgId, string userId);
    }
}
