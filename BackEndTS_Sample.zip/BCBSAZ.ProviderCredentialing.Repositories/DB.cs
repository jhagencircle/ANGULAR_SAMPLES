﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Repositories
{
	internal static class DB
	{
		public static class SystemLogs
		{
			public static class StoredProcs
			{
				public const string LogException = "dbo.usp_LogException @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11, @p12, @p13";
			}
		}

		public static class Email
		{
			public static class StoredProcs
			{
				public const string QueueEmail = "dbo.usp_QueueEmail @p0, @p1, @p2, @p3, @p4, @p5";
			}
		}

	}
}
