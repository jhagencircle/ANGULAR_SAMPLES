﻿using System;
using System.Collections.Generic;
using System.Text;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Common;

namespace BCBSAZ.Provider.Managers.RequestValidators.Common
{
	public static class PreviouslySelectedServiceTypeRequestValidator
	{
		public static IEnumerable<InvalidModelExceptionDetail> ValidateRequest(this PreviouslySelectedServiceTypeRequest request)
		{
			if (string.IsNullOrEmpty(request.UserId))
				yield return new InvalidModelExceptionDetail(nameof(MessageCountRequest.UserId), new ArgumentException("User Id is missing."));
		}
	}
}
