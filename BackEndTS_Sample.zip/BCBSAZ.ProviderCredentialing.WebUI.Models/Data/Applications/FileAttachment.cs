﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class FileAttachment 
	{

		public byte[] Contents { get; set; }

		public string FileName { get; set; }

		public string ContentType { get; set; }
	}
}
