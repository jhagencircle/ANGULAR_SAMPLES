﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Models
{
	/// <summary>
	/// Defines an exception to be thrown when an incoming request model is not valid.
	/// </summary>
	[SuppressMessage("Design", "CA1032:Implement standard exception constructors", Justification = "Additional constructors are not required.")]
	public class InvalidRequestException : Exception
	{
		/// <summary>
		/// Creates a new exception containing the exception details from the invalid model.
		/// </summary>
		/// <param name="details">The validation details for the request model.</param>
		public InvalidRequestException(IEnumerable<InvalidModelExceptionDetail> details) : base(GetExceptionMessage(details)) => Details = details;

		/// <summary>
		/// Creates a new exception containing the exception details from the invalid model.
		/// </summary>
		/// <param name="detail">The validation details for the request model.</param>
		public InvalidRequestException(InvalidModelExceptionDetail detail) : this(new InvalidModelExceptionDetail[] { detail }) { }

		/// <summary>
		/// Gets the validation details for the request model.
		/// </summary>
		public IEnumerable<InvalidModelExceptionDetail> Details { get; }

		/// <summary>
		/// Generates a detailed exception message containing all of the validation details for the request model.
		/// </summary>
		/// <param name="details">The validation details for the request model</param>
		/// <returns>A string containing the detailed exception message.</returns>
		private static string GetExceptionMessage(IEnumerable<InvalidModelExceptionDetail> details)
		{
			if (details.IsNullOrEmpty()) return null;

			var retVal = new StringBuilder();

			foreach (var detail in details)
			{
				retVal.AppendFormat(G.IC, "Invalid value specified for '{0}': {1} ({2}){3}",
					detail.PropertyName, detail.Message, detail.Exception.GetType().FullName, Environment.NewLine);
			}

			return retVal.ToString();
		}
	}

	/// <summary>
	/// Defines Model Validation details.
	/// </summary>
	public class InvalidModelExceptionDetail
	{
		/// <summary>
		/// Creates a new Model Validation Detail for the specified property and validation exception.
		/// </summary>
		/// <param name="propertyName">The name of the property which has been declared invalid.</param>
		/// <param name="exception">The exception related to the failed validation of the property.</param>
		/// <remarks>The Message property will be populated from the Message property of the provided exception.</remarks>
		public InvalidModelExceptionDetail(string propertyName, Exception exception) : this(propertyName, exception?.Message, exception) { }

		/// <summary>
		/// Creates a new Model Validation Detail for the specified property, message and validation exception.
		/// </summary>
		/// <param name="propertyName">The name of the property which has been declared invalid.</param>
		/// <param name="message">The validation message for the property.</param>
		/// <param name="exception">The exception related to the failed validation of the property.</param>
		public InvalidModelExceptionDetail(string propertyName, string message, Exception exception)
		{
			PropertyName = propertyName;
			Message = message;
			Exception = exception;
		}

		/// <summary>
		/// Gets the name of the property which has been declared invalid.
		/// </summary>
		public string PropertyName { get; }

		/// <summary>
		/// Gets the validation message for the property.
		/// </summary>
		public string Message { get; }

		/// <summary>
		/// Gets the exception related to the failed validation of the property.
		/// </summary>
		public Exception Exception { get; }
	}
}
