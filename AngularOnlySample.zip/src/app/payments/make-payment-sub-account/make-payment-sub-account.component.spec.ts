import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MakePaymentSubAccountComponent } from './make-payment-sub-account.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AccountMock } from '../../shared/mocks/account.mock';
import { AccountService } from 'src/app/shared/services/account.service';

describe('MakePaymentSubAccountsComponent', () => {
  let component: MakePaymentSubAccountComponent;
  let fixture: ComponentFixture<MakePaymentSubAccountComponent>;
  let mockAccountService: any = new AccountMock();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      declarations: [MakePaymentSubAccountComponent],
      providers: [
        {
          provide: AccountService,
          useValue: mockAccountService,
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MakePaymentSubAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
