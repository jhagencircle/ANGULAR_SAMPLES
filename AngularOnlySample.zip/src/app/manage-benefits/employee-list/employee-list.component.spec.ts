import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmployeeListComponent } from './employee-list.component';
import { DecimalPipe } from '@angular/common';
import { OverlaySidePanelService } from 'src/app/shared/components/overlay-side-panel/overlay-side-panel.service';
import { EmployeeServiceMock } from '../../shared/mocks/employee.service.mock';
import { EmployeeProfileService } from '../shared/employee-profile.service';
import { EmployeeService } from '../shared/employee.service';
import { AccountService } from 'src/app/shared/services/account.service';
import { AccountMock } from '../../shared/mocks/account.mock';
import { SpinnerService } from '../../shared/components/spinner/spinner.service';
import { OverlaySidePanelMock } from 'src/app/shared/mocks/overlay-side-panel.service.mock';
import { EmployeeMock } from '../../shared/mocks/employee.mock';

describe('EmployeeListComponent', () => {
  let component: EmployeeListComponent;
  let fixture: ComponentFixture<EmployeeListComponent>;
  let overlaySidePanelService: any = new OverlaySidePanelMock();
  let mockEmployeeService: any = new EmployeeServiceMock();
  let mockAccountService: any = new AccountMock();
  let mockEmployee: EmployeeMock = new EmployeeMock();
  //let spinnerService: SpinnerService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [EmployeeListComponent, DecimalPipe],
      providers: [
        { provide: EmployeeService, useValue: mockEmployeeService },
        { provide: OverlaySidePanelService, useValue: overlaySidePanelService },

        {
          provide: AccountService,
          useValue: mockAccountService,
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeListComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should sort', () => {
    component.onSort({ column: 'firstName', direction: 'asc' });
    expect(component.employeeService.sortColumn).toEqual('firstName');
    expect(component.employeeService.sortDirection).toEqual('asc');
  });

  it('should get employee profile', () => {
    let employee: any;
    mockEmployee.get().subscribe((data) => (employee = data.benefitSelection));
    spyOn(component.onSaveChanges, 'emit');
    component.employeeProfile(employee);
    expect(component.onSaveChanges.emit).toHaveBeenCalled();
  });

  it('should change', () => {
    component.ngOnChanges();
    component.employees$.subscribe((data) => {
      expect(data[0].employeeId).toBe('000201');
    });
  });

  it('should change Filter', () => {
    component.changeFilter('Medical', 'All');
    expect(component.planFilterSelected).toBe('Medical All');
    expect(component.employeeService.planMedical).toBe('All');

    component.changeFilter('Dental', 'All');
    expect(component.planFilterSelected).toBe('Dental All');
    expect(component.employeeService.planDental).toBe('All');
  });

  it('should clear filter selected', () => {
    component.clearFilterSelected();

    expect(component.planFilterSelected).toBe('');
    expect(component.employeeService.planMedical).toBeNull;
    expect(component.employeeService.planDental).toBeNull;
  });
});
