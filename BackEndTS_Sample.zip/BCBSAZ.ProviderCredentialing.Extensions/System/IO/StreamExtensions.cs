﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace System.IO
{
	public static class StreamExtensions
	{
		/// <summary>
		/// Reads a stream to the end and returns the resulting byte array.
		/// </summary>
		/// <param name="stream">The stream to be read.</param>
		/// <returns>Returns a byte array containing the contents of the stream.</returns>
		/// <exception cref="ArgumentNullException"></exception>
		/// <exception cref="ObjectDisposedException"></exception>
		/// <exception cref="NotSupportedException"></exception>
		public static async Task<byte[]> ReadAsByteArrayAsync(this Stream stream)
		{
			if (stream == null) throw new ArgumentNullException(nameof(stream));

			using (var retVal = new MemoryStream())
			{
				await stream.CopyToAsync(retVal);
				return retVal.ToArray();
			}
		}

		/// <summary>
		/// Reads a stream to the end and returns the resulting string using the specified encoding.
		/// </summary>
		/// <param name="stream">The stream to be read.</param>
		/// <returns>Returns a string containing the contents of the stream.</returns>
		/// <exception cref="ArgumentNullException"></exception>
		/// <exception cref="ObjectDisposedException"></exception>
		/// <exception cref="NotSupportedException"></exception>
		public static Task<string> ReadAsStringAsync(this Stream stream)
		{
			using (var reader = new StreamReader(stream))
			{
				return reader.ReadToEndAsync();
			}
		}
	}

}
