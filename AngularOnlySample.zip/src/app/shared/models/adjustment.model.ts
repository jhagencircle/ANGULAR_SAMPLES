export interface IAdjustment {
   
    adjustmentReason: string;
    adjustmentAmount: number;
}
