import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmployeeDependentListComponent } from './employee-dependent-list.component';
import { EmployeeMock } from '../../shared/mocks/employee.mock';
import { DependentMock } from 'src/app/shared/mocks/dependent.mock';
import { IDependent } from '../shared/models/dependent.model';

describe('EmployeeDependentListComponent', () => {
  let component: EmployeeDependentListComponent;
  let fixture: ComponentFixture<EmployeeDependentListComponent>;
  let mockEmployeeService: EmployeeMock = new EmployeeMock();
  let dependentMock: DependentMock;
  let currentDependent: IDependent;
  beforeEach(async () => {
    dependentMock = new DependentMock();
    await TestBed.configureTestingModule({
      declarations: [EmployeeDependentListComponent],
      imports: [HttpClientTestingModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeDependentListComponent);
    component = fixture.componentInstance;

    mockEmployeeService.get().subscribe((data) => {
      component.benefitSelection = data.benefitSelection;
    });
    dependentMock.getList().subscribe((data) => {
      component.dependentsInformation = data;
    });
    if (component.dependentsInformation !== undefined)
      currentDependent = component.dependentsInformation[0];

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  //TODO: Complete When edit dependent changes are made
  // it('should add dependent', () => {
  //   component.addDependent(currentDependent);
  // });
  // it('should edit dependent', () => {
  //   console.log('currentDependent', currentDependent);
  //   var store = { subAccount: {} };
  //   spyOn(localStorage, 'getItem').and.callFake((key: string): any => {
  //     return store.subAccount;
  //   });
  //   component.editDependent(currentDependent);
  //   console.log(
  //     'component.membreProfile.dependents',
  //     component.membreProfile.dependents
  //   );
  //   expect(currentDependent).toBe(component.membreProfile.dependents[0]);
  // });

  it('should show add form', () => {
    component.showAddForm();
    expect(component.showAdd).toBeTrue;
  });

  it('should hide add form', () => {
    component.hideAddForm();
    expect(component.showAdd).toBeFalse;
  });

  it('should click cell edit', () => {
    let expectedValue = currentDependent.isEdit;
    component.onClickEditCell(currentDependent);
    expect(currentDependent.isEdit).toBe(!expectedValue);
  });
});
