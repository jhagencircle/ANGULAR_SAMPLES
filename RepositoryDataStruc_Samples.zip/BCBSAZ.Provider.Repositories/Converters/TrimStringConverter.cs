﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BCBSAZ.Provider.Repositories.Converters
{
	/// <summary>
	/// Provides Value Conversion from Fixed Length (space padded) strings to Variable Length (trimmed) strings
	/// </summary>
	public class TrimStringConverter : ValueConverter<string, string>
	{
		public TrimStringConverter() : base(TrimString, TrimString) { }

		static Expression<Func<string, string>> TrimString => (s) => (s == null ? null : s.Trim());
	}
}
