﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Processors
{
	public interface IEmailProcessor
	{
		Task SendPreCertNotRequiredAsync(string fromAddress, string toAddress, string preCertId);

		Task SendPreCertNewRequestAsync(string fromAddress, string toAddress, string preCertId, string providerPortalUrl, DateTime updateDate);

		Task SendPreCertIncompleteAsync(string fromAddress, string toAddress, string preCertId);

		Task SendPreCertSubmittedAsync(string fromAddress, string toAddress, string preCertId);

		Task SendPreCertCancelledAsync(string fromAddress, string toAddress, string preCertId);

		Task SendPreCertApprovedAsync(string fromAddress, string toAddress, string preCertId);

		Task SendPreCertDeniedAsync(string fromAddress, string toAddress, string preCertId);

		Task SendTpaRegistrationAsync(string fromAddress, string toAddress, string userName, string password);
	}
}
