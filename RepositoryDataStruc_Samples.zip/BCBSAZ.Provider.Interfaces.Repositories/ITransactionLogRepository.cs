﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface ITransactionLogRepository
	{
		Task LogTransactionAsync(string systemName, string transactionType, string requestBuffer, string errorCode, DateTime endProcess, double totalProcessTime, double totalEdiProcessTime, double postProcessTime, string userId, string info);
	}
}
