﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.Managers.Email.Templates
{
	// Template Notes: See Read-Me.txt File

	internal static class TemplateStore
	{
		private static readonly Dictionary<string, string> _templateNameMaps;
		private static readonly Dictionary<string, Template> _templates;
		private static readonly Assembly _assembly;

		static TemplateStore()
		{
			_assembly = typeof(TemplateStore).Assembly;
			_templateNameMaps = GetTemplateNameMaps();
			_templates = new Dictionary<string, Template>(StringComparer.OrdinalIgnoreCase);
			TemplateNames = _templateNameMaps.Keys.ToArray();
		}

		private static Dictionary<string, string> GetTemplateNameMaps()
		{
			var resourceNames = _assembly.GetManifestResourceNames();

			var retVal = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			resourceNames.ForEach(AddTemplateNameMap, retVal);
			return retVal;
		}

		private static void AddTemplateNameMap(string resourceName, Dictionary<string, string> templateNameMaps)
		{
			var noExtension = resourceName.Replace(".html", string.Empty, StringComparison.OrdinalIgnoreCase);

			var lastIdx = noExtension.LastIndexOf('.');
			var templateName = (lastIdx <= 0) ? noExtension : noExtension.Substring(lastIdx + 1);

			templateNameMaps.Add(templateName, resourceName);
		}

		public static string[] TemplateNames { get; }

		public static async Task<Template> GetTemplateAsync(string templateName)
		{
			if (!_templates.ContainsKey(templateName))
			{
				if (!_templateNameMaps.ContainsKey(templateName))
					throw new ArgumentException("The specified e-mail template was not found.", nameof(templateName));

				using (Stream stream = _assembly.GetManifestResourceStream(_templateNameMaps[templateName]))
				{
					_templates.Add(templateName, new Template(await stream.ReadAsStringAsync()));
				}
			}

			return _templates[templateName];
		}
	}

}
