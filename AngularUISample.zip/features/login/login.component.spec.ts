import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { OktaAuthService, OKTA_CONFIG } from '@okta/okta-angular';
import { MockAuthService } from 'src/app/shared/mocks/mockAuthService';
import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let fakeOktaAuthService: OktaAuthService;

  beforeEach(async () => {
    const config = {
      clientId: '0oa10xg9dyrNFBl7h0h8',
      issuer: 'https://evalext.azblue.com/oauth2/ausieumlspeeWM4P70h7',
      redirectUri: '',
      scopes: ['openid', 'profile', 'email', 'employer', 'offline_access'],
      postLogoutRedirectUri: '',
      pkce: true,
    };
    await TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports: [RouterModule.forRoot([])],
      providers: [{ provide: OktaAuthService, useClass: MockAuthService }, { provide: OKTA_CONFIG, useValue: config }]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    fakeOktaAuthService = TestBed.inject(OktaAuthService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
});
