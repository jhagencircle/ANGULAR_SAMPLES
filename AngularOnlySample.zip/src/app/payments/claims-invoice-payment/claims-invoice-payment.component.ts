import { Component, OnInit } from '@angular/core';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { PaymentSectionEnum } from 'src/app/shared/enums/payment-section-enum';

@Component({
  selector: 'app-claims-invoice-payment',
  templateUrl: './claims-invoice-payment.component.html',
  styleUrls: ['./claims-invoice-payment.component.scss'],
})
export class ClaimsInvoicePaymentComponent implements OnInit {
  paymentSubsectionComponent: string | null;
  previousPaymentSection: string | null;
  accounts: any;
  reviewTitle: string = AppConstants.REVIEW_CLAIMS_INVOICE_TITLE;
  reviewSubmitText: string = AppConstants.REVIEW_SUBMIT_TEXT;

  constructor() {
    this.paymentSubsectionComponent = localStorage.getItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );
    this.previousPaymentSection = localStorage.getItem(
      AppConstants.PREVIOUS_PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );

    if (
      this.previousPaymentSection &&
      this.previousPaymentSection === PaymentSectionEnum.Account
    ) {
      localStorage.setItem(
        AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
        this.previousPaymentSection
      );
    }
    if (this.paymentSubsectionComponent === null) {
      localStorage.setItem(
        AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
        PaymentSectionEnum.ClaimsInvoice
      );
      this.paymentSubsectionComponent = PaymentSectionEnum.ClaimsInvoice;
    }
  }

  ngOnInit(): void {
    let subbAcountsJson: string | null = localStorage.getItem(
      AppConstants.PAYMENT_SUBSECTION_ACCOUNTS_LOCAL_STORAGE_KEY
    );
    if (subbAcountsJson != null) {
      this.accounts = JSON.parse(subbAcountsJson);
    }
  }

  ngOnDestroy(): void {
    localStorage.removeItem(AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY);
    localStorage.removeItem(
      AppConstants.PAYMENT_SUBSECTION_ACCOUNTS_LOCAL_STORAGE_KEY
    );
  }
}
