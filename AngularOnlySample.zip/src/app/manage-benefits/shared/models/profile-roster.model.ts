import { ITerminationCoverage, ISubscriber, IContactInformation } from '.';

export interface IProfileRoster {
  terminateCoverage: ITerminationCoverage | null;
  subscriber: ISubscriber | null;
  contact: IContactInformation | null;
  dependents: ISubscriber[];
  receivedDate: Date | null;
  topAccountId: string | null;
  billId: number;
}
