﻿using System;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Subscriber;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface ISubscriberRepository
	{
		Task<bool> IsMemberDelegatedAsync(string subscriberId);

		Task<bool> IsPrefixOOAAsync(string subPrefix);

		Patient[] GetPatients(string subscriberId, string firstName, string lastName, string ssn, DateTime dateOfBirth);
	}
}
