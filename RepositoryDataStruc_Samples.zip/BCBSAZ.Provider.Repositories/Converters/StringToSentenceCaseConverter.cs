﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BCBSAZ.Provider.Repositories.Converters
{
   public class StringToSentenceCaseConverter:ValueConverter<string,string>
    {
        public StringToSentenceCaseConverter() : base(StringToLower, StringToLower) { }

        static Expression<Func<string, string>> StringToLower => (s) => ((s == null) || string.IsNullOrEmpty(s)) ? null : (((s.Trim().Length >= 1)?(s.Trim().Substring(0, 1).ToUpper()):"") + ((s.Trim().Length > 1) ? (s.Trim().Substring(1, s.Trim().Length - 1).ToLower()) : ""));
    }
}
            