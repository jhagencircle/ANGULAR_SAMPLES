import { IPlan } from './plan.model';

export interface IBenefit {
  planSelection: IPlan[];
  eligibleForMedicare: boolean;
  lifeInsuranceBenefit: string;
  // healthCoverage?: string;
  // dentalCoverage?: string;
  // lifeCoverage?: string;
  medicareNumber?: string;
  partAEffectiveDate?: string;
  partBEffectiveDate?: string;
  flexibleSpendingSelection?: boolean;
}
