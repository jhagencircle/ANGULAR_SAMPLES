﻿using BCBSAZ.ProviderAuxiliaryPortal.ExceptionHandling.CustomException;
using BCBSAZ.ProviderAuxiliaryPortal.ExceptionHandling.Middleware;
using Microsoft.AspNetCore.Http;
using NSubstitute;
using Serilog;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http.Features;
using Xunit;

namespace BCBSAZ.ProviderAuxiliaryPortal.UnitTests.Middleware
{
    public class ExceptionMiddlewareTests
    {
        private readonly ILogger _logger;

        public ExceptionMiddlewareTests()
        {
            _logger = Substitute.For<ILogger>();
        }

        [Theory]
        [ClassData(typeof(ExceptionData))]
        public async void InvokeAsyncTest(Exception ex, int expectedStatus)
        {
            //Arrange
            var requestDelegate = new RequestDelegate(context => Task.FromException(ex));
            
            var response = Substitute.For<IHttpResponseFeature>();
            response.Body = new MemoryStream();
            
            var httpContext = new DefaultHttpContext();
            httpContext.Features.Set(response);

            var middleware = new ExceptionHandlerMiddleware(requestDelegate, _logger);

            //Act
            await middleware.Invoke(httpContext);

            //Assert
            Assert.Equal(expectedStatus, httpContext.Response.StatusCode);
        }
    }

    class ExceptionData : IEnumerable<object[]>
    {
        public IEnumerator<object[]> GetEnumerator()
        {
            yield return new object[] { new NotFoundException(), 404};
            yield return new object[] { new ForbiddenException(), 403 };
            yield return new object[] { new UnauthorizedException(), 401 };
            yield return new object[] { new ValidationException(), 400 };
            yield return new object[] { new Exception(), 500 };
            yield return new object[] { new ArgumentOutOfRangeException(), 500 };
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
