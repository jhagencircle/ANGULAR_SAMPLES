import { Observable, of } from 'rxjs';

export class RelationshipServiceMock {
  constructor() {}

  public static mockedRelationshipsByCoverage: any = {
    '1 Tier-1': [
      'Spouse',
      'Adopted Child',
      'Foster Child',
      'Child',
      'Child where Insured Has No Responsibility',
    ],
  };

  get(): Observable<any> {
    return of([
      'Spouse',
      'Grandmother or Grandfather',
      'Grandson or Granddaughter',
      'Uncle or Aunt',
      'Nephew or Niece',
      'Cousin',
      'Adopted Child',
      'Foster Child',
      'Son-in-law or Daughter-in-law',
      'Brother-in-law or Sister-in-law',
      'Mother-in-law or Father-in-law',
      'Brother or Sister',
      'Ward',
      'Stepson or Stepdaughter',
      'Self',
      'Child',
      'Employee',
      'Unknown',
      'Father or Mother',
      'Handicapped Dependent',
      'Sponsored Dependent',
      'Dependent of a Minor Dependent',
      'Ex-spouse',
      'Guardian',
      'Significant Other',
      'Court Appointed Guardian',
      'Mother',
      'Father',
      'Other Adult',
      'Emancipated Minor',
      'Collateral Dependent',
      'Organ Donor',
      'Cadaver Donor',
      'Injured Plaintiff',
      'Child where Insured Has No Responsibility',
      'Stepfather',
      'Stepmother',
      'Life Partner',
      'Other Relationship',
      'Domestic Partner',
      'Annuitant',
      'Trustee',
      'Stepparent',
      'Other Relative',
    ]);
  }

  getByCoverage(): Observable<any> {
    return of(RelationshipServiceMock.mockedRelationshipsByCoverage);
  }

  update(): Observable<boolean> {
    return of(true);
  }
}
