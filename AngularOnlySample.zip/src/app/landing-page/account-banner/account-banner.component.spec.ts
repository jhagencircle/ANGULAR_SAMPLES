import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AccountBannerComponent } from './account-banner.component';
import { CurrentBillMock } from 'src/app/shared/mocks/current-bill.mock';

describe('AccountBannerComponent', () => {
  let component: AccountBannerComponent;
  let fixture: ComponentFixture<AccountBannerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AccountBannerComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountBannerComponent);
    component = fixture.componentInstance;

    let accounts =
      CurrentBillMock.mockedCurrentBillSubsubAccount.subAccountSummary;
    if (accounts !== undefined) {
      component.account = accounts[0];
    }
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit selected account', () => {
    spyOn(component.selectedSubaccounts, 'emit');
    component.onSelectChange();
    expect(component.selectedSubaccounts.emit).toHaveBeenCalledWith(
      component.account
    );
  });

  it('should display Sub-sub-account', () => {
    component.displaySubSubAccounts();
    expect(component.account.isSubSubAccountsDisplayed).toBeTrue();
  });
});
