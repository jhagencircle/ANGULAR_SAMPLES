export interface IProducts {
  effectiveDate: Date | null;
  planType: string;
  hccPlanId: string | null;
  subAccountNumber: string;
  requiredStartDate: Date;
}
