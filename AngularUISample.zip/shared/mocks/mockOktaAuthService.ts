export class MockOktaAuthService {
    public async isAuthenticated() {
        return true;
    }

    public async getUser() {
        return {
            name: "User Name",
            email: "usermail@mail.com",
            sub: "axjlkasd12"
        };
    }

    public getAccessToken() {
        return "TestToken";
    }
}