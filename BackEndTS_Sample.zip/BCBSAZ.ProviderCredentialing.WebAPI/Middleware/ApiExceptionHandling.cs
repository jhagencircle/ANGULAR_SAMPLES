﻿using BCBSAZ.ProviderCredentialing.Models;
using BCBSAZ.ProviderCredentialing.Models.Responses.Common;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebAPI.Middleware
{
	/// <summary>
	/// Middleware class designed to provide Global Exception Handling
	/// </summary>
	internal class ApiExceptionHandling
	{
		/// <summary>
		/// Creates a list of custom responses based on Exception type thrown.
		/// </summary>
		// Add your custom exceptions, status codes and messages here (leave message blank to use default)
		private static readonly List<ExceptionResponse> _responses = new List<ExceptionResponse>()
		{
			new ExceptionResponse(typeof(Exception), HttpStatusCode.InternalServerError),
			new ExceptionResponse(typeof(InvalidRequestException), HttpStatusCode.BadRequest),
			new ExceptionResponse(typeof(UnauthorizedAccessException), HttpStatusCode.Forbidden)
		};

		/// <summary>
		/// Creates a list of default error messages based on Http Status Code.
		/// </summary>
		// These are the default messages based on HttpStatusCode, in DEBUG, the actual exception message will be used instead
		private static readonly Dictionary<HttpStatusCode, string> _defaultMessages = new Dictionary<HttpStatusCode, string>()
		{
			{ HttpStatusCode.InternalServerError, "Internal Server Error"},
			{ HttpStatusCode.Forbidden, "Request is not Authorized"},
			{ HttpStatusCode.Unauthorized, "Request is not Authorized"},
			{ HttpStatusCode.BadRequest, "Invalid Request"}
		};

		private readonly RequestDelegate _next;
		private readonly IHostEnvironment _hostEnvironment;
		private readonly IConfiguration _configuration;
		private readonly ILogger _logger;

		public ApiExceptionHandling(RequestDelegate next, IHostEnvironment hostEnvironment, IConfiguration configuration, ILogger<ApiExceptionHandling> logger)
		{
			_next = next;
			_hostEnvironment = hostEnvironment;
			_configuration = configuration;
			_logger = logger;
		}

		/// <summary>
		/// Called by the MVC Pipeline during a request
		/// </summary>
		/// <param name="context">The http context of the current request</param>
		public async Task Invoke(HttpContext context)
		{
			try
			{
				await _next(context);
			}
			catch (Exception ex)
			{
				await HandleExceptionAsync(context, ex);
			}
		}

		/// <summary>
		/// Handles the exception caught by the global exception handling.
		/// </summary>
		/// <param name="context">The http context of the current request</param>
		/// <param name="exception">The exception which was thrown</param>
		private async Task HandleExceptionAsync(HttpContext context, Exception exception)
		{
			var response = GetExceptionResponse(exception);

			_logger.LogError(-1, exception, context, response.Message);

			context.Response.ContentType = "application/json";
			context.Response.StatusCode = (int)response.Code;
			await context.Response.WriteAsync(JsonConvert.SerializeObject(response));
		}

		/// <summary>
		/// Gets a response using the defined responses by Exception type.
		/// </summary>
		/// <param name="exception">The exception which was thrown</param>
		/// <returns>Returns an Exception Response object appropriate for the thrown exception</returns>
		private ExceptionResponse GetExceptionResponse(Exception exception)
		{
			var retVal = (from r in _responses
										where r.ExceptionType == exception.GetType()
										select new ExceptionResponse(r)).FirstOrDefault() ?? new ExceptionResponse(_responses[0]);

			if (string.IsNullOrWhiteSpace(retVal.Message))
				SetDefaultMessage(retVal, exception);

			return retVal;
		}

		/// <summary>
		/// Gets the default message for the Exception Response (in 'Debug' mode this will be the exception details)
		/// </summary>
		/// <param name="response">The Exception Response object which has been created based on the type of exception thrown</param>
		/// <param name="exception">The exception which was thrown</param>
		private void SetDefaultMessage(ExceptionResponse response, Exception exception)
		{
			if (_hostEnvironment.IsDevelopment(_configuration))
			{
				var msg = new StringBuilder();

				msg.AppendLine(_defaultMessages.ContainsKey(response.Code) ? _defaultMessages[response.Code] : _defaultMessages[HttpStatusCode.InternalServerError]);
				msg.AppendLine();

				msg.AppendLine("Exception:");

				var indent = "\t";
				var ex = exception;
				while (ex != null)
				{
					msg.AppendFormat("{0}{1}: {2}{3}", indent, ex.GetType().FullName, ex.Message, Environment.NewLine);
					msg.AppendLine();
					ex = ex.InnerException;
					indent += "\t";
				}
				msg.AppendLine(exception.StackTrace);

				var message = msg.ToString();

#if DEBUG
				System.Diagnostics.Debug.WriteLine(string.Empty);
				System.Diagnostics.Debug.WriteLine(message);
				System.Diagnostics.Debug.WriteLine(string.Empty);
#endif

				if (string.IsNullOrWhiteSpace(response.Message))
					response.Message = message;
			}
			else
			{
				if (string.IsNullOrWhiteSpace(response.Message))
					response.Message = _defaultMessages.ContainsKey(response.Code) ? _defaultMessages[response.Code] : _defaultMessages[HttpStatusCode.InternalServerError];
			}
		}
	}
}
