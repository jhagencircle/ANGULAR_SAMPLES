﻿using BCBSAZ.ProviderCredentialing.Models.Data.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace BCBSAZ.ProviderCredentialing.Repositories.DbContexts
{
	/// <summary>
	/// Provides Application startup configuration for all Entity Framework DbContexts
	/// </summary>
	internal static class DbContextsStartup
	{

		#region Connection Strings (most stored in APO database)
		/************ NOT Stored in APO ************/
		private const string APO = "APO";

		/************ Stored in APO ************/
		private const string Credentialing = "Credentialing";
		private const string SystemLogs = "SystemLogs";
		private const string Email = "Email";

		private static readonly string[] apoDatabases = new string[]
		{
			Credentialing, SystemLogs, Email
		};

		private static ConnectionStringList GetConnectionStrings(IConfiguration configuration)
		{
			var apoServer = configuration.GetValue<string>("ApoServer");
			var apoEnvironment = configuration.GetValue<string>("ApoEnvironment");
			var apoConStr = $"Server={apoServer};database=APO;UID=APOUser;PWD=$a100#p@;Trusted_Connection=false;";

			var builder = new DbContextOptionsBuilder<ApoContext>()
				.UseSqlServer(apoConStr, providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

			var retVal = new ConnectionStringList()
			{
				new ConfigSetting() { Environment = apoEnvironment, Name = APO, Value = apoConStr },
			};

			using (var context = new ApoContext(builder.Options))
			{
				retVal.AddRange(
					from cs in context.ConfigSettings
					where
						cs.Environment == apoEnvironment &&
						apoDatabases.Contains(cs.Name)
					select cs);
			}

			return retVal;
		}

		private class ConnectionStringList : List<ConfigSetting>
		{
			public string this[string dbName]
			{
				get
				{
					return (from cs in this
									where cs.Name.Equals(dbName, StringComparison.OrdinalIgnoreCase)
									select cs.Value).FirstOrDefault();
				}
			}
		}

		#endregion

		/// <summary>
		/// Configures BCBSAZ.Provider Entity Framework DbContexts in the Service Collection using the provided configuration
		/// </summary>
		/// <param name="services">The Service Collection in which DbContexts will be configured</param>
		/// <param name="configuration">The configuration containing Db Connection information</param>
		public static void AddDbContexts(this IServiceCollection services, IConfiguration configuration)
		{
			var conStrs = GetConnectionStrings(configuration);

			services.AddDbContext<IApoContext, ApoContext>(options => options
				.UseSqlServer(conStrs[APO], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<ICredentialingContext, CredentialingContext>(options => options
				 .UseSqlServer(conStrs[Credentialing], providerOptions => providerOptions.CommandTimeout(60))
				 .UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll)
			);

			services.AddDbContext<IEmailContext, EmailContext>(options => options
				.UseSqlServer(conStrs[Email], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			// Because this is used by Logging, it needs to be a singleton, most other dbcontexts will be scoped.
			services.AddDbContext<ISystemLogsContext, SystemLogsContext>(options => options
				.UseSqlServer(conStrs[SystemLogs], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking),
				ServiceLifetime.Singleton
			);
		}
	}
}
