﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.TPA;

namespace BCBSAZ.Provider.Managers.RequestValidators.TPA
{
	public static class TpaProviderInfoRequestValidator
	{
		public static void Validate(this TpaProviderInfoRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetVoilations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetVoilations(TpaProviderInfoRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.TaxId))
				yield return new InvalidModelExceptionDetail(nameof(TpaProviderInfoRequest.TaxId), new ArgumentException("TaxId is missing."));

			if (string.IsNullOrWhiteSpace(request.ProviderId))
				yield return new InvalidModelExceptionDetail(nameof(TpaProviderInfoRequest.ProviderId), new ArgumentException("ProviderId is missing."));

			if (string.IsNullOrWhiteSpace(request.Network))
				yield return new InvalidModelExceptionDetail(nameof(TpaProviderInfoRequest.Network), new ArgumentException("Network is missing."));
		}
	}
}
