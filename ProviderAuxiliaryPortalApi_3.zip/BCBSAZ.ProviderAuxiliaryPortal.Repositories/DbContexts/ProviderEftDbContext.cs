﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts
{
    public class ProviderEftDbContext : DbContext
    {
        public DbSet<EftEnrollmentRequest> EftEnrollmentRequests { get; protected set; }


        public DbSet<ProviderIdentifier> ProviderIdentifiers { get; protected set; }
        
        /// <summary>
        /// Creates a new instance of the EftEnrollmentRequest DbContext object.
        /// </summary>
        /// <param name="request"></param>
        public ProviderEftDbContext(DbContextOptions<ProviderEftDbContext> request) : base(request) { }
                
        /// <summary>
        /// Defines custom model binding for models relating to the ProviderEft database
        /// </summary>
        /// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EftEnrollmentRequest>().HasKey(cs => new { cs.RequestId});
            modelBuilder.Entity<EftEnrollmentRequest>().Property(e => e.InsertDate).HasDefaultValueSql("GetDate()");

            modelBuilder.Entity<ProviderIdentifier>().HasKey(cs => new { cs.Id});
            modelBuilder.Entity<ProviderIdentifier>().Property(f => f.LastModified).HasDefaultValueSql("GetDate()");

        }

        public static ProviderEftDbContext CreateContextInstance(string connectionStr)
        {
            var builder = new DbContextOptionsBuilder<ProviderEftDbContext>()
                .UseSqlServer(connectionStr, providerOptions => providerOptions.CommandTimeout(60))
                .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

            return new ProviderEftDbContext(builder.Options);
        }

    }
}
