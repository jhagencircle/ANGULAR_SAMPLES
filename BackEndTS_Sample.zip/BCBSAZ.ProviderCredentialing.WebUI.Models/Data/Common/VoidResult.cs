﻿namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Common
{
	public class VoidResult
	{
		// Purposefully Empty.
	}
}
