﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using BCBSAZ.Provider.Managers.RequestValidators.PreCert;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.PreCert;
using BCBSAZ.Provider.Models.Data.PreCert.Medical;
using BCBSAZ.Provider.Models.Requests.PreCert;
using BCBSAZ.Provider.Models.Responses.PreCert;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Managers
{
	public partial class PreCertManager
	{
		private string _medicalFromAddress;
		private string _medicalStaffAddress;

		private void InitializeMedical(IConfiguration configuration)
		{
			_medicalFromAddress = configuration.GetValue<string>("MedicalPreCert_FromAddress");
			_medicalStaffAddress = configuration.GetValue<string>("MedicalPreCert_StaffAddress");
		}

		public async Task<GetMedicalPreCertResponse> GetMedicalPreCertAsync(GetMedicalPreCertRequest request, WebUser webUser)
		{
			request.Validate(webUser);

			var preCert = await _preCertRepository.GetMedicalPreCertByIdAsync(request.PreCertId);

			if (!IsInternal(webUser) && (preCert.UserId != webUser.UserId))
				throw new UnauthorizedAccessException();

			GetMedicalPreCertResponse precertResponse = new GetMedicalPreCertResponse(preCert);

			PopulateCommentsUserName(precertResponse);
			PopulateStatusesUserName(precertResponse);

			await AddDownloadHashes(precertResponse, webUser);

			return precertResponse;
		}

		private async Task AddDownloadHashes(GetMedicalPreCertResponse response, WebUser webUser)
		{
			foreach (var attachment in response.Attachments)
			{
				await AddDownloadHash(attachment, webUser);
			}
		}

		private async Task AddDownloadHash(Attachment attachment, WebUser webUser)
		{
			var fileHash = await _preCertRepository.GetUploadedFileHashAsync(attachment.FileId);
			using (var sha = SHA256.Create())
			{
				// Generate a download hash using the UserId and File Hash.  This hash will be validated when the user attempts
				// to download a file.  If the user changes the file Id (or username) part of the URL, then the hash won't match
				// and we will return a 403 response.
				attachment.DownloadHash = sha.GenerateHashHexString($"{ webUser.UserId }|{ fileHash }");
			}
		}

		public ViewMedicalPreCertsResponse ViewMedicalPreCertResults(ViewMedicalPreCertsRequest request, WebUser webUser)
		{
			request.Validate(webUser);

			return new ViewMedicalPreCertsResponse()
			{
				MedicalSummaries = _preCertRepository.ViewMedicalPreCertResults(webUser.UserId, webUser.OrgId, request.Status, request.FromDate, request.ToDate, IsInternal(webUser))
			};
		}

		#region Save PreCert
		public async Task<SaveMedicalPreCertResponse> SaveMedicalPreCertAsync(SaveMedicalPreCertRequest request, WebUser webUser)
		{
			request.Validate(webUser);

			var updateDate = DateTime.Now;

			request.Form.UserId = webUser.UserId;
			request.Form.InsertDate = updateDate;

			var preCert = await _preCertRepository.GetMedicalPreCertByIdAsync(request.PreCertId);

			if (request.PreCertId == 0)
			{
				preCert.UserId = webUser.UserId;
			}
			else if (!IsInternal(webUser) && (preCert.UserId != webUser.UserId))
			{
				throw new UnauthorizedAccessException();
			}

			var currentForm = ProcessForm(request, preCert);

			ProcessDiagnosticCodes(preCert, request.DiagnosisCodes, webUser.UserId, updateDate);
			ProcessCPTCodes(preCert, request.CPTCodes, webUser.UserId, updateDate);
			ProcessAttachments(preCert, request.Attachments, webUser.UserId, updateDate);
			ProcessComments(preCert, request.Form.FormComments, webUser.UserId, updateDate);
			var newStatus = ProcessStatus(preCert, request.Status, currentForm, webUser.UserId, updateDate);

			await _preCertRepository.SaveAllChangesAsync();

			await SendStatusEmailAsync(newStatus, preCert, updateDate);

			return new SaveMedicalPreCertResponse(preCert, updateDate);
		}

		private void ProcessComments(MedicalPreCert preCert, string formComments, string userId, DateTime updateDate)
		{
			if (string.IsNullOrWhiteSpace(formComments))
				return;

			preCert.Comments.Add(new Comments()
			{
				CommentText = formComments,
				UserId = userId,
				InsertDate = updateDate
			});
		}

		#region Process Form

		private Form ProcessForm(SaveMedicalPreCertRequest request, MedicalPreCert preCert)
		{
			var oldForm = (
				from f in preCert.Forms
				orderby f.InsertDate descending
				select f).FirstOrDefault();

			return (request.Status == PreCertStatus.Unsubmitted) ?
				UpdateForm(preCert, oldForm, request.Form) :
				AddFormIfNew(preCert, oldForm, request.Form);
		}

		private Form UpdateForm(MedicalPreCert preCert, Form oldForm, Form newForm)
		{
			if (oldForm == null)
			{
				preCert.Forms.Add(newForm);
				return newForm;
			}
			else
			{
				oldForm.UpdateForm(newForm);
				return oldForm;
			}
		}

		private Form AddFormIfNew(MedicalPreCert preCert, Form oldForm, Form newForm)
		{
			if (oldForm == null)
			{
				preCert.Forms.Add(newForm);
				return newForm;
			}
			else if (!oldForm.IsEqual(newForm))
			{
				newForm.PreviousId = oldForm.FormId;
				preCert.Forms.Add(newForm);
				return newForm;
			}
			else
			{
				oldForm.FormComments = newForm.FormComments;
				return oldForm;
			}
		}

		#endregion

		#region Process Diagnosis Codes

		private void ProcessDiagnosticCodes(MedicalPreCert preCert, IEnumerable<DiagnosisCode> diagnosisCodes, string userId, DateTime updateDate)
		{
			var newCodes = (
				from dc in diagnosisCodes
				select dc.Code);

			var oldCodes = (
				from dc in preCert.DiagnosisCodes
				where dc.RemovedByUserId == null
				select dc.Code);

			var deleted = (
				from dc in preCert.DiagnosisCodes
				where !newCodes.Contains(dc.Code, StringComparer.OrdinalIgnoreCase)
				select dc);

			var added = (
				from dc in diagnosisCodes
				where !oldCodes.Contains(dc.Code, StringComparer.OrdinalIgnoreCase)
				select dc);

			deleted.ForEach(DeleteDiagnosisCode, userId, updateDate);
			added.ForEach(AddDiagnosisCode, preCert, userId, updateDate);

		}

		private static void DeleteDiagnosisCode(DiagnosisCode code, string userId, DateTime updateDate)
		{
			if (code.IsRemoved)
				return;

			code.IsRemoved = true;
			code.RemovedByUserId = userId;
			code.DateRemoved = DateTime.Now;
		}

		private static void AddDiagnosisCode(DiagnosisCode code, MedicalPreCert preCert, string userId, DateTime updateDate)
		{
			if (string.IsNullOrWhiteSpace(code.Code))
				return;

			code.IsRemoved = false;
			code.AddedByUserId = userId;
			code.DateAdded = DateTime.Now;

			preCert.DiagnosisCodes.Add(code);
		}

		#endregion

		#region Process CPT Codes

		private void ProcessCPTCodes(MedicalPreCert preCert, IEnumerable<CPTCode> cptCodes, string userId, DateTime updateDate)
		{
			var newCodes = (
				from cc in cptCodes
				select cc.Code);

			var oldCodes = (
				from cc in preCert.CPTCodes
				where cc.RemovedByUserId == null
				select cc);



			var deleted = (
				from cc in preCert.CPTCodes
				where !newCodes.Contains(cc.Code, StringComparer.OrdinalIgnoreCase)
				select cc);

			var added = (
				from cc in cptCodes
				where !oldCodes.Any(x => x.Code.Equals(cc.Code, StringComparison.OrdinalIgnoreCase))
				select cc);

			oldCodes.ForEach(UpdateDescription, cptCodes);
			deleted.ForEach(DeleteCPTCode, userId, updateDate);
			added.ForEach(AddCPtCode, preCert, userId, updateDate);

		}

		private static void UpdateDescription(CPTCode code, IEnumerable<CPTCode> cptCodes)
		{
			var newValue = (from c in cptCodes
											where c.Code.Equals(code.Code, StringComparison.OrdinalIgnoreCase)
											select c).FirstOrDefault();

			if (newValue != null)
				code.Description = newValue.Description;
		}

		private static void DeleteCPTCode(CPTCode code, string userId, DateTime updateDate)
		{
			if (code.IsRemoved)
				return;

			code.IsRemoved = true;
			code.RemovedByUserId = userId;
			code.DateRemoved = DateTime.Now;
		}

		private static void AddCPtCode(CPTCode code, MedicalPreCert preCert, string userId, DateTime updateDate)
		{
			if (string.IsNullOrWhiteSpace(code.Code))
				return;

			code.IsRemoved = false;
			code.AddedByUserId = userId;
			code.DateAdded = DateTime.Now;

			preCert.CPTCodes.Add(code);
		}

		#endregion

		#region Process Attachments

		private void ProcessAttachments(MedicalPreCert preCert, IEnumerable<Attachment> attachments, string userId, DateTime updateDate)
		{
			var deleted = (
				from existing in preCert.Attachments
				join a in attachments on existing.FileId equals a.FileId
				where a.IsRemoved
				select existing);

			var added = (
				from a in attachments
				where IsNewAttachment(a, preCert.Attachments)
				select a);

			deleted.ForEach(DeleteAttachment, userId, updateDate);
			added.ForEach(AddAttachment, preCert, userId, updateDate);
		}

		private static bool IsNewAttachment(Attachment attachment, IEnumerable<Attachment> existingAttachments)
		{
			if (attachment.IsRemoved || attachment.AttachmentId != 0)
				return false;

			return !(from e in existingAttachments
							 where e.FileId == attachment.FileId
							 select e).Any();
		}

		private static void DeleteAttachment(Attachment attachment, string userId, DateTime updateDate)
		{
			attachment.IsRemoved = true;
			attachment.RemovedByUserId = userId;
			attachment.DateRemoved = updateDate;
		}

		private static void AddAttachment(Attachment attachment, MedicalPreCert preCert, string userId, DateTime updateDate)
		{
			attachment.FileName = Path.GetFileName(attachment.FileName);

			attachment.IsRemoved = false;
			attachment.AddedByUserId = userId;
			attachment.DateAdded = updateDate;

			preCert.Attachments.Add(attachment);
		}

		#endregion

		#region Process Status

		private PreCertStatus ProcessStatus(MedicalPreCert preCert, PreCertStatus status, Form form, string userId, DateTime updateDate)
		{
			var currentStatus = (
				from f in preCert.Forms
				from s in f.Statuses
				orderby s.InsertDate descending
				select s).FirstOrDefault();

			if ((currentStatus == null) || (currentStatus.FormStatus != status))
			{
				if ((currentStatus != null) && (currentStatus.FormStatus != PreCertStatus.Unsubmitted) && (status == PreCertStatus.Unsubmitted))
				{
					throw new InvalidRequestException(new InvalidModelExceptionDetail[]
					{
						new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Status), new ArgumentException("Attempted to set a Submitted Form to Unsubmitted Status."))
					});
				}

				form.Statuses.Add(new Status()
				{
					FormStatus = status,
					UserId = userId,
					InsertDate = updateDate
				});

				return status;
			}

			return PreCertStatus.Unsubmitted;
		}

		#endregion

		#endregion

		#region Send Email

		private async Task SendStatusEmailAsync(PreCertStatus status, MedicalPreCert preCert, DateTime updateDate)
		{
			if ((status != PreCertStatus.Unsubmitted) && !string.IsNullOrWhiteSpace(preCert.UserId))
			{
				var toAddress = await _preCertRepository.GetEmailAddressForUserAsync(preCert.UserId);
				var preCertId = string.Format(CultureInfo.InvariantCulture, "M{0:00000000}", preCert.MedicalPreCertId);

				switch (status)
				{
					case PreCertStatus.Approved:
						await _emailProcessor.SendPreCertApprovedAsync(_medicalFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.Canceled:
						await _emailProcessor.SendPreCertCancelledAsync(_medicalFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.Denied:
						await _emailProcessor.SendPreCertDeniedAsync(_medicalFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.Incomplete:
						await _emailProcessor.SendPreCertIncompleteAsync(_medicalFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.NotRequired:
						await _emailProcessor.SendPreCertNotRequiredAsync(_medicalFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.Pending:
						await _emailProcessor.SendPreCertSubmittedAsync(_medicalFromAddress, toAddress, preCertId);
						await _emailProcessor.SendPreCertNewRequestAsync(_medicalFromAddress, _medicalStaffAddress, preCertId, _providerPortalUrl, updateDate);
						break;
				}
			}
		}

		#endregion

		#region Cancel PreCert

		public async Task<CancelMedicalPreCertResponse> CancelMedicalPreCertAsync(CancelMedicalPreCertRequest request, WebUser webUser)
		{
			request.Validate(webUser);

			var preCert = await _preCertRepository.GetMedicalPreCertByIdAsync(request.PreCertId);
			var updateDate = DateTime.Now;

			var form = (
				from f in preCert.Forms
				orderby f.InsertDate descending
				select f).FirstOrDefault();

			form.Statuses.Add(new Status()
			{
				FormStatus = PreCertStatus.Canceled,
				InsertDate = updateDate,
				UserId = webUser.UserId
			});

			await _preCertRepository.SaveAllChangesAsync();
			await SendStatusEmailAsync(PreCertStatus.Canceled, preCert, updateDate);

			return new CancelMedicalPreCertResponse()
			{
				PreCertId = preCert.MedicalPreCertId,
				UpdateDate = updateDate
			};
		}

		#endregion

		public async Task<DownloadFileResponse> GetMedicalFileContentsAsync(DownloadFileRequest request)
		{
			request.Validate();

			var attachment = await _preCertRepository.GetMedicalAttachmentByIdAsync(request.AttachmentId);
			var file = await _preCertRepository.GetUploadedFileByIdAsync(attachment.FileId);

			using (var sha = SHA256.Create())
			{
				// Validate the download hash. If the user changes the file Id (or username) part of the URL, then the hash won't match
				// and we will return a 403 response.
				request.UserId = request.UserId.Replace("_", "\\");

				var downloadHash = sha.GenerateHashHexString($"{ request.UserId }|{ file.FileHash }");
				if (downloadHash != request.DownloadHash)
					throw new UnauthorizedAccessException();
			}

			return new DownloadFileResponse
			{
				FileName = attachment.FileName,
				FileContents = file.Contents,
				ContentType = file.ContentType
			};
		}

		private void PopulateCommentsUserName(GetMedicalPreCertResponse precertResponse)
		{
			var userIds = (
				from comment in precertResponse.Comments
				select comment.UserId).Distinct().ToArray();

			var users = _preCertRepository.GetUserNameByUserId(userIds);

			precertResponse.Comments.ForEach(AddUserInfoToComment, users);
		}

		private void PopulateStatusesUserName(GetMedicalPreCertResponse precertResponse)
		{
			var userIds = (
				from status in precertResponse.StatusHistory
				select status.UserId).Distinct().ToArray();

			var users = _preCertRepository.GetUserNameByUserId(userIds);

			precertResponse.StatusHistory.ForEach(AddUserInfoToStatus, users);
		}

		private void AddUserInfoToComment(Comments comment, User[] users)
		{
			var user = (
				from u in users
				where u.UserId.Equals(comment.UserId, StringComparison.OrdinalIgnoreCase)
				select u
			).FirstOrDefault();

			comment.UserFirstName = user?.FirstName;
			comment.UserLastName = user?.LastName;

			if (string.IsNullOrWhiteSpace(comment.UserFirstName) && string.IsNullOrWhiteSpace(comment.UserLastName))
				comment.UserFirstName = user?.UserId;
		}

		private void AddUserInfoToStatus(Status status, User[] users)
		{
			var user = (
				from u in users
				where u.UserId.Equals(status.UserId, StringComparison.OrdinalIgnoreCase)
				select u
			).FirstOrDefault();

			status.UserFirstName = user?.FirstName;
			status.UserLastName = user?.LastName;

			if (string.IsNullOrWhiteSpace(status.UserFirstName) && string.IsNullOrWhiteSpace(status.UserLastName))
				status.UserFirstName = user?.UserId;
		}
	}
}
