﻿using System;
using Microsoft.AspNetCore.Http;

namespace Microsoft.Extensions.Logging
{
	public class QueueLoggerProvider : ILoggerProvider
	{
		private readonly LogMessageQueue _logMessages;

		public QueueLoggerProvider(LogMessageQueue logMessages)
		{
			_logMessages = logMessages;
		}

		public ILogger CreateLogger(string categoryName)
		{
			return new QueueLogger(_logMessages, categoryName);
		}

		protected virtual void Dispose(bool disposing)
		{
		}

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}
	}
}
