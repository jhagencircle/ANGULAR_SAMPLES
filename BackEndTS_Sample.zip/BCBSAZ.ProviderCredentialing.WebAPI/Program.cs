using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;

namespace BCBSAZ.ProviderCredentialing.WebAPI
{
	public class Program
	{
		public static void Main(string[] args)
		{
			CreateHostBuilder(args).Build().Run();
		}

		public static IHostBuilder CreateHostBuilder(string[] args)
		{
			return Host.CreateDefaultBuilder(args)
				.ConfigureWebHostDefaults(webBuilder =>
				{
					webBuilder.UseStartup<Startup>();
					webBuilder.ConfigureLogging(UseQueueLogger);
				});
		}

		private static void UseQueueLogger(WebHostBuilderContext builderContext, ILoggingBuilder loggingBuilder)
		{
			try
			{
				loggingBuilder.AddConfiguration(builderContext.Configuration.GetSection("Logging"));

#if DEBUG
				loggingBuilder.AddConsole();
				loggingBuilder.AddDebug();
#endif

				loggingBuilder.AddEventSourceLogger();
				loggingBuilder.AddQueueLogger();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Unable to Add or Configure Logging.");

				var err = ex;

				while (err != null)
				{
					Console.WriteLine(err.GetType().FullName);
					Console.WriteLine(err.Message);

					err = err.InnerException;
				}

				Console.WriteLine(ex.StackTrace);
			}
			finally
			{
				Console.Out.Flush();
			}
		}
	}
}
