import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, Subject } from 'rxjs';
import { debounceTime, delay, switchMap, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { IPlan, IEmployeeRoster, IEmployee } from './models';
import { ISearchResult } from './models/search-result.model';
import { SortDirection } from '../../shared/directives/sortable.directive';
import { IState } from './state';

const compare = (
  v1: string | number | IPlan[] | any,

  v2: string | number | IPlan[] | any
) => (v1 < v2 ? -1 : v1 > v2 ? 1 : 0);

function sort(
  employees: IEmployeeRoster[],
  column: string,
  direction: string
): IEmployeeRoster[] {
  if (direction === '' || column === '') {
    return employees;
  } else {
    return [...employees].sort((a: any, b: any) => {
      const res = compare(a[column], b[column]);
      return direction === 'asc' ? res : -res;
    });
  }
}

function matches(
  employee: IEmployeeRoster,
  term: string,
  planMedical: string | null,
  planDental: string | null
) {
  return (
    (employee.firstName.toLowerCase().includes(term.toLowerCase()) ||
      employee.lastName.toLowerCase().includes(term.toLowerCase()) ||
      employee.employeeId?.toLowerCase().includes(term.toLowerCase()) ||
      employee.subscriberId?.toLowerCase().includes(term.toLowerCase())) &&
    (planMedical == null ||
      employee.medicalPlanId == planMedical ||
      (planMedical == 'All' && employee.medicalPlanId != '')) &&
    (planDental == null ||
      employee.dentalPlanId == planDental ||
      (planDental == 'All' && employee.dentalPlanId != ''))
  );
}

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  private _loading$ = new BehaviorSubject<boolean>(true);
  private _search$ = new Subject<void>();
  private _employees$ = new BehaviorSubject<IEmployeeRoster[]>([]);
  private _total$ = new BehaviorSubject<number>(0);
  private _employeeList: IEmployeeRoster[] = [];
  private _employee: IEmployee;

  private _state: IState = {
    page: 1,
    pageSize: 10,
    searchTerm: '',
    planMedical: null,
    planDental: null,
    sortColumn: '',
    sortDirection: '',
  };

  private url = `${environment.apiUrl}/api/Employee`;
  constructor(private http: HttpClient) {
    this._search$
      .pipe(
        tap(() => this._loading$.next(true)),
        debounceTime(200),
        switchMap(() => this._search()),
        delay(200),
        tap(() => this._loading$.next(false))
      )
      .subscribe((result) => {
        this._employees$.next(result.employees);
        this._total$.next(result.total);
      });

    this._search$.next();
  }

  get employees$() {
    return this._employees$.asObservable();
  }
  get total$() {
    return this._total$.asObservable();
  }
  get loading$() {
    return this._loading$.asObservable();
  }
  get page() {
    return this._state.page;
  }
  get pageSize() {
    return this._state.pageSize;
  }
  get searchTerm() {
    return this._state.searchTerm;
  }
  get planMedical() {
    return this._state.planMedical;
  }
  get planDental() {
    return this._state.planDental;
  }
  get employeeList(): IEmployeeRoster[] {
    return this._employeeList;
  }
  get employee(): IEmployee {
    return this._employee;
  }

  set page(page: number) {
    this._set({ page });
  }
  set pageSize(pageSize: number) {
    this._set({ pageSize });
  }
  set searchTerm(searchTerm: string) {
    this._set({ searchTerm });
  }
  set planMedical(planMedical: string | null) {
    this._set({ planMedical });
  }
  set planDental(planDental: string | null) {
    this._set({ planDental });
  }
  set sortColumn(sortColumn: string) {
    this._set({ sortColumn });
  }
  set sortDirection(sortDirection: SortDirection) {
    this._set({ sortDirection });
  }
  set employeeList(el: IEmployeeRoster[]) {
    this._employeeList = el;
  }
  set employee(emp: IEmployee) {
    this._employee = emp;
  }

  private _set(patch: Partial<IState>) {
    Object.assign(this._state, patch);
    this._search$.next();
  }

  private _search(): Observable<ISearchResult> {
    const {
      sortColumn,
      sortDirection,
      pageSize,
      page,
      searchTerm,
      planMedical,
      planDental,
    } = this._state;

    // 1. sort
    let employees = sort(this.employeeList, sortColumn, sortDirection);

    // 2. filter
    employees = employees.filter((employee) =>
      matches(employee, searchTerm, planMedical, planDental)
    );
    const total = employees.length;

    // 3. paginate
    employees = employees.slice(
      (page - 1) * pageSize,
      (page - 1) * pageSize + pageSize
    );
    return of({ employees, total });
  }

  get(accountId: string, billId: string): Observable<IEmployeeRoster[]> {
    return this.http.get<IEmployeeRoster[]>(
      `${this.url}/${accountId}?billId=${billId}`
    );
  }

  getById(accountId: string, subscriberId: string): Observable<IEmployee> {
    return this.http.get<IEmployee>(`${this.url}/${accountId}/${subscriberId}`);
  }

  export(employeeList: IEmployeeRoster[]) {
    let nowDate = new Date();
    let filename = `SubAccountDetail-${nowDate.toISOString()}`;
    let csvData = this.ConvertToCSV(employeeList);
    let blob = new Blob(['\ufeff' + csvData], {
      type: 'text/csv;charset=utf-8;',
    });
    let dwldLink = document.createElement('a');
    let url = URL.createObjectURL(blob);
    let isSafariBrowser =
      navigator.userAgent.indexOf('Safari') != -1 &&
      navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute('target', '_blank');
    }
    dwldLink.setAttribute('href', url);
    dwldLink.setAttribute('download', filename + '.csv');
    dwldLink.style.visibility = 'hidden';
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  private ConvertToCSV(employeeList: IEmployeeRoster[]) {
    let columnList = Object.keys(employeeList[0]);
    let csvContent = `${columnList.join(',')}\r\n`;

    employeeList.forEach((employee) => {
      csvContent +=
        `${employee.subscriberId},${employee.firstName},${employee.lastName},` +
        `${employee.employeeId},${employee.medicalId},${employee.dentalId},` +
        `${employee.amountBilled},${employee.adjustmentReason}\r\n`;
    });

    return csvContent;
  }
}
