export class AppConstants {
  public static USER_LOCAL_STORAGE_KEY = 'loginInfo';
  public static MENU_LOCAL_STORAGE_KEY = 'menuInfo';
  public static ACCOUNT_LOCAL_STORAGE_KEY = 'account';
  public static SUB_ACCOUNT_LOCAL_STORAGE_KEY = 'subAccount';
  public static SUB_ACCOUNT_LIST_LOCAL_STORAGE_KEY = 'subAccountList';
  public static PAYMENT_CONFIRMATION_LOCAL_STORAGE_KEY = 'paymentConfirmation';
  public static EMPLOYEE_ROSTER_ACCOUNT_LOCAL_STORAGE_KEY =
    'employeeRosterAccount';
  public static PAYMENT_CONFIRMATION_TITLE_SUCCESS =
    'Your payment was submitted successfully.';
  public static PAYMENT_CONFIRMATION_TITLE_ERROR =
    'There was an error processing your payment.';
  public static PAYMENT_CONFIRMATION_MESSAGE_SUCCESS =
    'Your account balance will be updated when your payment has been processed.';
  public static PAYMENT_CONFIRMATION_MESSAGE_ERROR =
    'Please try again later. If you still encounter problems, call 602-864-4115.';
  public static PAYMENT_CONFIRMATION_ICON_SUCCESS =
    './assets/icons/icon-circle-check.svg';
  public static PAYMENT_CONFIRMATION_ICON_ERROR =
    './assets/icons/warning-large.svg';
  public static CLAIMS_PAYMENT_CONFIRMATION_TITLE_SUCCESS =
    'Claims payment was submitted successfully.';
  public static TERMINATE_COVERAGE_DESCRIPTION =
    'Terminate all Blue Cross Blue Shield of Arizona coverage for this employee and dependents.';
  public static TERMINATE_COVERAGE_NOTE =
    'The adjustment amount will be automatically set to $0.00 upon selection.';
  public static MESSAGE_TOP_ACCOUNT_BILLING =
    'View account details and make adjustments to employee benefits.';
  public static MESSAGE_TOP_ACCOUNT_BILLING_SUBSCRIPTION =
    'View account details.';
  public static MESSAGE_SUB_SUB_ACCOUNT_BILLING_SUBSCRIPTION = `View account details, make adjustments to employee benefits and submit payments.
  <strong> Please note:</strong> If an account is up to date on the payments you’ll not to able to make another payment towards it.`;
  public static IGNORE_COLUMNS_EXPORT_LANDING_PAGE =
    'isSubSubAccountsDisplayed,';
  public static WELCOME_TITLE =
    'Welcome to your new and improved group website! We heard you!';
  public static GOT_IT = 'Got it';
  public static WS_COOKIE_KEY = 'ws-id';
  public static WS_AUX_LOCAL_STORAGE_KEY = 'ws-aux';
  public static OKTA_TOKEN_STORAGE = 'okta-token-storage';
  public static REVIEW_AUTOPAY_TITLE = 'Review Autopay';
  public static REVIEW_AUTOPAY_SUBMIT_TEXT = 'Enroll';
  public static PAYMENT_SECTION_LOCAL_STORAGE_KEY = 'paymentSection';
  public static PAYMENT_SUBSECTION_ACCOUNTS_LOCAL_STORAGE_KEY =
    'subsectionAccount';
  public static PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY = 'currentAccounts';
  public static PREVIOUS_PAYMENT_SECTION_LOCAL_STORAGE_KEY =
    'previousPaymentSection';
  public static CANCEL_ACCOUNT_NAME_LOCAL_STORAGE_KEY = 'saap';
  public static ENROLL_AUTOPAYMENT_SUCCESS =
    '<strong>You have successfully enrolled in Autopay.</strong> Your first automatic payment is scheduled for the next billing period.';
  public static ENROLL_AUTOPAYMENT_FAILED =
    'There was a problem Enrolling Autopayment';
  public static REVIEW_CLAIMS_INVOICE_TITLE = 'Review and Submit Claim Payment';
  public static REVIEW_CLAIMS_INVOICE_SUBMIT_TEXT = 'Submit Payment';
  public static BILLING_FAQ_TITLE = 'Bill Payment FAQs';
  public static REVIEW_SUBMIT_TEXT = 'Submit Payment';
  public static REVIEW_ACCOUNT_PAYMENT_TITLE = 'Review and Submit Payment';
  public static AUTOPAY_STATEMENT_DUE_DATE = 'Statement Due Date';
  public static AUTOPAY_TOTAL_BILLED_AMOUNT = 'Total Billed';
  public static AUTOPAY_DATA_KEY = 'payment';
  public static AUTOPAY_PAYMENT_DATE = 'Statement Date';
  public static AUTOPAY_CANCEL_ALERT_TITLE =
    'Cancel this recurring automatic payment?';
  public static AUTOPAY_CANCEL_BODY_ALERT =
    'You have chosen to cancel the recurring monthly payment for ${accountName}';
  public static AUTOPAY_CANCEL_MESSAGE =
    '<strong>You have succesfully canceled Autopay for ${saap}.</strong>';
  public static AUTOPAY_BUTTON_OK_TEXT = 'Cancel Autopay';
  public static AUTOPAY_BUTTON_CANCEL_TEXT = 'No';
  public static AUTOPAY_UNENROLLMENT_SUCCESS = 'Successful Unenrollment';
  public static AUTOPAY_ENROLL_SUCCESS = 'Successful Enrollment';
  public static BANK_ACCOUNT_ALERT_NAME = 'alert-1';
  public static BANK_ACCOUNT_ALERT_TEXT =
    '<strong>There was a problem adding the bank account.</strong><br/>Please confirm the routing and account numbers and try again. ';
  public static BANK_ACCOUNT_DELETE_ALERT_TITLE =
    'Delete this payment account?';
  public static BANK_ACCOUNT_SINGLE_DELETE_ALERT_TEXT =
    "You are about to delete the following ${bankAccountName} payment account. If you delete this bank account, you'll be unable to make online payments until you add a new bank account.";
  public static BANK_ACCOUNT_DELETE_ALERT_TEXT =
    'You are about to delete the following bank account: <strong>${bankAccountName}</strong>.';
  public static BANK_ACCOUNT_DELETE_BUTTON_OK_TEXT = 'Delete Account';
  public static BANK_ACCOUNT_DELETE_CANCEL_TEXT = 'No';
  public static HISTORICAL_STATEMENTS_TITLE = 'Historical Statements';
  public static HISTORICAL_STATEMENTS_INFO_MESSAGE =
    'Statements from the last 18 months are available.';
  public static COPYRIGHT_ORIGIN_YEAR = '2021';
  public static COPYRIGHT_SYMBOL = '© ';
  public static COPYRIGHT_DESCRIPTION =
    ' Blue Cross Blue Shield of Arizona. An independent licensee of the Blue Cross and Blue Shield Association.';
  public static HEADER_TITLE = 'Employer Portal';
  public static SUB_ACCOUNT_SUMMARY_LIST_LOCAL_STORAGE_KEY =
    'subAccountSummaryList';
  public static ADD_DAYS_MAX_PAYMENT_DATE_SMALL_ACCOUNT = 30;
  public static ADD_DAYS_MAX_PAYMENT_DATE_LARGE_ACCOUNT = 90;
  public static CANCEL_SCHEDULED_PAYMENT_ALERT_TITLE =
    'Cancel this scheduled payment?';
  public static CANCEL_SCHEDULED_PAYMENT_ALERT_TEXT =
    'You have chosen to cancel the ${paymentAmount} payment scheduled to be withdrawn from account ${bankAccountNickName} on ${TransactionDate}';
  public static CANCEL_SCHEDULED_PAYMENT_BUTTON_OK = 'Cancel Payment';
  public static CANCEL_SCHEDULED_PAYMENT_BUTTON_NO = 'No';
  public static CANCEL_SCHEDULED_PAYMENT_BUTTON_NOTIFICATION_SUCCESS =
    'Your scheduled payment has been canceled.';
  public static CANCEL_SCHEDULED_PAYMENT_BUTTON_NOTIFICATION_FAILED =
    'Your scheduled payment has not been canceled, please try again.';
  public static months: any[] = [
    { id: 0, name: 'January' },
    { id: 1, name: 'February' },
    { id: 2, name: 'March' },
    { id: 3, name: 'April' },
    { id: 4, name: 'May' },
    { id: 5, name: 'June' },
    { id: 6, name: 'July' },
    { id: 7, name: 'August' },
    { id: 8, name: 'September' },
    { id: 9, name: 'October' },
    { id: 10, name: 'November' },
    { id: 11, name: 'December' },
  ];
}
