﻿using BCBSAZ.Provider.Models.Data.Eligibility;
using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;
using Microsoft.EntityFrameworkCore;


namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IEligibilityContext : IDbContext
	{

		DbSet<InquiryRequest> InquiryRequests { get; set; }

		DbSet<InquiryResponse> InquiryResponses { get; set; }

		DbSet<Error> Errors { get; set; }

	}

	public class EligibilityContext : DbContext, IEligibilityContext
	{

		private const string eligibilitySchema = "eligibility";

		/// <summary>
		/// Creates a new instance of the Eligibility DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public EligibilityContext(DbContextOptions<EligibilityContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<InquiryRequest>().ToTable("Request", schema: eligibilitySchema);
			modelBuilder.Entity<InquiryResponse>().ToTable("Response", schema: eligibilitySchema);
			modelBuilder.Entity<Error>().ToTable("Error", schema: eligibilitySchema);
		}

		public DbSet<InquiryRequest> InquiryRequests { get; set; }


		public DbSet<InquiryResponse> InquiryResponses { get; set; }


		public DbSet<Error> Errors { get; set; }


	}
}
