﻿using System.Collections.Generic;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Enums;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public interface IName
	{
		string FirstName { get; set; }

		string LastName { get; set; }

		string MiddleInitial { get; set; }

		ICollection<NameType> Types { get; set; }
	}
}