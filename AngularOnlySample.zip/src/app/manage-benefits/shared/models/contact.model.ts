import { IPhone } from './phone.model';

export interface IContact {
  address: string;
  emailAddress: string;
  phoneNumbers: IPhone[];
}
