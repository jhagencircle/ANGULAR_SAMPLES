﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.Apo;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts
{
    public class ApoContext : DbContext
    {
        public DbSet<ConfigSetting> ConfigSettings { get; protected set; }

        /// <summary>
        /// Creates a new instance of the Email DbContext object.
        /// </summary>
        /// <param name="options"></param>
        public ApoContext(DbContextOptions<ApoContext> options) : base(options) { }



        /// <summary>
        /// Defines custom model binding and configurations for models relating to the Email database
        /// </summary>
        /// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ConfigSetting>().HasKey(cs => new { cs.Environment, cs.Name });
        }

        public static ApoContext CreateContextInstance(string connectionStr)
        {
            var builder = new DbContextOptionsBuilder<ApoContext>()
                .UseSqlServer(connectionStr, providerOptions => providerOptions.CommandTimeout(60))
                .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

            return new ApoContext(builder.Options);
        }
    }
}
