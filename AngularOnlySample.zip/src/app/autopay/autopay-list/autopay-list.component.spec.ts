import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DecimalPipe } from '@angular/common';

import { AutopayListComponent } from './autopay-list.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TooltipModule, TooltipOptions } from 'ng2-tooltip-directive';
import { TooltipDefaultOptions } from 'src/app/shared/providers/tooltipDefaultOptions';
import { ConfirmationDialogService } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.service';
import { AutopaymentService } from '../shared/autopayment.service';
import { AutopayMock } from 'src/app/shared/mocks/autopay.mock';
import { AccountService } from 'src/app/shared/services/account.service';
import { AccountMock } from 'src/app/shared/mocks/account.mock';
import { RouterTestingModule } from '@angular/router/testing';

describe('AutopayListComponent', () => {
  let component: AutopayListComponent;
  let fixture: ComponentFixture<AutopayListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        ReactiveFormsModule,
        FormsModule,
        NgbModule,
        TooltipModule.forRoot(TooltipDefaultOptions as TooltipOptions),
        RouterTestingModule,
      ],
      declarations: [AutopayListComponent, DecimalPipe],
      providers: [
        ConfirmationDialogService,
        { provide: AutopaymentService, useClass: AutopayMock },
        { provide: AccountService, useClass: AccountMock },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutopayListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should make a call to accountService.get()', () => {
    spyOn(component.accountService, 'get').and.callThrough();

    component.loadAutopayList();

    expect(component.accountService.get).toHaveBeenCalled();
  });

  it('should have "autopayList" populated ', () => {
    expect(component.autopayList.length).toBeGreaterThan(0);
    expect(component.autopayList).toEqual(AutopayMock.mockedAutoPayList);
  });

  it('should display autopay table', () => {
    component.hasAutopays = true;
    fixture.detectChanges();
    const element =
      fixture.debugElement.nativeElement.querySelector('#autopay-table');
    expect(element).toBeTruthy();
  });

  it('should check table header text fields', () => {
    expect(
      fixture.nativeElement.querySelector('#th_account').textContent
    ).toContain('Account');
    expect(
      fixture.nativeElement.querySelector('#th_bankAccount').textContent
    ).toContain('Bank Account');
    expect(
      fixture.nativeElement.querySelector('#th_paymentAmt').textContent
    ).toContain('Payment Amount');
    expect(
      fixture.nativeElement.querySelector('#th_paymentDate').textContent
    ).toContain('Payment Date');
    expect(
      fixture.nativeElement.querySelector('#th_paymentStatus').textContent
    ).toContain('Payment Status');
  });

  it('should check table row is populated with data', () => {
    let trs = fixture.nativeElement.querySelectorAll('tbody tr');
    let row1 = trs[0];
    expect(row1.cells[0].innerHTML).toBe('State of Arizona');
    expect(row1.cells[1].innerHTML).toBe('Wells Fargo');
    expect(row1.cells[2].innerHTML).toBe('Total Billed');
    expect(row1.cells[3].innerHTML).toBe('Statement Date');
    expect(row1.cells[4].innerHTML).toBe('Pending');
  });

  // it('should display information icon', () => {
  //   let autopay = AutopayMock.mockedAutoPayList[1];
  //   let var1 = component.isDeleteDisabled(autopay.accountId);
  //   fixture.detectChanges();

  //   let trs = fixture.nativeElement.querySelectorAll('tbody tr');
  //   let row2 = trs[1];

  //   expect(row2.cells[4].innerHTML).toBe('Processing');
  // });

  it('should hide autopay table', () => {
    component.hasAutopays = false;
    fixture.detectChanges();
    const element =
      fixture.debugElement.nativeElement.querySelector('#autopay-table');
    expect(element).toBeFalsy();
  });

  it('should display autopay form to set up an autopayment, when the account does not have autopayments', () => {
    component.hasAutopays = false;
    component.isAddFormVisible = true;
    fixture.detectChanges();
    const element =
      fixture.debugElement.nativeElement.querySelector('#add-autopay-form');
    expect(element).toBeTruthy();
  });

  it('should hide autopay form to set up an autopayment, when the account has autopayments', () => {
    component.hasAutopays = true;
    component.isAddFormVisible = false;
    fixture.detectChanges();
    const element =
      fixture.debugElement.nativeElement.querySelector('#add-autopay-form');
    expect(element).toBeFalsy();
  });

  it('should display Set Up Autopay button', () => {
    component.hasAutopays = true;
    component.isAddFormVisible = false;
    fixture.detectChanges();
    const element = fixture.debugElement.nativeElement.querySelector(
      '#btn-set-up-autopay'
    );
    expect(element).toBeTruthy();
  });

  it('should hide Set Up Autopay button', () => {
    component.hasAutopays = true;
    component.isAddFormVisible = true;
    fixture.detectChanges();
    const element = fixture.debugElement.nativeElement.querySelector(
      '#btn-set-up-autopay'
    );
    expect(element).toBeFalsy();
  });

  it('should display set up autopay form by clicking on the Set Up Autopay button', () => {
    component.hasAutopays = true;
    component.isAddFormVisible = false;
    fixture.detectChanges();
    let setUpButton = fixture.debugElement.nativeElement.querySelector(
      '#btn-set-up-autopay'
    );
    setUpButton.click();
    fixture.detectChanges();
    const addForm =
      fixture.debugElement.nativeElement.querySelector('#add-autopay-form');
    expect(addForm).toBeTruthy();
  });
});
