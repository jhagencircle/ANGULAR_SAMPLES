﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.Provider.Managers.ActiveDirectory
{
	public class GroupConfig
	{
		public Guid TeamPhoenix { get; set; }
		public IEnumerable<Guid> Medical { get; set; }
		public IEnumerable<Guid> Pharmacy { get; set; }
	}
}
