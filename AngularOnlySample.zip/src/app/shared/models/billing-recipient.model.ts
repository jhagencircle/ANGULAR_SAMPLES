export interface IBillingRecipient {
	billingRecipientAccountId: number;
	billingRecipientAccountName?: string;
	billingRecipientSubscriberHCCId?: string;
	billingRecipientSubscriberName?: string;
	billingRecipientSusbcriberAmountBilled: number;
}