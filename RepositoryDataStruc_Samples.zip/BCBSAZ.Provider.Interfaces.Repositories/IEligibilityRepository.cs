﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.Eligibility;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Xml271Processor;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IEligibilityRepository
	{
		Task<InquiryRequest> GetInquiryRequestAsync(long requestId);

		Task<InquiryInfo> GetInquiryAsync(long responseId);

		Task<PatientDetail> GetPatientDetailAsync(long responseId);

		Task<InsuranceInfo> GetInsuranceInfoAsync(long responseId);

		Task<EligibilitySummary> GetEligibilitySummaryAsync(long responseId);

		Task<IEnumerable<CoordinationOfBenefits>> GetCOBsAsync(long responseId);

		Task<Dictionary<string, Dictionary<string, IEnumerable<Cost>>>> GetDeductiblesAsync(long responseId);

		Task<Dictionary<string, ServiceTypeBenefitDictionary>> GetFullNetworkServiceTypeAsync(long responseId);

		Task SaveEligibilityInquiriesAsync(params InquiryRequest[] inquiryRequests);

		Task DeleteEligibilityInquiriesAsync(IEnumerable<long> requestIds);

		Task<InquiryResult> GetEligibilityInquiryAsync(long responseId);

		Task<BooksRiders[]> GetBooksAndRidersAsync(long responseId);

		Task<Dictionary<string, IEnumerable<GeneralInformation>>> GetGeneralInformationAsync(long responseId);

		Task<IEnumerable<EligibilityRequest>> GetEligibilityRequestsAsync(string orgId, int days, Models.Data.Common.ServiceType[] serviceTypes);

		Task<string> GetDisclaimerAsync(long responseId);



		void PopulateResponseInfo(InquiryResponse response);

		bool CanViewIDCard(string subscriberId, DateTime dateOfService, string firstname, string lastName, DateTime? dateOfBirth);

		BooksRiders[] GetBooksAndRiders(InquiryResult inquiryresult);

		Miscellaneous GenerateMiscellaneous(InquiryRequest request, InquiryResponse response, Models.Data.Common.ServiceType[] serviceTypes);

		GroupNumberInfo IsValidGroupNumber(string GroupNum);

		DiagnosisCodes[] GetDiagnosisCodes(string query, int pageSize, int pageNumber, out int totalCount);

		IEnumerable<ValueEnteredReturned> GetValueEnteredReturned(InquiryResult inquiryResult, ValuesEntered valuesEntered);

		Task<IEnumerable<Patient>> GetOrCreatePatientsAsync(params Patient[] patients);
		Task SaveChangesAsync();

		Task<string[]> GetEligibilityResultsAsync(long[] requestId);
	}
}
