export interface IStatement {
  billingPeriodFromDate: Date;
  billingPeriodToDate: Date;
  statementDate: Date;
  dueDate: Date;
  isLegacy: boolean;
  billingStatementId: string;
  accountName: string;
  accountNickName: string;
  status: string;
  paymentAmount: number;
  accountId?: string;
  isLoading?: boolean;
}
