﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.PreCert;
using BCBSAZ.Provider.Models.Requests.PreCert;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.PreCert
{
	internal static class SaveMedicalPreCertRequestValidator
	{
		public static void Validate(this SaveMedicalPreCertRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(SaveMedicalPreCertRequest request)
		{
			if (request.Status == PreCertStatus.Pending)
			{
				if (string.IsNullOrWhiteSpace(request.Form.MemberFirstName))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.MemberFirstName), new ArgumentException("Member's first name is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.MemberLastName))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.MemberLastName), new ArgumentException("Member's last name is Required."));

				if (request.Form.MemberDateOfBirth == new DateTime())
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.MemberDateOfBirth), new ArgumentException("Member's date of birth is Required."));

				if (request.Form.MemberDateOfBirth < DateTime.Now.AddYears(-SettingsManager.MaxAge) || request.Form.MemberDateOfBirth > DateTime.Now)
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.MemberDateOfBirth), new ArgumentException("Member's date of birth can only be between today and 120 years ago."));

				if (string.IsNullOrWhiteSpace(request.Form.MemberID))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.MemberID), new ArgumentException("Member Id is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.MemberPhone))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.MemberPhone), new ArgumentException("Member's phone number is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.RefProviderFirstName))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.RefProviderFirstName), new ArgumentException("Referring provider's first name is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.RefProviderLastName))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.RefProviderLastName), new ArgumentException("Referring provider's last name is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.RefProviderPhone))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.RefProviderPhone), new ArgumentException("Referring provider's phone is Required."));

				if (!request.DiagnosisCodes.Any())
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.DiagnosisCodes), new ArgumentException("Having at least one diagnosis code is Required."));

				if (!request.CPTCodes.Any())
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.CPTCodes), new ArgumentException("Referring provider's phone is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.ProviderFirstName))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderFirstName), new ArgumentException("Provider's first name is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.ProviderLastName))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderLastName), new ArgumentException("Provider's last name is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.ProviderOfficePhone))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderOfficePhone), new ArgumentException("Provider's phone is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.ProviderCity))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderCity), new ArgumentException("Provider's city is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.ProviderState))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderState), new ArgumentException("Provider's state is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.ProviderZipCode))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderZipCode), new ArgumentException("Provider's zip code is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.ProviderSpeciality))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderSpeciality), new ArgumentException("Provider's specialty is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.ProviderTin))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderTin), new ArgumentException("Provider's TIN is Required."));

				if (string.IsNullOrWhiteSpace(request.Form.ProviderNPI))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderNPI), new ArgumentException("Provider's NPI is Required."));

				if (request.Form.HasPlaceOfService)
				{
					if (string.IsNullOrWhiteSpace(request.Form.ProviderFacility))
						yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.ProviderFacility), new ArgumentException("Provider's facility name is Required."));

					if (string.IsNullOrWhiteSpace(request.Form.FacilityAddress))
						yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.FacilityAddress), new ArgumentException("Provider's facility address is Required."));

					if (string.IsNullOrWhiteSpace(request.Form.FacilityCity))
						yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.FacilityCity), new ArgumentException("Provider's facility city is Required."));

					if (string.IsNullOrWhiteSpace(request.Form.FacilityState))
						yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.FacilityState), new ArgumentException("Provider's facility state is Required."));

					if (string.IsNullOrWhiteSpace(request.Form.FacilityZipCode))
						yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.FacilityZipCode), new ArgumentException("Provider's facility zip code is Required."));

					if (string.IsNullOrWhiteSpace(request.Form.FacilityTin))
						yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.FacilityTin), new ArgumentException("Provider's facility TIN is Required."));

					if (string.IsNullOrWhiteSpace(request.Form.FacilityNPI))
						yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.FacilityNPI), new ArgumentException("Provider's facility NPI is Required."));
				}

				if (string.IsNullOrWhiteSpace(request.Form.Signature))
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.Signature), new ArgumentException("Signature is Required."));

				if (!request.Form.SignatureDate.HasValue)
					yield return new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Form.SignatureDate), new ArgumentException("Signature Date is Required."));
			}
		}
	}
}
