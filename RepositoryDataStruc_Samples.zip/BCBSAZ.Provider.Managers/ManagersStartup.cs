﻿using System;
using System.Collections.Generic;
using System.Text;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Processors;
using BCBSAZ.Provider.Managers.ApiClients;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Managers
{
	public static class ManagersStartup
	{
		public static void AddManagers(this IServiceCollection services, IConfiguration configuration)
		{
			services.AddSingleton<ILogMessageStorage, SystemLogsManager>();
			services.AddSingleton<IPurgeManager, PurgeManager>();
			services.AddSingleton<IClaimsApiClient, ClaimsApiClient>();
			services.AddSingleton<IIdCardApiClient, IdCardApiClient>();
			services.AddSingleton<IEligibilityApiClient, EligibilityApiClient>();
			services.AddSingleton<IOktaApiClient, OktaApiClient>();
			services.AddSingleton<IPlanProfileApiClient, PlanProfileApiClient>();
			services.AddSingleton<IOnlineRemitsApiClient, OnlineRemitsApiClient>();
			services.AddSingleton<IVelocityApiClient, VelocityApiClient>();

			services.AddScoped<IRemitsManager, RemitsManager>();
			services.AddScoped<IClaimsManager, ClaimsManager>();
			services.AddScoped<ICommonManager, CommonManager>();
			services.AddScoped<ISettingsManager, SettingsManager>();
			services.AddScoped<IEligibilityManager, EligibilityManager>();
			services.AddScoped<IFeeScheduleManager, FeeScheduleManager>();
			services.AddScoped<IFeatureToggleManager, FeatureToggleManager>();
			services.AddScoped<IPreCertManager, PreCertManager>();
			services.AddScoped<IProviderManager, ProviderManager>();
			services.AddScoped<ISecurityManager, SecurityManager>();
			services.AddScoped<ISubscriberManager, SubscriberManager>();
			services.AddScoped<ISystemLogsManager, SystemLogsManager>();
			services.AddScoped<ITPARegistrationManager, TPARegistrationManager>();
			services.AddScoped<ITPAFeeScheduleManager, TPAFeeScheduleManager>();
			services.AddScoped<IOfficeUserManagementManager, OfficeUserManagementManager>();
			services.AddScoped<IPlanProfileManager, PlanProfileManager>();
			services.AddScoped<IPatientManager, PatientManager>();

		}
	}
}
