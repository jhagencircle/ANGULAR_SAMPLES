import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EmployeeMock } from '../../shared/mocks/employee.mock';
import { EmployeeInformationComponent } from './employee-information.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('EmployeeInformationComponent', () => {
  let component: EmployeeInformationComponent;
  let fixture: ComponentFixture<EmployeeInformationComponent>;
  let mockEmployeeService: EmployeeMock = new EmployeeMock();
  let compiledDeb: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployeeInformationComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeInformationComponent);
    component = fixture.componentInstance;

    mockEmployeeService.get().subscribe((data) => {
      component.employeeInformation = data;
    });

    fixture.detectChanges();
    compiledDeb = fixture.debugElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show employee name', () => {
    const element = compiledDeb.query(By.css('#txtName')).nativeElement;
    expect(element.value).toEqual(
      `${component.employeeInformation.firstName} ${component.employeeInformation.lastName}`
    );
  });

  it('should show employeeId', () => {
    const element = compiledDeb.query(By.css('#txtEmployeeId')).nativeElement;
    expect(element.value).toEqual(component.employeeInformation?.employeeId);
  });

  it('should show date of birth', () => {
    const dateOfBird = new Date(component.employeeInformation?.dateOfBirth);
    const day =
      dateOfBird.getMonth() < 9
        ? `0${dateOfBird.getMonth() + 1}`
        : dateOfBird.getMonth() + 1;
    const element = compiledDeb.query(By.css('#txtBirthDate')).nativeElement;
    expect(element.value).toEqual(
      `${day}/${dateOfBird.getDate()}/${dateOfBird.getFullYear()}`
    );
  });

  it('should show SSN', () => {
    const element = compiledDeb.query(By.css('#txtSSN')).nativeElement;
    expect(element.value).toEqual(component.employeeInformation?.ssn);
  });

  it('should show marital status', () => {
    const element = compiledDeb.query(
      By.css('#txtMaritalStatus')
    ).nativeElement;
    expect(element.value).toEqual(component.employeeInformation?.maritalStatus);
  });

  it('should show gender', () => {
    const element = compiledDeb.query(By.css('#txtGender')).nativeElement;
    expect(element.value).toEqual(component.employeeInformation?.gender);
  });
});
