﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.Configuration;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.ApiClients;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.ApiClient;
using FluentAssertions;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace BCBSAZ.ProviderAuxiliaryPortal.UnitTests.Repositories.ApiClients
{
    public class EmailClientTest
    {
        private readonly IEmailClient _emailClient;

        public EmailClientTest()
        {
            var emialConfiguration = new EmailConfiguration() { SmtpHost = "TestSmtp.com", SmtpPort = 111, UseCredential = false };
            _emailClient = new EmailClient(emialConfiguration);
        }

        [Theory(Skip = "Fix them later")]
        [InlineData("test@test.com", "test@test.com", "subject", "body")]
        [InlineData("test@test.com", "test@test.com", "subject", "")]
        [InlineData("test@test.com", "test@test.com", "", "body")]
        public async void SendlEmail_Success(string toAddress, string fromAddress, string subject, string body)
        {
            //Arrange
#if !DEBUG
            _emailClient.SendEmailAsync(toAddress, fromAddress, subject, body).Returns(Task.CompletedTask);
#endif
            // Act
            var result = await _emailClient.SendEmailAsync(toAddress, fromAddress, subject, body, null);

            // Assert
            result.Should().Be(true);
        }
    }
}
