﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;

namespace Microsoft.Extensions.Hosting
{
	public static class HostEnvironmentExtensions
	{
		/// <summary>
		/// Provides an alternative way of determining if a hosting environment is considered "Development", the alternative environments specified will be considered as "Development"
		/// </summary>
		/// <param name="hostingEnvironment">The Asp.NetCore Hosting Environment</param>
		/// <param name="alternateEnvironments">A list of environment names which will also be considered "Development"</param>
		/// <returns>Returns true if the Hosting Environment Name is Development or is found in the list of alternative environments.</returns>
		public static bool IsDevelopment(this IHostEnvironment hostingEnvironment, params string[] alternateEnvironments)
		{
			if (hostingEnvironment == null) throw new ArgumentNullException(nameof(hostingEnvironment));

			// Shortcut if environment is already "Development"
			if (hostingEnvironment.IsDevelopment()) return true;

			// Shortcut if no alternate environments provided
			if (alternateEnvironments.IsNullOrEmpty()) return false;

			return alternateEnvironments.Contains(hostingEnvironment.EnvironmentName, StringComparer.OrdinalIgnoreCase);
		}

		/// <summary>
		/// Provides an alternative way of determining if a hosting environment is considered "Development", the alternative environments specified in the configuration item "DevelopmentEnvironments" will be considered as "Development"
		/// </summary>
		/// <param name="hostingEnvironment">The Asp.NetCore Hosting Environment</param>
		/// <param name="configuration">The configuration (or configuration section) containing the "DevelopmentEnvironments" configuration item.</param>
		/// <returns>Returns true if the Hosting Environment Name is Development or is found in the configured list of alternative environments.</returns>
		/// <remarks>The configuration item "DevelopmentEnvironments" should be a semicolon delimited string of Environment Names.</remarks>
		public static bool IsDevelopment(this IHostEnvironment hostingEnvironment, IConfiguration configuration)
		{
			var alternativeEnvironments = configuration.GetValue<string>("DevelopmentEnvironments");

			// No hosting environment specified, just return the default IsDevelopment method.
			if (string.IsNullOrWhiteSpace(alternativeEnvironments)) return hostingEnvironment.IsDevelopment();

			// Split the string and use the above extension method.
			return hostingEnvironment.IsDevelopment(alternativeEnvironments.Split(';', StringSplitOptions.RemoveEmptyEntries));
		}
	}
}
