﻿using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Interfaces.WCFClients;
using BCBSAZ.Provider.Managers.RequestValidators.Subscriber;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Data.Subscriber;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;
using BCBSAZ.Provider.Models.Requests.Subscriber;
using BCBSAZ.Provider.Models.Responses.Eligibility.Details;
using BCBSAZ.Provider.Models.Responses.Subscriber;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Managers
{
	public class SubscriberManager : ISubscriberManager
	{
		private readonly ISubscriberRepository _subscriberRepository;
		private readonly IProviderRepository _providerRepository;
		private readonly ICommonRepository _commonRepository;
		private readonly IWCFClientFactory _wcfClientFactory;
		private readonly IIdCardApiClient _idCardApiClient;
		private readonly IVelocityApiClient _velocityApiClient;
		private readonly IPlanProfileManager _planProfileManager;
		private readonly ILogger<SubscriberManager> _logger;

		public SubscriberManager(ISubscriberRepository subscriberRepository, IProviderRepository providerRepository, ICommonRepository commonRepository, IWCFClientFactory wcfClientFactory, IIdCardApiClient idCardApiClient, ILogger<SubscriberManager> logger, IPlanProfileManager planProfileManager, IVelocityApiClient velocityApiClient)
		{
			_subscriberRepository = subscriberRepository ?? throw new ArgumentNullException(nameof(subscriberRepository));
			_providerRepository = providerRepository ?? throw new ArgumentNullException(nameof(providerRepository));
			_commonRepository = commonRepository ?? throw new ArgumentNullException(nameof(commonRepository));
			_wcfClientFactory = wcfClientFactory;
			_idCardApiClient = idCardApiClient;
			_velocityApiClient = velocityApiClient;
			_planProfileManager = planProfileManager;
			_logger = logger;	
		}

		public async Task<IsMemberDelegatedResponse> IsMemberDelegatedAsync(IsMemberDelegatedRequest request)
		{
			request.Validate();

			if (string.IsNullOrWhiteSpace(request.SubscriberId) || (request.SubscriberId.Length < 3))
			{
				return new IsMemberDelegatedResponse()
				{
					IsMemberDelegated = false
				};
			}
			else
			{
				return new IsMemberDelegatedResponse()
				{
					IsMemberDelegated = await _subscriberRepository.IsMemberDelegatedAsync(request.SubscriberId)
				};
			}
		}

		#region IsMemberLocalAsync
		public async Task<IsMemberLocalResponse> IsMemberLocalAsync(IsMemberLocalRequest request)
		{
			request.Validate();

			var prefix = await GetAreaPrefixAsync(request.SubscriberId);
			if ((prefix == LOB.LCL) && IsValidSubscriberId(prefix, request.SubscriberId))
			{
				return new IsMemberLocalResponse()
				{
					IsMemberLocal = await _providerRepository.DoesMemberExistAsync(request.SubscriberId.Substring(3), request.DateOfBirth)
				};
			}
			else
			{
				return new IsMemberLocalResponse()
				{
					IsMemberLocal = false
				};
			}
		}

		private static readonly Regex _valSubLocal1 = new Regex("^[a-z0-9]+$", RegexOptions.Compiled | RegexOptions.IgnoreCase);
		private static readonly Regex _valSubLocal2 = new Regex("^99[a-z]{1}[a-z0-9]{9}$", RegexOptions.Compiled | RegexOptions.IgnoreCase);
		private static readonly Regex _valSubFEP = new Regex("^R[0-9]{8}$", RegexOptions.Compiled | RegexOptions.IgnoreCase);
		private static readonly Regex _valSubOOA = new Regex("^[a-z0-9]{4,17}$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

		private bool IsValidSubscriberId(LOB areaPrefix, string subscriberId)
		{
			switch (areaPrefix)
			{
				case LOB.LCL:
					return (_valSubLocal1.IsMatch(subscriberId) || _valSubLocal2.IsMatch(subscriberId));
				case LOB.FEP:
					return _valSubFEP.IsMatch(subscriberId);
				case LOB.OOA:
					return _valSubOOA.IsMatch(subscriberId);
				default:
					return true;
			}
		}

		private async Task<LOB> GetAreaPrefixAsync(string subscriberId)
		{
			if (string.IsNullOrWhiteSpace(subscriberId) || (subscriberId.Length < 3))
				return LOB.INVALID;

			var subPrefix = subscriberId.Substring(0, 3);

			var prefixes = GetAlphaPrefixes(LOB.LCL);
			if (prefixes.Contains(subPrefix, StringComparer.OrdinalIgnoreCase))
				return LOB.LCL;

			prefixes = GetAlphaPrefixes(LOB.MEDICARE);
			if (prefixes.Contains(subPrefix, StringComparer.OrdinalIgnoreCase))
				return LOB.MEDICARE;

			return await GetOtherPrefix(subPrefix);
		}

		private static readonly ConcurrentDictionary<LOB, string[]> _alphaPrefixes = new ConcurrentDictionary<LOB, string[]>();
		private string[] GetAlphaPrefixes(LOB areaPrefix)
		{
			if (!_alphaPrefixes.ContainsKey(areaPrefix))
			{
				_alphaPrefixes.TryAdd(areaPrefix, _commonRepository.GetAlphaPrefixes(areaPrefix));
			}
			return _alphaPrefixes[areaPrefix];
		}

		private static readonly ConcurrentDictionary<string, LOB> _otherPrefixes = new ConcurrentDictionary<string, LOB>();
		private async Task<LOB> GetOtherPrefix(string subPrefix)
		{
			subPrefix = subPrefix.ToLowerInvariant();
			if (!_otherPrefixes.ContainsKey(subPrefix))
			{
				if (Char.IsLetterOrDigit(subPrefix[0]) && Char.IsLetterOrDigit(subPrefix[1]) && Char.IsLetterOrDigit(subPrefix[2]))
				{
					if ((subPrefix[0] == 'r') && Char.IsDigit(subPrefix[1]) && Char.IsDigit(subPrefix[2]))
					{
						_otherPrefixes.TryAdd(subPrefix, LOB.FEP);
					}
					else if (Char.IsDigit(subPrefix[0]) && Char.IsDigit(subPrefix[1]) && Char.IsDigit(subPrefix[2]))
					{
						_otherPrefixes.TryAdd(subPrefix, LOB.CHS);
					}
					else if (await _subscriberRepository.IsPrefixOOAAsync(subPrefix))
					{
						_otherPrefixes.TryAdd(subPrefix, LOB.OOA);
					}
					else
					{
						_otherPrefixes.TryAdd(subPrefix, LOB.CHS);
					}
				}
				else
				{
					_otherPrefixes.TryAdd(subPrefix, LOB.INVALID);
				}
			}
			return _otherPrefixes[subPrefix];
		}
		#endregion

		public async Task<IdCardResponse> GetIdCardAsync(IdCardRequest request)
		{
			request.Validate();

			if (request.SubscriberId.Length == 12)
				request.SubscriberId = request.SubscriberId.Substring(3, 9);

			var documentClient = _wcfClientFactory.GetDocumentClient();

			return new IdCardResponse()
			{
				IdCards = await documentClient.GetSubscriberIdCardImages(request.SubscriberId)
			};
		}

		public async Task<VelocityIdCardResponse> GetVelocityIdCardAsync(VelocityIdCardRequest request)
		{
			request.Validate();
			var isInHrp = await _velocityApiClient.IsMemberInHrpAsync(request.SubscriberId);
			if (!isInHrp)
				return null;

			var rawIdCard = await _idCardApiClient.GetIdCardAsync(request);
			var idCards = new VelocityIdCardResponse() {
				SubscriberId = rawIdCard.SubscriberId,
				IssueDate = rawIdCard.IssueDate,
				CardLinks = new List<IdCard>()
			};

			if (rawIdCard.IdCardFound)
			{
				var tasks = new List<Task>();

				foreach (var rawCard in rawIdCard.CardLinks)
				{
					tasks.Add(GetIdCardImagesAsync(rawCard));
				}

				await Task.WhenAll(tasks);

				foreach (Task<IdCard> task in tasks)
				{
					if (task.Result != null)
						idCards.CardLinks.Add(task.Result);
				}
			}

			return idCards;
		} 			

		private async Task<IdCard> GetIdCardImagesAsync(IdCardLink CardLink)
		{
			try
			{
				var frontImageTask = _idCardApiClient.GetImageDataAsync(CardLink.Front);
				var backImageTask = _idCardApiClient.GetImageDataAsync(CardLink.Back);
				await Task.WhenAll(frontImageTask, backImageTask);
				//Only return the IdCard when both front and back images retrieve successfully
				return new IdCard()
				{
					FrontImageData = frontImageTask.Result,
					BackImageData = backImageTask.Result
				};
		
			}
			catch(Exception ex)
			{
				_logger.LogWarning(ex, "Failed to retrieve ID card image.");
				return null;
			}
		}

		public Task<string> CheckPrefixAsync(string prefix)
		{
			var idNumberClient = _wcfClientFactory.GetIDNumberClient();
			return idNumberClient.CheckPrefix(prefix);
		}

		#region ValidatePatient
		public async Task<ValidatePatientResponse> ValidatePatientAsync(ValidatePatientRequest request)
		{
			try
			{
				request.Validate();
			}
			catch (InvalidRequestException ex)
			{
				_logger.LogWarning(ex, "Invalid ValidatePatient request.");

				return new ValidatePatientResponse()
				{
					Status = PatientValidationStatus.InvalidRequest
				};
			}

			var lob = await GetAreaPrefixAsync(request.SubscriberId);
			var prefix = request.SubscriberId?.Substring(0, 3);

			if ((!string.IsNullOrWhiteSpace(request.SubscriberId)) && (lob == LOB.LCL))
			{
				if (request.SubscriberId.Length == 12)
					request.SubscriberId = request.SubscriberId.Substring(3, 9);
			}

			var results = (_subscriberRepository.GetPatients(request.SubscriberId, request.FirstName, request.LastName, request.SSN, request.DateOfBirth)) ?? new Patient[0];
			
			if (results.Any())
			{
				prefix = results.FirstOrDefault().Prefix;
				lob = await GetAreaPrefixAsync(prefix + results.FirstOrDefault().SubscriberId);
			}

			var cutoffDate = _providerRepository.GetMemberCutoffDate(prefix);
			
			return new ValidatePatientResponse()
			{
				LOB = lob,
				AreAdditionalFieldsRequired = lob == LOB.FEP || lob == LOB.OOA,
				Status = GetValidationStatus(results.ToArray()),
				Results = results,
				IsItsMa = (await _planProfileManager.GetItsMaAllPrefixes()).Contains(prefix, StringComparer.OrdinalIgnoreCase),
				CutoffDate = (cutoffDate != DateTime.MinValue) ? cutoffDate.ToString("yyyy-MM-dd") : "N/A"
			};
		}

		private static PatientValidationStatus GetValidationStatus(Patient[] results)
		{
			switch (results.Length)
			{
				case 0:
					return PatientValidationStatus.PatientNotFound;
				case 1:
					return PatientValidationStatus.Success;
				default:
					return PatientValidationStatus.MultipleMatches;
			}
		}
		#endregion

	}
}
