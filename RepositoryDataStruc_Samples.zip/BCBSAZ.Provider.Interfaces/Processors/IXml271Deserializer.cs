﻿using BCBSAZ.Provider.Models.Xml271Processor;

namespace BCBSAZ.Provider.Interfaces.Processors
{
	public interface IXml271Deserializer
	{
		InquiryResult DeserializeXml(string xmlData);
	}
}
