﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class Facility
	{
		[Required(ErrorMessage = "Facility Name is required")]
		[MaxLength(50)]
		[DisplayName("Facility Name")]
		[RegularExpression("^[A-Za-z-A-Za-zA-Za-z A-Za-z0-9 0-9]*[A-Za-z0-9]+$", ErrorMessage = "Please enter a valid Facility Name")]
		public string Name { get; set; }

		[Required]
		public FacilityType Type { get; set; }
	}
}