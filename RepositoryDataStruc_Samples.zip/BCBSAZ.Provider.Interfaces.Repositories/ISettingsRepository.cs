﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Settings;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface ISettingsRepository
	{

		#region Setting Values

		Task<SettingValue> GetSettingValueAsync(string applicationName, string settingName, string fieldName, string fieldValue, string userId, string defaultValue);

		#endregion

		#region Settings

		Task<IEnumerable<Setting>> GetSettingsForApplicationAsync(string applicationName, int settingTypeId);

		Task<Setting> GetSettingAsync(int settingId);

		Task<Setting> AddSettingAsync(Setting setting);

		Task<Setting> UpateSettingAsync(Setting setting);

		Task DeleteSettingAsync(int settingId);

		#endregion

		#region User Type Settings

		Task<IEnumerable<UserTypeSetting>> GetAllUserTypeSettingsAsync(int settingId);

		Task<UserTypeSetting> GetUserTypeSettingAsync(int userTypeSettingId);

		Task<UserTypeSetting> AddUserTypeSettingAsync(UserTypeSetting userTypeSetting);

		Task<UserTypeSetting> UpdateUserTypeSettingsAsync(UserTypeSetting userTypeSetting);

		Task DeleteUserTypeSettingAsync(int userTypeSettingId);

		#endregion

		#region User Settings

		Task<IEnumerable<UserSetting>> GetAllUserSettingsAsync(int settingId);

		Task<UserSetting> GetUserSettingAsync(int userSettingId);

		Task<UserSetting> AddUserSettingAsync(UserSetting userSetting);

		Task<UserSetting> UpdateUserSettingsAsync(UserSetting userSetting);

		Task DeleteUserSettingAsync(int userSettingId);

		#endregion

		#region Setting Types

		Task<IEnumerable<SettingType>> GetSettingTypesAsync();

		#endregion

		#region Setting Applications

		Task<IEnumerable<SettingApplication>> GetSettingApplicationsAsync();

		Task<SettingApplication> UpdateSettingApplicationAsync(SettingApplication application);

		#endregion

	}
}
