import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy,
} from '@angular/core';
import {
  FormGroup,
  Validators,
  AbstractControl,
  FormBuilder,
} from '@angular/forms';
import { IDependent } from '../shared/models/dependent.model';
import { IBenefit } from '../shared/models/benefit.model';
import { IPlan } from '../shared/models/plan.model';
import { RelationshipService } from '../shared/relationship.service';
import { IRelationship } from '../shared/models/relationship.model';
import { ITerminationReason } from '../shared/models/termination-reason.model';
import { TerminationReasonService } from '../shared/termination-reason.service';
import { MedicareTypeEnum } from '../shared/medicare-type.enum';
import { Subscription } from 'rxjs';
import { IRelationshipCoverage } from '../shared/models/relationship-coverage.model';
import { CoverageService } from '../shared/coverage.service';
import { ICoverage } from '../shared/models/coverage.model';

@Component({
  selector: 'app-employee-dependent-edit',
  templateUrl: './employee-dependent-edit.component.html',
  styleUrls: ['./employee-dependent-edit.component.scss'],
})
export class EmployeeDependentEditComponent implements OnInit, OnDestroy {
  @Output() onSuccessfulEdit: EventEmitter<any> = new EventEmitter();
  @Input() dependentInformation: IDependent;
  @Input() benefitSelection: IBenefit; //employee benefit selection

  form: FormGroup;
  activeSave: boolean = false;
  benefit: IBenefit;
  healthPlan: IPlan | undefined;
  dentalPlan: IPlan | undefined;
  healthInsurancePlanOptions: any[] = [];
  dentalPlanOptions: any[] = [];
  medicareTypes = MedicareTypeEnum;
  relationshipCoverage: IRelationshipCoverage[] = [];
  coverages: ICoverage[];
  terminateCoverageOption: any = {
    id: 'T',
    name: 'Terminate Coverage',
    type: 'T',
  };
  relationshipList: IRelationship[];
  terminationReasonList: ITerminationReason[];
  subscriptions: Subscription[] = [];

  get f() {
    return this.form.controls;
  }

  constructor(
    public fb: FormBuilder,
    private relationshipService: RelationshipService,
    private terminationReasonService: TerminationReasonService,
    private coverageService: CoverageService
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.getFormListsData();
    this.setFormValues();
    this.onChanges();
    this.loadCoverage();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  loadCoverage() {
    this.benefitSelection.planSelection.map((item) => {
      this.getCoverage(item.coverageID!);
    });
  }

  getCoverage(coverageId: string) {
    this.relationshipService.getByCoverage(coverageId).subscribe((data) => {
      this.relationshipCoverage.push({
        coverageID: coverageId,
        coverage: data,
      });
    });
  }

  onChanges(): void {
    this.form.valueChanges.subscribe((val) => {
      this.activeSave = true;
    });
  }

  createForm() {
    this.form = this.fb.group({
      lastName: ['', [Validators.required]],
      firstName: ['', [Validators.required]],
      ssn: [''],
      relationship: ['', [Validators.required]],
      dateOfBirth: ['', [Validators.required]],
      gender: [''],
      elegibleForMedicare: ['', [Validators.required]],
      medicareNumber: [''],
      partAEffectiveDate: [''],
      partBEffectiveDate: [''],
      effectiveDate: [''],
      healthInsurancePlan: [''],
      dentalInsurancePlan: [''],
      reasonForRemoval: [''],
      medicareType: [''],
    });
  }

  save() {
    this.addFieldValidations();
    if (this.form.valid) {
      this.setDependentValues();
      this.onSuccessfulEdit.emit({
        dependentInformation: this.dependentInformation,
      });
      this.activeSave = false;
    }
  }

  setDependentValues() {
    let effectiveDatePartA = this.f.partAEffectiveDate.value;
    let effectiveDatePartB = this.f.partBEffectiveDate.value;
    let dependentBenefitSelection: IPlan[] = [];

    let healthPlan = this.healthInsurancePlanOptions
      ? this.healthInsurancePlanOptions.find(
          (p) => p.id == this.f.healthInsurancePlan.value
        )!
      : null;
    let dentalPlan = this.dentalPlanOptions
      ? this.dentalPlanOptions.find(
          (p) => p.id == this.f.dentalInsurancePlan.value
        )!
      : null;
    if (
      (this.f.healthInsurancePlan && this.f.healthInsurancePlan.value == 'T') ||
      (this.f.detalInsurancePlan && this.f.detalInsurancePlan.value == 'T')
    ) {
      this.dependentInformation.isRemoved = true;
    } else {
      if (healthPlan) {
        dependentBenefitSelection.push(healthPlan);
      }
      if (dentalPlan) {
        dependentBenefitSelection.push(dentalPlan);
      }
    }

    this.dependentInformation.lastName = this.f.lastName.value;
    this.dependentInformation.firstName = this.f.firstName.value;
    this.dependentInformation.ssn = this.f.ssn.value;
    this.dependentInformation.dependentType = this.f.relationship.value;
    this.dependentInformation.dateOfBirth = this.f.dateOfBirth.value;
    this.dependentInformation.gender = this.f.gender.value;
    this.dependentInformation.benefitSelection.eligibleForMedicare =
      this.f.elegibleForMedicare.value;
    this.dependentInformation.benefitSelection.medicareNumber =
      this.f.elegibleForMedicare.value == 'false'
        ? ''
        : this.f.medicareNumber.value;
    this.dependentInformation.benefitSelection.partAEffectiveDate =
      this.f.elegibleForMedicare.value == 'false' ? '' : effectiveDatePartA;
    this.dependentInformation.benefitSelection.partBEffectiveDate =
      this.f.elegibleForMedicare.value == 'false' ? '' : effectiveDatePartB;
    this.dependentInformation.benefitSelection.planSelection =
      dependentBenefitSelection;
    this.dependentInformation.effectiveDate =
      this.f.effectiveDate?.value.toString();
    this.dependentInformation.removalReason = this.f.reasonForRemoval.value;
    this.dependentInformation.isEdit = false;
  }

  cancel() {
    this.dependentInformation.isEdit = false;
    this.form.reset();
  }

  setFormValues() {
    let medicareType;
    if (
      this.dependentInformation.benefitSelection?.partAEffectiveDate &&
      this.dependentInformation.benefitSelection?.partBEffectiveDate
    ) {
      medicareType = 'Both';
    } else if (this.dependentInformation.benefitSelection?.partAEffectiveDate) {
      medicareType = 'PartA';
    } else if (this.dependentInformation.benefitSelection?.partBEffectiveDate) {
      medicareType = 'PartB';
    }
    let dateOfBirth = new Date(this.dependentInformation.dateOfBirth);

    this.form.setValue({
      lastName: this.dependentInformation.lastName
        ? this.dependentInformation.lastName
        : '',

      firstName: this.dependentInformation.firstName
        ? this.dependentInformation.firstName
        : '',

      ssn: this.dependentInformation.ssn ? this.dependentInformation.ssn : '',
      relationship: this.dependentInformation.dependentType
        ? this.dependentInformation.dependentType
        : '',
      dateOfBirth: dateOfBirth,
      gender: this.dependentInformation.gender
        ? this.dependentInformation.gender
        : '',
      elegibleForMedicare: this.dependentInformation.benefitSelection
        ?.eligibleForMedicare
        ? this.dependentInformation.benefitSelection?.eligibleForMedicare.toString()
        : 'false',
      medicareNumber: this.dependentInformation.benefitSelection?.medicareNumber
        ? this.dependentInformation.benefitSelection?.medicareNumber
        : '',

      partAEffectiveDate: this.dependentInformation.benefitSelection
        ?.partAEffectiveDate
        ? new Date(
            this.dependentInformation.benefitSelection?.partAEffectiveDate
          )
        : null,
      partBEffectiveDate: this.dependentInformation.benefitSelection
        ?.partBEffectiveDate
        ? new Date(
            this.dependentInformation.benefitSelection?.partBEffectiveDate
          )
        : null,
      effectiveDate: this.dependentInformation?.effectiveDate
        ? new Date(this.dependentInformation?.effectiveDate)
        : null,
      healthInsurancePlan:
        this.dependentInformation.isRemoved && this.healthPlan
          ? 'T'
          : this.healthPlan
          ? this.healthPlan.id
          : '',

      dentalInsurancePlan:
        this.dependentInformation.isRemoved && this.dentalPlan
          ? 'T'
          : this.dentalPlan
          ? this.dentalPlan.id
          : '',

      reasonForRemoval: this.dependentInformation.removalReason
        ? this.dependentInformation.removalReason
        : '',
      medicareType: medicareType ? medicareType : '',
    });
    //this.initialized = true;
  }

  getFormListsData() {
    //get relationship list
    let relationshipSubs = this.relationshipService.get().subscribe((data) => {
      this.relationshipList = data;
    });

    //get reason for removal list
    let reasonForRemovalSubs = this.terminationReasonService
      .get()
      .subscribe((data) => {
        this.terminationReasonList = data;
      });

    this.healthPlan = this.benefitSelection?.planSelection.find((p) => {
      if (p.type.toLowerCase().includes('medical')) {
        return p;
      } else return null;
    });

    this.dentalPlan = this.benefitSelection?.planSelection.find((p) => {
      if (p.type.toLowerCase().includes('dental')) {
        return p;
      } else return null;
    });

    if (this.healthPlan) {
      console.log(this.healthPlan.coverageID);

      let coverageSubscription = this.coverageService
        .get()
        .subscribe((coverages) => {
          this.coverages = coverages;
          let coverageName: string = '';
          let coverage = this.coverages.find(
            (c) => c.id == this.healthPlan?.coverageID
          );
          if (coverage) {
            coverageName = coverage.description;
          }
          this.relationshipService
            .getByCoverage(this.healthPlan?.coverageID!)
            .subscribe((data) => {
              console.log(data);

              let relationships: any = data[coverageName].map((r: string) => {
                return r.toLowerCase();
              });

              if (
                relationships.includes(
                  this.dependentInformation.dependentType.toLowerCase()
                )
              ) {
                this.healthInsurancePlanOptions.push(this.healthPlan);
                this.healthInsurancePlanOptions.push(
                  this.terminateCoverageOption
                );
              }
            });
        });
      this.subscriptions.push(coverageSubscription);
    }
    if (this.dentalPlan) {
      let coverageSubscription = this.coverageService
        .get()
        .subscribe((coverages) => {
          this.coverages = coverages;
          let coverageName: string = '';
          let coverage = this.coverages.find(
            (c) => c.id == this.dentalPlan?.coverageID
          );
          if (coverage) {
            coverageName = coverage.description;
          }
          this.relationshipService
            .getByCoverage(this.dentalPlan?.coverageID!)
            .subscribe((data) => {
              console.log(data);

              let relationships: any = data[coverageName].map((r: string) => {
                return r.toLowerCase();
              });

              if (
                relationships.includes(
                  this.dependentInformation.dependentType.toLowerCase()
                )
              ) {
                this.dentalPlanOptions.push(this.dentalPlan);
                this.dentalPlanOptions.push(this.terminateCoverageOption);
              }
            });
        });
      this.subscriptions.push(coverageSubscription);
    }
    this.subscriptions.push(relationshipSubs);
    this.subscriptions.push(reasonForRemovalSubs);
  }

  addFieldValidations() {
    this.f.medicareNumber.clearValidators();
    this.f.medicareNumber.updateValueAndValidity();
    this.f.medicareType.clearValidators();
    this.f.medicareType.updateValueAndValidity();
    this.f.partAEffectiveDate.clearValidators();
    this.f.partAEffectiveDate.updateValueAndValidity();
    this.f.partBEffectiveDate.clearValidators();
    this.f.partBEffectiveDate.updateValueAndValidity();
    if (this.f.elegibleForMedicare.value == 'true') {
      this.f.medicareNumber.setValidators([Validators.required]);
      this.f.medicareNumber.updateValueAndValidity();
      this.f.medicareType.setValidators([Validators.required]);
      this.f.medicareType.updateValueAndValidity();
      if (
        this.f.medicareType.value == 'Both' ||
        this.f.medicareType.value == 'PartA'
      ) {
        this.f.partAEffectiveDate.setValidators([Validators.required]);
        this.f.partAEffectiveDate.updateValueAndValidity();
      }
      if (
        this.f.medicareType.value == 'Both' ||
        this.f.medicareType.value == 'PartB'
      ) {
        this.f.partBEffectiveDate.setValidators([Validators.required]);
        this.f.partBEffectiveDate.updateValueAndValidity();
      }
    }
  }

  changeMedicare(e: any) {
    if (e.target.value == 'false') {
      this.f.medicareNumber.setValue('');
      this.f.medicareType.setValue('');
      this.f.partAEffectiveDate.setValue(null);
      this.f.partBEffectiveDate.setValue(null);
    }
  }

  changeMedicareType(e: any) {
    this.f.partAEffectiveDate.setValue(null);
    this.f.partBEffectiveDate.setValue(null);
  }

  getField(fieldName: string): AbstractControl | null {
    return this.form.get(fieldName);
  }
}
