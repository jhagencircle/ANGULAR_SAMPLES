﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Claims;
using BCBSAZ.Provider.Repositories.DbContexts;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using BCBSAZ.Provider.Models.Data.ClaimsDetails;
using BCBSAZ.Provider.Models.Data.Common;

namespace BCBSAZ.Provider.Repositories
{
	public class ClaimsRepository : IClaimsRepository
	{
		private readonly IClaimsContext _claimsContext;
		private readonly IPatientsContext _patientsContext;
		private readonly IClearingHouseContext _clearingHouseContext;
		private readonly ISubscriberContext _subscriberContext;
		private readonly ILogger _logger;
		private readonly IHttpContextAccessor _contextAccessor;

		public ClaimsRepository(IClaimsContext claimsContext, IPatientsContext patientsContext, IClearingHouseContext clearingHouseContext, ISubscriberContext subsscriberContext, ILogger<ClaimsRepository> logger, IHttpContextAccessor contextAccessor)
		{
			_claimsContext = claimsContext;
			_patientsContext = patientsContext;
			_clearingHouseContext = clearingHouseContext;
			_subscriberContext = subsscriberContext;
			_logger = logger;
			_contextAccessor = contextAccessor;
		}

		public Task SaveClaimsRequestAsync(ClaimsRequest request)
		{
			_claimsContext.ClaimsRequest.Add(request);
			return _claimsContext.SaveChangesAsync();
		}

		public Task SaveClaimsResponseAsync(ClaimsResponse response)
		{
			_claimsContext.ClaimsResponse.Add(response);
			return _claimsContext.SaveChangesAsync();
		}

		public Task<ClaimsRequest> GetClaimsAsync(long requestId)
		{
			return (
				from req in _claimsContext.ClaimsRequest
				where req.RequestId == requestId
				select req).FirstOrDefaultAsync();
		}

		public ClaimStatusMessage[] GetMessages()
		{
			try
			{
				return _claimsContext.MessageCodes.FromSqlRaw(
				DB.Claims.StoredProcs.GetMessageCodes).AsEnumerable().ToArray();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, _contextAccessor.HttpContext, "Error retrieving Claims Message Codes");
				return new ClaimStatusMessage[0];
			}
		}

		public ClaimStatusCode[] GetStatusCodes()
		{
			return _claimsContext.StatusCodes.FromSqlRaw(
				DB.Claims.StoredProcs.GetStatusCodes).AsEnumerable().ToArray();
		}

		public TPAInfo GetTPAInfo(string TPANumber) =>
			_clearingHouseContext.GetTPAInfo.FromSqlRaw(
			DB.ClearingHouse.StoredProcs.TPAInfo, TPANumber).AsEnumerable().FirstOrDefault();

		public PatientInfo GetPatientAddress(string SubscriberId, string DOB) =>
			_subscriberContext.GetPatientAddress.FromSqlRaw(
				DB.Subscriber.StoredProcs.GetPatientAddress, SubscriberId, DOB).AsEnumerable().FirstOrDefault();

		public async Task PurgeClaimsResultsAsync(int days)
		{
			var dateForPurge = DateTime.Now.AddDays(days * -1);
			await _claimsContext.Database.ExecuteSqlRawAsync(DB.Claims.StoredProcs.PurgeClaimsResults, days == 0 ? dateForPurge.ToString("yyyy-MM-dd") : null);
		}

		public async Task<IEnumerable<ClaimsRequest>> GetClaimsHistoryResultsAsync(string orgId, int days)
		{
			var startDate = DateTime.Today.AddDays(-days);
			var retVal = await (
					from r in _claimsContext.ClaimsRequest
					where
						r.OrgId == orgId &&
						r.ClaimsFound != null &&
						r.InsertDate >= startDate
					orderby r.RequestId descending
					select new ClaimsRequest()
					{
						RequestId = r.RequestId,
						UserId = r.UserId,
						Region = r.Region,
						LOB = r.LOB,
						SubscriberId = r.SubscriberId,
						MemberFirstName = r.MemberFirstName.ToTitleCase(),
						MemberMiddleInitial = r.MemberMiddleInitial.ToTitleCase(),
						MemberLastName = r.MemberLastName.ToTitleCase(),
						MemberGender = r.MemberGender,
						MemberSSN = r.MemberSSN,
						PatientFirstName = r.PatientFirstName.ToTitleCase(),
						PatientMiddleInitial = r.PatientMiddleInitial.ToTitleCase(),
						PatientLastName = r.PatientLastName.ToTitleCase(),
						DateOfBirth = r.DateOfBirth,
						PatientGender = r.PatientGender,
						PatientSSN = r.PatientSSN,
						IsDependent = r.IsDependent,
						StartDate = r.StartDate,
						EndDate = r.EndDate,
						ProcessedClaims = r.ProcessedClaims,
						PendingClaims = r.PendingClaims,
						DeniedClaims = r.DeniedClaims,
						BilledAmount = r.BilledAmount,
						BilledType = r.BilledType,
						ICN = r.ICN,
						ProvidersList = r.ProvidersList.ToArray(),
						ClaimsFound = r.ClaimsFound,
						InsertDate = r.InsertDate,
						OrgId = r.OrgId
					}).ToArrayAsync();
			return retVal;
		}

		public async Task SaveChangesAsync() => await _patientsContext.SaveChangesAsync();


		public async Task<Patient> GetOrCreatePatientAsync(Patient patient)
		{
			var retVal = GetPatient(patient);

			if (retVal == null)
			{
				retVal = AddNavigationProperties(patient);
				await _patientsContext.Patients.AddAsync(patient);
			}

			return retVal;
		}

		private Patient AddNavigationProperties(Patient patient)
		{
			patient.Orgs = new List<PatientOrg>();
			patient.Users = new List<PatientUser>();
			return patient;
		}

		private Patient GetPatient(Patient patient)
		{
			var retVal = (
				from p in _patientsContext.Patients
				where
				p.SubscriberId == patient.SubscriberId &&
				p.PatientFirstName == patient.PatientFirstName &&
				p.PatientLastName == patient.PatientLastName &&
				p.DateOfBirth.Date == patient.DateOfBirth.Date
				select p).FirstOrDefault();

			return retVal;
		}
	}
}
