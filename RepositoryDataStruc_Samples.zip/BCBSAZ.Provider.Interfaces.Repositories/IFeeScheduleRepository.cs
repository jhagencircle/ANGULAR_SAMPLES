﻿using System;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.FeeSchedule;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	/// <summary>
	/// Data Access logic for Fee Schedule Api methods
	/// </summary>
	public interface IFeeScheduleRepository
	{
		/// <summary>
		/// Gets Professional Fee Schedules 
		/// </summary>
		/// <param name="request">A validated Professional Fees Request</param>
		/// <returns>A result object containing the Professional Fees grouped by Site of Service and DME</returns>
		ProfessionalFee[] GetProfessionalFees(string providerId, string taxId, DateTime? searchDate, string specialty, string procedureCodes, string siteOfServiceCodes, bool isHistoric);

		/// <summary>
		/// Gets Outpatient Fee Schedules
		/// </summary>
		/// <param name="request">A validated Outpatient Fees Request</param>
		/// <returns>A result object containing the Outpatient Fees grouped by Site of Service</returns>
		OutpatientFee[] GetOutpatientFees(DateTime? searchDate, string specialty, string procedureCodes, string siteOfServiceCodes, bool isHistoric);

		/// <summary>
		/// Gets Asc Fee Schedules
		/// </summary>
		/// <param name="request">A validated Asc Fees Request</param>
		/// <returns>A result object containing the Asc Fees grouped by Site of Service</returns>
		AscFee[] GetAscFees(DateTime? searchDate, string specialty, string procedureCodes, string siteOfServiceCodes, bool isHistoric);

		ProviderTaxId[] GetTaxIdsForProvider(string providerId, string orgId);

		Specialty[] GetSpecialties();
	}
}
