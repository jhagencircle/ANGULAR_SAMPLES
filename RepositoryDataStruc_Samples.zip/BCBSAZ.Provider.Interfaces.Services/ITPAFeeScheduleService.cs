﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.TPA;
using BCBSAZ.Provider.Models.Responses.Common;
using BCBSAZ.Provider.Models.Responses.TPA;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface ITPAFeeScheduleService
	{
		Task<Models.Responses.Common.Select2Response> GetPlaceOfService(TPAPlaceOfServiceRequest request);

		Task<TPAFeeScheduleResponse> GetTpaFeeScheduleDetailAsync(TPAFeeScheduleRequest request);

		Task<TpaProviderInstitutionResponse> GetTpaProviderInstitution(TpaProviderInstitutionRequest request);
	}
}
