﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Models.API.PlanProfile;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Managers.ApiClients
{
	public class PlanProfileApiClient : ApiClientBase, IPlanProfileApiClient
	{
		protected override string Name => "Plan Profile API";

		public PlanProfileApiClient(IConfiguration configuration, IOktaApiClient oktaClient) : base(oktaClient)
		{
			base.Timeout = new TimeSpan(0, 0, configuration.GetValue<int>(Constants.Configuration.Timeouts.PlanProfileTimeout));
			var serviceUrl = configuration.GetValue<string>(Constants.Configuration.VelocityApiUrl);

			if (string.IsNullOrWhiteSpace(serviceUrl))
				throw new ArgumentException("Invalid Service Url specified for Velocity API.");

			BaseAddress = new Uri(serviceUrl.EnsureEndsWith('/'));

			DefaultRequestHeaders.Clear();
			DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
		}

		public Task<IEnumerable<PlanPrefix>> GetPrefixesAsync(string planInfoName) =>
		 GetAsync<IEnumerable<PlanPrefix>>(string.Format(Constants.PlanProfileApiUrls.GetPrefixes, planInfoName));
	}
}
