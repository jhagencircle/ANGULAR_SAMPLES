﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Requests.Eligibility.Inquiries;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.Eligibility
{
	internal static class SubmitInquiriesRequestValidator
	{
		public static void Validate(this SubmitInquiriesRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(SubmitInquiriesRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.Region))
				yield return new InvalidModelExceptionDetail(nameof(SubmitInquiriesRequest.Region), new ArgumentNullException("The Region is null or empty."));
			else if (!Regions.Valid.Contains(request.Region, StringComparer.OrdinalIgnoreCase))
				yield return new InvalidModelExceptionDetail(nameof(SubmitInquiriesRequest.Region), new ArgumentException("The Region specified is not valid."));

			if (request.Inquiries.Any())
			{
				request.Inquiries.ForEach(AddViolationsToInquiry);
			}
			else
			{
				yield return new InvalidModelExceptionDetail(nameof(SubmitInquiriesRequest.Inquiries), new ArgumentNullException("The request contained no inquiries."));
			}
		}

		private static void AddViolationsToInquiry(Inquiry inquiry)
		{
			if (inquiry != null)
				inquiry.Violations = Violations(inquiry);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(Inquiry inquiry)
		{
			if (inquiry.DateOfService < DateTime.Today.AddMonths(-33) || inquiry.DateOfService > DateTime.Today.AddDays(35))
				yield return new InvalidModelExceptionDetail(nameof(Inquiry.DateOfService), new ArgumentException("The Date of Service specified is outside of the acceptable range."));

			if (string.IsNullOrWhiteSpace(inquiry.InquiryType))
				yield return new InvalidModelExceptionDetail(nameof(Inquiry.InquiryType), new ArgumentNullException("The Inquiry Type is null or empty."));
			else if (!InquiryTypes.Valid.Contains(inquiry.InquiryType, StringComparer.OrdinalIgnoreCase))
				yield return new InvalidModelExceptionDetail(nameof(Inquiry.InquiryType), new ArgumentException("The Inquiry Type specified is not valid."));

			if (string.IsNullOrWhiteSpace(inquiry.SubscriberId))
				yield return new InvalidModelExceptionDetail(nameof(Inquiry.SubscriberId), new ArgumentNullException("The Subscriber Id is null or empty."));

			if (inquiry.Patient == null)
			{
				yield return new InvalidModelExceptionDetail(nameof(Inquiry.Patient), new ArgumentNullException("Patient inquiry is null."));
			}
			else
			{
				if (string.IsNullOrWhiteSpace(inquiry.Patient.FirstName))
					yield return new InvalidModelExceptionDetail(nameof(Inquiry.Patient.FirstName), new ArgumentNullException("Patient First Name is null or empty."));

				if (string.IsNullOrWhiteSpace(inquiry.Patient.LastName))
					yield return new InvalidModelExceptionDetail(nameof(Inquiry.Patient.FirstName), new ArgumentNullException("Patient Last Name is null or empty."));

				if (inquiry.Patient.DateOfBirth < DateTime.Today.AddYears(-SettingsManager.MaxAge) || inquiry.Patient.DateOfBirth > DateTime.Today)
					yield return new InvalidModelExceptionDetail(nameof(Inquiry.Patient.DateOfBirth), new ArgumentException("The Date of Birth specified is outside of the acceptable range."));

				if (string.IsNullOrWhiteSpace(inquiry.Patient.Gender))
					yield return new InvalidModelExceptionDetail(nameof(Inquiry.Patient.Gender), new ArgumentNullException("Patient Gender is null or empty."));
				else if (!Genders.Valid.Contains(inquiry.Patient.Gender, StringComparer.OrdinalIgnoreCase))
					yield return new InvalidModelExceptionDetail(nameof(Inquiry.Patient.Gender), new ArgumentException("The Patient Gender specified is not valid."));
			}

			if (inquiry.IsDependent)
			{
				if (inquiry.Subscriber == null)
				{
					yield return new InvalidModelExceptionDetail(nameof(Inquiry.Subscriber), new ArgumentNullException("Subscriber inquiry is null."));
				}
				else
				{
					if (string.IsNullOrWhiteSpace(inquiry.Subscriber.FirstName))
						yield return new InvalidModelExceptionDetail(nameof(Inquiry.Subscriber.FirstName), new ArgumentNullException("Subscriber First Name is null or empty."));

					if (string.IsNullOrWhiteSpace(inquiry.Subscriber.LastName))
						yield return new InvalidModelExceptionDetail(nameof(Inquiry.Subscriber.FirstName), new ArgumentNullException("Subscriber Last Name is null or empty."));
				}
			}

			// TODO: Validate Service Types?
			// TODO: Validate additional "InPatient" fields are present when Service Type = Hospital Service Type

		}
	}
}
