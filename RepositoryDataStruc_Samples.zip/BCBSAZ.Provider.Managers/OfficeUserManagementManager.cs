﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Interfaces.WCFClients;
using BCBSAZ.Provider.Managers.RequestValidators.OfficeUserManagement;
using BCBSAZ.Provider.Models.Requests.OfficeUserManagement;
using BCBSAZ.Provider.Models.Responses.OfficeUserManagement;
using BCBSAZ.Provider.Service.WCF.Clients.BizTalk271EDI;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Managers
{
	public class OfficeUserManagementManager : IOfficeUserManagementManager
	{
		private readonly IOfficeUserManagementRepository _officeUserManagementRepository;
		private readonly IWCFClientFactory _wcfClientFactory;
		private readonly ISecurityManager _securityManager;
		private readonly ILogger _logger;

		public OfficeUserManagementManager(IOfficeUserManagementRepository officeUserManagementRepository, ISecurityManager securityManager, ILogger<OfficeUserManagementManager> logger, IWCFClientFactory wcfClientFactory)
		{
			_officeUserManagementRepository = officeUserManagementRepository;
			_securityManager = securityManager;
			_logger = logger;
			_wcfClientFactory = wcfClientFactory;
		}

		#region User Methods

		public OrgUsersResponse GetOrgUsers(WebUser webUser) =>
			new OrgUsersResponse()
			{
				Users = _officeUserManagementRepository.GetOrgUsers(webUser.OrgId)
			};

		public UserProfileResponse GetUserProfile(string userId) =>
			new UserProfileResponse()
			{
				UserProfile = _officeUserManagementRepository.GetUserProfile(userId)
			};

		public SaveUserProfileResponse InsertUserProfile(WebUser user, SaveUserProfileRequest request)
		{
			request.PasswordReset = true; // Force validator to validate password.
			request.Validate(user);

			try
			{
				var passwordHash = _securityManager.HashPassword(request.UserProfile.Username, request.UserProfile.Password);
				var answerHash = _securityManager.HashString(request.UserProfile.SecurityQuestionAnswer);
				var createdBy = $"OUM - {user.UserId}";

				_officeUserManagementRepository.InsertUserProfile(createdBy, user.OrgId, request.UserProfile, passwordHash, answerHash);
				_officeUserManagementRepository.SetProvidersForUser(user.OrgId, request.UserProfile.SubOrg, request.UserProfile.Username, request.Providers);

				using (var client = _wcfClientFactory.GetSecurityServiceClient())
				{
					if (client != null)
					{
						var result = client.ResetOtherUserPasswordAsync(request.UserProfile.Username, request.UserProfile.Password, request.UserProfile.Password).Result;
						if (!result)
						{
							return new SaveUserProfileResponse()
							{
								Failed = true,
								Message = "Failed to update password..."
							};
						}

					}
				}

					return new SaveUserProfileResponse();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Exception in {nameof(OfficeUserManagementManager)}.{nameof(InsertUserProfile)}: {ex.GetType().Name}-{ex.Message}");
				return new SaveUserProfileResponse()
				{
					Failed = true,
					Message = ex.Message
				};
			}
		}

		public SaveUserProfileResponse UpdateUserProfile(WebUser user, SaveUserProfileRequest request)
		{
			request.Validate(user);

			try
			{
				var passwordHash = request.PasswordReset ? _securityManager.HashPassword(request.UserProfile.Username, request.UserProfile.Password) : null;

				_officeUserManagementRepository.UpdateUserProfile(request.UserProfile, passwordHash);
				_officeUserManagementRepository.SetProvidersForUser(user.OrgId, request.UserProfile.SubOrg, request.UserProfile.Username, request.Providers);
				if (!String.IsNullOrEmpty(request.UserProfile.Password))
				{
					using (var client = _wcfClientFactory.GetSecurityServiceClient())
					{
						if (client != null)
						{
							bool result = client.ResetOtherUserPasswordAsync(request.UserProfile.Username, request.UserProfile.Password, request.UserProfile.Password).Result;
							if (!result)
							{
								return new SaveUserProfileResponse()
								{
									Failed = true,
									Message = "Failed to update password..."
								};
							}
						}
					}
				}
				return new SaveUserProfileResponse();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Exception in {nameof(OfficeUserManagementManager)}.{nameof(UpdateUserProfile)}: {ex.GetType().Name}-{ex.Message}");
				return new SaveUserProfileResponse()
				{
					Failed = true,
					Message = ex.Message
				};
			}
		}

		public DeleteUserProfileResponse DeleteUserProfile(WebUser user, string userId)
		{
			try
			{
				_officeUserManagementRepository.DeleteUserProfile(user.OrgId, userId);
				return new DeleteUserProfileResponse();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Exception in {nameof(OfficeUserManagementManager)}.{nameof(DeleteUserProfile)}: {ex.GetType().Name}-{ex.Message}");
				return new DeleteUserProfileResponse()
				{
					Failed = true,
					Message = ex.Message
				};
			}

		}

		public GetUserProvidersResponse GetUserProviders(WebUser user, string subOrg, string userId) =>
			new GetUserProvidersResponse()
			{
				Providers = _officeUserManagementRepository.GetProvidersForUser(user.OrgId, subOrg, userId)
			};

		public SetUserProviderResponse SetUserProviders(SetUserProvidersRequest request)
		{
			request.Validate();

			try
			{
				_officeUserManagementRepository.SetProvidersForUser(request.OrgId, request.SubOrg, request.UserId, request.Providers);
				return new SetUserProviderResponse();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Exception in {nameof(OfficeUserManagementManager)}.{nameof(SetUserProviders)}: {ex.GetType().Name}-{ex.Message}");
				return new SetUserProviderResponse()
				{
					Failed = true,
					Message = ex.Message
				};
			}
		}


		#endregion

		#region Sub Org Methods

		public SubOrgListResponse GetSubOrgList(WebUser webUser) =>
			new SubOrgListResponse()
			{
				SubOrgs = _officeUserManagementRepository.GetSubOrgs(webUser.OrgId)
			};

		public SubOrgResponse GetSubOrg(WebUser webUser, string subOrg) =>
			new SubOrgResponse()
			{
				SubOrg = _officeUserManagementRepository.GetSubOrg(webUser.OrgId, subOrg)
			};

		public SaveSubOrgResponse InsertSubOrg(WebUser webUser, SaveSubOrgRequest request)
		{
			request.Validate();

			try
			{
				_officeUserManagementRepository.InsertSubOrg(webUser.OrgId, request.SubOrg);
				
				if (request.Providers != null)
					_officeUserManagementRepository.SetProvidersForSubOrg(webUser.OrgId, request.SubOrg.Name, request.Providers);

				return new SaveSubOrgResponse();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Exception in {nameof(OfficeUserManagementManager)}.{nameof(InsertSubOrg)}: {ex.GetType().Name}-{ex.Message}");
				return new SaveSubOrgResponse()
				{
					Failed = true,
					Message = ex.Message
				};
			}
		}

		public SaveSubOrgResponse UpdateSubOrg(WebUser webUser, SaveSubOrgRequest request)
		{
			request.Validate();

			try
			{
				_officeUserManagementRepository.UpdateSubOrg(webUser.OrgId, request.SubOrg);

				if (request.Providers != null)
					_officeUserManagementRepository.SetProvidersForSubOrg(webUser.OrgId, request.SubOrg.Name, request.Providers);

				return new SaveSubOrgResponse();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Exception in {nameof(OfficeUserManagementManager)}.{nameof(UpdateSubOrg)}: {ex.GetType().Name}-{ex.Message}");
				return new SaveSubOrgResponse()
				{
					Failed = true,
					Message = ex.Message
				};
			}
		}

		public DeleteSubOrgResponse DeleteSubOrg(WebUser user, string subOrg)
		{
			try
			{
				_officeUserManagementRepository.DeleteSubOrg(user.OrgId, subOrg);
				return new DeleteSubOrgResponse();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Exception in {nameof(OfficeUserManagementManager)}.{nameof(DeleteSubOrg)}: {ex.GetType().Name}-{ex.Message}");
				return new DeleteSubOrgResponse()
				{
					Failed = true,
					Message = ex.Message
				};
			}
		}

		public SubOrgUsersResponse GetSubOrgUsers(WebUser user, string subOrg) =>
			new SubOrgUsersResponse()
			{
				Users = _officeUserManagementRepository.GetSubOrgUsers(user.OrgId, subOrg)
			};

		public GetSubOrgProvidersResponse GetSuborgProviders(WebUser user, string subOrg) =>
			new GetSubOrgProvidersResponse()
			{
				Providers = _officeUserManagementRepository.GetProvidersForSubOrg(user.OrgId, subOrg)
			};

		public SetSubOrgProvidersResponse SetSuborgProviders(SetSubOrgProvidersRequest request)
		{
			request.Validate();

			try
			{
				_officeUserManagementRepository.SetProvidersForSubOrg(request.OrgId, request.SubOrg, request.Providers);
				return new SetSubOrgProvidersResponse();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Exception in {nameof(OfficeUserManagementManager)}.{nameof(SetSuborgProviders)}: {ex.GetType().Name}-{ex.Message}");
				return new SetSubOrgProvidersResponse()
				{
					Failed = true,
					Message = ex.Message
				};
			}
		}
		#endregion
	}
}
