﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using Newtonsoft.Json;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models.Logging
{
    public class LoggingModel
    {
        public string Message { get; set; }
        public string UserId { get; set; }
        public string AdditionalInformation { get; set; }
        [JsonIgnore]
        public string Source { get; set; }
        [JsonIgnore]
        public LogLevelEnum Level { get; set; }
        public override string ToString()
        {
            return JsonConvert.SerializeObject(this).Replace("\\\"", "\"");
        }
    }
}
