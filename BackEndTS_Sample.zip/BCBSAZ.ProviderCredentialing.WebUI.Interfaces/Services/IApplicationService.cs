﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.Models.Responses;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications;

namespace BCBSAZ.ProviderCredentialing.WebUI.Interfaces.Services
{
	public interface IApplicationService
	{
		Task<SubmitApplicationResponse> SubmitApplicationAsync(ProviderCredentialForm form, IEnumerable<FileAttachment> attachments);
	}
}
