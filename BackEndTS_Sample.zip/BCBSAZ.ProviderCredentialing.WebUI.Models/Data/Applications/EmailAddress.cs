﻿using BCBSAZ.ProviderCredentialing.WebUI.Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class EmailAddress
	{
		public EmailAddress() =>
			Types = new List<EmailAddressType>();

		public EmailAddress(params EmailAddressType[] emailAddressTypes) =>
			Types = new List<EmailAddressType>(emailAddressTypes);

		[DisplayName("Email Address")]
		[Required(ErrorMessage = "Email Address is required")]
		[RegularExpression(@"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$", ErrorMessage = "Please enter a valid Email Address")]
		[MaxLength(50)]
		public string Address { get; set; }

		public ICollection<EmailAddressType> Types { get; set; }

		public bool IsMatch(EmailAddress value)
		{
			return
				Address.EqualsNullable(value.Address, StringComparison.OrdinalIgnoreCase);
		}
	}
}