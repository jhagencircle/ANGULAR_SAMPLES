﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.TPA;
using BCBSAZ.Provider.Models.Responses.TPA;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface ITPAProviderContractService
	{
		Task<TpaProviderContractStatusResponse> GetTpaProviderContractsAsync(TpaProviderContractStatusRequest request);
		Task<TpaProviderInfoResponse> GetTpaProviderInfoAsync(TpaProviderInfoRequest request);
	}
}
