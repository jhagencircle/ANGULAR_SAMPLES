﻿using BCBSAZ.ProviderAuxiliaryPortal.Models;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.ApiClient;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Net.Mail;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories
{
    public class EmailRepository : IEmailRepository
    {
        private readonly EmailContext _emailContext;
        private readonly IEmailClient _emailClient;

        public EmailRepository(EmailContext emailContext, IEmailClient emailClient)
        {
            _emailContext = emailContext;
            _emailClient = emailClient;
        }

        public async Task<bool> SendExternalEmailAsync(string toAddress, string fromAddress, string subject, string body, string cc, string bcc)
        {
            await _emailContext.Database.ExecuteSqlRawAsync(Constants.StoredProcedure.Email.QUEQUE_EMAIL, toAddress, fromAddress, cc, bcc, subject, body);

            return true;
        }

        public async Task<bool> SendInternalEmailAsync(string toAddress, string fromAddress, string subject, string body, IEnumerable<Attachment> attachments, string cc = null, string bcc = null)
        {
            await _emailClient.SendEmailAsync(fromAddress, toAddress, subject, body, attachments, cc, bcc);

            return true;
        }
    }
}
