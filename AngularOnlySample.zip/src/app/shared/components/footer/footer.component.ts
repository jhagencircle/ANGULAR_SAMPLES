import { Component, OnInit } from '@angular/core';
import { AppConstants } from '../../constants/app-constants';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent implements OnInit {
  originYear: string;
  newYear: string;
  copyrightYear: string;
  copyrightText: string;

  constructor() {}

  ngOnInit(): void {
    this.loadFooter();
  }

  loadFooter() {
    this.originYear = AppConstants.COPYRIGHT_ORIGIN_YEAR;
    this.newYear = new Date().getFullYear().toString();
    this.copyrightYear =
      this.newYear != this.originYear
        ? this.originYear + ' - ' + this.newYear
        : this.originYear;
    this.copyrightText =
      AppConstants.COPYRIGHT_SYMBOL +
      this.copyrightYear +
      AppConstants.COPYRIGHT_DESCRIPTION;
  }
}
