﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Managers.Email.Templates
{
	// Template Notes: See Read-Me.txt File

	internal class Template
	{
		public Template(string templateContent)
		{
			using (var reader = new StringReader(templateContent))
			{
				Subject = reader.ReadLine();
				Body = reader.ReadToEnd();
			}

			var data = Encoding.UTF8.GetBytes(Subject);
			System.Diagnostics.Debug.WriteLine(data);
		}

		public string Subject { get; }

		public string Body { get; }

		private string[] _placeHolders = null;
		public string[] PlaceHolders
		{
			get
			{
				if (_placeHolders == null)
				{
					_placeHolders = FindPlaceHolders("%%", Subject, Body).ToArray();
				}
				return _placeHolders;
			}
		}

		public MailMessage CreateMessage(string from, string to, IEnumerable<KeyValuePair<string, string>> placeHolderValues) => CreateMessage(new MailAddress(from), new MailAddress(to), placeHolderValues);

		public MailMessage CreateMessage(MailAddress from, MailAddress to, IEnumerable<KeyValuePair<string, string>> placeHolderValues)
		{
			GetSubjectAndBody(placeHolderValues, out var subject, out var body);

			return new MailMessage(from, to)
			{
				IsBodyHtml = body.StartsWith("<", StringComparison.OrdinalIgnoreCase),
				Subject = subject,
				Body = body
			};
		}

		public void GetSubjectAndBody(IEnumerable<KeyValuePair<string, string>> placeHolderValues, out string subject, out string body)
		{
			subject = Subject;
			body = Body;

			if (placeHolderValues != null)
			{
				foreach (KeyValuePair<string, string> item in placeHolderValues)
				{
					subject = subject.Replace(item.Key, item.Value);
					body = body.Replace(item.Key, item.Value);
				}
			}
		}

		private static IEnumerable<string> FindPlaceHolders(string placeHolder, params string[] elements)
		{
			foreach (var element in elements)
			{
				var startIdx = element.IndexOf(placeHolder);
				while (startIdx >= 0)
				{
					var endIdx = (element.IndexOf(placeHolder, startIdx + placeHolder.Length));
					var length = (endIdx - startIdx) - placeHolder.Length;

					yield return length < 0 ? element.Substring(startIdx + placeHolder.Length) : element.Substring(startIdx + placeHolder.Length, length);

					startIdx = element.IndexOf(placeHolder, endIdx + placeHolder.Length);
				}
			}
		}
	}

}
