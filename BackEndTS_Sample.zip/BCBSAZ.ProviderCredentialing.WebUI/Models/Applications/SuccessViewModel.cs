﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Applications
{
	public class SuccessViewModel
	{
		public string SuccessContent { get; set; }
	}
}
