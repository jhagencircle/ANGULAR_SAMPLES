import {
  Component,
  OnInit,
  EventEmitter,
  Output,
  OnDestroy,
} from '@angular/core';
import { Autopay } from '../shared/autopay.model';
import { AutopaymentService } from '../shared/autopayment.service';
import { SpinnerService } from '../../shared/components/spinner/spinner.service';
import { AccountService } from 'src/app/shared/services/account.service';
import { ISummary } from 'src/app/shared/models/summary.model';
import { ConfirmationDialogService } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.service';
import { ModalSize } from 'src/app/shared/enums/modal-size-enum';
import { AppConstants } from '../../shared/constants/app-constants';
import { PaymentStatusEnum } from '../../shared/enums/payment-status-enum';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-autopay-list',
  templateUrl: './autopay-list.component.html',
  styleUrls: ['./autopay-list.component.scss'],
})
export class AutopayListComponent implements OnInit, OnDestroy {
  hasAutopays: boolean = false;
  autopayList: any[];
  isAddFormVisible: boolean;
  account: ISummary;
  @Output() autopayDeleted = new EventEmitter();
  subscriptions: Subscription[] = [];

  constructor(
    public autopayService: AutopaymentService,
    private spinnerService: SpinnerService,
    public accountService: AccountService,
    private confirmationDialogService: ConfirmationDialogService,
    private router: Router
  ) {}
  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  ngOnInit(): void {
    this.loadAutopayList();
  }

  showAddForm() {
    this.isAddFormVisible = true;
  }

  hideAddForm() {
    if (!this.hasAutopays) {
      this.router.navigate(['/landing-page']);
    } else {
      this.isAddFormVisible = false;
    }
  }

  isDeleteDisabled(accountId: string) {
    let currentAutopay = this.autopayList.find(
      (item) => item.accountId === accountId
    );
    return currentAutopay?.paymentStatus === PaymentStatusEnum.Processing;
  }

  openCancelConfirmationDialog(autopay: Autopay) {
    let modalHeader: string = AppConstants.AUTOPAY_CANCEL_ALERT_TITLE;
    let modalbody: string = AppConstants.AUTOPAY_CANCEL_BODY_ALERT.replace(
      '${accountName}',
      autopay.accountName
    );
    let btnOkText: string = AppConstants.AUTOPAY_BUTTON_OK_TEXT;
    let btnCancelText: string = AppConstants.AUTOPAY_BUTTON_CANCEL_TEXT;
    let modalSize: string = ModalSize.MEDIUM;
    this.confirmationDialogService
      .confirm(modalHeader, modalbody, btnOkText, btnCancelText, modalSize)
      .then((confirmed) => {
        if (confirmed) {
          this.cancelAutopayment(autopay);
        }
      });
  }

  cancelAutopayment(autopay: Autopay) {
    this.spinnerService.show(true);

    let subscription = this.autopayService
      .cancel(autopay.accountId)
      .subscribe((model) => {
        if (model.message === AppConstants.AUTOPAY_UNENROLLMENT_SUCCESS)
          this.autopayDeleted.emit(autopay.accountName);
        this.spinnerService.show(false);
      });
    this.subscriptions.push(subscription);
  }

  loadAutopayList() {
    this.spinnerService.show(true);
    let subscription = this.accountService
      .get()
      .subscribe((account: ISummary) => {
        if (account) {
          this.account = account;
          this.autopayService.getList(account.accountId).subscribe((data) => {
            this.spinnerService.show(false);
            if (data !== undefined) {
              this.autopayList = data.map((d) => ({
                paymentAmont: AppConstants.AUTOPAY_TOTAL_BILLED_AMOUNT,
                paymentDate: AppConstants.AUTOPAY_PAYMENT_DATE,
                ...d,
              }));
              this.autopayService.update(this.autopayList);
              this.hasAutopays = true;
              this.isAddFormVisible = false;
            } else {
              this.hasAutopays = false;
              this.isAddFormVisible = true;
            }
          });
        }
      });
    this.subscriptions.push(subscription);
  }
}
