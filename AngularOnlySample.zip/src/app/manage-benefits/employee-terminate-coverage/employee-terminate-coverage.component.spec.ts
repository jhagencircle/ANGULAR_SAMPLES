import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EmployeeTerminateCoverageComponent } from './employee-terminate-coverage.component';
import { EmployeeService } from '../shared/employee.service';
import { EmployeeServiceMock } from '../../shared/mocks/employee.service.mock';
import { EmployeeProfileService } from '../shared/employee-profile.service';
import { of } from 'rxjs';
import { IEmployee, ITerminationCoverage } from '../shared/models';

describe('EmployeeTerminateCoverageComponent', () => {
  let component: EmployeeTerminateCoverageComponent;
  let fixture: ComponentFixture<EmployeeTerminateCoverageComponent>;
  let mockEmployeeService: any = new EmployeeServiceMock();
  let employeeProfileServiceSpy: { update: jasmine.Spy; get: jasmine.Spy };
  let terminateCoverage: ITerminationCoverage;

  beforeEach(async () => {
    mockEmployeeService.get().subscribe((employee: any) => {
      employeeProfileServiceSpy = {
        update: jasmine.createSpy('update').and.returnValue(of(true)),
        get: jasmine.createSpy('get').and.returnValue(of(employee)),
      };
    });

    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [EmployeeTerminateCoverageComponent],
      providers: [
        { provide: EmployeeService, useValue: mockEmployeeService },
        {
          provide: EmployeeProfileService,
          useValue: employeeProfileServiceSpy,
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeTerminateCoverageComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should cancel child', () => {
    component.onCancelChild();
    expect(component.showEdit).toBeFalsy();
  });

  it('should on send data child', () => {
    console.log(
      'mockEmployeeService.terminateCoverage',
      mockEmployeeService.terminateCoverage
    );
    component.onSendDataChild(mockEmployeeService.terminateCoverage);
    expect(employeeProfileServiceSpy.update.calls.count()).toBe(1);
  });
});
