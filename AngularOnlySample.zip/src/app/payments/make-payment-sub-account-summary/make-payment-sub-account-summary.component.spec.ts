import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MakePaymentSubAccountSummaryComponent } from './make-payment-sub-account-summary.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DecimalPipe } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Observable, of } from 'rxjs';
import { MockSubAccount } from '../../shared/mocks/sub-account.mock';
import { BankAccountMock } from 'src/app/shared/mocks/bank-account.mock';

describe('MakePaymentSubAccountSummaryComponent', () => {
  let component: MakePaymentSubAccountSummaryComponent;
  let fixture: ComponentFixture<MakePaymentSubAccountSummaryComponent>;
  let mockSubAccount: any = new MockSubAccount();
  let mockBankAccountModel: BankAccountMock = new BankAccountMock();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        HttpClientTestingModule,
        NgbModule,
      ],
      declarations: [MakePaymentSubAccountSummaryComponent, DecimalPipe],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MakePaymentSubAccountSummaryComponent);
    component = fixture.componentInstance;

    mockBankAccountModel
      .get()
      .subscribe((data) => (component.bankAccounts = data));

    mockSubAccount.getList().subscribe((data: any) => {
      component.account = data[0];
    });

    component.events = of();

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
