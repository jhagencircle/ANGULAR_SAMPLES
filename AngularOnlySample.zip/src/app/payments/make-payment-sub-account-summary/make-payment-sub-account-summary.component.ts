import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { PaymentsService } from '../shared/payments.service';

@Component({
  selector: 'app-make-payment-sub-account-summary',
  templateUrl: './make-payment-sub-account-summary.component.html',
  styleUrls: ['./make-payment-sub-account-summary.component.scss'],
})
export class MakePaymentSubAccountSummaryComponent implements OnInit {
  @Input() events: Observable<void>;
  @Input() bankAccounts: any;
  @Input() account: any;
  @Input() minDate: Date;
  @Input() maxDate: Date;
  @Output() ProcessPayment = new EventEmitter<any>();
  @ViewChild('paymentForm') paymentFormElement: any;
  currentBillTotalAmount: string;
  form: FormGroup;
  isChecked: boolean = true;
  submitted: boolean;
  amount: string;

  private eventsSubscription: Subscription;

  get f() {
    return this.subAccountPaymentForm.controls;
  }
  constructor(public fb: FormBuilder, public paymentsService: PaymentsService) {
    this.minDate = new Date();
  }

  subAccountPaymentForm = this.fb.group({
    bankAccount: ['', [Validators.required]],
    date: [new Date(), [Validators.required]],
    amount: ['', [Validators.required]],
  });

  ngOnInit(): void {
    this.eventsSubscription = this.events.subscribe(() => {
      this.paymentFormElement.ngSubmit.emit();
      if (this.paymentFormElement.valid) {
        this.ProcessPayment.emit({
          amount: this.paymentsService.parseNumber(
            this.paymentFormElement.form.value.amount
          ),
          bankAccount: this.bankAccounts.find(
            (element: any) =>
              element.id ===
              parseInt(this.paymentFormElement.form.value.bankAccount)
          ),
          date: this.paymentFormElement.form.value.date,
          totalAmount: this.paymentsService.parseNumber(
            this.currentBillTotalAmount
          ),
          accountId: this.account.accountId,
        });
      } else {
        this.ProcessPayment.emit({ hasError: true });
      }

      this.submitted = true;
    });

    let paymentAmount = parseFloat(this.account.totalBilledAmount);
    let adjustmentAmount = parseFloat(this.account.totalAdjustedAmount);

    this.currentBillTotalAmount = this.paymentsService.parseCurrency(
      paymentAmount + adjustmentAmount
    );

    this.amount = this.paymentsService.parseCurrency(paymentAmount);
  }

  ngOnDestroy() {
    this.eventsSubscription.unsubscribe();
  }

  getTotalAmount() {
    let amountFloat = this.paymentsService.parseNumber(this.amount);
    if (amountFloat <= 0 || isNaN(amountFloat)) {
      amountFloat = 1;
    }
    this.amount = this.paymentsService.parseCurrency(amountFloat);
    this.currentBillTotalAmount = this.paymentsService.parseCurrency(
      amountFloat + this.account.totalAdjustedAmount
    );
  }

  onClick() {
    this.amount = this.paymentsService.parseNumber(this.amount).toString();
  }
}
