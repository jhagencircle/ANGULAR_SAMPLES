﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface IWebApiClient
	{

		/// <summary>
		/// Sends the request provided to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestMessage">The request message for the Provider Web Api method</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		Task<TResult> SendRequestAsync<TResult>(HttpRequestMessage requestMessage) where TResult : class;

		/// <summary>
		/// Gets the content provided by the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		[SuppressMessage("Design", "CA1054:Uri parameters should not be strings", Justification = "Expected Url is partial and therefore not a valid Uri.")]
		Task<TResult> GetAsync<TResult>(string requestUri) where TResult : class;

		/// <summary>
		/// Posts the specified content to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <param name="body">The object to be serialized for the body content of the request, or preserialized data in the form of a string.</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		[SuppressMessage("Design", "CA1054:Uri parameters should not be strings", Justification = "Expected Url is partial and therefore not a valid Uri.")]
		Task<TResult> PostAsync<TResult>(string requestUri, object body) where TResult : class;

		/// <summary>
		/// Puts the specified content to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <param name="body">The object to be serialized for the body content of the request, or preserialized data in the form of a string.</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		[SuppressMessage("Design", "CA1054:Uri parameters should not be strings", Justification = "Expected Url is partial and therefore not a valid Uri.")]
		Task<TResult> PutAsync<TResult>(string requestUri, object body) where TResult : class;


		/// <summary>
		/// Submits a Delete Request to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		[SuppressMessage("Design", "CA1054:Uri parameters should not be strings", Justification = "Expected Url is partial and therefore not a valid Uri.")]
		Task<TResult> DeleteAsync<TResult>(string requestUri) where TResult : class;
	}
}
