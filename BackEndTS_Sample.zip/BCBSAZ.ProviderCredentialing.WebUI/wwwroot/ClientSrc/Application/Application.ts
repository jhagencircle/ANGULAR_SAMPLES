﻿import { Site } from "../Site/Site"
import { PageSelector } from "./PageSelector"
import moment = require("moment");
import { Degree } from "./Degree"
import { Specialty } from "./Specialties"
import { FileUpload } from "../Site/FileUpload"
import { OfficeHoursComponent } from "../Application/OfficeHoursComponent"
import { Select2Specialities } from "./Select2Specialities";


export module Application {
	let formId = "#provider-credential-form";
	let continueBtn = "#continue-btn";
	let goBackBtn = "#go-back-btn";
	let minAllowedDate: Date;
	let maxAllowedDate: Date;
	let futureMaxAllowedDate: Date;
	let today = new Date();
	let fileUploader: FileUpload = null;
	let mainOfficeHours: OfficeHoursComponent;
	let secondaryOfficeHours: OfficeHoursComponent;
	let fileIndex: number = 0;

	let id_attachmentBody = "#attachmentBody";

	let primaryStreet: string = "";
	let primaryCity: string = "";
	let primaryState: string = "";
	let primaryZip: string = "";
	let primaryPhone: string = "";
	let primaryFax: string = "";
	let primaryEmail: string = "";

	const _errorDialogOptions: JQueryUI.DialogOptions = {
		height: 300,
		width: 400,
		modal: true,
		buttons: { Ok: function () { $(this).dialog("close"); } }
	};

	export function initialize() {		
		setupTimePicker();
		PageSelector.initialize();
		setSignatureDate(); 
		setupDropdowns();
		fileUploader = new FileUpload(processFile, fileIndex);
		mainOfficeHours = new OfficeHoursComponent("#office-hours");
		secondaryOfficeHours = new OfficeHoursComponent("#secondary-office-hours");

		setTimeout(() => {
			setupDates();
			wireupEvents();
			$(":input").inputmask();
		}, 200);

		if (($("#SubmitFailure").val() as string).toLowerCase() === "true") {
			processSubmitFailure();
		}
		var specialitiesArray =[]
		
	Specialty.specialties.forEach((spec,index) =>{
			var dataSpec = new Select2Specialities();
			dataSpec.id = spec;
		dataSpec.text = spec;
		specialitiesArray.push(dataSpec);
			});
		
		$("#Form_OtherPracticingSpecialties").select2({
			data: specialitiesArray			
		});
		if ($("#selectedOtherPracticingSpeciality").val() != "")
			$("#Form_OtherPracticingSpecialties").val($("#selectedOtherPracticingSpeciality").val().toString().split(",")).trigger('change');
		
	}

	function wireupEvents() {
		$(continueBtn).click((event) => {
			event.preventDefault();
			moveToNextPage();
			pagingChecks();
		});

		$(goBackBtn).click((event) => {
			event.preventDefault();
			PageSelector.showPreviousPage();
		});

		$("#same-hours-as-primary").change((e) => sameHoursAsPrimaryChange(e));
		$("#additional-information-and-submit input[type='radio']").change((e) => { additionalOfficeChange(e); });
		$("#add-hours").click((e) => addOfficeHours(e, true));
		$("#secondary-add-hours").click((e) => addOfficeHours(e, false));
		$("#add-another-language").click((e) => addAnotherLanguage(e));
		$("#add-another-name").click((e) => addAnotherName(e));
		$("#caqh-confirmation input[type='radio']").change((e) => { showHideCaqhError(e) });
		$("#add-another-facility").click((e) => addAnotherFacility(e));
		$("#Form_Degree").change((e) => changeDegree(e, "#other-degree-input"));
		$("#Form_SupervisingPhysicianDegree").change((e) => changeDegree(e, "#supervising-other-degree"));
		$("#main-office").on('click', '.remove-hours', (e) => { removeOfficeHours(e, true); });
		$("#main-office-same-hours").click((e) => disableDayOfWeek(e, true));
		$("#secondary-office-same-hours").click((e) => disableDayOfWeek(e, false));
		$("input[name='Form.HasDeaRegistrationNumber']").change((e) => changeDea(e));
		$("#secondary-office").on('click', '.remove-hours', (e) => { removeOfficeHours(e, false); });
		$(".date-field").click(() => { $('#ui-datepicker-div').css('z-index', '0');}) /*this fixes the date picker showing up underneath the rest of the form*/

		$(`${formId} input, select, textarea`).blur((event) => { validateField(event); });

		$("#Form_UseSameForBilling").click(() => showHideAddress("Form_BillingAddress"));
		$("#Form_UseSameForMailing").click(() => showHideAddress("Form_MailingAddress"));
		$("#Form_UseSameForMedicalRecords").click(() => showHideAddress("Form_MedicalRecordsAddress"));
		$("#Form_UseSameForCredentialing").click(() => showHideAddress("Form_CredentialingAddress"));
		$("#Form_Signature").blur(() => setSignatureDate());
	}

	function processSubmitFailure() {
		var pageToShow: number = 5; // default to last page.
		var isError: boolean = (($("#NotValid").val() as string).toLowerCase() === "true");

		if (isError) {
			// TODO: Figure out where the first validation error is!
		}

		PageSelector.enableAllPages(pageToShow, isError);
		$("#errorModalContent").dialog(_errorDialogOptions);
	}

	function validateDateField(field: JQuery<any>) {
		field.valid();
	}

	function moveToNextPage() {
		var currentPageNum = PageSelector.currentPageNumber;
		var isValid = false;

		if (currentPageNum == 3)
			isValid = PageSelector.validatePage(() =>  mainOfficeHours.requireOfficeHours());
		else if (currentPageNum == 5)
			isValid = PageSelector.validatePage(() => $("#Form_HasAdditionalAddress").is(":checked") ? secondaryOfficeHours.requireOfficeHours() : true);
		else
			isValid = PageSelector.validatePage();

		if (!isValid)
			Site.scrollErrorIntoView(500);

		if (isValid && PageSelector.currentPageNumber < PageSelector.totalPages) {
			PageSelector.showNextPage();
		}
		else if (isValid && PageSelector.isLastPage()) {
			$(formId).submit();
		}
		else
			console.error("unknown error occurred when trying to continue to next page");	
	}


	function showHideCaqhError(e: JQuery.TriggeredEvent) {
		console.log(e.target.value);
		if (e.target.value == "false") {
			$("#caqh-contact-info-container").addClass("display-none");
			$("#not-cqha-registered-error").removeClass("display-none");
			$("#caqh-information-section").addClass("display-none");
			$("#flow-control-buttons").addClass("display-none");
		} else {
			$("#caqh-contact-info-container").removeClass("display-none");
			$("#not-cqha-registered-error").addClass("display-none");
			$("#caqh-information-section").removeClass("display-none");
			$("#flow-control-buttons").removeClass("display-none");
		}
	}

	function validateField(e: JQuery.TriggeredEvent) {
		$(e.target).valid();
	}

	function changeDea(e: JQuery.TriggeredEvent) {
		if (e.target.value === "true") {
			$("#dea-registration-info").removeClass("display-none");
			$("#Form_DeaRegistration_RegistrationNumber").attr("data-val-required", "DEA Registration Number is Required");
			$("#Form_DeaRegistration_RegistrationNumber").attr("data-val-regex", "Please enter a valid DEA Registration");
			$("#Form_DeaRegistration_RegistrationNumber").attr("data-val-regex-pattern", "^[a-zA-Z0-9]{9}$");
			$("#Form_DeaRegistration_RegistrationNumber").attr("data-val", "true");

			$("#Form_DeaRegistration_ExpirationDate").attr("data-val-required", "DEA Expiration Date is Required");
			$("#Form_DeaRegistration_ExpirationDate").attr("data-val-isdate","Please enter a valid Date");
			$("#Form_DeaRegistration_ExpirationDate").attr("data-val", "true");

			$("#Form_DeaRegistration_RegistrationNumber-error").html("");
			$("#Form_DeaRegistration_RegistrationNumber").removeClass("input-validation-error");
			$("#Form_DeaRegistration_ExpirationDate-error").html("");
			$("#Form_DeaRegistration_ExpirationDate").removeClass("input-validation-error");
		} else {
			$("#Form_DeaRegistration_RegistrationNumber").val("");
			$("#Form_DeaRegistration_RegistrationNumber").removeClass("valid");
			$("#Form_DeaRegistration_RegistrationNumber").removeAttr("data-val-regex");
			$("#Form_DeaRegistration_RegistrationNumber").removeAttr("data-val-regex-pattern");

			$("#Form_DeaRegistration_ExpirationDate").val("");
			$("#Form_DeaRegistration_ExpirationDate").removeClass("valid");
			$("#Form_DeaRegistration_ExpirationDate").removeAttr("data-val-required");
			$("#Form_DeaRegistration_ExpirationDate").removeAttr("data-val-isdate");

			$("#dea-registration-info").addClass("display-none");
			$("#dea-registration-info").find("input").removeAttr("data-val");
		}

		Site.reloadFormValidation(formId);
	}

	function additionalOfficeChange(e: JQuery.TriggeredEvent) {
		if (e.target.value == "false") {
			$("#additional-office-address-container").addClass("display-none");
			removedRequiredAttr("#additional-office-address-container");
		} else {
			$("#additional-office-address-container").removeClass("display-none");
			addRequiredAttr("#additional-office-address-container");
		}
		Site.reloadFormValidation(formId);
	}

	function removedRequiredAttr(container: string) {
		$(`${container} .required-optional`).removeAttr("data-val");

		$(`${container} .required-optional`).val("");
		$(`${container} .required-optional`).trigger("blur");
	}

	function addRequiredAttr(container: string) {
		$(`${container} .required-optional`).attr("data-val","true");		
	}

	function changeDegree(e: JQuery.TriggeredEvent, showField: string) {
		if ($(e.target).val() === "Other") {
			$(showField).removeClass("display-none");
			if ((`#${$(e.target).attr('id')}`) =="#Form_Degree") {
				$("#supervising-physician-degree").addClass("display-none");
			}
			
		}
		else if (((`#${$(e.target).attr('id')}`) == "#Form_Degree") && (($(e.target).val() === "PA") || ($(e.target).val() === "PA-C"))) {

			$(showField).addClass("display-none");
			$("#supervising-physician-degree").removeClass("display-none");

			$("#Form_SupervisingPhysicianName_FirstName").attr("data-val-required", "Supervising physician's first name is Required");
			$("#Form_SupervisingPhysicianName_LastName").attr("data-val-required", "Supervising physician's last name is Required");
			$("#Form_SupervisingPhysicianDegree").attr("data-val-required", "Supervising physician's degree is Required");
			$("#Form_SupervisingPhysicianDegree").attr("data-val", "true");
		}
		else {			
			$(showField).addClass("display-none");
			if ((`#${$(e.target).attr('id')}`) == "#Form_Degree") {
				$("#supervising-physician-degree").addClass("display-none");

				$("#Form_SupervisingPhysicianName_FirstName").removeAttr("data-val-required");
				$("#Form_SupervisingPhysicianName_LastName").removeAttr("data-val-required");
				$("#Form_SupervisingPhysicianDegree").removeAttr("data-val-required");
				$("#Form_SupervisingPhysicianDegree").removeAttr("data-val");
			}
		}
		Site.reloadFormValidation(formId);
	}



	function disableDayOfWeek(e: JQuery.TriggeredEvent, isPrimary: boolean) {
		var container = isPrimary ? "#main-office" : "#secondary-office";
		var officeHoursObj = isPrimary ? mainOfficeHours : secondaryOfficeHours;

		if ($(e.target).is(":checked")) {
			$(`${container} .day-of-week option`).filter((_, x) => { return $(x).val() < 6 && $(x).val() > 0}).attr("disabled", "true");
			$(`${container} .day-of-week`).val('6');
			officeHoursObj.sameHoursMondayThroughFriday();
		}
		else
			$(`${container} .day-of-week option`).removeAttr("disabled");
	}

	function setupDates() {
		minAllowedDate = moment(today).subtract(100, "year").toDate();
		maxAllowedDate = today;		
		futureMaxAllowedDate = moment(today).add("years", 100).toDate();

		var allDateFields = $(".date-field");

		$.each(allDateFields, (_, e) => {
			var shouldAllowFutureDate = $(e).attr("data-no-maxdate") == "true";
			var doNotAllowPrevDates = $(e).attr("data-mindate") == "today";
			var maxDate = shouldAllowFutureDate ? futureMaxAllowedDate : maxAllowedDate;
			var minDate = doNotAllowPrevDates ? today : minAllowedDate;
			Site.initializeDatePicker(`#${$(e).attr("id")}`, minDate, maxDate, validateDateField);

			//if($(e).attr("data-min-date"))

			$(e).attr("data-min-date", minDate.toDateString());
			$(e).attr("data-max-date", maxDate.toDateString())

			$(e).attr("data-val-maxdate", "Please enter a valid Date");
			$(e).attr("data-val-mindate", "Please enter a valid Date");			
			$(e).attr("data-val-isdate", "Please enter a valid Date");
		});

		Site.reloadFormValidation(formId);
	}

	function setSignatureDate() {
		$("#Form_DateTimeSigned").val(moment(new Date()).format("MM/DD/YYYY HH:mm:ss"));
	}

	function sameHoursAsPrimaryChange(e: JQuery.TriggeredEvent) {
		if ($(e.target).is(":checked")) {
			secondaryOfficeHours.setOfficeHours(mainOfficeHours.officeHours);

			$("#secondary-office .day-of-week").attr("disabled", "true");
			$("#secondary-office .start-time").attr("disabled", "true");
			$("#secondary-office .end-time").attr("disabled", "true");
			$("#secondary-office .btn-add-hours").attr("disabled", "true");
		} else {
			$("#secondary-office .day-of-week").removeAttr("disabled");
			$("#secondary-office .start-time").removeAttr("disabled");
			$("#secondary-office .end-time").removeAttr("disabled");
			$("#secondary-office .btn-add-hours").removeAttr("disabled");
		}
	}

	function addOfficeHours(e: JQuery.TriggeredEvent, isPrimary: boolean) {
		e.preventDefault();
		var container = isPrimary ? "#main-office" : "#secondary-office";
		var startTimeOptions = $(`${container} .start-time option`).toArray().map(x => $(x).val() as string);
		var endTimeOptions = $(`${container} .end-time option`).toArray().map(x => $(x).val() as string);
		var startTime = $(`${container} .start-time option:selected`)
		var endTime = $(`${container} .end-time option:selected`)
		var dayOfWeek = $(`${container} .day-of-week option:selected`);

		if (endTimeOptions.indexOf(endTime.text()) < startTimeOptions.indexOf(startTime.text())) {
			$(`${container} .error`).text("The end time cannot be before the start time");
			$(`${container} .start-time`).addClass("input-validation-error");
			$(`${container} .end-time`).addClass("input-validation-error");
		} else {
			$(`${container} .error`).text("");
			$(`${container} .start-time`).removeClass("input-validation-error");
			$(`${container} .end-time`).removeClass("input-validation-error");
			if (isPrimary) {
				mainOfficeHours.addOfficeHour(dayOfWeek.val() as string, startTime.text(), endTime.text());
				$("#main-office-same-hours").removeAttr("disabled");
			}
			else {
				secondaryOfficeHours.addOfficeHour(dayOfWeek.val() as string, startTime.text(), endTime.text());
				$("#secondary-office-same-hours").removeAttr("disabled");
			}
		}
	}

	function removeOfficeHours(e: JQuery.TriggeredEvent, isPrimary: boolean) {
		var rowId = $(e.target).closest(".hours").attr("data-row-id");

		if (isPrimary) {
			mainOfficeHours.removeOfficeHour(rowId);
		}
		else
			secondaryOfficeHours.removeOfficeHour(rowId);
	}

	function addAnotherLanguage(e: JQuery.TriggeredEvent) {
		e.preventDefault();

		console.log("Other Languages Input Val: '" + $("#otherLanguagesCount").val() + "'");

		var numLanguages = parseInt($("#otherLanguagesCount").val() as string);

		console.log("Other Languages parsed Val: '" + numLanguages + "'");

		var container = $("#other-languages").clone();
		container.find("input").attr("name", `Form.Languages[${numLanguages}].Name`);
		container.find("input").attr("id", `Form_Languages_${numLanguages}__Name`);
		container.find("input").removeAttr("value").val("");
		$("#other-languages-container").append(container);
		$("#otherLanguagesCount").val(++numLanguages);

		Site.reloadFormValidation(formId);
	}

	function addAnotherName(e: JQuery.TriggeredEvent) {
		e.preventDefault();
		$("#additional-name-row").removeClass("display-none");
		$("#add-another-name").addClass("display-none");

		Site.reloadFormValidation(formId);
	}

	function addAnotherFacility(e: JQuery.TriggeredEvent) {
		e.preventDefault();

		var facilityCount = parseInt($("#facilitiesCount").val() as string);
		var container = $("#facility-row").clone();
		container.find("label").attr("for", `Form_Facilities_${facilityCount}__Name`);
		container.find("input").attr("name", `Form.Facilities[${facilityCount}].Name`);
		container.find("input").attr("id", `Form_Facilities_${facilityCount}__Name`);
		container.find("select").attr("name", `Form.Facilities[${facilityCount}].Type`);
		container.find("select").attr("id", `Form_Facilities_${facilityCount}__Type`);
		container.find("select").attr("aria-describedby", `Form_Facilities_${facilityCount}__Type-error`);
		$(container.find("span")[0]).attr("id", `Form_Facilities_${facilityCount}__Name-error`);
		$(container.find("span")[1]).attr("id", `Form_Facilities_${facilityCount}__Type-error`);
		$(container.find("span")[0]).attr("data-valmsg-for", `Form.Facilities[${facilityCount}].Name`);
		$(container.find("span")[1]).attr("data-valmsg-for", `Form.Facilities[${facilityCount}].Type`);
		$("#facilities-container").append(container);
		$("#facilitiesCount").val(++facilityCount);

		Site.reloadFormValidation(formId);
	}

	function setupTimePicker() {
		Site.initializeTimePicker("#timepicker-start-time", "form-control-tertiary start-time", true);
		Site.initializeTimePicker("#timepicker-end-time", "form-control-tertiary end-time", true);
		Site.initializeTimePicker("#secondary-timepicker-start-time", "form-control-tertiary start-time", true);
		Site.initializeTimePicker("#secondary-timepicker-end-time", "form-control-tertiary end-time", true);
	}

	function processFile(file: any) {
		const oldIndex: number = fileIndex;
		$(`#fileRow_${oldIndex}`).show();
		$(`#fileDiv_${oldIndex}`).append(file[0].name);
		$(`#removeRow_${oldIndex}`).click((event) => {
			event.preventDefault();
			removeFile(oldIndex);
		});

		++fileIndex;
		const currentIndex: string = fileIndex.toString();
		const bodyHtml = `<tr id="fileRow_${fileIndex}" style="display: none;">
							<td id="fileDiv_${currentIndex}" class="uploaded-file-name"> <input type="file" id="fileInput_${currentIndex}" name="files" accept=".jpg,.jpeg,.pdf" style="display: none;" /></td>
							<td><button id="removeRow_${currentIndex}" class="remove-file"><img src="images/remove-hours.png" class="remove-file" /></button></td>
						 </tr>`;

		$(id_attachmentBody).append(bodyHtml);
		fileUploader.updateAddFilesButton();
	}

	function removeFile(idx: number) {
		$(`#fileRow_${idx}`).remove();
	}

	function pagingChecks() {
		billingAddressUpdated();
		showHideAdditionalOffice();
	}

	function billingAddressUpdated() {
		if (PageSelector.currentPageNumber === 4) {
			primaryStreet = $("#Form_PrimaryOfficeAddress_StreetAddress").val().toString();
			primaryCity = $("#Form_PrimaryOfficeAddress_City").val().toString();
			primaryState = $("#Form_PrimaryOfficeAddress_State").val().toString();
			primaryZip = $("#Form_PrimaryOfficeAddress_ZipCode").val().toString();
			primaryPhone = $("#Form_PrimaryOfficeAddress_Phone").val().toString();
			primaryFax = $("#Form_PrimaryOfficeAddress_Fax").val().toString();
			primaryEmail = $("#Form_PrimaryOfficeAddress_EmailAddress").val().toString();

			$("#addressHolderContainer").html(`${primaryStreet}<br />${primaryCity}, ${primaryState} ${primaryZip}`);
		}
	}
	
	function showHideAddress(id: string) {
		var containerId: string;
		var callerId: string;

		switch (id) {
			case "Form_BillingAddress":
				containerId = "#medica-address-container";
				callerId = "#Form_UseSameForBilling";
				break;
			case "Form_MailingAddress":
				containerId = "#mailing-address-container";
				callerId = "#Form_UseSameForMailing";
				break;
			case "Form_MedicalRecordsAddress":
				containerId = "#medical-records-address-container";
				callerId = "#Form_UseSameForMedicalRecords";
				break;
			case "Form_CredentialingAddress":
				containerId = "#credentialing-address-container";
				callerId = "#Form_UseSameForCredentialing";
				break;
		}

		if ($(callerId).is(":checked"))
			useSameAsPrimaryAddress(id, containerId);
		else
			showOldAddress(id, containerId);
	}

	function useSameAsPrimaryAddress(id: string, containerId: string) {
		$(containerId).hide();
		$(`#${id}_StreetAddress`).val(`${primaryStreet}`);
		$(`#${id}_City`).val(`${primaryCity}`);
		$(`#${id}_State`).val(`${primaryState}`);
		$(`#${id}_ZipCode`).val(`${primaryZip}`);
		$(`#${id}_Phone`).val(`${primaryPhone}`);
		$(`#${id}_Fax`).val(`${primaryFax}`);
		$(`#${id}_EmailAddress`).val(`${primaryEmail}`);
	}

	function showOldAddress(id: string, containerId: string) {
		$(containerId).show();
		$(`#${id}_StreetAddress`).val("");
		$(`#${id}_City`).val("");
		$(`#${id}_State`).val("");
		$(`#${id}_ZipCode`).val("");
		$(`#${id}_Phone`).val("");
		$(`#${id}_Fax`).val("");
		$(`#${id}_EmailAddress`).val("");
	}

	function showHideAdditionalOffice() {
		if (PageSelector.currentPageNumber === 5) {
			if ($("#Form_HasAdditionalAddress").is(":checked")) {
				$("#additional-office-address-container").removeClass("display-none");
				addRequiredAttr("#additional-office-address-container");
				addRequiredAttr("#secondary-office-hours");
			} else {
				$("#additional-office-address-container").addClass("display-none");
				removedRequiredAttr("#additional-office-address-container");
				removedRequiredAttr("#secondary-office-hours");
			}
			Site.reloadFormValidation(formId);
		}
	}

	function setupDropdowns() {
		Degree.degrees.forEach((deg) => {
			$("#Form_Degree, #Form_SupervisingPhysicianDegree").append(`<option value="${deg}">${deg}</option>`);
		});

		if (($("#SelectedDegree").val() as string) !== "")
			$("#Form_Degree").val($("#SelectedDegree").val());

		if (($("#SupervisingPhysicianSelectedDegree").val() as string) !== "")
			$("#Form_SupervisingPhysicianDegree").val($("#SupervisingPhysicianSelectedDegree").val());


		Specialty.specialties.forEach((spec) => {
			$("#Form_PracticingSpecialty").append(`<option value="${spec}">${spec}</option>`);
		});

		if (($("#SelectedSpecialty").val() as string) !== "")
			$("#Form_PracticingSpecialty").val($("#SelectedSpecialty").val());


		$("#Form_SupervisingPhysicianDegree option[value='PA'], #Form_SupervisingPhysicianDegree option[value='PA-C']").attr("disabled", "true");
	}
}