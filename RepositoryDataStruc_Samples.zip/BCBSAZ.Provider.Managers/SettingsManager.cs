﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Managers.RequestValidators.Settings;
using BCBSAZ.Provider.Models.Data.Settings;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Requests.Settings;
using BCBSAZ.Provider.Models.Responses.Settings;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers
{
	public class SettingsManager : ISettingsManager
	{
		private readonly ISettingsRepository _settingsRepository;

		public SettingsManager(ISettingsRepository settingsRepository) =>
			_settingsRepository = settingsRepository;

		#region Setting Values
		public const int MaxAge = 125;

		public Task<SettingValue> GetSettingValueAsync(string settingName, string defaultValue, WebUser webUser) =>
			_settingsRepository.GetSettingValueAsync(Constants.Settings.ProviderApplication, settingName, Constants.Settings.OrgIdFieldName, webUser.OrgId, webUser.UserId, defaultValue);

		public async Task<SettingValueResponse> GetSettingValueAsync(SettingValueRequest request)
		{
			request.Validate();

			return new SettingValueResponse()
			{
				Setting = await _settingsRepository.GetSettingValueAsync(request.ApplicationName, request.SettingName, request.FieldName, request.FieldValue, request.UserId, request.DefaultValue)
			};
		}

		public async Task<FeatureToggleResponse> IsFeatureEnabledAsync(SettingValueRequest request)
		{
			var setting = await _settingsRepository.GetSettingValueAsync(request.ApplicationName, request.SettingName, request.FieldName, request.FieldValue, request.UserId, request.DefaultValue);
			return new FeatureToggleResponse()
			{
				SettingId = setting.SettingId,
				SettingName = setting.Name,
				IsEnabled = setting.AsEnum<FeatureToggle>() == FeatureToggle.Enabled
			};
		}

		public async Task<FeatureToggleResponse> IsBetaLinkEnabledAsync(SettingValueRequest request)
		{
			var setting = await _settingsRepository.GetSettingValueAsync(request.ApplicationName, request.SettingName, request.FieldName, request.FieldValue, request.UserId, request.DefaultValue);
			return new FeatureToggleResponse()
			{
				SettingId = setting.SettingId,
				SettingName = setting.Name,
				IsEnabled = setting.AsEnum<FeatureToggle>() == FeatureToggle.BetaLink
			};
		}

		#endregion

		#region Settings

		public async Task<AllSettingsResponse> GetSettingsForApplicationAsync(AllSettingsRequest request)
		{
			request.Validate();

			return new AllSettingsResponse()
			{
				Settings = await _settingsRepository.GetSettingsForApplicationAsync(request.ApplicationName, request.SettingTypeId)
			};
		}

		public async Task<SettingResponse> GetSettingAsync(GetSettingRequest request)
		{
			request.Validate();

			return new SettingResponse()
			{
				Setting = await _settingsRepository.GetSettingAsync(request.SettingId)
			};
		}

		public async Task<SettingResponse> AddSettingAsync(AddSettingRequest request)
		{
			request.Validate();

			return new SettingResponse()
			{
				Setting = await _settingsRepository.AddSettingAsync(request.Setting)
			};
		}

		public async Task<SettingResponse> UpdateSettingsAsync(UpdateSettingRequest request)
		{
			request.Validate();

			return new SettingResponse()
			{
				Setting = await _settingsRepository.UpateSettingAsync(request.Setting)
			};
		}

		public async Task<DeleteSettingResponse> DeleteSettingAsync(DeleteSettingRequest request)
		{
			request.Validate();

			await _settingsRepository.DeleteSettingAsync(request.SettingId);

			return new DeleteSettingResponse();
		}

		#endregion

		#region User Type Settings

		public async Task<AllUserTypeSettingsResponse> GetAllUserTypeSettingsAsync(GetAllUserTypeSettingsRequest request)
		{
			request.Validate();

			return new AllUserTypeSettingsResponse()
			{
				UserTypeSettings = await _settingsRepository.GetAllUserTypeSettingsAsync(request.SettingId)
			};
		}

		public async Task<UserTypeSettingResponse> GetUserTypeSettingAsync(GetUserTypeSettingRequest request)
		{
			request.Validate();

			return new UserTypeSettingResponse()
			{
				UserTypeSetting = await _settingsRepository.GetUserTypeSettingAsync(request.UserTypeSettingId)
			};
		}

		public async Task<UserTypeSettingResponse> AddUserTypeSettingAsync(AddUserTypeSettingRequest request)
		{
			request.Validate();

			return new UserTypeSettingResponse()
			{
				UserTypeSetting = await _settingsRepository.AddUserTypeSettingAsync(request.UserTypeSetting)
			};
		}

		public async Task<UserTypeSettingResponse> UpdateUserTypeSettingsAsync(UpdateUserTypeSettingRequest request)
		{
			request.Validate();

			return new UserTypeSettingResponse()
			{
				UserTypeSetting = await _settingsRepository.UpdateUserTypeSettingsAsync(request.UserTypeSetting)
			};
		}

		public async Task<DeleteUserTypeSettingResponse> DeleteUserTypeSettingAsync(DeleteUserTypeSettingRequest request)
		{
			request.Validate();

			await _settingsRepository.DeleteUserTypeSettingAsync(request.UserTypeSettingId);

			return new DeleteUserTypeSettingResponse();
		}

		#endregion

		#region User Settings

		public async Task<AllUserSettingsResponse> GetAllUserSettingsAsync(GetAllUserSettingsRequest request)
		{
			request.Validate();

			return new AllUserSettingsResponse()
			{
				UserSettings = await _settingsRepository.GetAllUserSettingsAsync(request.SettingId)
			};
		}

		public async Task<UserSettingResponse> GetUserSettingAsync(GetUserSettingRequest request)
		{
			request.Validate();

			return new UserSettingResponse()
			{
				UserSetting = await _settingsRepository.GetUserSettingAsync(request.UserSettingId)
			};
		}

		public async Task<UserSettingResponse> AddUserSettingAsync(AddUserSettingRequest request)
		{
			request.Validate();

			return new UserSettingResponse()
			{
				UserSetting = await _settingsRepository.AddUserSettingAsync(request.UserSetting)
			};
		}

		public async Task<UserSettingResponse> UpdateUserSettingsAsync(UpdateUserSettingRequest request)
		{
			request.Validate();

			return new UserSettingResponse()
			{
				UserSetting = await _settingsRepository.UpdateUserSettingsAsync(request.UserSetting)
			};
		}

		public async Task<DeleteUserSettingResponse> DeleteUserSettingAsync(DeleteUserSettingRequest request)
		{
			request.Validate();

			await _settingsRepository.DeleteUserSettingAsync(request.UserSettingId);

			return new DeleteUserSettingResponse();
		}

		#endregion

		#region Setting Types

		public async Task<AllSettingTypesResponse> GetSettingTypesAsync()
		{
			return new AllSettingTypesResponse()
			{
				SettingTypes = await _settingsRepository.GetSettingTypesAsync()
			};
		}

		#endregion

		#region Setting Applications

		public async Task<AllSettingApplicationsResponse> GetSettingApplicationsAsync()
		{
			return new AllSettingApplicationsResponse()
			{
				 Applications= await _settingsRepository.GetSettingApplicationsAsync()
			};
		}

		public async Task<SettingApplicationResponse> UpdateSettingApplicationAsync(UpdateSettingApplicationRequest request)
		{
			request.Validate();

			return new SettingApplicationResponse()
			{
				 Application = await _settingsRepository.UpdateSettingApplicationAsync(request.Application)
			};
		}
		#endregion

	}
}
