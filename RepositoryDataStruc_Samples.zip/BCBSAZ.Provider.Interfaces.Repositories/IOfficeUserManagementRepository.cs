﻿using System;
using System.Collections.Generic;
using System.Text;
using BCBSAZ.Provider.Models.Data.OfficeUserManagement;
using BCBSAZ.Provider.Models.Enums.OfficeUserManagement;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IOfficeUserManagementRepository
	{
		UserSummary[] GetOrgUsers(string orgId);
		UserProfile GetUserProfile(string userId);
		void InsertUserProfile(string createdBy, string orgId, UserProfile userProfile, string passwordHash, string answerHash);
		void UpdateUserProfile(UserProfile userProfile, string passwordHash);
		void DeleteUserProfile(string orgId, string userId);
		void SetProvidersForUser(string orgId, string subOrg, string userId, IEnumerable<AssignedProvider> providers);
		AssignedProvider[] GetProvidersForUser(string orgId, string subOrg, string userId);


		SubOrgSummary[] GetSubOrgs(string orgId);
		SubOrg GetSubOrg(string orgId, string subOrg);
		void DeleteSubOrg(string orgId, string subOrg);
		void UpdateSubOrg(string orgId, SubOrg subOrg);
		void InsertSubOrg(string orgId, SubOrg subOrg);
		UserSummary[] GetSubOrgUsers(string orgId, string subOrg);
		void SetProvidersForSubOrg(string orgId, string subOrg, IEnumerable<AssignedProvider> providers);
		AssignedProvider[] GetProvidersForSubOrg(string orgId, string subOrg);
	}
}
