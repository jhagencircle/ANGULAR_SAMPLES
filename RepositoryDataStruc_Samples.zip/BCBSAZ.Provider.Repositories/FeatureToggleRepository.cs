﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.FeatureToggles;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using TogEnviron = BCBSAZ.Provider.Models.Data.FeatureToggles.Environment;

namespace BCBSAZ.Provider.Repositories
{
	public class FeatureToggleRepository : IFeatureToggleRepository
	{
		private readonly IMemberFeaturesContext _context;
		private readonly IMemoryCache _memoryCache;

		public FeatureToggleRepository(IMemberFeaturesContext context, IMemoryCache memoryCache)
		{
			_context = context;
			_memoryCache = memoryCache;
		}

		protected Application[] Applications
		{
			get => _memoryCache.GetOrCreate(Constants.CacheKeys.FeatureToggleApplications, Constants.Cache.SlidingFourHours(), GetApplications);
		}

		private Application[] GetApplications()
		{
			return _context.Applications.FromSqlRaw(DB.FeatureToggle.StoredProcs.GetApplications).AsEnumerable().ToArray();
		}

		protected TogEnviron[] Environments
		{
			get => _memoryCache.GetOrCreate(Constants.CacheKeys.FeatureToggleEnvironments, Constants.Cache.SlidingFourHours(), GetEnvironments);
		}

		private TogEnviron[] GetEnvironments()
		{
			return _context.Environments.FromSqlRaw(DB.FeatureToggle.StoredProcs.GetEnvironments).AsEnumerable().ToArray();
		}

		public FeatureToggle[] GetFeatureToggles(string applicationName, string environmentName)
		{
			var applicationId = (from a in Applications
													 where a.ApplicationName.Equals(applicationName, StringComparison.OrdinalIgnoreCase)
													 select a.ApplicationId).FirstOrDefault();

			var environmentId = (from e in Environments
													 where e.EnvironmentName.Equals(environmentName, StringComparison.OrdinalIgnoreCase)
													 select e.EnvironmentId).FirstOrDefault();

			return _context.FeatureToggles.FromSqlRaw(DB.FeatureToggle.StoredProcs.GetFeatureToggles, environmentId, applicationId).AsEnumerable().ToArray();
		}
	}
}
