﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.ApiClients;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Home;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Responses.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace BCBSAZ.ProviderCredentialing.WebUI.Controllers
{
	public class HomeController : Controller
	{
		private static class SitecoreKeys
		{
			public static readonly string[] Bullets = {
				"First Bullet",
				"Second Bullet",
				"Third Bullet",
				"Fourth Bullet"
			};

			public const string MainHeader = "Gray Header - Get Started";
			public const string SubHeader = "Info Header";
			public const string Note = "Please Note";
		}

		public async Task<IActionResult> Index([FromServices]ISitecoreWebClient sitecore)
		{
			var translations = TranslateTexts(sitecore);

			await Task.WhenAll(translations.Select(t => t.Task));

			var viewModel = new IndexViewModel()
			{
				BulletPoints = (
					from t in translations
					where SitecoreKeys.Bullets.Contains(t.Key)
					select t.Task.Result
				).ToArray(),

				MainHeader = (
					from t in translations
					where t.Key == SitecoreKeys.MainHeader
					select t.Task.Result
				).FirstOrDefault(),

				SubHeader = (
					from t in translations
					where t.Key == SitecoreKeys.SubHeader
					select t.Task.Result
				).FirstOrDefault(),

				Note = (
					from t in translations
					where t.Key == SitecoreKeys.Note
					select t.Task.Result
				).FirstOrDefault()

			};

			return View(viewModel);
		}

		public IEnumerable<(string Key, Task<string> Task)> TranslateTexts(ISitecoreWebClient sitecore)
		{
			foreach (var bullet in SitecoreKeys.Bullets)
			{
				yield return (bullet, sitecore.TranslateTextAsync(bullet));
			}

			yield return (SitecoreKeys.MainHeader, sitecore.TranslateTextAsync(SitecoreKeys.MainHeader));
			yield return (SitecoreKeys.SubHeader, sitecore.TranslateTextAsync(SitecoreKeys.SubHeader));
			yield return (SitecoreKeys.Note, sitecore.TranslateTextAsync(SitecoreKeys.Note));
		}

		[HttpGet("Test")]
		public async Task<TestResponse> GetTest([FromServices]IConfiguration config, [FromServices]IHostEnvironment host, [FromServices]IWebApiClient webApiClient)
		{
			TestResponse retVal;

			try
			{
				retVal = await webApiClient.GetAsync<TestResponse>("api/v1/common/test");
			}
			catch (Exception ex)
			{
				retVal = new TestResponse()
				{
					ApiEnvironment = "Unknown",
					ApiVersion = "Unknown",
					ApiDescription = $"{ex.GetType().FullName}: {ex.Message}"
				};
			}

			retVal.WebEnvironment = host.EnvironmentName;
			retVal.WebDescription = config.GetValue<string>("TestValue");
			retVal.WebVersion = GetAssemblyVersion();

			return retVal;
		}

		[HttpGet("Fail")]
		public TestResponse GetError()
		{
			throw new InvalidOperationException();
		}

		[HttpGet("ApiFail")]
		public Task<TestResponse> GetApiError([FromServices]IWebApiClient webApiClient)
		{
			return webApiClient.GetAsync<TestResponse>("credentialing/api/v1/common/fail");
		}

		private string GetAssemblyVersion()
		{
			var assembly = typeof(HomeController).Assembly;
			var attr = assembly.GetCustomAttribute<AssemblyFileVersionAttribute>();

			return attr?.Version ?? string.Empty;
		}

		public IActionResult Privacy()
		{
			return View();
		}
	}
}