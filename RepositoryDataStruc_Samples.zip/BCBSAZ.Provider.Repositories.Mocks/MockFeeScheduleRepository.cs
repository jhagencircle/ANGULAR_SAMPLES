﻿using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Requests.FeeSchedule;
using BCBSAZ.Provider.Models.Data.FeeSchedule;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.Common;

namespace BCBSAZ.Provider.Repositories.Mocks
{
	/// <summary>
	/// Defines a Mock Fee Schedule Repository used for testing purposes.
	/// </summary>
	public class MockFeeScheduleRepository : Mock<IFeeScheduleRepository>, IFeeScheduleRepository
	{
		/// <summary>
		/// Creates a Mock Fee Schedule Repository with default data for Professional Fees and Outpatient Fees
		/// </summary>
		public MockFeeScheduleRepository() : this(GetProfessionalFeesResultMockData, GetOutpatientFeesMockData) { }

		/// <summary>
		/// Creates a Mock Fee Schedule Repository with Professional Fee data provided by the specified function.
		/// </summary>
		/// <param name="professionalMockFunc">The function which will provide mock data for Professional Fees.</param>
		public MockFeeScheduleRepository(Func<ProfessionalFee[]> professionalMockFunc) : this(professionalMockFunc, null) { }

		/// <summary>
		/// Creates a Mock Fee Schedule Repository with Outpatient Fee data provided by the specified function.
		/// </summary>
		/// <param name="outpatientMockFunc">The function which will provide mock data for Outpatient Fees.</param>
		public MockFeeScheduleRepository(Func<OutpatientFee[]> outpatientMockFunc) : this(null, outpatientMockFunc) { }

		/// <summary>
		/// Creates a Mock Fee Schedule Repository with Professional and Outpatient Fee data provided by the specified functions.
		/// </summary>
		/// <param name="professionalMockFunc">The function which will provide mock data for Professional Fees.</param>
		/// <param name="outpatientMockFunc">The function which will provide mock data for Outpatient Fees.</param>
		public MockFeeScheduleRepository(Func<ProfessionalFee[]> professionalMockFunc, Func<OutpatientFee[]> outpatientMockFunc)
		{
			if (professionalMockFunc != null)
			{
				Setup(mock => mock
					.GetProfessionalFees(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
					.Returns(professionalMockFunc());
			}

			if (outpatientMockFunc != null)
			{
				Setup(mock => mock
					.GetOutpatientFees(It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
					.Returns(outpatientMockFunc());
			}
		}

		/// <summary>
		/// Default Mock Data for Professional Fees
		/// </summary>
		/// <returns></returns>
		private static ProfessionalFee[] GetProfessionalFeesResultMockData()
		{
			return ProfessionalFeesMockData.ToArray();
		}

		private static IEnumerable<ProfessionalFee> ProfessionalFeesMockData
		{
			get
			{
				#region Professional Non-Facility
				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9039",
					Description = "(Mocked) Injection, Blinatumobmab, 1 microgram",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 131.98m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "1N",
					SiteCode = "PNF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9041",
					Description = "(Mocked) Inj, Bortezomb, 0.1 mg",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 57.85m,
					ProfFee = 198.93m,
					TechnicalFee = 57.85m,
					Region = "1N",
					SiteCode = "PNF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9042",
					Description = "(Mocked) Injection, Brentuximab Vedotin, 1 mg",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 177.58m,
					ProfFee = decimal.Zero,
					TechnicalFee = 177.58m,
					Region = "1N",
					SiteCode = "PNF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9043",
					Description = "(Mocked) Injection, Cabazitaxel, 1 mg",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 198.93m,
					ProfFee = 57.85m,
					TechnicalFee = 198.93m,
					Region = "1N",
					SiteCode = "PNF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};
				#endregion

				#region Professional Non-ASCFacility
				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9039",
					Description = "(Mocked) Injection, Blinatumobmab, 1 microgram",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 132.98m,
					ProfFee = 1.00m,
					TechnicalFee = 1.00m,
					Region = "1F",
					SiteCode = "NAF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9041",
					Description = "(Mocked) Inj, Bortezomb, 0.1 mg",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 58.85m,
					ProfFee = 199.93m,
					TechnicalFee = 58.85m,
					Region = "1F",
					SiteCode = "NAF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9042",
					Description = "(Mocked) Injection, Brentuximab Vedotin, 1 mg",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 178.58m,
					ProfFee = 1.00m,
					TechnicalFee = 178.58m,
					Region = "1F",
					SiteCode = "NAF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9043",
					Description = "(Mocked) Injection, Cabazitaxel, 1 mg",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 199.93m,
					ProfFee = 58.85m,
					TechnicalFee = 199.93m,
					Region = "1F",
					SiteCode = "NAF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};
				#endregion

				#region Professional ASCFacility
				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9039",
					Description = "(Mocked) Injection, Blinatumobmab, 1 microgram",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 133.98m,
					ProfFee = 2.00m,
					TechnicalFee = 2.00m,
					Region = "ASC",
					SiteCode = "PAF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9041",
					Description = "(Mocked) Inj, Bortezomb, 0.1 mg",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 59.85m,
					ProfFee = 200.93m,
					TechnicalFee = 59.85m,
					Region = "ASC",
					SiteCode = "PAF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9042",
					Description = "(Mocked) Injection, Brentuximab Vedotin, 1 mg",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 179.58m,
					ProfFee = 2.00m,
					TechnicalFee = 179.58m,
					Region = "ASC",
					SiteCode = "PAF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "J9043",
					Description = "(Mocked) Injection, Cabazitaxel, 1 mg",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 200.93m,
					ProfFee = 58.85m,
					TechnicalFee = 200.93m,
					Region = "ASC",
					SiteCode = "PAF",
					TermDate = null,
					TreatmentType = "M",
					IsDME = false
				};
				#endregion

				#region DME: Professional Non-Facility
				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4233",
					Description = "(Mocked) REPLACE BATTERY ALKALINE W/HOME BLOOD GLUCOSE MONITOR OWNED BY PATIENT EACH",
					EffectiveDate = new DateTime(2017, 04, 01),
					TotalFee = 10.66m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "1N",
					SiteCode = "PNF",
					TermDate = null,
					TreatmentType = "J",
					IsDME = true
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4233",
					Description = "(Mocked) REPLACE BATTERY ALKALINE W/HOME BLOOD GLUCOSE MONITOR OWNED BY PATIENT EACH",
					EffectiveDate = new DateTime(2017, 04, 01),
					TotalFee = 0.66m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "1N",
					SiteCode = "PNF",
					TermDate = null,
					TreatmentType = "L",
					IsDME = true
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4234",
					Description = "(Mocked) REPLACE BATTERY ALKALINE J CELW/HOME BLOOD GLUCOSE MONITOR OWNED BY PT EACH",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 13.04m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "1N",
					SiteCode = "PNF",
					TermDate = null,
					TreatmentType = "J",
					IsDME = true
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4234",
					Description = "(Mocked) REPLACE BATTERY ALKALINE J CELW/HOME BLOOD GLUCOSE MONITOR OWNED BY PT EACH",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 3.04m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "1N",
					SiteCode = "PNF",
					TermDate = null,
					TreatmentType = "L",
					IsDME = true
				};
				#endregion

				#region DME: Professional Non-ASCFacility
				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4233",
					Description = "(Mocked) REPLACE BATTERY ALKALINE W/HOME BLOOD GLUCOSE MONITOR OWNED BY PATIENT EACH",
					EffectiveDate = new DateTime(2017, 04, 01),
					TotalFee = 11.66m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "1F",
					SiteCode = "NAF",
					TermDate = null,
					TreatmentType = "J",
					IsDME = true
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4233",
					Description = "(Mocked) REPLACE BATTERY ALKALINE W/HOME BLOOD GLUCOSE MONITOR OWNED BY PATIENT EACH",
					EffectiveDate = new DateTime(2017, 04, 01),
					TotalFee = 1.66m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "1F",
					SiteCode = "NAF",
					TermDate = null,
					TreatmentType = "L",
					IsDME = true
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4234",
					Description = "(Mocked) REPLACE BATTERY ALKALINE J CELW/HOME BLOOD GLUCOSE MONITOR OWNED BY PT EACH",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 4.04m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "1F",
					SiteCode = "NAF",
					TermDate = null,
					TreatmentType = "J",
					IsDME = true
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4234",
					Description = "(Mocked) REPLACE BATTERY ALKALINE J CELW/HOME BLOOD GLUCOSE MONITOR OWNED BY PT EACH",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 14.04m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "1F",
					SiteCode = "NAF",
					TermDate = null,
					TreatmentType = "L",
					IsDME = true
				};
				#endregion

				#region DME: Professional ASCFacility
				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4233",
					Description = "(Mocked) REPLACE BATTERY ALKALINE W/HOME BLOOD GLUCOSE MONITOR OWNED BY PATIENT EACH",
					EffectiveDate = new DateTime(2017, 04, 01),
					TotalFee = 12.66m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "ASC",
					SiteCode = "PAF",
					TermDate = null,
					TreatmentType = "J",
					IsDME = true
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4233",
					Description = "(Mocked) REPLACE BATTERY ALKALINE W/HOME BLOOD GLUCOSE MONITOR OWNED BY PATIENT EACH",
					EffectiveDate = new DateTime(2017, 04, 01),
					TotalFee = 2.66m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "ASC",
					SiteCode = "PAF",
					TermDate = null,
					TreatmentType = "L",
					IsDME = true
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4234",
					Description = "(Mocked) REPLACE BATTERY ALKALINE J CELW/HOME BLOOD GLUCOSE MONITOR OWNED BY PT EACH",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 15.04m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "ASC",
					SiteCode = "PAF",
					TermDate = null,
					TreatmentType = "J",
					IsDME = true
				};

				yield return new ProfessionalFee()
				{
					ProcedureCode = "A4234",
					Description = "(Mocked) REPLACE BATTERY ALKALINE J CELW/HOME BLOOD GLUCOSE MONITOR OWNED BY PT EACH",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 5.04m,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero,
					Region = "ASC",
					SiteCode = "PAF",
					TermDate = null,
					TreatmentType = "L",
					IsDME = true
				};
				#endregion
			}
		}

		/// <summary>
		/// Default Mock Data for Outpatient Fees
		/// </summary>
		/// <returns></returns>
		private static OutpatientFee[] GetOutpatientFeesMockData()
		{
			return OutpatientFeeMockData.ToArray();
		}

		private static IEnumerable<OutpatientFee> OutpatientFeeMockData
		{
			get
			{
				#region OPC
				yield return new OutpatientFee()
				{
					ProcedureCode = "J9039",
					Description = "(Mocked) Injection, Blinatumobmab, 1 microgram",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 131.98m,
					Region = "OPC",
					SiteCode = "OP",
					TermDate = null
				};

				yield return new OutpatientFee()
				{
					ProcedureCode = "J9041",
					Description = "(Mocked) Inj, Bortezomb, 0.1 mg",
					EffectiveDate = new DateTime(2017, 01, 01),
					TotalFee = 57.85m,
					Region = "OPC",
					SiteCode = "OP",
					TermDate = null
				};

				yield return new OutpatientFee()
				{
					ProcedureCode = "J9042",
					Description = "(Mocked) Injection, Brentuximab Vedotin, 1 mg",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 177.58m,
					Region = "OPC",
					SiteCode = "OP",
					TermDate = null
				};

				yield return new OutpatientFee()
				{
					ProcedureCode = "J9043",
					Description = "(Mocked) Injection, Cabazitaxel, 1 mg",
					EffectiveDate = new DateTime(2018, 04, 01),
					TotalFee = 198.93m,
					Region = "OPC",
					SiteCode = "OP",
					TermDate = null
				};
				#endregion
			}
		}

		///// <summary>
		///// Default Mock Data for Outpatient Fees
		///// </summary>
		///// <returns></returns>
		//private static AscFee[] GetAscFeesMockData()
		//{
		//	return AscFeesMockData.ToArray();
		//}

		//private static IEnumerable<AscFee> AscFeesMockData
		//{
		//	get
		//	{
		//		#region ASC
		//		yield return new AscFee()
		//		{
		//			ProcedureCode = "J9039",
		//			Description = "(Mocked) Injection, Blinatumobmab, 1 microgram",
		//			EffectiveDate = new DateTime(2018, 04, 01),
		//			TotalFee = 131.98m,
		//			Region = "ASC",
		//			SiteCode = "ASC",
		//			TermDate = null
		//		};

		//		yield return new AscFee()
		//		{
		//			ProcedureCode = "J9041",
		//			Description = "(Mocked) Inj, Bortezomb, 0.1 mg",
		//			EffectiveDate = new DateTime(2017, 01, 01),
		//			TotalFee = 57.85m,
		//			Region = "ASC",
		//			SiteCode = "ASC",
		//			TermDate = null
		//		};

		//		yield return new AscFee()
		//		{
		//			ProcedureCode = "J9042",
		//			Description = "(Mocked) Injection, Brentuximab Vedotin, 1 mg",
		//			EffectiveDate = new DateTime(2018, 04, 01),
		//			TotalFee = 177.58m,
		//			Region = "ASC",
		//			SiteCode = "ASC",
		//			TermDate = null
		//		};

		//		yield return new AscFee()
		//		{
		//			ProcedureCode = "J9043",
		//			Description = "(Mocked) Injection, Cabazitaxel, 1 mg",
		//			EffectiveDate = new DateTime(2018, 04, 01),
		//			TotalFee = 198.93m,
		//			Region = "ASC",
		//			SiteCode = "ASC",
		//			TermDate = null
		//		};
		//		#endregion
		//	}
		//}

		///// <summary>
		///// Default Mock Data for Provider TaxId's
		///// </summary>
		///// <returns></returns>
		//private static IEnumerable<ProviderTaxId> GetTaxIdsForProviderAndOrgAsyncMockData()
		//{
		//	yield return new ProviderTaxId() { TaxId = "651205795" };
		//	yield return new ProviderTaxId() { TaxId = "651205796" };
		//	yield return new ProviderTaxId() { TaxId = "651205797" };
		//	yield return new ProviderTaxId() { TaxId = "651205798" };
		//	yield return new ProviderTaxId() { TaxId = "651205799" };
		//}

		//private static IEnumerable<Specialty> GetSpecialtiesMockData()
		//{
		//	yield return new Specialty() { SpecialtyId = "101", Description = "Mock Specialty 101" };
		//	yield return new Specialty() { SpecialtyId = "102", Description = "Mock Specialty 102" };
		//	yield return new Specialty() { SpecialtyId = "103", Description = "Mock Specialty 103" };
		//	yield return new Specialty() { SpecialtyId = "104", Description = "Mock Specialty 104" };
		//	yield return new Specialty() { SpecialtyId = "105", Description = "Mock Specialty 105" };
		//}


		/// <summary>
		/// Gets Mocked Professional Fee Schedules 
		/// </summary>
		/// <param name="request">A validated Professional Fees Request</param>
		/// <returns>A result object containing the Professional Fees grouped by Site of Service and DME from the configured Mock Data</returns>
		public ProfessionalFee[] GetProfessionalFees(string providerId, string taxId, DateTime? searchDate, string specialty, string procedureCodes, string siteOfServiceCodes, bool isHistoric)
		{
			return Object.GetProfessionalFees(providerId, taxId, searchDate, specialty, procedureCodes, siteOfServiceCodes, isHistoric);
		}

		/// <summary>
		/// Gets Mocked Outpatient Fee Schedules
		/// </summary>
		/// <param name="request">A validated Outpatient Fees Request</param>
		/// <returns>A result object containing the Outpatient Fees grouped by Site of Service from the configured Mock Data</returns>
		public OutpatientFee[] GetOutpatientFees(DateTime? searchDate, string specialty, string procedureCodes, string siteOfServiceCodes, bool isHistoric)
		{
			return Object.GetOutpatientFees(searchDate, specialty, procedureCodes, siteOfServiceCodes, isHistoric);
		}

		/// <summary>
		/// Gets Mocked Asc Fee Schedules
		/// </summary>
		/// <param name="request">A validated Asc Fees Request</param>
		/// <returns>A result object containing the Asc Fees grouped by Site of Service from the configured Mock Data</returns>
		public AscFee[] GetAscFees(DateTime? searchDate, string specialty, string procedureCodes, string siteOfServiceCodes, bool isHistoric)
		{
			return Object.GetAscFees(searchDate, specialty, procedureCodes, siteOfServiceCodes, isHistoric);
		}

		public ProviderTaxId[] GetTaxIdsForProvider(string providerId, string orgId)
		{
			return Object.GetTaxIdsForProvider(providerId, orgId);
		}

		public Specialty[] GetSpecialties()
		{
			return Object.GetSpecialties();
		}
	}
}
