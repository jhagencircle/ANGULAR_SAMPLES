﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Settings;

namespace BCBSAZ.Provider.Managers.RequestValidators.Settings
{
	internal static class AllSettingsRequestValidator
	{
		public static void Validate(this AllSettingsRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(AllSettingsRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.ApplicationName))
				yield return new InvalidModelExceptionDetail(nameof(AllSettingsRequest.ApplicationName), new ArgumentException("Application Name is not valid."));

			if (request.SettingTypeId < 0)
				yield return new InvalidModelExceptionDetail(nameof(AllSettingsRequest.SettingTypeId), new ArgumentException("Setting Type is not valid."));
		}
	}
}
