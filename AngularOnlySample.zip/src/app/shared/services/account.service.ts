import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ISummary } from '../models/summary.model';
import { AppConstants } from '../constants/app-constants';

@Injectable({
  providedIn: 'root',
})
export class AccountService {
  private account = new BehaviorSubject<any>(null);

  constructor(private http: HttpClient) {
    const account = localStorage.getItem(
      AppConstants.ACCOUNT_LOCAL_STORAGE_KEY
    );
    if (account) {
      this.account.next(JSON.parse(account));
    }
  }
  update(account: ISummary) {
    localStorage.setItem(
      AppConstants.ACCOUNT_LOCAL_STORAGE_KEY,
      JSON.stringify(account)
    );
    this.account.next(account);
  }

  get(): Observable<ISummary> {
    return this.account.asObservable();
  }
}
