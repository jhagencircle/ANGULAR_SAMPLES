﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.PreCert;
using Medical = BCBSAZ.Provider.Models.Data.PreCert.Medical;
using Pharmacy = BCBSAZ.Provider.Models.Data.PreCert.Pharmacy;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IPreCertRepository
	{
		Task SaveFileAsync(UploadedFile file);

		Task SaveAllChangesAsync();


		Task<Medical.MedicalPreCert> GetMedicalPreCertByIdAsync(long preCertId);

		Task<Medical.Attachment> GetMedicalAttachmentByIdAsync(long medicalAttachmentId);


		Task<Pharmacy.PharmacyPreCert> GetPharmacyPreCertByIdAsync(long preCertId);

		Task<Pharmacy.Attachment> GetPharmacyAttachmentByIdAsync(long medicalAttachmentId);


		Task<UploadedFile> GetUploadedFileByIdAsync(long fileId);

		Task<string> GetUploadedFileHashAsync(long fileId);

		Task<string> GetEmailAddressForUserAsync(string userId);


		Medical.Summary[] ViewMedicalPreCertResults(string userId, string orgId, PreCertStatus status, DateTime fromDate, DateTime toDate, bool isInternal);

		Pharmacy.Summary[] ViewPharmacyPreCertResults(string userId, string orgId, PreCertStatus status, DateTime fromDate, DateTime toDate, bool isInternal);

		User[] GetUserNameByUserId(params string[] userIds);
	}
}
