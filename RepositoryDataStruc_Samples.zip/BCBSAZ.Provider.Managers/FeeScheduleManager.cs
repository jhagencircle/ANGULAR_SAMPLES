﻿using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Managers.RequestValidators;
using BCBSAZ.Provider.Managers.RequestValidators.FeeSchedule;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.FeeSchedule;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Requests.FeeSchedule;
using BCBSAZ.Provider.Models.Responses.FeeSchedule;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Managers
{
	/// <summary>
	/// Defines the Fee Schedule Manager
	/// </summary>
	public class FeeScheduleManager : IFeeScheduleManager
	{
		private IFeeScheduleRepository _repository;

		public FeeScheduleManager(IFeeScheduleRepository repository)
		{
			_repository = repository ?? throw new ArgumentNullException(nameof(repository));
		}

		#region GetProfessionalFees
		/// <summary>
		/// Gets Professional Fee Schedules 
		/// </summary>
		/// <param name="request">A validated Professional Fees Request</param>
		/// <returns>A result object containing the Professional Fees grouped by Site of Service and DME</returns>
		public ProfessionalFeesResponse GetProfessionalFees(ProfessionalFeesRequest request)
		{
			request.Validate();

			var fees = _repository.GetProfessionalFees(request.ProviderId, request.TaxId, request.SearchDate, request.Specialty, request.ProcedureCodes, request.SiteOfServiceCodes, request.IsHistoric);

			ApplyDiscount(fees, request.Discount);

			return new ProfessionalFeesResponse()
			{
				NonFacilityFees = fees.Where(IsProfessionalNonFacilityFee),
				ASCFacilityFees = fees.Where(IsProfessionalASCFacilityFee),
				NonASCFacilityFees = fees.Where(IsProfessionalNonASCFacilityFees),
				DMEFees = GetGeneralDMEFees(fees)
			};
		}

		private static bool IsProfessionalNonFacilityFee(ProfessionalFee fee) =>
			fee.SiteCode.Equals(ManagerConstants.FeeSchedule.ProfNonFacilityCode, StringComparison.OrdinalIgnoreCase) && !fee.IsDME;

		private static bool IsProfessionalASCFacilityFee(ProfessionalFee fee) =>
			fee.SiteCode.Equals(ManagerConstants.FeeSchedule.ProfASCFacilityCode, StringComparison.OrdinalIgnoreCase) && !fee.IsDME;

		private static bool IsProfessionalNonASCFacilityFees(ProfessionalFee fee) =>
			fee.SiteCode.Equals(ManagerConstants.FeeSchedule.ProfNonASCFacilityCode, StringComparison.OrdinalIgnoreCase) && !fee.IsDME;

		private static IEnumerable<DMEFee> GetGeneralDMEFees(IEnumerable<ProfessionalFee> fees)
		{
			var rentalFees = fees.Where(f => f.IsDME && f.TreatmentType == "L").ToList(); // Needs to be List so we can add records below.
			var purchaseFees = fees.Where(f => f.IsDME && f.TreatmentType == "J");
			var otherFees = fees.Where(f => f.IsDME && f.TreatmentType != "J" && f.TreatmentType != "L");

			// Linq doesn't support full outer joins...
			// so, we're going to make sure the first collection has all of the entries, then do our final Linq query
			rentalFees.AddRange(
				from p in purchaseFees
				join rr in rentalFees on GetProfessionalFeeCompositeKey(p) equals GetProfessionalFeeCompositeKey(rr) into rfees
				from r in rfees.DefaultIfEmpty()
				where r is null
				select new ProfessionalFee()
				{
					ProcedureCode = p.ProcedureCode,
					Description = p.Description,
					EffectiveDate = p.EffectiveDate,
					IsDME = p.IsDME,
					Region = p.Region,
					SiteCode = p.SiteCode,
					TermDate = p.TermDate,
					TreatmentType = p.TreatmentType,
					TotalFee = decimal.Zero,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero
				});

			rentalFees.AddRange(
				from o in otherFees
				join rr in rentalFees on GetProfessionalFeeCompositeKey(o) equals GetProfessionalFeeCompositeKey(rr) into rfees
				from r in rfees.DefaultIfEmpty()
				where r is null
				select new ProfessionalFee()
				{
					ProcedureCode = o.ProcedureCode,
					Description = o.Description,
					EffectiveDate = o.EffectiveDate,
					IsDME = o.IsDME,
					Region = o.Region,
					SiteCode = o.SiteCode,
					TermDate = o.TermDate,
					TreatmentType = o.TreatmentType,
					TotalFee = decimal.Zero,
					ProfFee = decimal.Zero,
					TechnicalFee = decimal.Zero
				});

			// Now that we've added the missing records to the first collection, we can simply do left joins
			return (
				from r in rentalFees
				join pf in purchaseFees on GetProfessionalFeeCompositeKey(r) equals GetProfessionalFeeCompositeKey(pf) into pFees
				join of in otherFees on GetProfessionalFeeCompositeKey(r) equals GetProfessionalFeeCompositeKey(of) into oFees
				from p in pFees.DefaultIfEmpty()
				from o in oFees.DefaultIfEmpty()
				select new DMEFee()
				{
					ProcedureCode = r.ProcedureCode,
					Description = r.Description,
					Region = r.Region,
					SiteCode = r.SiteCode,
					EffectiveDate = r.EffectiveDate,
					TermDate = r.TermDate,
					RentalFee = r.TotalFee,
					PurchaseFee = (p?.TotalFee ?? decimal.Zero),
					OtherFee = (o?.TotalFee ?? decimal.Zero)
				}).Distinct(new DMEComparer());
		}

		private class DMEComparer : IEqualityComparer<DMEFee>
		{
			public bool Equals(DMEFee x, DMEFee y)
			{
				return x.ProcedureCode.Equals(y.ProcedureCode, StringComparison.OrdinalIgnoreCase) &&
					x.RentalFee == y.RentalFee &&
					x.PurchaseFee == y.PurchaseFee &&
					x.EffectiveDate.Date == y.EffectiveDate.Date;
			}

			public int GetHashCode(DMEFee obj)
			{
				return $"{obj.ProcedureCode}|{obj.RentalFee}|{obj.PurchaseFee}|{obj.EffectiveDate:yyyyMMdd}".GetHashCode();
			}
		}

		private static string GetProfessionalFeeCompositeKey(ProfessionalFee fee)
		{
			return string.Format(CultureInfo.InvariantCulture, "{0}|{1}|{2}", fee.ProcedureCode, fee.Region, fee.EffectiveDate);
		}

		private static void ApplyDiscount(IEnumerable<ProfessionalFee> result, decimal discount)
		{
			if (discount == 1m)
				return;

			foreach (var fee in result)
			{
				fee.TotalFee *= discount;
				fee.ProfFee *= discount;
				fee.TechnicalFee *= discount;
			}
		}
		#endregion

		#region GetOutpatientFees
		/// <summary>
		/// Gets Outpatient Fee Schedules
		/// </summary>
		/// <param name="request">A validated Outpatient Fees Request</param>
		/// <returns>A result object containing the Outpatient Fees grouped by Site of Service</returns>
		public OutpatientFeesResponse GetOutpatientFees(OutpatientFeesRequest request)
		{
			request.Validate();

			var fees = _repository.GetOutpatientFees(request.SearchDate, request.Specialty, request.ProcedureCodes, request.SiteOfServiceCodes, request.IsHistoric);

			ApplyDiscount(fees, request.Discount);

			return new OutpatientFeesResponse()
			{
				Fees = fees
			};
		}

		private static void ApplyDiscount(IEnumerable<OutpatientFee> result, decimal discount)
		{
			if (discount == 1m)
				return;

			foreach (var fee in result)
			{
				fee.TotalFee *= discount;
			}
		}
		#endregion

		#region GetAscFees
		public AscFeesResponse GetAscFees(AscFeesRequest request)
		{
			request.Validate();

			var fees = _repository.GetAscFees(request.SearchDate, request.Specialty, request.ProcedureCodes, request.SiteOfServiceCodes, request.IsHistoric);

			ApplyDiscount(fees, request.Discount);

			return new AscFeesResponse()
			{
				Fees = fees
			};
		}

		private static void ApplyDiscount(IEnumerable<AscFee> result, decimal discount)
		{
			if (discount == 1m)
				return;

			foreach (var fee in result)
			{
				fee.TotalFee *= discount;
			}
		}
		#endregion

		public TaxIdsForProviderResponse GetTaxIdsForProvider(TaxIdsForProviderRequest request)
		{
			request.Validate();

			return new TaxIdsForProviderResponse()
			{
				ProviderTaxIds = _repository.GetTaxIdsForProvider(request.ProviderId, request.OrgId)
			};
		}

		public SpecialtiesResponse GetSpecialties(SpecialtiesRequest request)
		{
			request.Validate();

			return new SpecialtiesResponse()
			{
				Specialties = _repository.GetSpecialties()
			};
		}

	}
}
