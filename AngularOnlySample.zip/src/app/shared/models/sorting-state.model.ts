import { SortDirection } from './sortable.directive';

export interface ISortingState {
  sortColumn: any;
  sortDirection: SortDirection;
}
