﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Settings;

namespace BCBSAZ.Provider.Managers.RequestValidators.Settings
{
	internal static class GetUserSettingRequestValidator
	{
		public static void Validate(this GetUserSettingRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(GetUserSettingRequest request)
		{
			if (request.UserSettingId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(GetUserSettingRequest.UserSettingId), new ArgumentException("UserSettingId is not valid."));
		}
	}
}
