import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.scss'],
})
export class LogInComponent implements OnInit {
  constructor(public oktaAuth: OktaAuthService, private router: Router) { }

  formLogin: FormGroup = new FormGroup({
    username: new FormControl(''),
    password: new FormControl(''),
  });

  async ngOnInit() {
    await this.signIn();
  }

  async signIn() {
    this.oktaAuth.signInWithRedirect({
      originalUri: '/landing-page',
    });
    //We need to uncomment this when login in portal will be available
    // if (await this.isUserLogged()) {
    //   this.oktaAuth.signInWithRedirect({
    //     originalUri: '/landing-page',
    //   });
    // } else {
    //   window.location.href = environment.loginUrl;
    // }
  }

  private async isUserLogged() {
    const scopes = this.oktaAuth.options.scopes;
    const params = Object.assign({ scopes: scopes }, this.oktaAuth.options);
    try {
      //await this.oktaAuth.token.getWithoutPrompt(params);
      await this.oktaAuth.token.getWithPopup(params);
      return true;
    } catch {
      return false;
    }
  }
}
