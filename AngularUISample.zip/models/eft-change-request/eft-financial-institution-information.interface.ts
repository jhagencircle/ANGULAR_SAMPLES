export interface IFinancialInstitutionInformation {
    financialInstitutionName: string;
    financialInstitutionAddress: string;
    financialInstitutionCity: string;
    financialInstitutionState: string;
    financialInstitutionZipCode: string;
    financialInstitutionRoutingNumber: string;
    financialInstitutionAccountType: string;
    financialInstitutionAccountNumber: string;
    financialInstitutionConfirmAccountNumber: string;
    financialInstitutionTin: string;
    financialInstitutionNpi: string;
    financialInstitutionAccounts: [];
}