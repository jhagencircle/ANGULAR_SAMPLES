export interface IPaymentHistory {
    transactionId: string;
    paymentTransactionDate: string;
    accountName: string;
    bankAccountNickname: string;
    statusName: string;
    paymentAmount: number;
    paymentTransactionNumber: string;
    invoiceNumber: string;
}