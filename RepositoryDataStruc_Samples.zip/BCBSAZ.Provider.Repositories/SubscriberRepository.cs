﻿using System;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Subscriber;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories
{
	public class SubscriberRepository : ISubscriberRepository
	{
		private readonly ITICustomContext _context;
		private readonly ISubscriberContext _subscriberContext;

		public SubscriberRepository(ITICustomContext context, ISubscriberContext subscriberContext)
		{
			_context = context;
			_subscriberContext = subscriberContext;

		}

		public async Task<bool> IsMemberDelegatedAsync(string subscriberId)
		{
			// NOTE: Because we are dealing with a Stored Proc which uses an Output Parameter, we must use SqlParameters
			var returnCodeParam = new SqlParameter()
			{
				ParameterName = "@ReturnCode",
				DbType = System.Data.DbType.AnsiString,
				Size = 1,
				Direction = System.Data.ParameterDirection.Output
			};

			var subscriberIdParam = new SqlParameter("@SubscriberID", subscriberId.Substring(3));

			await _context.Database.ExecuteSqlRawAsync(DB.TICustom.StoredProcs.IsDelegatedMember, returnCodeParam, subscriberIdParam);

			return (returnCodeParam.Value as string) == "0";
		}

		public async Task<bool> IsPrefixOOAAsync(string subPrefix)
		{
			// NOTE: Because we are dealing with a Stored Proc which uses an Output Parameter, we must use SqlParameters
			var returnCodeParam = new SqlParameter()
			{
				ParameterName = "@ReturnCode",
				DbType = System.Data.DbType.AnsiString,
				Size = 1,
				Direction = System.Data.ParameterDirection.Output
			};

			var prefixToCheckParam = new SqlParameter("@PrefixToCheck", subPrefix);

			await _context.Database.ExecuteSqlRawAsync(DB.TICustom.StoredProcs.CheckAssocPlanProfilePrefix, returnCodeParam, prefixToCheckParam);

			/* 
			 * Codes are:
			 * 0 = Its Host
			 * 1 = Not Found
			 * 2 = MA Its Host
			 */
			return (returnCodeParam.Value as string) == "0" || returnCodeParam.Value as string == "2";
		}

		public Patient[] GetPatients(string subscriberId, string firstName, string lastName, string ssn, DateTime dateOfBirth)
		{
			var validatePatientResults = _subscriberContext.Patient.FromSqlRaw(
				DB.Subscriber.StoredProcs.ValidatePatient,
					subscriberId,
					dateOfBirth,
					firstName,
					lastName,
					ssn
				).AsEnumerable();

			return
				(from ValidatePatient patient in validatePatientResults
				select new Patient()
				{
					IsActive = patient.IsActive,
					SubscriberId = patient.SubscriberId,
					IsDental = patient.IsDental,
					IsDependent = patient.IsDependent,
					Prefix = patient.Prefix,
					IsAdvantage = patient.IsAdvantage,
					Subscriber = new Subscriber()
					{
						FirstName = patient.SubscriberFirstName,
						LastName = patient.SubscriberLastName,
						DateOfBirth = patient.SubscriberDateOfBirth
					},
					Member = new Member()
					{
						FirstName = patient.PatientFirstName,
						LastName = patient.PatientLastName,
						DateOfBirth = patient.PatientDateOfBirth,
						Gender = patient.PatientGender,
						MemberId = patient.PatientMemberId,
						SSN = patient.PatSSN
					}
				}).ToArray();
		}
	}
}
