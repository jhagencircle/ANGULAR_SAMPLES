﻿using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace BCBSAZ.Provider.Repositories
{
	/// <summary>
	/// Provides Application startup configuration for all Entity Framework DbContexts
	/// </summary>
	internal static class DbContextsStartup
	{

		#region Connection Strings (most stored in APO database)
		/************ NOT Stored in APO ************/
		private const string APO = "APO";
		private const string Features = "Features";

		/************ Stored in APO ************/
		private const string ProviderInet = "ProviderInet";
		private const string FeeSched = "FeeSched";
		private const string InetSMP = "InetSMP";
		private const string BCBSAZSql = "BCBSAZSql";
		private const string TICustom = "TICustom";
		private const string ContractIssuance = "ContractIssuance";
		private const string Group2 = "Group2";
		private const string SystemLogs = "SystemLogs";
		private const string Subscriber = "Subscriber";
		private const string ClearingHouse = "ClearingHouse";
		private const string Codes = "Codes";
		private const string Email = "Email";
		private const string TpaInet = "TPAInet";

		private static readonly string[] apoDatabases = new string[]
		{
			ProviderInet, FeeSched, InetSMP, BCBSAZSql, TICustom, ContractIssuance, Group2, SystemLogs, Subscriber, ClearingHouse, Codes, Email, TpaInet
		};

		private static ConnectionStringList GetConnectionStrings(IConfiguration configuration)
		{
			var apoServer = configuration.GetValue<string>("ApoServer");
			var apoEnvironment = configuration.GetValue<string>("ApoEnvironment");
#if DEBUG
			var apoConStr = $"Server={apoServer};database=APO;UID=APOUser;PWD=$a100#p@;Trusted_Connection=false;";
#else
			var apoConStr = $"Server={apoServer};database=APO;Trusted_Connection=true;";
#endif

			var featureServer = configuration.GetValue<string>("FeatureToggleServer");
			var featureConStr = $"Server={featureServer};database=MemberFeatures;Trusted_Connection=true;";

			var builder = new DbContextOptionsBuilder<ApoContext>()
				.UseSqlServer(apoConStr, providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

			var retVal = new ConnectionStringList()
			{
				new ConfigSetting() { Environment = apoEnvironment, Name = APO, Value = apoConStr },
				new ConfigSetting() { Environment = apoEnvironment, Name = Features, Value = featureConStr}
			};

			using (var context = new ApoContext(builder.Options))
			{
				retVal.AddRange(
					from cs in context.ConfigSettings
					where
						cs.Environment == apoEnvironment &&
						apoDatabases.Contains(cs.Name)
					select cs);
			}

			return retVal;
		}

		private class ConnectionStringList : List<ConfigSetting>
		{
			public string this[string dbName]
			{
				get
				{
					return (from cs in this
									where cs.Name.Equals(dbName, StringComparison.OrdinalIgnoreCase)
									select cs.Value).FirstOrDefault();
				}
			}
		}

		#endregion

		/// <summary>
		/// Configures BCBSAZ.Provider Entity Framework DbContexts in the Service Collection using the provided configuration
		/// </summary>
		/// <param name="services">The Service Collection in which DbContexts will be configured</param>
		/// <param name="configuration">The configuration containing Db Connection information</param>
		public static void AddDbContexts(this IServiceCollection services, IConfiguration configuration)
		{
			var conStrs = GetConnectionStrings(configuration);

			services.AddDbContext<IApoContext, ApoContext>(options => options
				.UseSqlServer(conStrs[APO], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<IMemberFeaturesContext, MemberFeaturesContext>(options => options
				.UseSqlServer(conStrs[Features], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<IProviderInetContext, ProviderInetContext>(options => options
				.UseSqlServer(conStrs[ProviderInet], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<ISettingsContext, SettingsContext>(options => options
				.UseLazyLoadingProxies()
				.UseSqlServer(conStrs[ProviderInet], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll)
			);

			services.AddDbContext<IEligibilityContext, EligibilityContext>(options => options
				.UseLazyLoadingProxies()
				.UseSqlServer(conStrs[ProviderInet], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll)
			);

			services.AddDbContext<IPreCertContext, PreCertContext>(options => options
				.UseLazyLoadingProxies()
				.UseSqlServer(conStrs[ProviderInet], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll)
			);

			services.AddDbContext<IFeeSchedContext, FeeSchedContext>(options => options
				.UseSqlServer(conStrs[FeeSched], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<IInetSMPContext, InetSMPContext>(options => options
				.UseSqlServer(conStrs[InetSMP], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<IBcbsazSqlContext, BcbsazSqlContext>(options => options
				.UseSqlServer(conStrs[BCBSAZSql], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<ITICustomContext, TICustomContext>(options => options
				.UseSqlServer(conStrs[TICustom], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<IContractIssuanceContext, ContractIssuanceContext>(options => options
				.UseSqlServer(conStrs[ContractIssuance], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<IGroup2Context, Group2Context>(options => options
				.UseSqlServer(conStrs[Group2], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<ISubscriberContext, SubscriberContext>(options => options
				.UseSqlServer(conStrs[Subscriber], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<IClearingHouseContext, ClearingHouseContext>(options => options
				.UseSqlServer(conStrs[ClearingHouse], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<ICodesContext, CodesContext>(options => options
				.UseSqlServer(conStrs[Codes], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);

			services.AddDbContext<IClaimsContext, ClaimsContext>(options => options
				.UseLazyLoadingProxies()
				.UseSqlServer(conStrs[ProviderInet], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll)
			);

			services.AddDbContext<IPatientsContext, PatientsContext>(options => options
				.UseLazyLoadingProxies()
				.UseSqlServer(conStrs[ProviderInet], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll)
			);

			services.AddDbContext<ITransactionLogContext, TransactionLogContext>(options => options
				//	.UseLazyLoadingProxies()
				.UseSqlServer(conStrs[SystemLogs], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
			);



			// Singleton DbContext objects
			services.AddDbContext<ISystemLogsContext, SystemLogsContext>(options => options
				.UseSqlServer(conStrs[SystemLogs], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking),
				ServiceLifetime.Singleton
			);

			services.AddDbContext<IPurgeContext, PurgeContext>(options => options
			.UseSqlServer(conStrs[ProviderInet], providerOptions => providerOptions.CommandTimeout(7200))
			.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking),
			ServiceLifetime.Singleton
			);

			services.AddDbContext<IEmailContext, EmailContext>(options => options
				.UseSqlServer(conStrs[Email], providerOptions => providerOptions.CommandTimeout(60))
				.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking),
				ServiceLifetime.Singleton
			);

		}
	}
}
