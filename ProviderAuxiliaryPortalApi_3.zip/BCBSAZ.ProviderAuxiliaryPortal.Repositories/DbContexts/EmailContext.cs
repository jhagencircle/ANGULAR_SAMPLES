﻿using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts
{
    public class EmailContext : DbContext
    {
        /// <summary>
        /// Creates a new instance of the Email DbContext object.
        /// </summary>
        /// <param name="options"></param>
        public EmailContext(DbContextOptions<EmailContext> options) : base(options) { }

        /// <summary>
        /// Defines custom model binding and configurations for models relating to the Email database
        /// </summary>
        /// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }
    }
}
