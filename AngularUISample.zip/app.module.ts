import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './common/shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from 'src/environments/environment';
import { OKTA_CONFIG, OktaAuthModule } from '@okta/okta-angular';
import { AuthGuard } from './core/auth.guard';
import { SessionComponent } from './shared/components/session/session.component';
import { FooterComponent } from './common/shared/footer/footer.component';
import { HeaderComponent } from './common/shared/header/header.component';
import { GlobalErrorHandler } from './shared/middleware/globalErrorHandler';
import { HttpMiddleware } from './shared/middleware/httpMiddleware';

const config = {
  clientId: '0oa10xg9dyrNFBl7h0h8',
  issuer: 'https://evalext.azblue.com/oauth2/ausieumlspeeWM4P70h7',
  redirectUri: environment.oktaRedirectCallbackUrl,
  scopes: ['openid', 'profile', 'email', 'employer', 'offline_access'],
  postLogoutRedirectUri: environment.oktaPostLogoutRedirectUri,
  pkce: true,
};

@NgModule({
  declarations: [
    AppComponent,
    SessionComponent,
    FooterComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    SharedModule,
    BrowserAnimationsModule,
    OktaAuthModule
  ],
  providers: [
    AuthGuard,
    {
      provide: ErrorHandler,
      useClass: GlobalErrorHandler,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpMiddleware,
      multi: true,
    },
    { provide: OKTA_CONFIG, useValue: config }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
