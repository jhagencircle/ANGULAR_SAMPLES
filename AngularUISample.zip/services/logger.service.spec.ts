import { TestBed } from '@angular/core/testing';
import { OktaAuthService } from '@okta/okta-angular';
import { MockOktaAuthService } from '../shared/mocks/mockOktaAuthService';
import { HttpClientTestingModule } from '@angular/common/http/testing';


import { LoggerService } from './logger.service';

describe('LoggerService', () => {
  let service: LoggerService;
  let oktaMock: MockOktaAuthService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        { provide: OktaAuthService, useClass: MockOktaAuthService }
      ],
    });
    service = TestBed.inject(LoggerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call isAuthenticated method when Logs information', () => {
    spyOn(service.oktaAuth, "isAuthenticated").and.callThrough();
    service.logInformation("", "");
    expect(service.oktaAuth.isAuthenticated).toHaveBeenCalled();
  });

  it('should call isAuthenticated method when Logs Error', () => {
    spyOn(service.oktaAuth, "isAuthenticated").and.callThrough();
    service.logError("", "");
    expect(service.oktaAuth.isAuthenticated).toHaveBeenCalled();
  });

  it('should call isAuthenticated method when Logs Fatal', () => {
    spyOn(service.oktaAuth, "isAuthenticated").and.callThrough();
    service.logFatal("", "");
    expect(service.oktaAuth.isAuthenticated).toHaveBeenCalled();
  });

  it('should call isAuthenticated method when Logs information', () => {
    spyOn(service.oktaAuth, "isAuthenticated").and.callThrough();
    service.logInformation("", "");
    expect(service.oktaAuth.isAuthenticated).toHaveBeenCalled();
  });
});
