import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LandingPageComponent } from './landing-page.component';
import { RouterTestingModule } from '@angular/router/testing';
import { OktaAuthModule, OKTA_CONFIG } from '@okta/okta-angular';
import { AuthService } from '../core/auth/auth.service';
import { CurrentBillMock } from 'src/app/shared/mocks/current-bill.mock';
import { BillService } from '../shared/services/bill.service';
import { AccountService } from 'src/app/shared/services/account.service';
import { AccountMock } from 'src/app/shared/mocks/account.mock';
import { UserService } from '../shared/services/user.service';
import { UserMock } from 'src/app/shared/mocks/user.mock';
import { SubAccountService } from '../shared/services/sub-account.service';
import { MockSubAccount } from 'src/app/shared/mocks/sub-account.mock';

describe('LandingPageComponent', () => {
  let component: LandingPageComponent;
  let fixture: ComponentFixture<LandingPageComponent>;
  let currentBillMock: any = new CurrentBillMock();
  let mockAccountService: any = new AccountMock();
  let userService: any = new UserMock();
  let mockSubAccount: any = new MockSubAccount();

  const oktaConfig = {
    issuer: 'https://not-real.okta.com',
    clientId: 'fake-client-id',
    redirectUri: 'http://localhost:4200',
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, OktaAuthModule],
      declarations: [LandingPageComponent],
      providers: [
        { provide: BillService, useValue: currentBillMock },
        { provide: UserService, useValue: userService },
        { provide: AccountService, useValue: mockAccountService },
        { provide: SubAccountService, useValue: mockSubAccount },
        AuthService,
        { provide: OKTA_CONFIG, useValue: oktaConfig },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    component.getCurrentBill();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get current bill', () => {
    expect(component.account.accountId).toEqual('019867');
    expect(component.subAccountSummaryList.length).toBeGreaterThan(0);
  });

  it('should select sub-account', () => {
    component.subAccountSummaryList[0].isChecked = true;
    component.onSelectedSubaccounts(component.subAccountSummaryList[0]);
    expect(component.subaccounts.length).toEqual(1);
    expect(component.subaccounts[0].accountId).toEqual(
      component.subAccountSummaryList[0].accountId
    );
  });

  it('should select all', () => {
    component.onSelectAll();
    expect(component.subaccounts.length).toBeGreaterThan(0);
  });
});
