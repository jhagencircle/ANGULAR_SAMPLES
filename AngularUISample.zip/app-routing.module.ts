import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/auth.guard';
import { OktaCallbackComponent } from '@okta/okta-angular';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'home', loadChildren: () => import('./features/home/home-routing.module').then(m => m.HomeRoutingModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'financialManagerUser', loadChildren: () => import('./features/financial-manager-user/financial-manager-user.module').then(m => m.FinancialManagerUserModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'login',
    loadChildren: () =>
      import('./features/login/login.module').then((m) => m.LoginModule),
  },
  {
    path: 'eft', loadChildren: () => import('./features/eft-change-request-form/eft-change-request-form.module').then(m => m.EftChangeRequestFormModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'login/callback',
    component: OktaCallbackComponent,
  },
  { path: '**', loadChildren: () => import('./features/home/home-routing.module').then(m => m.HomeRoutingModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
