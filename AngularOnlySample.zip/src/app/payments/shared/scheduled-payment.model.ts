export interface IScheduledPayment {
  transactionId: number;
  accountName: string;
  paymentTransactionNumber: string;
  paymentAmount: number;
  paymentTransactionDate: string;
  paymentTokenId: string;
  bankAccountNickname: string;
  statusName: string;
  invoiceNumber: number;
  transactionOrigin: string;
  isEdit?: boolean;
}
