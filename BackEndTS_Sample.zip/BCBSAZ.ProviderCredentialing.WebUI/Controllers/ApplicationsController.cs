﻿
// *********** DEVELOPER NOTES ***********
// Generated PDF will be saved to C:\Temp\Application.pdf (when in DEBUG only)
// Enabling DEBUG_PDF_FORM will allow a developer to view the PDF Form as Html (instead of the normal "Success" page)
// ***************************************

//#define DEBUG_PDF_FORM 
using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.ApiClients;
using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.Services;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Applications;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using SelectPdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebUI.Controllers
{
	public class ApplicationsController : Controller
	{
		private static class SitecoreKeys
		{
			public static readonly string Signature = "Signature";
			public static readonly string CAQHIntro = "CAQH Intro";
			public static readonly string CaqhError = "CAQH Error";
			public static readonly string CaqhOutro = "CAQH Outro";
			public static readonly string ConciergeInfo = "Concierge Info";
			public static readonly string AddressesOutro = "Addresses Outro";
			public static readonly string SuccessContent = "Success Content";
		}

		private readonly IApplicationService _service;
		private readonly ISitecoreWebClient _sitecoreWebClient;
		private readonly ILogger _logger;

		public ApplicationsController(IApplicationService service, ISitecoreWebClient sitecore, ILogger<ApplicationsController> logger)
		{
			_service = service;
			_sitecoreWebClient = sitecore;
			_logger = logger;
		}

		#region Submit
		[HttpPost]
		public async Task<IActionResult> Index(ApplicationViewModel viewModel, IList<IFormFile> files)
		{
			var sitecoreContent = TranslateTexts();
			var tasks = sitecoreContent.Select(t => (Task)t.Task).ToList();

			files.ForEach(ValidateFileType, ModelState);

			if (ModelState.IsValid)
			{
				tasks.Add(SubmitApplicationAsync(viewModel, files));
			}
			else
			{
				viewModel.NotValid = true;
				viewModel.SubmitFailure = true;
			}

			await Task.WhenAll(tasks);

			viewModel.Attachments = new Attachments()
			{
				AllowMultiple = true,
				AcceptedFileTypes = ".jpg,.jpeg,.pdf"
			};

			if (viewModel.SubmitSuccess)
			{
#if DEBUG && DEBUG_PDF_FORM
			return View("PdfForm", viewModel.Form);
#else
				var model = new SuccessViewModel() {SuccessContent = (
						from sc in sitecoreContent
						where sc.Key == SitecoreKeys.SuccessContent
						select sc.Task.Result).FirstOrDefault()
				};
				return View("SuccessView", model);
#endif
			}
			else
			{
				return View(SetSitecoreContent(viewModel, sitecoreContent));
			}

		}

		private static void ValidateFileType(IFormFile file, ModelStateDictionary modelState)
		{
			if (!file.ContentType.Contains("jpeg") && !file.ContentType.Contains("jpg") && !file.ContentType.Contains("pdf"))
				modelState.AddModelError("File", "Unsupported File Type<br />(Accepted file types are PDFs and JPGs)");
		}

		private async Task SubmitApplicationAsync(ApplicationViewModel viewModel, IList<IFormFile> files)
		{
			try
			{

				IEnumerable<FileAttachment> attachments;

				if (files.IsNullOrEmpty())
				{
					viewModel.Form.AttachedFileNames = new string[] { "No Documents Attached" };

					attachments = new FileAttachment[]
					{
						await GenerateFormPdf(viewModel.Form)
					};
				}
				else
				{
					viewModel.Form.AttachedFileNames = files.Select(f => Path.GetFileName(f.FileName));

					var attachmentTasks = files.ForEachReturn(GetFileAttachement).ToList();

					attachmentTasks.Add(GenerateFormPdf(viewModel.Form));

					await Task.WhenAll(attachmentTasks);

					attachments = (
						from task in attachmentTasks
						select task.Result
						);
				}

				var response = await _service.SubmitApplicationAsync(viewModel.Form, attachments);

				viewModel.SubmitSuccess = true;
				viewModel.ApplicationId = response.ApplicationId;
				viewModel.SubmittedDate = response.SubmittedDate;
			}
			catch(InvalidApiResponseException ex)
			{
				_logger.LogError(ex, HttpContext, "Error Submitting Credentialing Application");

				if (ex.StatusCode == System.Net.HttpStatusCode.BadRequest)
				{
					ModelState.AddModelError(string.Empty, ex.Content); // TODO: Translate ex.Content (which is JSon) into an html content block or into multiple ModelErrors.
					viewModel.NotValid = true;
					viewModel.SubmitFailure = true;
				}
				else
				{
					ModelState.AddModelError(string.Empty, "A Network or database error occured, please try again.");
					viewModel.SubmitFailure = true;
				}
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, HttpContext, "Error Submitting Credentialing Application");
				ModelState.AddModelError(string.Empty, "A Network or database error occured, please try again.");
				viewModel.SubmitFailure = true;
			}
		}

		private async Task<FileAttachment> GenerateFormPdf(ProviderCredentialForm form)
		{
			var view = View("PdfForm", form);
			var htmlForm = await view.ToHtmlAsync(HttpContext, RouteData);

			var converter = new HtmlToPdf();

			converter.Options.PdfPageSize = PdfPageSize.Letter;
			converter.Options.MarginTop = 20;
			converter.Options.MarginBottom = 20;
			converter.Options.MarginLeft = 0;
			converter.Options.MarginRight = 0;
			converter.Options.WebPageWidth = 1200;

			var doc = converter.ConvertHtmlString(htmlForm);

#if DEBUG
			try
			{
				doc.Save("C:\\Temp\\Application.pdf");
			}
			catch { }
#endif

			return new FileAttachment()
			{
				FileName = "Application.pdf",
				ContentType = "application/pdf",
				Contents = doc.Save()
			};
		}

		private async Task<FileAttachment> GetFileAttachement(IFormFile file)
		{
			using (var stream = new MemoryStream())
			{
				await file.CopyToAsync(stream);

				return new FileAttachment
				{
					Contents = stream.ToArray(),
					ContentType = file.ContentType,
					FileName = Path.GetFileName(file.FileName)
				};
			}
		}
		#endregion

		#region Get Page
		[HttpGet]
		public async Task<IActionResult> Index()
		{
			var sitecoreContent = TranslateTexts();

			var viewModel = new ApplicationViewModel()
			{
				Form = new ProviderCredentialForm(),
				Attachments = new Attachments()
				{
					AllowMultiple = true,
					AcceptedFileTypes = ".jpg,.jpeg,.pdf"
				}
			};

			await Task.WhenAll(sitecoreContent.Select(t => t.Task));

			return View(SetSitecoreContent(viewModel, sitecoreContent));
		}
		#endregion

		#region Sitecore Content
		private static ApplicationViewModel SetSitecoreContent(ApplicationViewModel viewModel, IEnumerable<(string Key, Task<string> Task)> sitecoreContent)
		{
			viewModel.Signature = (
				from x in sitecoreContent
				where x.Key == SitecoreKeys.Signature
				select x.Task.Result).FirstOrDefault();

			viewModel.CaqhIntro = (
				from x in sitecoreContent
				where x.Key == SitecoreKeys.CAQHIntro
				select x.Task.Result).FirstOrDefault();

			viewModel.CaqhError = (
				from x in sitecoreContent
				where x.Key == SitecoreKeys.CaqhError
				select x.Task.Result).FirstOrDefault();

			viewModel.CaqhOutro = (
				from x in sitecoreContent
				where x.Key == SitecoreKeys.CaqhOutro
				select x.Task.Result).FirstOrDefault();

			viewModel.AddressesOutro = (
				from x in sitecoreContent
				where x.Key == SitecoreKeys.AddressesOutro
				select x.Task.Result).FirstOrDefault();

			viewModel.ConciergeInfo = (
				from x in sitecoreContent
				where x.Key == SitecoreKeys.ConciergeInfo
				select x.Task.Result).FirstOrDefault();

			viewModel.SuccessContent = (
				from x in sitecoreContent
				where x.Key == SitecoreKeys.SuccessContent
				select x.Task.Result).FirstOrDefault();

			return viewModel;
		}

		public IEnumerable<(string Key, Task<string> Task)> TranslateTexts()
		{
			yield return (SitecoreKeys.Signature, _sitecoreWebClient.TranslateTextAsync(SitecoreKeys.Signature));
			yield return (SitecoreKeys.CAQHIntro, _sitecoreWebClient.TranslateTextAsync(SitecoreKeys.CAQHIntro));
			yield return (SitecoreKeys.CaqhError, _sitecoreWebClient.TranslateTextAsync(SitecoreKeys.CaqhError));
			yield return (SitecoreKeys.CaqhOutro, _sitecoreWebClient.TranslateTextAsync(SitecoreKeys.CaqhOutro));
			yield return (SitecoreKeys.AddressesOutro, _sitecoreWebClient.TranslateTextAsync(SitecoreKeys.AddressesOutro));
			yield return (SitecoreKeys.ConciergeInfo, _sitecoreWebClient.TranslateTextAsync(SitecoreKeys.ConciergeInfo));
			yield return (SitecoreKeys.SuccessContent, _sitecoreWebClient.TranslateTextAsync(SitecoreKeys.SuccessContent));
		}
		#endregion

	}
}
