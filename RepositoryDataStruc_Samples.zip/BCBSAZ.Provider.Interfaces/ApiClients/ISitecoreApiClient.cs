﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface ISitecoreApiClient
	{
		/// <summary>
		/// Gets the content provided by the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		[SuppressMessage("Design", "CA1054:Uri parameters should not be strings", Justification = "Expected Url is partial and therefore not a valid Uri.")]
		Task<TResult> GetAsync<TResult>(string requestUri) where TResult : class;
	}
}
