﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;

namespace BCBSAZ.Provider.Managers.RequestValidators.Subscriber
{
	internal static class IdCardRequestValidator
	{
		public static void Validate(this IdCardRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(IdCardRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.SubscriberId))
				yield return new InvalidModelExceptionDetail(nameof(request.SubscriberId), new ArgumentException("Subscriber Id is missing."));
		}
	}
}
