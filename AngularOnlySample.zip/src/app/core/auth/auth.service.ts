import { Injectable } from '@angular/core';
import { OktaAuthService } from '@okta/okta-angular';
import { User } from 'src/app/shared/models/user.model';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  authenticated: boolean = false;

  get isLogged(): boolean {
    return this.authenticated;
  }

  constructor(public oktaAuth: OktaAuthService) {
    this.isAuthenticated();
  }

  async isAuthenticated(): Promise<boolean> {
    let isOktaAuthenticated: boolean = await this.oktaAuth.isAuthenticated();
    let isGBARole: boolean = false;
    if (isOktaAuthenticated) {
      //Verify role
      const userClaims = await this.oktaAuth.getUser();
      let groups = userClaims.employerGroups;
      isGBARole = groups.some((group: string) => group === 'Employer_GBA');
      if (isGBARole) {
        this.authenticated = true;
      }
    }
    return this.authenticated;
  }

  logout() {
    this.oktaAuth.signOut();
    localStorage.clear();
  }
}
