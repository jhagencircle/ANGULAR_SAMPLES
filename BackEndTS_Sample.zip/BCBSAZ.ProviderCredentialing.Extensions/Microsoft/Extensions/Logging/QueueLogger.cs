﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;

namespace Microsoft.Extensions.Logging
{
	public class QueueLogger : ILogger
	{
		private readonly LogMessageQueue _logMessages;
		private readonly string _categoryName;

		public QueueLogger(LogMessageQueue logMessages, string categoryName)
		{
			_logMessages = logMessages;
			_categoryName = ShortenCategoryName(categoryName ?? string.Empty);
		}

		public IDisposable BeginScope<TState>(TState state)
		{
			return null;
		}

		private static string ShortenCategoryName(string categoryName)
		{
			var retVal = categoryName;

			while (retVal.Length > 100)
			{
				var idx = retVal.IndexOf('.', StringComparison.Ordinal);
				retVal = (idx == -1) ? retVal.Substring(0, 100) : retVal.Substring(idx + 1);
			}

			return retVal;
		}

		private static string GetHeaderValue(IHeaderDictionary headers, string key)
		{
			if (headers == null)
				return null;

			if (headers.TryGetValue(key, out StringValues value))
			{
				return value.ToString();
			}
			else
			{
				return null;
			}
		}

		private static string GetFormData(HttpRequest request)
		{
			if (request == null)
				return null;

			return request.HasFormContentType ? request.Form.ToString().TruncateAt(2000) : null;
		}

		public bool IsEnabled(LogLevel logLevel)
		{
			if (_logMessages == null)
				return false;

			return true;
		}

		public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
		{
			if (formatter == null) throw new ArgumentNullException(nameof(formatter));

			HttpContext context = null;
			if (exception is ExceptionWrapper exWrapper)
			{
				context = exWrapper.HttpContext;
				exception = exWrapper.Exception;
			}

			if (IsEnabled(logLevel))
			{
				_logMessages.Enqueue(new LogMessage()
				{
					ParentException = 0,
					IsHandled = eventId.Id >= 0,
					UserId = "Credentialing User",
					SessionId = "Credentialing", // .TruncateAt(16),
					Source = exception?.Source.TruncateAt(100),
					Member = _categoryName,
					Url = context?.Request.Path.Value.TruncateAt(250),
					RefererUrl = GetHeaderValue(context?.Request.Headers, "Referer").TruncateAt(250),
					HttpUserAgent = GetHeaderValue(context?.Request.Headers, "User-Agent").TruncateAt(100),
					Form = GetFormData(context?.Request),
					QueryString = (context?.Request?.QueryString.ToString()).TruncateAt(500),
					Message = formatter(state, exception).TruncateAt(2000),
					StackTrace = exception?.StackTrace.TruncateAt(2000),
					AdditionalInfo = "none" //.TruncateAt(500)
				});
			}
		}
	}
}
