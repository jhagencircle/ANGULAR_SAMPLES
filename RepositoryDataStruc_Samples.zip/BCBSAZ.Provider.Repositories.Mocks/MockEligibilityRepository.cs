﻿using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;
using BCBSAZ.Provider.Models.Xml271Processor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Eligibility;
using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Responses.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Xml271Processor.Codes;
using BCBSAZ.Provider.Models.Requests.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Data.Common;

namespace BCBSAZ.Provider.Repositories.Mocks
{
	public class MockEligibilityRepository : IEligibilityRepository
	{

		public Task<IEnumerable<CoordinationOfBenefits>> GetCOBsAsync(long responseId)
		{
			return Task.FromResult((from cob in MockCoordinationOfBenefits
															where cob.ResponseId == responseId
															select cob));
		}

		public Task<Dictionary<string, Dictionary<string, IEnumerable<Cost>>>> GetDeductiblesAsync(long responseId)
		{
			throw new NotImplementedException();
		}

		public Task SaveEligibilityInquiriesAsync(params InquiryRequest[] inquiryRequests)
		{
			return Task.CompletedTask;
		}

		public Task<EligibilitySummary> GetEligibilitySummaryAsync(long responseId)
		{
			return Task.FromResult(
					(from es in MockEligibilitySummaries where es.ResponseId == responseId select es)
					.FirstOrDefault());
		}

		public Task<InquiryInfo> GetInquiryAsync(long responseId)
		{
			return Task.FromResult((from i in MockInquiries where i.ResponseId == responseId select i)
					.FirstOrDefault());
		}

		public Task<InsuranceInfo> GetInsuranceInfoAsync(long responseId)
		{
			return Task.FromResult((from ii in MockInsuranceInfos where ii.ResponseId == responseId select ii)
					.FirstOrDefault());
		}

		public Task<PatientDetail> GetPatientDetailAsync(long responseId)
		{
			return Task.FromResult((from pd in MockPatientDetails where pd.ResponseId == responseId select pd)
					.FirstOrDefault());
		}

		public Task<InquiryResult> GetEligibilityInquiryAsync(long responseId)
		{
			throw new NotImplementedException();
		}

		public Task<BooksRiders[]> GetBooksAndRidersAsync(long responseId)
		{
			return Task.FromResult(MockBooksAndRiders.ToArray());
		}

		public Task<Dictionary<string, IEnumerable<GeneralInformation>>> GetGeneralInformationAsync(long responseId)
		{
			return Task.FromResult((
				from x in GeneralInformation
				where x.Key == responseId
				select x.Value).FirstOrDefault());
		}

		public LegacyInquiry GetLegacyInquiry(int inquiryId)
		{
			throw new NotImplementedException();
		}

		public bool InquiryExists(int inquiryId)
		{
			return false;
		}

		public bool CanViewIDCard(string subscriberId, DateTime dateOfService, string firstname, string lastName, DateTime? dateOfBirth)
		{
			throw new NotImplementedException();
		}

		public void PopulateResponseInfo(InquiryResponse response)
		{
			throw new NotImplementedException();
		}

		public ResponseXRef[] InsertLegacyRequest(long requestId)
		{
			throw new NotImplementedException();
		}

		public GroupNumberInfo IsValidGroupNumber(string GroupNum)
		{
			throw new NotImplementedException();
		}

		public DiagnosisCodes[] GetDiagnosisCodes(string query, int pageSize, int pageNumber, out int totalCount)
		{
			throw new NotImplementedException();
		}


		public Task PurgeEligibilityInquiryResultsAsync(int days)
		{
			throw new NotImplementedException();
		}

		public BooksRiders[] GetBooksAndRiders(InquiryResult inquiryresult)
		{
			throw new NotImplementedException();
		}

		public IEnumerable<ValueEnteredReturned> GetValueEnteredReturned(InquiryResult inquiryResult, ValuesEntered valuesEntered)
		{
			throw new NotImplementedException();
		}

		public Miscellaneous GenerateMiscellaneous(InquiryRequest request, InquiryResponse response, Models.Data.Common.ServiceType[] serviceTypes)
		{
			throw new NotImplementedException();
		}

		public Task<Dictionary<string, ServiceTypeBenefitDictionary>> GetFullNetworkServiceTypeAsync(long responseId)
		{
			//return Task.FromResult(FullNetworkService);
			throw new NotImplementedException();
		}

		public Task<IEnumerable<EligibilityRequest>> GetEligibilityRequestsAsync(string orgId, int days, Models.Data.Common.ServiceType[] serviceTypes)
		{
			throw new NotImplementedException();
		}

		public Task<string> GetDisclaimerAsync(long responseId)
		{
			throw new NotImplementedException();
		}

		public InquiryRequest[] GetEligibilityRequestsByLegacyRequestId(IEnumerable<int> legacyRequestIds)
		{
			throw new NotImplementedException();
		}

		public IEnumerable<LegacyInquiry> GetLegacyInquiries(IEnumerable<int> inquiryIds)
		{
			throw new NotImplementedException();
		}

		public Task<InquiryRequest> GetInquiryRequestAsync(long requestId)
		{
			throw new NotImplementedException();
		}

		public Task DeleteEligibilityInquiriesAsync(IEnumerable<long> requestIds) => throw new NotImplementedException();

		public async Task<IEnumerable<Patient>> GetOrCreatePatientsAsync(params Patient[] patients)
		{
			throw new NotImplementedException();
		}

		public Task SaveChangesAsync()
		{
			throw new NotImplementedException();
		}

		#region Mock Data

		private static IEnumerable<InquiryInfo> MockInquiries
		{
			get
			{
				yield return new InquiryInfo()
				{
					ResponseId = 100001,
					MemberId = "NNJ851849996",
					FirstName = "John",
					LastName = "Puiia",
					IsActive = true,
					DateOfService = DateTime.Today,
					//EffectiveDate = new DateTime(DateTime.Today.Year, 1, 1),
					ServiceTypes = new string[] { "Health Benefit Plan Coverage", "Acupuncture", "Allergy" },
					HasBenefits = true,
					Status = "Active"
				};

				yield return new InquiryInfo()
				{
					ResponseId = 10177,
					MemberId = "PXO850357224",
					FirstName = "Kristy",
					LastName = "Vasquez",
					IsActive = false,
					DateOfService = DateTime.Today,
					//EffectiveDate = new DateTime(DateTime.Today.Year, 1, 1),
					ServiceTypes = new string[] { "Adjunctive Dental Service" },
					HasBenefits = false,
					Status = "Inactive"
				};

				yield return new InquiryInfo()
				{
					ResponseId = 100003,
					MemberId = "FQL850422980",
					FirstName = "Aimee",
					LastName = "Maynard",
					IsActive = true,
					DateOfService = DateTime.Today,
					//EffectiveDate = new DateTime(DateTime.Today.Year, 1, 1),
					ServiceTypes = new string[] { "Case Management", "Dental Care", "Dental Crowns" },
					HasBenefits = false,
					Status = "Active-D"
				};

				yield return new InquiryInfo()
				{
					ResponseId = 100004,
					MemberId = "PMK850422980",
					FirstName = "Emily",
					LastName = "Maynard",
					IsActive = true,
					DateOfService = DateTime.Today,
					//EffectiveDate = new DateTime(DateTime.Today.Year, 1, 1),
					ServiceTypes = new string[] { "Case Management", "Dental Care", "Dental Crowns" },
					HasBenefits = false,
					Status = "Active-D"
				};

				yield return new InquiryInfo()
				{
					ResponseId = 100005,
					MemberId = "XAH850772915",
					FirstName = "Eric",
					LastName = "Popilek",
					IsActive = true,
					DateOfService = DateTime.Today,
					//EffectiveDate = new DateTime(DateTime.Today.Year, 1, 1),
					ServiceTypes = new string[] { "Adjunctive Dental Service" },
					HasBenefits = true,
					Status = "Active"
				};
			}
		}

		private static IEnumerable<PatientDetail> MockPatientDetails
		{
			get
			{
				yield return new PatientDetail()
				{
					ResponseId = 100001,
					Gender = "M",
					DateOfBirth = new DateTime(1956, 12, 12),
					Relationship = "Owner",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "1001 Infinite Loop Way",
						Street2 = "Suite 101",
						City = "Cupertino",
						State = "CA",
						Zip = "95014",
						ZipPlusFour = "1001"
					},
					Pcp = new PrimaryCareProvider()
					{
						FirstName = "",
						LastName = "",
						Degree = "",
						Npi = ""
					}
				};

				yield return new PatientDetail()
				{
					ResponseId = 10177,
					Gender = "F",
					DateOfBirth = new DateTime(1981, 9, 3),
					Relationship = "Spouse",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "1001 Infinite Loop Way",
						Street2 = "Suite 102",
						City = "Cupertino",
						State = "CA",
						Zip = "95014",
						ZipPlusFour = "1001"
					},
					Pcp = new PrimaryCareProvider()
					{
						FirstName = "",
						LastName = "",
						Degree = "",
						Npi = ""
					}
				};

				yield return new PatientDetail()
				{
					ResponseId = 100003,
					Gender = "F",
					DateOfBirth = new DateTime(1994, 1, 23),
					Relationship = "Child",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "1001 Infinite Loop Way",
						Street2 = "Suite 103",
						City = "Cupertino",
						State = "CA",
						Zip = "95014",
						ZipPlusFour = "1001"
					},
					Pcp = new PrimaryCareProvider()
					{
						FirstName = "James",
						LastName = "Coorigan",
						Degree = "M.D.",
						Npi = "111222333"
					}
				};

				yield return new PatientDetail()
				{
					ResponseId = 100004,
					Gender = "F",
					DateOfBirth = new DateTime(1994, 1, 23),
					Relationship = "Child",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "1001 Infinite Loop Way",
						Street2 = "Suite 104",
						City = "Cupertino",
						State = "CA",
						Zip = "95014",
						ZipPlusFour = "1001"
					},
					Pcp = new PrimaryCareProvider()
					{
						FirstName = "James",
						LastName = "Coorigan",
						Degree = "M.D.",
						Npi = "222333444"
					}
				};

				yield return new PatientDetail()
				{
					ResponseId = 100005,
					Gender = "M",
					DateOfBirth = new DateTime(1985, 05, 06),
					Relationship = "Head of House",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "1001 Infinite Loop Way",
						Street2 = "Suite 105",
						City = "Cupertino",
						State = "CA",
						Zip = "95014",
						ZipPlusFour = "1001"
					},
					Pcp = new PrimaryCareProvider()
					{
						FirstName = "",
						LastName = "",
						Degree = "",
						Npi = ""
					}
				};
			}
		}

		private static IEnumerable<EligibilitySummary> MockEligibilitySummaries
		{
			get
			{
				var yearStart = new DateTime(DateTime.Today.Year, 1, 1);
				var yearEnd = new DateTime(DateTime.Today.Year, 12, 31);

				var monthStart = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
				var monthEnd = new DateTime(DateTime.Today.Year, DateTime.Today.Month + 1, 1).AddDays(-1);

				yield return new EligibilitySummary()
				{
					ResponseId = 100001,
					GracePeriod = new NullableRange<DateTime>(monthStart, monthEnd),
					PaidThrough = new NullableRange<DateTime>(yearStart, yearEnd),
					PreExistingEnd = monthStart,
					TerminationDate = DateTime.MaxValue
				};

				yield return new EligibilitySummary()
				{
					ResponseId = 10177,
					GracePeriod = new NullableRange<DateTime>(monthStart, monthEnd),
					PaidThrough = new NullableRange<DateTime>(yearStart, yearEnd),
					PreExistingEnd = monthStart,
					TerminationDate = DateTime.MaxValue
				};

				yield return new EligibilitySummary()
				{
					ResponseId = 100003,
					GracePeriod = new NullableRange<DateTime>(monthStart, monthEnd),
					PaidThrough = new NullableRange<DateTime>(yearStart, yearEnd),
					PreExistingEnd = monthStart,
					TerminationDate = DateTime.MaxValue
				};

				yield return new EligibilitySummary()
				{
					ResponseId = 100004,
					GracePeriod = new NullableRange<DateTime>(monthStart, monthEnd),
					PaidThrough = new NullableRange<DateTime>(yearStart, yearEnd),
					PreExistingEnd = monthStart,
					TerminationDate = DateTime.MaxValue
				};

				yield return new EligibilitySummary()
				{
					ResponseId = 100005,
					GracePeriod = new NullableRange<DateTime>(monthStart, monthEnd),
					PaidThrough = new NullableRange<DateTime>(yearStart, yearEnd),
					PreExistingEnd = monthStart,
					TerminationDate = DateTime.MaxValue
				};
			}
		}

		private static IEnumerable<InsuranceInfo> MockInsuranceInfos
		{
			get
			{
				yield return new InsuranceInfo()
				{
					ResponseId = 100001,
					FirstName = "John",
					LastName = "Puiia",
					MiddleName = "",
					GroupName = "Plan Name",
					GroupNumber = "ID11111111",
					InsuranceType = "Preferred Provider Organization (PPO)",
					ProductName = "Blue Preferred",
					IsHMO = true
				};

				yield return new InsuranceInfo()
				{
					ResponseId = 10177,
					FirstName = "Enrique",
					LastName = "Vasquez",
					MiddleName = "",
					GroupName = "Plan Name",
					GroupNumber = "ID22222222",
					InsuranceType = "Preferred Provider Organization (PPO)",
					ProductName = "Blue Preferred",
					IsHMO = true
				};

				yield return new InsuranceInfo()
				{
					ResponseId = 100003,
					FirstName = "Gary",
					LastName = "Maynard",
					MiddleName = "",
					GroupName = "Plan Name",
					GroupNumber = "ID33333333",
					InsuranceType = "Preferred Provider Organization (PPO)",
					ProductName = "Blue Preferred",
					IsHMO = false
				};

				yield return new InsuranceInfo()
				{
					ResponseId = 100004,
					FirstName = "Gary",
					LastName = "Maynard",
					MiddleName = "",
					GroupName = "Plan Name",
					GroupNumber = "ID44444444",
					InsuranceType = "Preferred Provider Organization (PPO)",
					ProductName = "Blue Preferred",
					IsHMO = false
				};

				yield return new InsuranceInfo()
				{
					ResponseId = 100005,
					FirstName = "Eric",
					LastName = "Popilek",
					MiddleName = "",
					GroupName = "Plan Name",
					GroupNumber = "ID55555555",
					InsuranceType = "Preferred Provider Organization (PPO)",
					ProductName = "Blue Preferred",
					IsHMO = true
				};

			}
		}

		private static IEnumerable<CoordinationOfBenefits> MockCoordinationOfBenefits
		{
			get
			{
				yield return new CoordinationOfBenefits()
				{
					ResponseId = 10177,
					MemberId = "NNJ851849996",
					FirstName = "John",
					LastName = "Puiia",
					MiddleName = "",
					CarrierName = "Cigna",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "1001 N. Cigna Way",
						Street2 = "",
						City = "Phoenix",
						State = "AZ",
						Zip = "85001",
						ZipPlusFour = "1001",
					},
					PhoneNumber = "(800) 555-1111",
					VerifiedDate = new DateTime(DateTime.Today.Year - 1, 10, 15)
				};

				yield return new CoordinationOfBenefits()
				{
					ResponseId = 10177,
					MemberId = "NNJ851849996",
					FirstName = "John",
					LastName = "Puiia",
					MiddleName = "",
					CarrierName = "Blue",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "2001 W. Main St.",
						Street2 = "",
						City = "Mesa",
						State = "AZ",
						Zip = "85291",
						ZipPlusFour = "2001"
					},
					PhoneNumber = "(800) 444-1111",
					VerifiedDate = new DateTime(DateTime.Today.Year - 1, 11, 15)
				};

				yield return new CoordinationOfBenefits()
				{
					ResponseId = 10177,
					MemberId = "NNJ851849996",
					FirstName = "John",
					LastName = "Puiia",
					MiddleName = "",
					CarrierName = "Red",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "3001 S. Central Blvd.",
						Street2 = "Suite 101",
						City = "Glendale",
						State = "AZ",
						Zip = "85301",
						ZipPlusFour = "3001",

					},
					PhoneNumber = "(800) 333-1111",

					VerifiedDate = new DateTime(DateTime.Today.Year - 1, 12, 15)
				};

				yield return new CoordinationOfBenefits()
				{
					ResponseId = 100003,
					MemberId = "FQL850422980",
					FirstName = "Gary",
					LastName = "Maynard",
					MiddleName = "",
					CarrierName = "Cigna",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "1003 N. Cigna Way",
						Street2 = "",
						City = "Phoenix",
						State = "AZ",
						Zip = "85003",
						ZipPlusFour = "1003"

					},
					PhoneNumber = "(800) 555-3333",
					VerifiedDate = new DateTime(DateTime.Today.Year - 1, 10, 15)
				};

				//yield return new CoordinationOfBenefits()
				//{
				//    ResponseId = 100004,
				//    MemberId = "FQL850422980",
				//    FirstName = "Gary",
				//    LastName = "Maynard",
				//    MiddleName = "",
				//    CarrierName = "Cigna",
				//    StreetAddress = "1004 N. Cigna Way",
				//    StreetAddress2 = "",
				//    City = "Phoenix",
				//    State = "AZ",
				//    ZipCode = "85004",
				//    ZipPlusFour = "1004",
				//    PhoneNumber = "(800) 555-4444",
				//    VerifiedDate = new DateTime(DateTime.Today.Year - 1, 10, 15)
				//};

				//yield return new CoordinationOfBenefits()
				//{
				//    ResponseId = 100004,
				//    MemberId = "FQL850422980",
				//    FirstName = "Gary",
				//    LastName = "Maynard",
				//    MiddleName = "",
				//    CarrierName = "Blue",
				//    StreetAddress = "2004 W. Main St.",
				//    StreetAddress2 = "",
				//    City = "Mesa",
				//    State = "AZ",
				//    ZipCode = "85294",
				//    ZipPlusFour = "2004",
				//    PhoneNumber = "(800) 444-4444",
				//    VerifiedDate = new DateTime(DateTime.Today.Year - 1, 11, 15)
				//};

				yield return new CoordinationOfBenefits()
				{
					ResponseId = 100004,
					MemberId = "UHL851730287",
					FirstName = "Debbie",
					LastName = "Bandoli",
					MiddleName = "",
					CarrierName = "Cigna",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "1004 N. Cigna Way",
						Street2 = "",
						City = "Phoenix",
						State = "AZ",
						Zip = "85004",
						ZipPlusFour = "1004",
					},
					PhoneNumber = "(800) 555-4444",
					VerifiedDate = new DateTime(DateTime.Today.Year - 1, 10, 15)
				};

				yield return new CoordinationOfBenefits()
				{
					ResponseId = 100004,
					MemberId = "UHL851730287",
					FirstName = "Debbie",
					LastName = "Bandoli",
					MiddleName = "",
					CarrierName = "Blue",
					Address = new Models.Data.Eligibility.Details.Address
					{
						Street1 = "2004 W. Main St.",
						Street2 = "",
						City = "Mesa",
						State = "AZ",
						Zip = "85294",
						ZipPlusFour = "2004"

					},

					PhoneNumber = "(800) 444-4444",
					VerifiedDate = new DateTime(DateTime.Today.Year - 1, 11, 15)
				};
			}
		}

		//private static IEnumerable<Cost> MockInNetworkDeductibles
		//{
		//	get
		//	{
		//		yield return new Cost
		//		{
		//			Type = "Individual",
		//			Limit = 500.00m,
		//			Remaining = 0.00m,
		//			AdditionalInfo = new List<string> { "Applied to all service types, unless indicated otherwise" }
		//		};
		//		yield return new Cost
		//		{
		//			Type = "Family",
		//			Limit = 1500.00m,
		//			Remaining = 500.00m,
		//			AdditionalInfo = new List<string> { "Applied to all service types, unless indicated otherwise" }
		//		};
		//	}
		//}

		//private static IEnumerable<Cost> MockInNetworkOutOfPocketDeductibles
		//{
		//	get
		//	{
		//		yield return new Cost
		//		{
		//			Type = "Individual",
		//			Limit = 3000.00m,
		//			Remaining = 1500.00m,
		//			AdditionalInfo = new List<string>()
		//		};

		//		yield return new Cost
		//		{
		//			Type = "Family",
		//			Limit = 5000.00m,
		//			Remaining = 3500.00m,
		//			AdditionalInfo = new List<string>()
		//		};
		//	}
		//}

		//private static IEnumerable<Cost> MockOutOfNetworkDeductibles
		//{
		//	get
		//	{
		//		yield return new Cost
		//		{
		//			Type = "Individual",
		//			Limit = 6000.00m,
		//			Remaining = 6000.00m,
		//			AdditionalInfo = new List<string>()
		//		};
		//		yield return new Cost
		//		{
		//			Type = "Family",
		//			Limit = 10000.00m,
		//			Remaining = 8000.00m,
		//			AdditionalInfo = new List<string>()
		//		};
		//	}
		//}

		//private static IEnumerable<Cost> MockOutOfNetworkOutOfPocketDeductibles
		//{
		//	get
		//	{
		//		yield return new Cost
		//		{
		//			Type = "Individual",
		//			Limit = 8500.00m,
		//			Remaining = 6500.00m,
		//			AdditionalInfo = new List<string>()
		//		};
		//		yield return new Cost
		//		{
		//			Type = "Family",
		//			Limit = 15000.00m,
		//			Remaining = 9000.00m,
		//			AdditionalInfo = new List<string>()
		//		};
		//	}
		//}

		private static Dictionary<string, Dictionary<string, IEnumerable<ServiceTypeBenefit>>> FullNetworkService =>
				new Dictionary<string, Dictionary<string, IEnumerable<ServiceTypeBenefit>>>
				{
								{
										"Health Benefit Plan Coverage", new Dictionary<string, IEnumerable<ServiceTypeBenefit>>
										{
												{"Tier 1 In Network", MockServiceTypeBenefits.Take(3)},
												{"Tier 2 In Network", MockServiceTypeBenefits.Take(3)},
												{"Out of Network", MockServiceTypeBenefitsOutOfNetwork.Take(3)},
												{"Network Not Applicable", MockServiceTypeBenefits.Take(3)}
										}
								},
								{
										"Acupuncture", new Dictionary<string, IEnumerable<ServiceTypeBenefit>>
										{
												{"Tier 1 In Network", MockServiceTypeBenefits.Skip(3).Take(3)},
												{"Tier 2 In Network", MockServiceTypeBenefits.Skip(3).Take(3)},
												{"Out of Network", MockServiceTypeBenefitsOutOfNetwork.Skip(3).Take(3)},
												{"Network Not Applicable", MockServiceTypeBenefits.Skip(3).Take(3)}
										}
								},
								{
										"Allergy", new Dictionary<string, IEnumerable<ServiceTypeBenefit>>
										{
												{"Tier 1 In Network", MockServiceTypeBenefits.Skip(6).Take(3)},
												{"Tier 2 In Network", MockServiceTypeBenefits.Skip(6).Take(3)},
												{"Out of Network", MockServiceTypeBenefitsOutOfNetwork.Skip(6).Take(3)},
												{"Network Not Applicable", MockServiceTypeBenefits.Skip(6).Take(3)}
										}
								},
								{
										"Case Management", new Dictionary<string, IEnumerable<ServiceTypeBenefit>>
										{
												{"Tier 1 In Network", MockServiceTypeBenefits.Skip(9).Take(3)},
												{"Tier 2 In Network", MockServiceTypeBenefits.Skip(9).Take(3)},
												{"Out of Network", MockServiceTypeBenefitsOutOfNetwork.Skip(9).Take(3)},
												{"Network Not Applicable", MockServiceTypeBenefits.Skip(9).Take(3)}
										}
								},
								{
										"Dental Care", new Dictionary<string, IEnumerable<ServiceTypeBenefit>>
										{
												{"Tier 1 In Network", MockServiceTypeBenefits.Skip(12).Take(3)},
												{"Tier 2 In Network", MockServiceTypeBenefits.Skip(12).Take(3)},
												{"Out of Network", MockServiceTypeBenefitsOutOfNetwork.Skip(12).Take(3)},
												{"Network Not Applicable", MockServiceTypeBenefits.Skip(12).Take(3)}
										}
								}
				};

		private static IEnumerable<ServiceTypeBenefit> MockServiceTypeBenefits
		{
			get
			{
				return Enumerable.Empty<ServiceTypeBenefit>();
				#region Health and Benefit Plan Coverage

				//yield return new ServiceTypeBenefit
				//{
				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Doctor's Office",
				//	CoPay = new CoPay { Amount = 0.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.8, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 28
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Inactive,
				//	PlaceOfService = "Hospital",
				//	CoPay = new CoPay { Amount = 0.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.8, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 28
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Doctor's Office",
				//	CoPay = new CoPay { Amount = 0.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.8, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 28
				//	}
				//};

				#endregion

				#region Acupuncture

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Chiropractic Office",
				//	CoPay = new CoPay { Amount = 100.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.25, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 10
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 5
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Chiropractic Office",
				//	CoPay = new CoPay { Amount = 100.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.25, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 10
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 5
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Chiropractic Office",
				//	CoPay = new CoPay { Amount = 100.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.25, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 10
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 5
				//	}
				//};

				#endregion

				#region Allergy

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "N/A",
				//	CoPay = new CoPay { Amount = 10.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.5, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 13
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "N/A",
				//	CoPay = new CoPay { Amount = 10.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.5, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 13
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "N/A",
				//	CoPay = new CoPay { Amount = 10.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.5, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 13
				//	}
				//};

				#endregion

				#region Case Management

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Inactive,
				//	PlaceOfService = "Hospital",
				//	CoPay = new CoPay { Amount = 125.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.75, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 20
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 20
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Hospital",
				//	CoPay = new CoPay { Amount = 125.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.75, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 20
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 20
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Inactive,
				//	PlaceOfService = "Hospital",
				//	CoPay = new CoPay { Amount = 125.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.75, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 20
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 20
				//	}
				//};

				#endregion

				#region Dental Care

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Dental Office",
				//	CoPay = new CoPay { Amount = 0.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 1.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 2
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 1
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Dental Office",
				//	CoPay = new CoPay { Amount = 0.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 1.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 2
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 1
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Dental Office",
				//	CoPay = new CoPay { Amount = 0.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 1.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 2
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 1
				//	}
				//};

				#endregion
			}
		}

		private static IEnumerable<ServiceTypeBenefit> MockServiceTypeBenefitsOutOfNetwork
		{
			get
			{
				return Enumerable.Empty<ServiceTypeBenefit>();
				#region Health and Benefit Plan Coverage

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Doctor's Office",
				//	CoPay = new CoPay { Amount = 1025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.5, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 28
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Hospital",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 28
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Doctor's Office",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 28
				//	}
				//};

				//#endregion

				//#region Acupuncture

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 10
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 5
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 10
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 5
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 10
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 5
				//	}
				//};

				#endregion

				#region Allergy

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "N/A",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 13
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "N/A",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 13
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "N/A",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 30
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 13
				//	}
				//};

				#endregion

				#region Case Management

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Inactive,
				//	PlaceOfService = "Hospital",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 20
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 20
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Inactive,
				//	PlaceOfService = "Hospital",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 20
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 20
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Inactive,
				//	PlaceOfService = "Hospital",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 20
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 20
				//	}
				//};

				#endregion

				#region Dental Care

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Dental Office",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 2
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 1
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Dental Office",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 2
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 1
				//	}
				//};

				//yield return new ServiceTypeBenefit
				//{

				//	EligibilityStatus = EligibilityStatus.Active,
				//	PlaceOfService = "Dental Office",
				//	CoPay = new CoPay { Amount = 201025.0, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	CoInsurance = new CoInsurance { Amount = 0.45, AuthorizationStatus = AuthorizationStatus.NotRequired },
				//	Limit = new Limit
				//	{
				//		Amount = 2
				//	},
				//	Remaining = new Remaining
				//	{
				//		Amount = 1
				//	}
				//};

				#endregion
			}
		}

		private static IEnumerable<BooksRiders> MockBooksAndRiders
		{
			get
			{
				yield return new BooksRiders
				{
					BenefitType = "Medical",
					Name = "Benefit Book",
					Url = "/Documents/BenefitBook?docID=b28717f1-ef14-48c5-beda-7b16a936b802",
					ImageType = "PDF"

				};
				yield return new BooksRiders
				{
					BenefitType = "Medical",
					Name = "Rider",
					Url = "/Documents/BenefitBook?docID=b28717f1-ef14-48c5-beda-7b16a936b802",
					ImageType = "PDF"

				};
				yield return new BooksRiders
				{
					BenefitType = "Medical",
					Name = "Rider",
					Url = "/Documents/BenefitBook?docID=b28717f1-ef14-48c5-beda-7b16a936b802",
					ImageType = "PDF"

				};
				yield return new BooksRiders
				{
					BenefitType = "Medical",
					Name = "Rider",
					Url = "/Documents/BenefitBook?docID=b28717f1-ef14-48c5-beda-7b16a936b802",
					ImageType = "PDF"
				};
			}
		}

		public static Dictionary<int, Dictionary<string, IEnumerable<GeneralInformation>>> GeneralInformation
		{
			get
			{
				return new Dictionary<int, Dictionary<string, IEnumerable<GeneralInformation>>>
								{
										{
												100001, new Dictionary<string, IEnumerable<GeneralInformation>>
												{
														{
																"Codes",
																new List<GeneralInformation>()
																{
																	new GeneralInformation()
																	{
																		Code="A4000",
																		Description="General Information for A4000",
																		Modifiers=new List<string>(){"26","31"}
																	},
																	new GeneralInformation()
																	{
																		Code="A4001",
																		Description="General Information for A4001",
																		Modifiers=new List<string>(){"26","31"}
																	}
																}
													}
												}

			}




				};


			}
		}

		public Dictionary<string, IEnumerable<ValueEnteredReturned>> MockEnteredReturneds =>
				new Dictionary<string, IEnumerable<ValueEnteredReturned>>
				{
								{
										"Member", new List<ValueEnteredReturned>
										{
												new ValueEnteredReturned
												{
														Key = "Member ID",
														ValueEntered = "ABC584848484",
														ValueReturned = "ABC123456789"
												},
												new ValueEnteredReturned
												{
														Key = "First Name",
														ValueEntered = "Johnathan",
														ValueReturned = "John"
												},
												new ValueEnteredReturned
												{
														Key = "Last Name",
														ValueEntered = "White",
														ValueReturned = "White"
												}
										}
								},
								{"Patient", new List<ValueEnteredReturned>
								{

										new ValueEnteredReturned
										{
												Key = "First Name",
												ValueEntered = "Johnathan",
												ValueReturned = "John"
										},
										new ValueEnteredReturned
										{
												Key = "Last Name",
												ValueEntered = "White",
												ValueReturned = "White"
										},
										new ValueEnteredReturned
										{
												Key = "Date of Birth",
												ValueEntered = "03/26/1996",
												ValueReturned = "03/26/1998"
										}
								}}
				};

		#endregion

	}
}
