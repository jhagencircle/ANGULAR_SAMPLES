﻿using System;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Responses.Eligibility.Inquiries;

namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface IString270Client : IDisposable
	{
		Task<string> Get271(string edi, SubmitInquiriesTest test = null);
	}
}
