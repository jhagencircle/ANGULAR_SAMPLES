import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import {
  FormGroup,
  Validators,
  AbstractControl,
  FormBuilder,
} from '@angular/forms';
import { AlertService } from 'src/app/shared/components/alert/alert.service';
import { ISummary } from 'src/app/shared/models/summary.model';
import { AccountService } from 'src/app/shared/services/account.service';
import { BankAccountTypeEnum } from '../shared/bank-account-type.enum';
import { BankAccount } from '../shared/bank-account.model';
import { BankAccountService } from '../shared/bank-account.service';
import { AppConstants } from '../../shared/constants/app-constants';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-bank-account-add',
  templateUrl: './bank-account-add.component.html',
  styleUrls: ['./bank-account-add.component.scss'],
})
export class BankAccountAddComponent implements OnInit, OnDestroy {
  @Output() showSaveForm = new EventEmitter<boolean>();
  @Output() loadBankAccountList = new EventEmitter<boolean>();
  accountTypes = BankAccountTypeEnum;
  newBankAccount: BankAccount = new BankAccount();
  accountId: string;
  onSave: boolean;
  loading: boolean = false;
  subscriptions: Subscription[] = [];
  form: FormGroup;

  get f() {
    return this.form.controls;
  }

  getField(fieldName: string): AbstractControl | null {
    return this.form.get(fieldName);
  }
  constructor(
    private fb: FormBuilder,
    private bankAccountService: BankAccountService,
    private accountService: AccountService,
    public alertService: AlertService
  ) {
    this.accountService.get().subscribe((account: ISummary) => {
      if (account) {
        this.accountId = account.accountId;
      }
    });
  }

  ngOnInit(): void {
    this.createForm();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }
  createForm() {
    this.form = this.fb.group({
      bankName: ['', [Validators.required, Validators.maxLength(32)]],
      nameOnAccount: ['', [Validators.required]],
      nickname: ['', [Validators.required]],
      type: ['', [Validators.required]],
      routingNumber: [
        '',
        [
          Validators.required,
          Validators.minLength(9),
          Validators.pattern('^[0-9]*$'),
        ],
      ],
      number: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(17),
          Validators.pattern('^[0-9]*$'),
        ],
      ],
      numberConfirmation: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(17),
          Validators.pattern('^[0-9]*$'),
        ],
      ],
    });
  }

  initializeForm() {
    this.form.setValue({
      bankName: '',
      nameOnAccount: '',
      nickname: '',
      type: '',
      routingNumber: '',
      number: '',
      numberConfirmation: '',
    });
  }

  save() {
    this.onSave = true;
    this.setBankAccountValues();
    this.saveBankAccount();
  }

  setBankAccountValues() {
    this.newBankAccount.accountId = this.accountId;
    this.newBankAccount.name = this.f.bankName.value;
    this.newBankAccount.nameOnAccount = this.f.nameOnAccount.value;
    this.newBankAccount.nickname = this.f.nickname.value;
    this.newBankAccount.type = this.f.type.value;
    this.newBankAccount.routingNumber = String(this.f.routingNumber.value);
    this.newBankAccount.accountNumber = String(this.f.number.value);
  }
  cancel() {
    this.onSave = false;
    this.newBankAccount = new BankAccount();
    this.initializeForm();
    this.close();
  }

  saveBankAccount() {
    if (this.form.valid) {
      if (this.f.number.value === this.f.numberConfirmation.value) {
        //display spinner
        this.loading = true;
        let subscription = this.bankAccountService
          .save(this.newBankAccount)
          .subscribe(
            () => {
              //hide spinner
              this.loading = false;
              //show success message
              this.loadBankAccountList.emit(true);
              this.close();
            },
            (error: HttpErrorResponse) => {
              //hide spinner
              this.loading = false;
              //show error message
              this.showErrorMessage();
              this.loadBankAccountList.emit(false);
            }
          );
        this.subscriptions.push(subscription);
      } else {
        //hide spinner
        this.loading = false;
        //show error message
        this.showErrorMessage();
      }
    }
  }

  close() {
    this.showSaveForm.emit(false);
  }

  showErrorMessage() {
    this.alertService.clear(AppConstants.BANK_ACCOUNT_ALERT_NAME);
    this.alertService.error(AppConstants.BANK_ACCOUNT_ALERT_TEXT, {
      id: AppConstants.BANK_ACCOUNT_ALERT_NAME,
    });
  }
}
