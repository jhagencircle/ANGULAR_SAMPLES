﻿using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Logging;
using Microsoft.AspNetCore.Mvc;

namespace BCBSAZ.ProviderAuxiliaryPortal.WebAPI.Controllers.v1
{


    [Route("api/[controller]")]
    [ApiController]
    public class LoggingController : ControllerBase
    {
        private readonly ILoggingManager _loggingManager;

        public LoggingController(ILoggingManager loggingManager)
        {
            _loggingManager = loggingManager;
        }

        [HttpPost]
        public ActionResult Log(LoggingModel loggingModel)
        {
            _loggingManager.Log(loggingModel);
            return Ok();
        }

        

    }
}
