﻿using BCBSAZ.Provider.Models.Requests.SamlTokens;
using BCBSAZ.Provider.Models.Responses.SamlTokens;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface ISamlService
	{
		Task<CreateEvicoreTokenResponse> CreateEvicoreToken(CreateEvicoreTokenRequest request, WebUser webUser);

		Task<CreateInterQualTokenResponse> CreateInterQualToken(WebUser webUser);

	}
}
