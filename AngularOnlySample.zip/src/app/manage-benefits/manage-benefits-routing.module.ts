import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { ManageBenefitsComponent } from './manage-benefits.component';
import { EmployeeDependentEditComponent } from './employee-dependent-edit/employee-dependent-edit.component';

const routes: Routes = [
  {
    path: '',
    component: ManageBenefitsComponent,
  },
  {
    path: 'employee-list',
    component: EmployeeListComponent,
  },
  {
    path: 'edit',
    component: EmployeeDependentEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManageBenefitsRoutingModule {}
