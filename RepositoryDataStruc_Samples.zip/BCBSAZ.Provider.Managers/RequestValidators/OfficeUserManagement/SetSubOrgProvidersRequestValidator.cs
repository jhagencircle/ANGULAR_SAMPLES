﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.OfficeUserManagement;

namespace BCBSAZ.Provider.Managers.RequestValidators.OfficeUserManagement
{
	internal static class SetSubOrgProvidersRequestValidator
	{
		public static void Validate(this SetSubOrgProvidersRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(SetSubOrgProvidersRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.OrgId))
				yield return new InvalidModelExceptionDetail(nameof(SetSubOrgProvidersRequest.OrgId), new ArgumentException("Invalid OrgId specified."));

			if (string.IsNullOrWhiteSpace(request.SubOrg))
				yield return new InvalidModelExceptionDetail(nameof(SetSubOrgProvidersRequest.SubOrg), new ArgumentException("Invalid Sub Org specified."));
		}
	}
}
