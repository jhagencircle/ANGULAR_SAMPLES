﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;
using BCBSAZ.Provider.Models.Responses.Eligibility.Details;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface IIdCardApiClient
	{
		Task<VelocityIdCardRawResponse> GetIdCardAsync(VelocityIdCardRequest request);
		Task<Byte[]> GetImageDataAsync(string url);
	}
}
