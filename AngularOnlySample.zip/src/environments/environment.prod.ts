export const environment = {
  production: true,
  apiUrl: 'https://olbp.services.azblue.com:8193',
  oktaRedirectCallbackUrl: 'https://olbp.stage.secure.azblue.com/login/callback',
  oktaPostLogoutRedirectUri: 'https://olbp.stage.secure.azblue.com/',
  loginUrl: 'https://employer.stage.secure.azblue.com/log-in'
};
