﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Common;
using BCBSAZ.Provider.Models.Responses.Remits;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IRemitsRepository
	{
		public Task<ProviderTaxId[]> GetProviderTaxIdsAvailableForRemitAsync(string orgId);
		
	}
}
