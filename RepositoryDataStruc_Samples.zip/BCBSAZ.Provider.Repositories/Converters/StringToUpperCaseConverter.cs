﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BCBSAZ.Provider.Repositories.Converters
{
   public class StringToUpperCaseConverter:ValueConverter<string, string>
    {
        public StringToUpperCaseConverter() : base(StringToUpper, StringToUpper) { }

        static Expression<Func<string, string>> StringToUpper => (s) => (s == null ? null : s.Trim().ToUpper());
    }
}
