import { Component, OnInit } from '@angular/core';
import { AppConstants } from '../../shared/constants/app-constants';
import { AccountService } from 'src/app/shared/services/account.service';
import { ISummary } from 'src/app/shared/models/summary.model';

@Component({
  selector: 'app-payment-confirmation',
  templateUrl: './payment-confirmation.component.html',
  styleUrls: ['./payment-confirmation.component.scss'],
})
export class PaymentConfirmationComponent implements OnInit {
  paymentComponent: string | null;
  accountBilling: string;
  account: ISummary;

  constructor(private accountService: AccountService) {
    this.paymentComponent = localStorage.getItem(
      AppConstants.PREVIOUS_PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );

    this.accountService.get().subscribe((account: ISummary) => {
      if (account) {
        this.account = account;
        this.accountBilling = account.billingLevel;
      }
    });
  }

  ngOnInit(): void {}
}
