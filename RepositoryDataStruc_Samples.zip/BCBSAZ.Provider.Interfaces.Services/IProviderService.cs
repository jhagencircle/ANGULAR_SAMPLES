﻿using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Responses.Common;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface IProviderService
	{
		Task<TaxIdsForOrgResponse> GetTaxIdsForOrganizationAsync(string orgId);

		Task<ServiceTypesResponse> GetServiceTypesAsync();

		Task<IEnumerable<ServiceType>> GetServiceTypesForEvicoreAsync();

		Task<ProviderInfoResponse> GetProviderInfoForCurrentUserAsync(WebUser user);

	}
}
