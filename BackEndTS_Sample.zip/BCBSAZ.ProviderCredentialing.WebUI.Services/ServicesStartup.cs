﻿using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.ApiClients;
using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.Services;
using BCBSAZ.ProviderCredentialing.WebUI.Services;
using BCBSAZ.ProviderCredentialing.WebUI.Services.ApiClients;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.WebUI
{
	public static class ServicesStartup
	{
		public static void AddWebApiServices(this IServiceCollection services, IConfiguration configuration)
		{
#if !DEBUG
			services.AddSingleton<ILogMessageStorage, SystemLogsService>();
#endif

			services.AddScoped<IApplicationService, ApplicationService>();

			services.AddSingleton<IWebApiClient, WebApiClient>();
			services.AddSingleton<ISitecoreApiClient, SitecoreApiClient>();
			services.AddSingleton<ISitecoreWebClient, SitecoreWebClient>();
		}
	}
}
