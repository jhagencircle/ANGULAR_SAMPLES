﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Remits;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IRemitsManager
	{
		Task<IEnumerable<ProviderRemittance>> GetRemitsAsync(RemitSearchRequest request);
		Task<IEnumerable<ProviderRemittance>> GetLegacyRemitsAsync(RemitSearchRequest request);
		Task<ProviderMergedRemittanceResponse> GetMergedRemitsAsync(WebUser webUser, RemitSearchRequest request);
		Task<RemitDocumentResponse> GetDocumentAsync(RemitDocumentRequest request);
		Task<RemitDocumentResponse> GetVelocityRemitDocument(int documentId, StringBuilder info, WebUser webUser);
		Task<IEnumerable<SearchVelocityRemitDocumentResponse>> SearchVelocityRemitDocument(SearchVelocityRemitDocumentRequest request);
		Task<IEnumerable<SearchVelocityRemitDocumentResponse>> SearchMultipleVelocityRemitDocumentAsync(string transactionNumber);
    IEnumerable<SearchVelocityRemitDocumentResponse> CheckForMultipleResponsesAsync(IEnumerable<SearchVelocityRemitDocumentResponse>[] request);
	}
}
