import { ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BankAccountAddComponent } from './bank-account-add.component';
import { NgModule } from '@angular/core';
import { AlertService } from 'src/app/shared/components/alert/alert.service';
import { BankAccountService } from 'src/app/bank-account/shared/bank-account.service';
import { AccountService } from 'src/app/shared/services/account.service';
import { Observable, of } from 'rxjs';
import { ISummary } from '../../shared/models/summary.model';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AccountMock } from 'src/app/shared/mocks/account.mock';

describe('BankAccountAddComponent', () => {
  let component: BankAccountAddComponent;
  let fixture: ComponentFixture<BankAccountAddComponent>;

  let mockBankAccountService;
  let mockAccountService: any = new AccountMock();
  let mockAlertService;

  beforeEach(async () => {
    mockBankAccountService = {};
    mockAlertService = {};
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, HttpClientTestingModule],
      declarations: [BankAccountAddComponent],
      providers: [
        { provide: AlertService, useValue: mockAlertService },
        { provide: BankAccountService, useValue: mockBankAccountService },
        { provide: AccountService, useValue: mockAccountService },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BankAccountAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    spyOn(mockAccountService, 'get').and.returnValue({
      subscribe: () => {},
    });
    expect(component).toBeTruthy();
  });

  it('should has required validator', fakeAsync(() => {
    expect(component.form.valid).toBeFalsy();

    component.form.controls.bankName.setValue('Wells Fargo');
    component.form.controls.nameOnAccount.setValue('US');
    component.form.controls.nickname.setValue('boa');
    component.form.controls.type.setValue('Savings');
    component.form.controls.routingNumber.setValue('123456789');
    component.form.controls.number.setValue('123456789');
    component.form.controls.numberConfirmation.setValue('123456789');

    expect(component.form.valid).toBeTruthy();
    component.setBankAccountValues();

    expect(component.form.controls.bankName.value).toEqual(
      component.newBankAccount.name
    );
    expect(component.form.controls.nameOnAccount.value).toEqual(
      component.newBankAccount.nameOnAccount
    );
    expect(component.form.controls.nickname.value).toEqual(
      component.newBankAccount.nickname
    );
    expect(component.form.controls.type.value).toEqual(
      component.newBankAccount.type
    );
    expect(component.form.controls.routingNumber.value).toEqual(
      component.newBankAccount.routingNumber
    );
    expect(component.form.controls.number.value).toEqual(
      component.newBankAccount.accountNumber
    );
  }));

  it('bankName field validity', () => {
    let errors: any = {};
    let bankName = component.form.controls.bankName;
    errors = bankName.errors || {};
    expect(errors.required).toBeTruthy();
  });
});
