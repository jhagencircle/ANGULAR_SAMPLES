﻿using BCBSAZ.ProviderCredentialing.Interfaces.Repositories;
using BCBSAZ.ProviderCredentialing.Repositories;
using BCBSAZ.ProviderCredentialing.Repositories.DbContexts;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing
{
	public static class RepositoriesStartup
	{
		public static void AddRepositories(this IServiceCollection services, IConfiguration configuration)
		{
			services.AddDbContexts(configuration);

			services.AddScoped<IEmailRepository, EmailRepository>();
			services.AddScoped<IApplicationRepository, ApplicationRepository>();

			// Because this is used by Logging, it needs to be a singleton, most other repositories will be scoped.
			services.AddSingleton<ISystemLogsRepository, SystemLogsRepository>();
		}
	}
}
