﻿namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Enums
{
	public enum AddressType
	{
		OfficeAddress,
		BillingAddress,
		MailingAddress,
		MedicalRecords, 
		Credentialing,
		Additional
	}
}
