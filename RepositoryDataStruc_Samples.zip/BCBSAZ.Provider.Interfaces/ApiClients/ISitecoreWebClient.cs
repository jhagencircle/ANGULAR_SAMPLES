﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.NavigationMenu;
using BCBSAZ.Provider.Models.Enums;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface ISitecoreWebClient
	{
		Task<string> GetContentAsync(string identifier, HttpRequest request = null);
		Task<string> TranslateTextAsync(string key);
		Task<IEnumerable<TopMenuItem>> GetNavigationMenuAsync(NavMenuType menuType);
		Task<T> GetSitecoreContentAsync<T>(HttpMethod method, string requestUrl);
	}
}
