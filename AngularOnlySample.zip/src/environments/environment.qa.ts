export const environment = {
  production: false,
  apiUrl: 'https://olbp.test.services.azblue.com:8693',
  oktaRedirectCallbackUrl: 'https://olbp.test.secure.azblue.com/login/callback',
  oktaPostLogoutRedirectUri: 'https://olbp.test.secure.azblue.com/',
  loginUrl: 'https://employer.test.secure.azblue.com/log-in',
};
