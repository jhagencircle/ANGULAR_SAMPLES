﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.UserProfile;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface
{
    public interface IUserProfileManager
    {
        Task<UserProfile> GetUserProfileAsync(string userId);
        Task<bool> CreateUserProfileAsync(UserProfileRequest request);
        Task<bool> UpdateUserProfileAsync(UserProfileRequest request);
        Task<bool> DeleteUserProfileAsync(string orgId, string userId);
    }
}
