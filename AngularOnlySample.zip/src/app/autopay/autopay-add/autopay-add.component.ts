import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy,
} from '@angular/core';
import { BankAccountService } from 'src/app/bank-account/shared/bank-account.service';
import { BankAccount } from 'src/app/bank-account/shared/bank-account.model';
import { PaymentsService } from '../../payments/shared/payments.service';
import { ISummary } from 'src/app/shared/models/summary.model';
import { AccountService } from 'src/app/shared/services/account.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SubAccountService } from '../../shared/services/sub-account.service';
import { AutopaymentService } from '../shared/autopayment.service';
import { PaymentSectionEnum } from 'src/app/shared/enums/payment-section-enum';
import { AppConstants } from '../../shared/constants/app-constants';
import { Subscription } from 'rxjs';
import { AccountLevelEnum } from 'src/app/shared/enums/account-level-enum';

@Component({
  selector: 'app-autopay-add',
  templateUrl: './autopay-add.component.html',
  styleUrls: ['./autopay-add.component.scss'],
})
export class AutopayAddComponent implements OnInit, OnDestroy {
  @Output() cancelClick = new EventEmitter<string>();

  autopayList: any[];
  bankAccounts: BankAccount[];
  account: ISummary;
  subAccountSummaryList: ISummary[] = [];
  submitted: boolean;
  subAccountPayment: any = [];
  payToAccount: any[] = [];
  subscriptions: Subscription[] = [];
  form: FormGroup;
  accountLevelEnum = AccountLevelEnum;

  constructor(
    private accountService: AccountService,
    private bankAccountService: BankAccountService,
    public fb: FormBuilder,
    public paymentsService: PaymentsService,
    private subaccountService: SubAccountService,
    private autopaymentService: AutopaymentService
  ) {
    this.getMainAccount();
    this.loadBankAccounts();
  }

  get f() {
    return this.form.controls;
  }

  ngOnInit(): void {
    this.createForm();
    this.loadAccounts();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  createForm() {
    this.form = this.fb.group({
      bankAccount: ['', [Validators.required]],
      subAccount: ['', [Validators.required]],
    });
  }

  getMainAccount() {
    if (!this.account) {
      this.accountService.get().subscribe((account: ISummary) => {
        if (account) {
          this.account = account;
        }
      });
    }
  }

  loadBankAccounts() {
    this.bankAccountService.get(this.account.accountId).subscribe((data) => {
      this.bankAccounts = data;
    });
  }

  loadAccounts() {
    let subscription = this.autopaymentService.get().subscribe((data) => {
      this.autopayList = data || new Array<any>();
      if (this.account.billingLevel === AccountLevelEnum.TopAccount) {
        this.payToAccount.push({
          disabled:
            this.autopayList.find(
              (x) => x.accountId === this.account.accountId
            ) !== undefined
              ? true
              : false,
          name: this.account.accountName,
          value: this.account.accountId,
        });
        this.subAccountSummaryList.push(this.account);
      }
      if (
        this.account.billingLevel === AccountLevelEnum.SubAccount ||
        this.account.billingLevel === AccountLevelEnum.SubSubAccount
      ) {
        this.subaccountService.getList().subscribe((subaccounts) => {
          if (subaccounts) {
            subaccounts.map((s) =>
              this.payToAccount.push({
                disabled:
                  this.autopayList.find((x) => x.accountId === s.accountId) !==
                  undefined
                    ? true
                    : false,
                name: s.accountName,
                value: s.accountId,
              })
            );
            this.subAccountSummaryList = subaccounts;
          }
        });
      }
    });
    this.subscriptions.push(subscription);
  }

  onFormSubmit() {
    this.addFieldValidations();
    if (this.form.valid) {
      let currentAccount: any = this.subAccountSummaryList.find(
        (item: any) => item.accountId === this.form.value.subAccount
      );
      if (
        currentAccount === undefined &&
        (this.form.value.subAccount === this.account.accountId ||
          this.account.billingLevel == AccountLevelEnum.TopAccount)
      ) {
        currentAccount = this.account;
      }
      currentAccount[AppConstants.AUTOPAY_DATA_KEY] = {
        totalAmount: AppConstants.AUTOPAY_TOTAL_BILLED_AMOUNT,
        bankAccount: this.bankAccounts.find(
          (element: any) => element.id === parseInt(this.form.value.bankAccount)
        ),
        date: AppConstants.AUTOPAY_STATEMENT_DUE_DATE,
      };
      this.subAccountPayment.push(currentAccount);
      this.goToReview();
    }
  }

  goToReview() {
    localStorage.setItem(
      AppConstants.PAYMENT_SUBSECTION_ACCOUNTS_LOCAL_STORAGE_KEY,
      JSON.stringify(this.subAccountPayment)
    );
    let currentSection = localStorage.getItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );
    localStorage.setItem(
      AppConstants.PREVIOUS_PAYMENT_SECTION_LOCAL_STORAGE_KEY,
      currentSection ?? PaymentSectionEnum.Autopayment
    );
    localStorage.setItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
      PaymentSectionEnum.Review
    );
    window.location.reload();
  }

  cancel() {
    this.cancelClick.emit();
  }

  addFieldValidations() {
    this.f.subAccount.clearValidators();
    this.f.subAccount.updateValueAndValidity();

    if (
      this.account.billingLevel == AccountLevelEnum.SubAccount ||
      this.account.billingLevel == AccountLevelEnum.SubSubAccount
    ) {
      this.f.subAccount.setValidators([Validators.required]);
      this.f.subAccount.updateValueAndValidity();
    }
  }
}
