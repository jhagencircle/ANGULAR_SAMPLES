﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IPurgeContext : IDbContext
	{ 

	}
	public class PurgeContext : DbContext, IPurgeContext
	{
		public PurgeContext(DbContextOptions<PurgeContext> options) : base(options) { }
	}
}
