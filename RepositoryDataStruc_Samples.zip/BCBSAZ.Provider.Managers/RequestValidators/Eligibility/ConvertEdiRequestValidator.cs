﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.Eligibility
{
	internal static class ConvertEdiRequestValidator
	{
		public static void Validate(this ConvertEdiRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(ConvertEdiRequest request)
		{
			if (request.TestTool == null)
				yield return new InvalidModelExceptionDetail(nameof(ConvertEdiRequest.TestTool), new ArgumentException("TestTool data missing."));

			if (string.IsNullOrWhiteSpace(request.TestTool.EDIInquiry))
				yield return new InvalidModelExceptionDetail(nameof(ConvertEdiRequest.TestTool.EDIInquiry), new ArgumentException("EDI Inquiry missing."));
		}
	}
}
