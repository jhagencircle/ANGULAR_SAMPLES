﻿using BCBSAZ.ProviderCredentialing.WebAPI.Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel.DataAnnotations;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	public class Facility
	{
		public string Name { get; set; }

		[JsonConverter(typeof(StringEnumConverter))]
		public FacilityType Type { get; set; }
	}
}
