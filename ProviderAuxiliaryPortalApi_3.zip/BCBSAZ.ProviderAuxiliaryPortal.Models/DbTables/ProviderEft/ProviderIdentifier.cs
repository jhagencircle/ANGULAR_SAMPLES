﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft
{
    [Table("ProviderIdentifier")]
    public class ProviderIdentifier
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [JsonIgnore]
        [ForeignKey("RequestId")]
        public virtual EftEnrollmentRequest EftEnrollmentRequests { get; set; }
        
        [ForeignKey("EftEnrollmentRequest")]
        public long RequestId { get; set; }

        public int AcctLinkageType { get; set; }

        public string TinNumber { get; set; }

        public string NpiNumber { get; set; }

        public DateTime? LastModified { get; set; }
    }
}
