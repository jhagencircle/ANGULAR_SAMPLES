﻿using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using Microsoft.Extensions.Configuration;

using ApiRequest = BCBSAZ.Provider.Models.API.Claims.Request;
using ApiResponse = BCBSAZ.Provider.Models.API.Claims.Response;

namespace BCBSAZ.Provider.Managers.ApiClients
{
	public class ClaimsApiClient : ApiClientBase, IClaimsApiClient
	{
		private const string CorrelationIdHeader = "X-Correlation-ID";

		public ClaimsApiClient(IConfiguration configuration, IOktaApiClient oktaClient) : base(oktaClient)
		{
			base.Timeout = new TimeSpan(0, 0, configuration.GetValue<int>(Constants.Configuration.Timeouts.ClaimsTimeout));
			var serviceUrl = configuration.GetValue<string>(Constants.Configuration.VelocityApiUrl);

			if (string.IsNullOrWhiteSpace(serviceUrl))
				throw new ArgumentException("Invalid Service Url specified for Velocity API.");

			BaseAddress = new Uri(serviceUrl.EnsureEndsWith('/'));

			DefaultRequestHeaders.Clear();
			DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
		}

		protected override string Name => "Claims API";

		public async Task<ApiResponse.ClaimsApiResponse> GetClaims(ApiRequest.ClaimsApiRequest request)
		{
			try
			{
				if (base.DefaultRequestHeaders.Contains(CorrelationIdHeader))
					base.DefaultRequestHeaders.Remove(CorrelationIdHeader);

				base.DefaultRequestHeaders.Add(CorrelationIdHeader, request.CorrelationId);

				return await PostAsync<ApiResponse.ClaimsApiResponse>(Constants.ClaimsApiUrls.FindClaims, request);
			}
			catch (InvalidApiResponseException ex)
			{
				if (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
				{
					return CreateErrorResponse(request, "NotFound");
				}
				else if (ex.StatusCode == System.Net.HttpStatusCode.GatewayTimeout)
				{
					return CreateErrorResponse(request, "Timeout");
				}

				throw;
			}
		}

		private static ApiResponse.ClaimsApiResponse CreateErrorResponse(ApiRequest.ClaimsApiRequest request, string status) =>
			new ApiResponse.ClaimsApiResponse()
			{
				CorrelationId = request.CorrelationId,
				InformationReceiver = GetInformationReceiver(request),
				Subscriber = GetSubscriber(request),
				Dependent = GetDependent(request),
				Claims = GetClaim(request, status),
				Provider = GetProvider(request)
			};

		private static IEnumerable<ApiResponse.Claim> GetClaim(ApiRequest.ClaimsApiRequest request, string status) =>
			new ApiResponse.Claim[1]
			{
				new ApiResponse.Claim()
				{
					StatusCodes = new ApiResponse.StatusCode[1]
					{
						new ApiResponse.StatusCode()
						{
							ClaimStatusCategoryCode = (status == "NotFound") ? "A4" : "E2",
							ClaimStatusCode = (status == "NotFound") ? "35" : "0",
							EntityCode = null
						}
					}
				}
			};

		private static ApiResponse.Subscriber GetSubscriber(ApiRequest.ClaimsApiRequest request) =>
			new ApiResponse.Subscriber()
			{
				IdPrefix = string.Empty,
				Id = request.Subscriber?.Id,
				FirstName = request.Subscriber?.FirstName,
				LastName = request.Subscriber?.LastName,
				DateOfBirth = request.Subscriber?.DateOfBirth
			};

		private static ApiResponse.Dependent GetDependent(ApiRequest.ClaimsApiRequest request) =>
			new ApiResponse.Dependent()
			{
				FirstName = request.Member?.FirstName,
				LastName = request.Member?.LastName,
				DateOfBirth = request.Member?.DateOfBirth
			};

		private static ApiResponse.Provider GetProvider(ApiRequest.ClaimsApiRequest request) =>
			new ApiResponse.Provider()
			{
				Id = request.Provider.NPI,
				FirstName = request.Provider.FirstName,
				LastName = request.Provider.LastName,
				TaxId = request.Provider.TaxId,
				IdQualifier = string.Empty,
				NameQualifier = string.Empty,
				StatusCodes = new ApiResponse.StatusCode[0]
			};

		private static ApiResponse.InformationReceiver GetInformationReceiver(ApiRequest.ClaimsApiRequest request) =>
			new ApiResponse.InformationReceiver()
			{
				Id = string.Empty,
				IdQualifier = string.Empty,
				FirstName = string.Empty,
				LastName = string.Empty,
				NameQualifier = string.Empty,
				StatusCodes = new ApiResponse.StatusCode[0]
			};

	}
}
