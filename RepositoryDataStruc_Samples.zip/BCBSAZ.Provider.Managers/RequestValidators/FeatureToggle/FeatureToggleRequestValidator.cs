﻿using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.FeatureToggles;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BCBSAZ.Provider.Managers.RequestValidators.FeatureToggle
{
	internal static class FeatureToggleRequestValidator
	{
		public static void Validate(this FeatureToggleRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(FeatureToggleRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.ApplicationName))
				yield return new InvalidModelExceptionDetail(nameof(FeatureToggleRequest.ApplicationName), new ArgumentException("Application name is missing."));

			if (string.IsNullOrWhiteSpace(request.EnvironmentName))
				yield return new InvalidModelExceptionDetail(nameof(FeatureToggleRequest.EnvironmentName), new ArgumentException("Environment name is missing."));

			if (string.IsNullOrWhiteSpace(request.FeatureName))
				yield return new InvalidModelExceptionDetail(nameof(FeatureToggleRequest.FeatureName), new ArgumentException("Feature name is missing."));
		}
	}
}
