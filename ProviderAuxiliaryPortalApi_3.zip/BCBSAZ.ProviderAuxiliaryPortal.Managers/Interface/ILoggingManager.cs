﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.Logging;

namespace BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface
{
    public interface ILoggingManager
    {
        void Log(LoggingModel model);
    }
}
