﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Settings;

namespace BCBSAZ.Provider.Managers.RequestValidators.Settings
{
	internal static class UpdateSettingRequestValidator
	{
		public static void Validate(this UpdateSettingRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(UpdateSettingRequest request)
		{
			if (request.Setting == null)
				yield return new InvalidModelExceptionDetail(nameof(UpdateSettingRequest.Setting), new ArgumentException("Setting is missing."));

			if (request.Setting.SettingId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(UpdateSettingRequest.Setting.SettingId), new ArgumentException("Invalid SettingId specified."));

			var context = new ValidationContext(request.Setting);
			var results = new List<ValidationResult>();

			if (!Validator.TryValidateObject(request.Setting, context, results))
			{
				foreach (var result in results)
				{
					yield return new InvalidModelExceptionDetail(result.MemberNames.FirstOrDefault() ?? nameof(UpdateSettingRequest.Setting), new ArgumentException(result.ErrorMessage));
				}
			}
		}
	}
}
