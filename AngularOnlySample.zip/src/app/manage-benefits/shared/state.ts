import { SortDirection } from '../../shared/directives/sortable.directive';

export interface IState {
  page: number;
  pageSize: number;
  searchTerm: string;
  planMedical: string | null;
  planDental: string | null;
  sortColumn: string;
  sortDirection: SortDirection;
}
