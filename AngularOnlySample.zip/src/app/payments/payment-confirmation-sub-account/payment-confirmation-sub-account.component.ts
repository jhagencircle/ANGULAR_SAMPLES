import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { IPaymentResponse } from '../shared/payment-response.model';
import { PaymentsService } from '../shared/payments.service';
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-payment-confirmation-sub-account',
  templateUrl: './payment-confirmation-sub-account.component.html',
  styleUrls: ['./payment-confirmation-sub-account.component.scss'],
})
export class PaymentConfirmationSubAccountComponent implements OnInit {
  paymentConfirmations: IPaymentResponse[];
  paymentConfirmationsSuccess: IPaymentResponse[];
  paymentConfirmationsError: IPaymentResponse[];
  titleSuccess: string;
  messageSuccess: string;
  iconSuccess: string;
  titleError: string;
  messageError: string;
  iconError: string;
  constructor(
    private paymentsService: PaymentsService,
    private router: Router,
    public sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.setPaymentConfirmations();
    this.titleSuccess = AppConstants.PAYMENT_CONFIRMATION_TITLE_SUCCESS;
    this.messageSuccess = AppConstants.PAYMENT_CONFIRMATION_MESSAGE_SUCCESS;
    this.iconSuccess = AppConstants.PAYMENT_CONFIRMATION_ICON_SUCCESS;
    this.titleError = AppConstants.PAYMENT_CONFIRMATION_TITLE_ERROR;
    this.messageError = AppConstants.PAYMENT_CONFIRMATION_MESSAGE_ERROR;
    this.iconError = AppConstants.PAYMENT_CONFIRMATION_ICON_ERROR;
  }

  setPaymentConfirmations() {
    this.paymentConfirmations = this.paymentsService.getPaymentConfirmation();
    if (this.paymentConfirmations) {
      //Get success payments
      this.paymentConfirmationsSuccess = this.paymentConfirmations.filter(
        (c) => c.statusName != 'ERROR' && c.paymentTransactionNumber != ''
      );
      //Get error payments
      this.paymentConfirmationsError = this.paymentConfirmations.filter(
        (c) => c.statusName == 'ERROR' || c.paymentTransactionNumber == ''
      );
    }
  }

  goToLandigPage() {
    this.router.navigate(['/landing-page']);
  }

  getStyleName() {
    let styleName: String = '';
    const elements = document.getElementsByTagName('link');
    for (let index = 0; index < elements.length; index++) {
      if (elements[index].href.startsWith(document.baseURI)) {
        styleName += elements[index].href + ',';
      }
    }
    styleName = styleName.slice(0, -1);
    return styleName;
  }
}
