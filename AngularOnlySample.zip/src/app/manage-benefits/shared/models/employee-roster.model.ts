import { IPlan } from './plan.model';

export interface IEmployeeRoster {
  subscriberId: string;
  amountBilled: number;
  adjustmentReason: string;
  firstName: string;
  lastName: string;
  employeeId: string;
  medicalId: string; //medical subscriber Id
  dentalId: string; //dental subscriber Id
  plans: IPlan[];
  medicalPlanName: string;
  dentalPlanName: string;
  medicalPlanId: string;
  dentalPlanId: string;
}
