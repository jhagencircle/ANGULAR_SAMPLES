import { IPhone, IAddress } from '.';

export interface IContactInformation {
  addresses: IAddress[];
  phoneNumbers: IPhone[];
  email: string;
}
