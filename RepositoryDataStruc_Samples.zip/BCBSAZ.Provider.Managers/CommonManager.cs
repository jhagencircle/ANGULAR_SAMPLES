﻿using System;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Managers.RequestValidators.Common;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Responses.Common;
using Microsoft.Extensions.Caching.Memory;

namespace BCBSAZ.Provider.Managers
{
	public class CommonManager : ICommonManager
	{
		private readonly ICommonRepository _commonRepository;
		private readonly IProviderRepository _providerRepository;

		public CommonManager(ICommonRepository commonRepository, IProviderRepository providerRepository)
		{
			_commonRepository = commonRepository;
			_providerRepository = providerRepository;
		}

		public string GetDatabaseServerName() =>
			_commonRepository.GetDatabaseServerName();

		public MessageCountResponse GetMessageCount(MessageCountRequest request)
		{
			request.Validate();

			return new MessageCountResponse()
			{
				MessageCount = _commonRepository.GetMessageCount(request.UserId)
			};
		}

		public ServiceTypesResponse GetServiceTypes(ServiceTypesRequest request)
		{
			request.Validate();

			return new ServiceTypesResponse()
			{
				ServiceTypes = _providerRepository.GetServiceTypes()
			};
		}

		public Select2Response GetNpisByOrgId(Select2Request request, string orgId, string userId)
		{
			var results = _providerRepository.GetNpisByOrg(orgId, userId, request.Query, request.PageNumber, request.PageSize,
				out var totalCount);

			return new Select2Response()
			{
				Results = (
					from r in results
					select new Select2Item()
					{
						Id = $"{r.ProviderId}|{r.FullName}|{r.TaxId}",
						Text = $"{r.ProviderId}|{r.FullName}|{r.TaxId}"
					}),
				TotalCount = totalCount
			};
		}

		public Select2Response GetNpisByOrgIdForTpa(Select2Request request)
		{
			var results = _providerRepository.GetNpisByOrgForTPA(request.Query, request.PageNumber, request.PageSize, out var totalCount);
			return new Select2Response()
			{
				Results = (
					from r in results
					select new Select2Item()
					{
						Id = $"{r.ProviderId}|{r.FullName}|{r.TaxId}",
						Text = $"{r.ProviderId}|{r.FullName}|{r.TaxId}"
					}),
				TotalCount = totalCount
			};

		}
		public PreviouslySelectedServiceTypeResponse GetPreviouslySelectedServiceTypes(PreviouslySelectedServiceTypeRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var validationResults = request.ValidateRequest();
			if (validationResults.Any())
				throw new InvalidRequestException(validationResults);

			return new PreviouslySelectedServiceTypeResponse
			{
				ServiceTypes = _providerRepository.GetPreviouslySelectedServiceTypes(request.UserId)
			};
		}

		public void UpdateSelectedServiceTypes(UpdateServiceTypeSelectionRequest request)
		{
			if (request == null)
				throw new ArgumentException(nameof(request));

			var validationResults = request.ValidateRequest();
			if (validationResults.Any())
				throw new InvalidRequestException(validationResults);

			var serviceTypeIds = string.Join(",", request.ServiceTypes);

			_providerRepository.UpdateSelectedServiceTypeAsync(request.UserId, serviceTypeIds);
		}

		public DoesUsernameExistResponse CheckUsername(DoesUsernameExistRequest request)
		{
			if (request.Username == null)
				throw new ArgumentException(nameof(request.Username));

			return new DoesUsernameExistResponse
			{
				Exists = _providerRepository.DoesUsernameExist(request.Username).Result
			};
		}
	}
}
