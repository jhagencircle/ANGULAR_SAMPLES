import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { STATES } from 'src/app/models/data/states';
import { ValidationRegex } from 'src/app/models/data/validation-regex';

@Component({
  selector: 'app-eft-provider-information-form',
  templateUrl: './eft-provider-information-form.component.html',
  styleUrls: ['./eft-provider-information-form.component.scss', '../eft-change-request-form.component.scss']
})
export class EftProviderInformationFormComponent implements OnInit {
  public providerInformationForm: FormGroup;
  states = STATES;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.providerInformationForm = this.formBuilder.group({
      providerName: ['', { updateOn: 'change', validators: [Validators.required, Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)] }],
      providerDba: ['', { updateOn: 'change', validators: [Validators.required, Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)] }],
      providerAddress: ['', { updateOn: 'change', validators: [Validators.required] }],
      providerCity: ['', { updateOn: 'change', validators: [Validators.required, Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)] }],
      providerState: ['', { updateOn: 'change', validators: [Validators.required] }],
      providerZipCode: ['', { updateOn: 'change', validators: [Validators.required, Validators.minLength(5), Validators.pattern(ValidationRegex.NUMERIC_ONLY)] }],
      providerTin: ['', { updateOn: 'change', validators: [Validators.required, Validators.minLength(9), Validators.pattern(ValidationRegex.NUMERIC_ONLY)] }],
      providerNpi: ['', { updateOn: 'change', validators: [Validators.required, Validators.minLength(10), Validators.pattern(ValidationRegex.NUMERIC_ONLY)] }],
      providerContactName: ['', { updateOn: 'change', validators: [Validators.required, Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)] }],
      providerPhone: ['', { updateOn: 'change', validators: [Validators.required, Validators.pattern(ValidationRegex.TEN_DIGITS_PHONE_NUMBER)] }],
      providerPhoneExt: ['', { updateOn: 'change', validators: [Validators.pattern(ValidationRegex.NUMERIC_ONLY)] }],
      providerEmailAddress: ['', { updateOn: 'change', validators: [Validators.required, Validators.email] }],
      providerFax: ['', { updateOn: 'change', validators: [Validators.pattern(ValidationRegex.TEN_DIGITS_PHONE_NUMBER)]}],
    });
  }

  public isInvalid(control: AbstractControl): boolean{
    if(!control) return false;
    return control.invalid && (control.touched || control.dirty);
  }

  public save(): void{
    this.setFormDirty();
  }


  private setFormDirty(): void{
    for (var control in this.providerInformationForm.controls){
      this.providerInformationForm.controls[control].markAsDirty();
    }
  }


  /******************************** GETTERS **************************************/
  
  public get providerInfoFromControl() { return this.providerInformationForm.controls; }

  /*****************************************************************************/
}
