import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { EftChangeRequestFormRoutingModule } from './eft-change-request-form-routing.module';
import { EftChangeRequestFormComponent } from './eft-change-request-form.component';
import { EftProviderInformationFormComponent } from './eft-provider-information-form/eft-provider-information-form.component';
import { EftSubmissionInformationFormComponent } from './eft-submission-information-form/eft-submission-information-form.component';
import { EftFinancialInstitutionInformationFormComponent } from './eft-financial-institution-information-form/eft-financial-institution-information-form.component'
import { AngularMaterialSharedModule } from 'src/app/common/shared/angular-material-shared.module';

import { NgxMaskModule } from 'ngx-mask';
import { SharedModule } from 'src/app/common/shared/shared.module';


@NgModule({
  declarations: [
    EftChangeRequestFormComponent,
    EftProviderInformationFormComponent,
    EftSubmissionInformationFormComponent,
    EftFinancialInstitutionInformationFormComponent
  ],
  imports: [
    CommonModule,
    EftChangeRequestFormRoutingModule,
    AngularMaterialSharedModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    NgxMaskModule.forRoot()

  ]
})
export class EftChangeRequestFormModule { }
