﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IPlanProfileManager
	{
		Task<IEnumerable<string>> ItsMaLocalPrefixes { get; }
		Task<IEnumerable<string>> ItsMaHostPrefixes { get; }

		Task<IEnumerable<string>> GetItsMaAllPrefixes();
	}
}
