import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { ICoverage } from 'src/app/manage-benefits/shared/models/coverage.model';

@Injectable({
  providedIn: 'root',
})
export class CoverageServiceMock {
  constructor() {}
  public static mockedCoverages: ICoverage[] = [
    {
      id: '001',
      description: 'Coverage01',
    },

    {
      id: '002',
      description: 'Coverage02',
    },

    {
      id: '003',
      description: 'Coverage03',
    },
  ];
  public get(): Observable<ICoverage[]> {
    return of(CoverageServiceMock.mockedCoverages);
  }
}
