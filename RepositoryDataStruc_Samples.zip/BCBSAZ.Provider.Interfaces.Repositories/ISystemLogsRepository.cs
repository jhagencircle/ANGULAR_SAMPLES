﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface ISystemLogsRepository
	{
		Task InsertLogMessageAsync(LogMessage message);
	}
}
