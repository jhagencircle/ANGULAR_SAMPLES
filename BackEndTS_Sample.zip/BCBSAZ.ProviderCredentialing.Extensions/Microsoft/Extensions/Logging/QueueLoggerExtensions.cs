﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace Microsoft.Extensions.Logging
{
	public static class QueueLoggerExtensions
	{
		public static ILoggingBuilder AddQueueLogger(this ILoggingBuilder builder)
		{
			if (builder == null) throw new ArgumentNullException(nameof(builder));

			builder.Services.AddSingleton(new LogMessageQueue());
			builder.Services.AddSingleton<ILoggerProvider, QueueLoggerProvider>();
			builder.Services.AddHostedService<LogMessageQueueProcessor>();

			return builder;
		}

	}
}
