import { from, Observable, of } from 'rxjs';
import { IEmployee } from 'src/app/manage-benefits/shared/models';

export class EmployeeMock {
  constructor() {}

  get(): Observable<any> {
    return of({
      subscriberId: '000100',
      memberId: '000101',
      accountId: '000495-001',
      subAccountId: '',
      firstName: 'Neil',
      lastName: 'Docker',
      employeeId: '000201',
      location: 'Arizona',
      dateOfBirth: '03-22-1965',
      ssn: '1234567891',
      maritalStatus: 'Single',
      gender: 'Male',
      effectiveDateOfPolicy: '06-30-2021',
      contactInformation: {
        address: '1313 Mockingbird Lane',
        emailAddress: 'mylittlepony@hotmail.com',
        phoneNumbers: [
          { number: '6026398981', phoneType: 'Personal' },
          { number: '6026312345', phoneType: 'home' },
        ],
      },
      benefitSelection: {
        planSelection: [
          {
            id: 'ZZZZBP2021010803553TIER',
            name: '2002101 030855 NGF Triple Choice',
            type: 'Medical',
          },
        ],
        eligibleForMedicare: false,
        medicareNumber: null,
        partAEffectiveDate: null,
        partBEffectiveDate: null,
        lifeInsuranceBenefit: null,
        flexibleSpendingSelection: true,
      },
      dependents: [
        {
          firstName: 'Tobias',
          middleName: '',
          lastName: 'Docker',
          dependentType: 'child',
          dateOfBirth: '07-23-2013',
          ssn: '4413745752',
          gender: 'Male',
          benefitSelection: {
            planSelection: [
              {
                id: 'ZZZZBP2021010803553TIER',
                name: '2002101 030855 NGF Triple Choice',
                type: 'Medical',
              },
            ],
            eligibleForMedicare: false,
            medicareNumber: null,
            partAEffectiveDate: null,
            partBEffectiveDate: null,
            lifeInsuranceBenefit: null,
            flexibleSpendingSelection: false,
          },
          removalReason: null,
        },
      ],
    });
  }
}
