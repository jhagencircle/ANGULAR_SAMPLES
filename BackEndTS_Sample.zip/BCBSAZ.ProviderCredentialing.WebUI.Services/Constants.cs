﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.WebUI
{
	public static class Constants
	{
		public static class Configuration
		{
			public const string ProviderUrl = "ProviderUrl";
			public const string WebApiUrl = "WebApiUrl";
			public const string SitecoreApiUrl = "SitecoreApiUrl";
		}

		public static class SitecoreWebUrls
		{
			public const string GetContent = "?sc_itemid={0}";
			public const string TranslateText = "bcbsaz.providerportal.web/navigationmenu/translatetext?key={0}";
		}

		public static class WebApiUrls
		{
			public static class SystemLogs
			{
				public const string Insert = "api/v1/SystemLogs/Insert";
			}

			public static class Application
			{
				public const string Submit = "api/v1/Application/Submit";
			}
		}

		public static class Durations
		{
			public const int OneMinute = 60;
			public const int OneHour = OneMinute * 60;
			public const int OneDay = OneHour * 24;
		}

		public static class Cache
		{
			public const string NoCache = "No-Cache";
			public const string HalfHour = "30-Minutes";
			public const string OneHour = "1-Hour";
			public const string FourHours = "4-Hours";
			public const string HalfDay = "12-Hours";
			public const string OneDay = "1-Day";
		}

		public static class CacheKeys
		{
			public const string SitecoreTranslateText = "SitecoreTranslateText::{0}";
		}
	}
}
