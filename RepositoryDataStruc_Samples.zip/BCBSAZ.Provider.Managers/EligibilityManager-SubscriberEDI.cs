﻿using System;
using System.Collections.Generic;
using System.Text;
using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;

namespace BCBSAZ.Provider.Managers
{
	partial class EligibilityManager
	{
		private string GenerateSubscriberEDI(InquiryRequest request, string serviceType)
		{
			var ediInfo = new EDIInfo(request.ProviderId);
			var controlNum = GenerateControlNumber();
			var dob = request.DateOfBirth.ToString(GsDateFormat);
			var dos = request.DateOfService.ToString(GsDateFormat);

			return $"ISA*00*          *00*          *ZZ*AZX12WEB       *33*53589          *{ediInfo.IsaDate}*{ediInfo.IsaTime}*^*00501*{controlNum}*1*{_x12Environment}*:~" +
			$"GS*HS*AZX12WEB*53589*{ediInfo.GsDate}*{ediInfo.IsaTime}*{controlNum}*X*005010X279A1~" +
			$"ST*270*{controlNum}*005010X279A1~" +
			$"BHT*0022*13*{controlNum}*{ediInfo.GsDate}*{ediInfo.IsaTime}~" +
			$"HL*1**20*1~" +
			$"NM1*PR*2*BCBSAZ*****NI*53589~" +
			$"HL*2*1*21*1~" +
			$"NM1*1P*2*INFORMATIONRECEIVERNAME*****{ediInfo.ProviderIdQualifier}*{request.ProviderId}~" +
			$"HL*3*2*22*0~" +
			$"TRN*1*201112290314*9149514987~" +
			$"NM1*IL*1*{request.LastName}*{request.FirstName}****MI*{request.SubscriberId}~" +
			$"DMG*D8*{dob}*{request.Gender}~" +
			$"DTP*291*D8*{dos}~" +
			$"EQ*{serviceType}~" +
			$"SE*13*{controlNum}~" +
			$"GE*1*{controlNum}~" +
			$"IEA*1*{controlNum}~";
		}
	}
}
