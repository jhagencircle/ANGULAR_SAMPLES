﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.Provider.Repositories
{
	internal static class DB
	{

		public static class Apo
		{
			public class StoredProcs
			{
				public const string GetConfigSetting = "dbo.usp_APOGet_configsetting @p0, @p1, @p2";
			}
		}

		public static class FeatureToggle
		{
			public class StoredProcs
			{
				public const string GetFeatureToggles = "dbo.usp_GetTogglesByEnvironmentAndApplication @p0, @p1";
				public const string GetApplications = "dbo.usp_GetApplications";
				public const string GetEnvironments = "dbo.usp_GetEnvironments";
			}
		}

		public static class FeeSched
		{
			public class StoredProcs
			{
				public const string GetProfessionalFees = "dbo.usp_GetProfessionalFees @p0, @p1, @p2, @p3, @p4, @p5, @p6";
				public const string GetOutpatientFees = "dbo.usp_GetOutpatientFees @p0, @p1, @p2, @p3, @p4";
				public const string GetAscFees = "dbo.usp_GetAscFees @p0, @p1, @p2, @p3, @p4";
				public const string GetSpecialties = "dbo.usp_GetSpecialties";
				public const string TpaGetFeeDetail = "dbo.usp_GetTPAFees @p0, @p1, @p2";
			}
		}

		public static class InetSMP
		{
			public class StoredProcs
			{
				public const string GetMessageCount = "dbo.usp_MessageCount_Get p0";
			}
		}

		public static class TpaInet
		{
			public static class StoredProcs
			{
				public const string CheckUsername = "tpa.CheckIfUsernameExists @username, @count OUTPUT";
			}			
		}

		public static class ProviderInet
		{
			public static class StoredProcs
			{
				// Provider Schema
				public const string GetTaxIdsForOrgId = "provider.GetTaxIdsByOrgId @p0";
				public const string DoesMemberExist = "provider.DoesMemberExist @SubscriberId, @DateOfBirth, @ReturnValue OUTPUT";
				public const string GetTaxIdsForProviderAndOrgAsync = "provider.GetTaxIdsForProvider @p0, @p1";
				public const string GetUser = "provider.GetUser @p0";
				public const string GetUserRoles = "provider.GetUserRoles @p0";
				public const string GetSettingValue = "provider.GetSettingValue @p0, @p1, @p2";
				public const string GetServicetypes = "provider.GetServiceTypes";
				public const string GetNPIs = "provider.getNPIs @orgID, @userID, @beginsWith, @PageSize, @PageNumber, @TotalCount OUTPUT";
				public const string GetPreviouslySelectedServiceTypes = "provider.GetPreviouslySelectedServiceTypes @p0";
				public const string UpdateSelectedServiceTypes = "provider.UpdateSelectedServiceTypes @p0, @p1";
				public const string PurgeEligibilityAndBenefitsResults = "provider.PurgeEligibilityAndBenefitsResults @p0";
				public const string GetProviderInfo = "provider.GetProviderInfo @p0, @p1, @p2, @p3";
				public const string GetMemberCutoffDate = "provider.GetMemberCutoffDate @p0";

				// Eligibility Schema
				public const string GetValuesEntered = "eligibility.GetInquiryValuesEntered @p0";

				// PreCert Schema
				public const string PreCert_GetUserEmailAddress = "precert.GetUserEmailAddress @UserId, @EmailAddress OUTPUT";
				public const string ViewMedicalPrecerts = "precert.ViewMedicalPrecerts @p0, @p1, @p2, @p3, @p4, @p5";
				public const string ViewPharmacyPrecerts = "precert.ViewPharmacyPrecerts @p0, @p1, @p2, @p3, @p4, @p5";
				public const string SaveUserInfo = "precert.SaveUserInfo @p0, @p1, @p2, @p3, @p4, @p5";
				public const string GetUserInfo = "precert.GetUserInfo @p0";

				// TPA Schema
				public const string GetNPIsForTpa = "tpa.getNPIsForTpa @beginsWith, @PageSize, @PageNumber, @TotalCount OUTPUT";
				public const string CreateTpaUser = "tpa.CreateTpaUser @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9"; 
				public const string TpaGetPlaceOfService = "tpa.getPlaceOfService @dateOfService, @query, @PageSize, @PageNumber, @TotalCount OUTPUT";
				public const string TpaGetProviderContractStatus = "tpa.GetProviderContractStatus @p0, @p1, @p2, @p3";
				public const string TpaGetProviderInfo = "tpa.GetProviderInfo @p0, @p1, @p2";

				// OUM Schema
				public const string GetOrgUsers = "oum.GetOrgUsers @p0";
				public const string GetUserProfile = "oum.GetUserProfile @p0";
				public const string InsertUserProfile = "oum.InsertUserProfile @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11";
				public const string UpdateUserProfile = "oum.UpdateUserProfile @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7";
				public const string DeleteUserProfile = "oum.DeleteUserProfile @p0, @p1";
				public const string GetProvidersForUser = "oum.GetProvidersForUser @p0, @p1, @p2";
				public const string SetProvidersForUser = "oum.SetProvidersForUser @p0, @p1, @p2, @p3";
				public const string GetSubOrgs = "oum.GetSubOrgs @p0";
				public const string GetSubOrg = "oum.GetSubOrg @p0, @p1";
				public const string DeleteSubOrg = "oum.DeleteSubOrg @p0, @p1";
				public const string UpdateSubOrg = "oum.UpdateSubOrg @p0, @p1, @p2, @p3";
				public const string InsertSubOrg = "oum.InsertSubOrg @p0, @p1, @p2, @p3";
				public const string GetSubOrgUsers = "oum.GetSubOrgUsers @p0, @p1";
				public const string GetProvidersForSubOrg = "oum.GetProvidersForSubOrg @p0, @p1";
				public const string SetProvidersForSubOrg = "oum.SetProvidersForSubOrg @p0, @p1, @p2";

				//Remits Schema
				public const string GetAvailableTaxIds = "dbo.usp_GetTaxInfoByOrgId @p0"; 


				// Legacy (dbo) Schema
				public const string GetInstitutionCount = "dbo.usp_getInstitutionCount @pdTaxId, @pdProvId, @institutionCount OUTPUT";
			}
		}

		public static class Security
		{
			public static class StoredProcs
			{
			}
		}

		public static class TICustom
		{
			public static class StoredProcs
			{
				public const string CheckAssocPlanProfilePrefix = "dbo.usp_CheckAssocPlanProfilePrefix @ReturnCode OUTPUT, @PrefixToCheck";
				public const string IsDelegatedMember = "dbo.usp_IsDelegatedMember @ReturnCode OUTPUT, @SubscriberID";
			}
		}

		public static class SystemLogs
		{
			public static class StoredProcs
			{
				public const string LogException = "dbo.usp_LogException @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11, @p12, @p13";
				public const string LogTransaction = "dbo.usp_LogSocketTransaction @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9";
			}
		}

		public static class ContractIssuance
		{
			public static class StoredProcs
			{
				public const string GetBenefitBookStock = "dbo.GetMember_Eligibility_By_SubId_ByDateOfService @p0, @p1";
				public const string GetBenefitBookDoc = "dbo.GetMember_Document_By_SubId_ByDateOfService_For_Provider_WODoc @p0, @p1";
			}
		}

		public static class Group2
		{
			public static class StoredProcs
			{
				public const string GetGroupNameByGroupNumber = "dbo.usp_GetGroupNameByGroupNumber @p0";
			}
		}

    public static class BCBSAZSQl
    {
        public static class StoredProcs
        {
            public const string IsIdCardSuppressedForProvider = "dbo.IsIdCardSuppressedForProvider @p0, @p1, @p2, @p3, @p4";

        }
    }

		public static class Subscriber
		{
			public static class StoredProcs
			{
				public const string ValidatePatient = "provider.ValidatePatient @p0, @p1, @p2, @p3, @p4 ";
				public const string GetPatientAddress = "provider.GetPatientAddress @p0, @p1";

			}
		}

		public static class ClearingHouse
		{
			public static class StoredProcs
			{
				public const string CHSGroupNumber = "dbo.usp_IsCHSGroup @p0 ";
				public const string TPAInfo = "dbo.usp_GetTPAInfoByTPANum @p0 ";
			}
		}

		public static class Codes
		{
			public static class StoredProcs
			{
				public const string GetDiagnosisCodes = "dbo.getDiagnosisCodes @beginsWith, @PageSize, @PageNumber, @TotalCount OUTPUT";
			}
		}

		public static class Claims
		{
			public static class StoredProcs
			{
				public const string GetStatusCodes = "Claim.GetClaimStatusCodes";
				public const string GetMessageCodes = "Claim.GetClaimMessageCodes";
				public const string PurgeClaimsResults = "provider.PurgeClaimsResults @p0";
			}
		}

		public static class Email
		{
			public static class StoredProcs
			{
				public const string QueueEmail = "dbo.usp_QueueEmail @p0, @p1, @p2, @p3, @p4, @p5";
			}
		}
	}
}
