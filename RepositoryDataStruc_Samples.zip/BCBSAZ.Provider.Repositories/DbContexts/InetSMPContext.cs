﻿using BCBSAZ.Provider.Models.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{

	public interface IInetSMPContext : IDbContext
	{
		DbSet<MessageCount> MessageCounts { get; }
	}

	public class InetSMPContext : DbContext, IInetSMPContext
	{
		/// <summary>
		/// Creates a new instance of the FeeSched DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public InetSMPContext(DbContextOptions<InetSMPContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<MessageCount>().HasNoKey();
		}

		public DbSet<MessageCount> MessageCounts { get; protected set; }

	}
}
