﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Settings;

namespace BCBSAZ.Provider.Managers.RequestValidators.Settings
{
	internal static class SettingRequestValidator
	{
		public static void Validate(this SettingValueRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(SettingValueRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.ApplicationName))
				yield return new InvalidModelExceptionDetail(nameof(SettingValueRequest.ApplicationName), new ArgumentException("Application Name is not valid."));

			if (string.IsNullOrWhiteSpace(request.SettingName))
				yield return new InvalidModelExceptionDetail(nameof(SettingValueRequest.SettingName), new ArgumentException("Setting Name is not valid."));
		}
	}
}
