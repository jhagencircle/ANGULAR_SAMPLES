﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface
{
    public interface IEftEnrollmentManager
    {
        Task<bool> CreateEftUserProfileAsync(EftEnrollmentRequest request);
        Task<bool> UpdateEftUserProfileAsync(EftEnrollmentRequest request, ProviderEftStatusEnum status = ProviderEftStatusEnum.NotSaved);       

    }
}


