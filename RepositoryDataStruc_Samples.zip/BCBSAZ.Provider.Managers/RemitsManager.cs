﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Interfaces.WCFClients;
using BCBSAZ.Provider.Models.Data.Remits;
using BCBSAZ.Provider.Models.Exceptions;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Remits;
using BCBSAZ.Provider.Utilities;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using system;



namespace BCBSAZ.Provider.Managers
{
	public class RemitsManager : IRemitsManager
	{

		private readonly IWCFClientFactory _wcfClientFactory;
		private readonly ILogger _logger;
		private readonly IHttpContextAccessor _contextAccessor;
		private readonly ISettingsManager _settingsManager;
		private readonly IVelocityApiClient _velocityApiClient;
		private readonly IRemitsRepository _remitsRepository;
		private readonly IOnlineRemitsApiClient _onlineRemitsApiClient;
		private readonly ITransactionLogRepository _transitionsLogRepository;

		private static readonly JsonSerializerSettings _serializerSettings = GetJsonSerializerSettings();

		public RemitsManager(IWCFClientFactory wcfClientFactory, IHttpContextAccessor contextAccessor, ILogger<RemitsManager> logger, ISettingsManager settingsManager, IVelocityApiClient velocityApiClient,
			IRemitsRepository remitsRepository, IOnlineRemitsApiClient onlineRemitsApiClient, ITransactionLogRepository transitionsLogRepository)
		{
			_wcfClientFactory = wcfClientFactory;
			_logger = logger;
			_contextAccessor = contextAccessor;
			_settingsManager = settingsManager;
			_onlineRemitsApiClient = onlineRemitsApiClient;
			_velocityApiClient = velocityApiClient;
			_remitsRepository = remitsRepository;
			_transitionsLogRepository = transitionsLogRepository;

		}

		public async Task<IEnumerable<SearchVelocityRemitDocumentResponse>> SearchMultipleVelocityRemitDocumentAsync(string transactionNumber)
		{
				var commercial = CreateRemitRequest(Constants.VelocityApis.DocumentEopRemitComm, Constants.VelocityApis.DocumentTypeGroupRemitsComm, transactionNumber);
				var nonCommercial = CreateRemitRequest(Constants.VelocityApis.DocumentEopRemit, Constants.VelocityApis.DocumentTypeGroupRemits, transactionNumber);
				var comTask = GetVelocityRemitDocumentWithExceptionFilterAsync(commercial);
				var nonTask = GetVelocityRemitDocumentWithExceptionFilterAsync(nonCommercial);
				var docs = await Task.WhenAll(comTask, nonTask);
				var result = CheckForMultipleResponsesAsync(docs);

			return result;

		}

		public IEnumerable<SearchVelocityRemitDocumentResponse> CheckForMultipleResponsesAsync(IEnumerable<SearchVelocityRemitDocumentResponse>[] request)
		{
			var document1 = request.First().Any();
			var document2 = request.Last().Any();
			var response = document1 ^ document2 ? request.Where(req => req.Any() is true).FirstOrDefault() : new List<SearchVelocityRemitDocumentResponse>();
			return response;
		}

		private async Task<IEnumerable<SearchVelocityRemitDocumentResponse>> GetVelocityRemitDocumentWithExceptionFilterAsync(SearchVelocityRemitDocumentRequest request)
		{
			var result = await SearchVelocityRemitDocument(request);
			return result;

		}

		private SearchVelocityRemitDocumentRequest CreateRemitRequest(string docType, string docGroup, string transNumber)
		{
			var searchRequest = new SearchVelocityRemitDocumentRequest()
			{
				DocumentType = docType,
				DocumentTypeGroup = docGroup,
				keywords = new List<NameValuePair>() { new NameValuePair() { Name = "Transaction ID", Value = transNumber } }
			};
			return searchRequest;
		}

		public async Task<ProviderMergedRemittanceResponse> GetMergedRemitsAsync(WebUser webUser, RemitSearchRequest request)
		{
			var processInfo = new StringBuilder();

			var apiProcessTimer = Stopwatch.StartNew();

			var mergedRemitsProcessTimer = Stopwatch.StartNew();

			if (request.TaxId.IsNullOrEmpty())
			{
				var taxIdList = await _remitsRepository.GetProviderTaxIdsAvailableForRemitAsync(webUser.OrgId);
				request.AvailableTaxIDs = string.Join(",", taxIdList.Select(x => x.TaxId));
			}

			if (request.ServiceStartDate == DateTime.MinValue) request.ServiceStartDate = null;
			if (request.ServiceEndDate == DateTime.MinValue) request.ServiceEndDate = null;


			var wcfRemittances = Enumerable.Empty<ProviderRemittance>();
			var apiRemittances = Enumerable.Empty<ProviderRemittance>();
			var mergedRemittanceResponse = new ProviderMergedRemittanceResponse();

			var jsonRequest = JsonConvert.SerializeObject(request, _serializerSettings);

			var tasks = new List<Task>();

			var IsNewRemitApiOn = (await _settingsManager.GetSettingValueAsync(Constants.Settings.Names.UseNewRemitsApi, Constants.Settings.Defaults.UseNewRemitsApi, webUser)).AsBool();

			//TODO: Hard coded for temporary test, can be remove after next release
			var remitTestOption = (await _settingsManager.GetSettingValueAsync("Remit Test", "0", webUser)).AsInt();

			if (IsNewRemitApiOn)
			{
				tasks.Add(Task.Run(async () =>
				{
					try
					{
						//EdiProcessTime - start
						//TODO: Hard coded for temporary test, can be remove after next release
						if (remitTestOption == 1 || remitTestOption == 3)
						{
							throw new InvalidApiResponseException("Test Exception for Api Exception", new Exception("This is test exception"));
						}

						apiRemittances = await GetRemitsAsync(request);

					}
					catch (Exception ex)
					{
						mergedRemittanceResponse.IsRemitApiSuccess = false;

						_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Retrieving Remits from Velocity API");
						processInfo.AppendLine($"Error Retrieving Remits from API: {ex.GetType().FullName} - " + ex.GetFullMessage(Environment.NewLine));

					}

					finally
					{
						apiProcessTimer.Stop();

						processInfo.AppendLine($"Remits API took {apiProcessTimer.Elapsed.TotalSeconds} seconds.");
					}
				}));
			}
			var wcfProcessTimer = Stopwatch.StartNew();

			tasks.Add(Task.Run(async () =>
			{
				try
				{
					//TODO: Hard coded for temporary test, can be remove after next release
					if (remitTestOption == 2 || remitTestOption == 3)
					{
						throw new InvalidWcfServiceReponseException("Test Exception for Wcf Exception", new Exception("This is test exception"));
					}

					wcfRemittances = await GetLegacyRemitsAsync(request);
				}
				catch (Exception ex)
				{

					mergedRemittanceResponse.IsRemitWcfServiceSuccess = false;

					_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Retrieving Remits from Legacy WCF Service");

					processInfo.AppendLine($"Error Retrieving Remits from Legacy WCF Service: {ex.GetType().FullName}" + ex.GetFullMessage(Environment.NewLine));
				}

				finally
				{
					wcfProcessTimer.Stop();
					processInfo.AppendLine($"Remits WCF process took {wcfProcessTimer.Elapsed.TotalSeconds} seconds.");
				}

			}));

			await Task.WhenAll(tasks);

			mergedRemittanceResponse.Remittances = wcfRemittances.Union(apiRemittances).OrderByDescending(x => x.StatementDate);

			mergedRemitsProcessTimer.Stop();			

			var apiProcessTime = apiProcessTimer.Elapsed.TotalSeconds;
			var wcfProcessTime = wcfProcessTimer.Elapsed.TotalSeconds;			
			var totalProcessTime = mergedRemitsProcessTimer.Elapsed.TotalSeconds;			

			var responseStatus = "Success";

			if (!mergedRemittanceResponse.IsRemitWcfServiceSuccess && !mergedRemittanceResponse.IsRemitApiSuccess)
				responseStatus = "Fail-Both";
			else if (!mergedRemittanceResponse.IsRemitApiSuccess)			
				responseStatus = "Fail-API";
			else if (!mergedRemittanceResponse.IsRemitWcfServiceSuccess)
				responseStatus = "Fail-WCF";

			await _transitionsLogRepository.LogTransactionAsync(Environment.MachineName, "P_Remit", jsonRequest, responseStatus, DateTime.Now, totalProcessTime, apiProcessTime, wcfProcessTime, webUser.UserId, processInfo.ToString());

			return mergedRemittanceResponse;

		}

		public async Task<IEnumerable<ProviderRemittance>> GetLegacyRemitsAsync(RemitSearchRequest request)
		{
			using (var documentSearchClient = _wcfClientFactory.GetDocumentSearchClient())
			{
				return await documentSearchClient.GetRemitDetails(request);
			}
		}

		public async Task<IEnumerable<ProviderRemittance>> GetRemitsAsync(RemitSearchRequest request)
		{
			return await _onlineRemitsApiClient.GetRemitsAsync(request);
		}

		public async Task<RemitDocumentResponse> GetDocumentAsync(RemitDocumentRequest request)
		{
			using (var documentSearchClient = _wcfClientFactory.GetDocumentSearchClient())
			{
				RemitDocument remitDoc = null;
				try
				{
					//TODO: Hard coded for temporary test, can be remove after next release
					var remitTestOption = (await _settingsManager.GetSettingValueAsync("Remit Test", "0", _contextAccessor.HttpContext.GetWebUser())).AsInt();
					if (remitTestOption == 4)
					{
						throw new Exception("Test Exception for Wcf Exception");
					}

					remitDoc = await documentSearchClient.GetRemitDocument(request);
				}
				catch (Exception ex)
				{
					throw new InvalidWcfServiceReponseException("Error Retrieving Remit document from WCF Service", ex);
				}

				return new RemitDocumentResponse()
				{
					Document = remitDoc
				};
			}
		}

		public async Task<RemitDocumentResponse> GetVelocityRemitDocument(int documentId, StringBuilder info, WebUser webUser)
		{
			byte[] rawRemitDocument;

			try
			{
				//TODO: Hard coded for temporary test, can be remove after next release
				var remitTestOption = (await _settingsManager.GetSettingValueAsync("Remit Test", "0", _contextAccessor.HttpContext.GetWebUser())).AsInt();
				if (remitTestOption == 4)
				{
					throw new Exception("Test Exception for Velocity API Exception");
				}

				var sw1 = Stopwatch.StartNew();
				rawRemitDocument = await _velocityApiClient.GetRemitDocumentAsync(documentId);
				sw1.Stop();

				info.AppendLine($"Get Remit Document took {sw1.Elapsed.TotalSeconds} seconds.");
			}
			catch (Exception ex)
			{
				throw new InvalidApiResponseException("Error Retrieving Remit document from Velocity Api", ex);
			}

			string contentType;
			byte[] contents;

			if ((await _settingsManager.GetSettingValueAsync(Constants.Settings.Names.ConvertRemitsToPDF, "true", webUser)).AsBool())
			{
				var sw3 = Stopwatch.StartNew();
				contents = await PdfUtilities.ConvertImageToPdfAsync(rawRemitDocument);
				contentType = MediaTypeNames.Application.Pdf;
				sw3.Stop();

				info.AppendLine($"Convert to PDF took {sw3.Elapsed.TotalSeconds} seconds.");
			}
			else
			{
				var sw2 = Stopwatch.StartNew();
				contentType = MediaType.GetContentType(rawRemitDocument);
				contents = rawRemitDocument;
				sw2.Stop();

				info.AppendLine($"Get Content Type took {sw2.Elapsed.TotalSeconds} seconds.");
			}

			return new RemitDocumentResponse()
			{
				Document = new RemitDocument()
				{
					ContentType = contentType,
					Contents = contents
				},
				Info = info.ToString()
			};
		}

		public async Task<IEnumerable<SearchVelocityRemitDocumentResponse>> SearchVelocityRemitDocument(SearchVelocityRemitDocumentRequest request)
		{
			IEnumerable<SearchVelocityRemitDocumentResponse> responses;
			try
			{
				responses = await _velocityApiClient.SearchRemitDocumentAsync(request);
			}
			catch (Exception ex)
			{
				throw new InvalidApiResponseException("Error searching Remit records from Velocity Api", ex);
			}

			return responses;
		}

		private static JsonSerializerSettings GetJsonSerializerSettings() =>
			 new JsonSerializerSettings()
			 {
				 DateFormatString = "yyyy-MM-dd",
				 Formatting = Formatting.Indented,
				 NullValueHandling = NullValueHandling.Ignore,
				 ContractResolver = new CamelCasePropertyNamesContractResolver()
			 };

	}
}
