export interface IPlan {
  id: string;
  name: string;
  type: string;
  specialtyType?: string;
  coverageID?: string;
}
