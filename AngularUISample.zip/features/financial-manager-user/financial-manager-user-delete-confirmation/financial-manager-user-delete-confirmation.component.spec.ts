import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { FinancialManagerUserDeleteConfirmationComponent } from './financial-manager-user-delete-confirmation.component';

describe('FinancialManagerUserDeleteConfirmationComponent', () => {
  let component: FinancialManagerUserDeleteConfirmationComponent;
  let fixture: ComponentFixture<FinancialManagerUserDeleteConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinancialManagerUserDeleteConfirmationComponent ],
      providers: [ NgbActiveModal ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialManagerUserDeleteConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
