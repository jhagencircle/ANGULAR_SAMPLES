import {
  Component,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { ISummary } from '../shared/models/summary.model';
import {
  NgbdSortableHeader,
  SortEvent,
} from '../shared/directives/sortable.directive';
import { IStatement } from './shared/statement.model';
import { StatementService } from './shared/statement.service';
import { formatDate } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { of, Subscription } from 'rxjs';
import { AppConstants } from '../shared/constants/app-constants';
import { AccountLevelEnum } from '../shared/enums/account-level-enum';
import { groupBy, mergeMap, reduce, toArray } from 'rxjs/operators';
import { IPeriodStatement } from './shared/period-statement';

const compare = (
  v1: string | number | Date | boolean | any,
  v2: string | number | Date | boolean | any
) => (v1! < v2! ? -1 : v1! > v2! ? 1 : 0);

@Component({
  selector: 'app-historical-statements',
  templateUrl: './historical-statements.component.html',
  styleUrls: ['./historical-statements.component.scss'],
})
export class HistoricalStatementsComponent implements OnInit, OnDestroy {
  statements: IStatement[] = [];
  statementList: IPeriodStatement[] = [];
  statementFrom: Date;
  statementTo: Date;
  sortColumnsIco: any = { statementFrom: 'sort' };
  account: ISummary;
  subscriptions: Subscription[] = [];
  title: string = AppConstants.HISTORICAL_STATEMENTS_TITLE;
  informationalMessage: string =
    AppConstants.HISTORICAL_STATEMENTS_INFO_MESSAGE;
  periodStatements: any[] = [];
  accountLevelEnum = AccountLevelEnum;

  @ViewChildren(NgbdSortableHeader) headers: QueryList<NgbdSortableHeader>;

  constructor(public statementService: StatementService) {}

  ngOnInit(): void {
    this.loadHistoricalStatements();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  loadHistoricalStatements() {
    this.account = JSON.parse(localStorage.getItem('account') || '[]');

    let subscription = this.statementService
      .get(this.account.accountId)
      .subscribe((data) => {
        this.statements = data.map((d) => ({ isLoading: false, ...d }));
        if (
          this.account.billingLevel == AccountLevelEnum.SubAccount ||
          this.account.billingLevel == AccountLevelEnum.SubSubAccount
        ) {
          of(this.statements)
            .pipe(
              mergeMap((res) => res),
              groupBy((statement) => {
                return `${statement.billingPeriodFromDate},${statement.billingPeriodToDate}`;
              }),
              mergeMap((group) => group.pipe(toArray()))
            )
            .subscribe((p) => {
              this.periodStatements = p;
              this.statementList.push({
                billingPeriodFromDate: p[0].billingPeriodFromDate,
                billingPeriodToDate: p[0].billingPeriodToDate,
                statements: this.periodStatements,
                expanded: false,
              });
            });
        }
        this.onSort({ column: 'billingPeriodFromDate', direction: 'desc' });
      });
    this.subscriptions.push(subscription);
  }

  onSort({ column, direction }: SortEvent) {
    this.sortColumnsIco['statementFrom'] = this.setDirectionIco(direction);
    // resetting other headers
    if (this.headers) {
      this.headers.forEach((header) => {
        if (header.sortable !== column) {
          header.direction = '';
        }
      });
    }
    // sorting statements
    if (direction === '' || column === '') {
      if (this.account.billingLevel == AccountLevelEnum.TopAccount) {
        this.statements;
      } else {
        this.statementList;
      }
    } else {
      if (this.account.billingLevel == AccountLevelEnum.TopAccount) {
        this.statements = [...this.statements].sort((a: any, b: any) => {
          const res = compare(a[column], b[column]);
          return direction === 'asc' ? res : -res;
        });
      } else {
        this.statementList = [...this.statementList].sort((a: any, b: any) => {
          const res = compare(a[column], b[column]);
          return direction === 'asc' ? res : -res;
        });
      }
    }
  }
  setDirectionIco(direction: string): string {
    if (direction !== '') {
      return 'sort-' + direction;
    } else {
      return 'sort';
    }
  }

  downLoadPDF(statement: IStatement) {
    statement.isLoading = true;
    let fromDate = formatDate(
      statement.billingPeriodFromDate,
      'MMM d',
      'en-US'
    );
    let toDate = formatDate(
      statement.billingPeriodToDate,
      'mediumDate',
      'en-US'
    );
    let fileName = `Statement ${fromDate} - ${toDate}`;
    statement.accountId = this.account.accountId;
    let subscription = this.statementService.downloadPDF(statement).subscribe(
      (res: any) => {
        statement.isLoading = false;
        var newBlob = new Blob([res], { type: 'application/pdf' });
        const fileURL = window.URL.createObjectURL(newBlob);

        //Use a download link.
        let link: any = window.document.createElement('a');
        if ('download' in link) {
          link.setAttribute('href', fileURL);

          //Set the download attribute.
          link.setAttribute('download', fileName);

          //Simulate clicking download link.
          let event: any = window.document.createEvent('MouseEvents');
          event.initMouseEvent(
            'click',
            true,
            true,
            window,
            1,
            0,
            0,
            0,
            0,
            false,
            false,
            false,
            false,
            0,
            null
          );
          link.dispatchEvent(event);
        }
      },
      (error: HttpErrorResponse) => {
        //hide spinner
        statement.isLoading = false;
      }
    );
    this.subscriptions.push(subscription);
  }
  groupby(array: any, property: any) {
    return array.reduce((result: any, currentItem: any) => {
      const key = currentItem[property];
      if (!result[key]) {
        result[key] = [];
      }
      result[key].push(currentItem);
      return result;
    }, {});
  }
}
