﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Requests.Claims;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.Claims
{
	internal static class ClaimsInquiryRequestValidator
	{
		public static void Validate(this ClaimsInquiryRequest request, WebUser webUser)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (webUser == null)
				throw new ArgumentNullException(nameof(webUser));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(ClaimsInquiryRequest request)
		{
			if (request.ClaimsRequest == null)
			{
				yield return new InvalidModelExceptionDetail(nameof(ClaimsInquiryRequest.ClaimsRequest), new ArgumentException("Claims Request is missing."));
			}
			else
			{
				if (string.IsNullOrWhiteSpace(request.ClaimsRequest.SubscriberId))
					yield return new InvalidModelExceptionDetail(nameof(ClaimsInquiryRequest.ClaimsRequest.SubscriberId), new ArgumentException("Claims Request is missing SubscriberId"));
				else
					request.ClaimsRequest.SubscriberId = request.ClaimsRequest.SubscriberId.ToUpperInvariant();

				if ((request.ClaimsRequest.DateOfBirth < DateTime.Today.AddYears(-SettingsManager.MaxAge)) || (request.ClaimsRequest.DateOfBirth > DateTime.Today))
					yield return new InvalidModelExceptionDetail(nameof(ClaimsInquiryRequest.ClaimsRequest.DateOfBirth), new ArgumentException("Claims Request Date Of Birth is out of range."));

				if (request.ClaimsRequest.ProvidersList.IsNullOrEmpty())
				{
					yield return new InvalidModelExceptionDetail(nameof(ClaimsInquiryRequest.ClaimsRequest.ProvidersList), new ArgumentException("Claims Request is missing provider list."));
				}
				else
				{
					foreach (var prov in request.ClaimsRequest.ProvidersList)
					{
						if (prov == null)
							yield return new InvalidModelExceptionDetail(nameof(ClaimsInquiryRequest.ClaimsRequest.ProvidersList), new ArgumentException("Claims Request provider list has provider that is null."));

						if (string.IsNullOrWhiteSpace(prov.NPI) && string.IsNullOrWhiteSpace(prov.TaxId))
							yield return new InvalidModelExceptionDetail(nameof(ClaimsInquiryRequest.ClaimsRequest.ProvidersList), new ArgumentException("Claims Request provider list has provider with missing NPI and TaxId."));
					}
				}
			}
		}
	}
}
