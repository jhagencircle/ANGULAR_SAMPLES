﻿using System.Linq;

namespace System.Collections.Generic
{
	/// <summary>
	/// Extension Methods for IEnumerable<T>
	/// </summary>
	public static class EnumerableExtensions
	{
		/// <summary>
		/// Test to see if the specified array is null or contains no elements.
		/// </summary>
		/// <param name="collection">The array to be tested.</param>
		/// <returns>Returns true if the array is null or contains no elements.</returns>
		public static bool IsNullOrEmpty<T>(this IEnumerable<T> collection)
		{
			return ((collection == null) || (!collection.Any()));
		}

		/// <summary>
		/// Performs the specified action on each element of the collection.
		/// </summary>
		/// <typeparam name="T">The type of elements in the collection.</typeparam>
		/// <param name="collection">The collection of elements upon which the action will be performed.</param>
		/// <param name="validator">The validator to be used to test the item.</param>
		/// <param name="action">The delegate to perform on each element of the collection.</param>
		/// <exception cref="System.ArgumentNullException">System.ArgumentNullException</exception>
		public static void ForEachIf<T>(this IEnumerable<T> collection, Predicate<T> validator, Action<T> action)
		{
			if (collection == null) throw new ArgumentNullException(nameof(collection));
			if (validator == null) throw new ArgumentNullException(nameof(validator));
			if (action == null) throw new ArgumentNullException(nameof(action));

			foreach (T item in collection)
			{
				if (validator(item))
					action(item);
			}
		}

		/// <summary>
		/// Returns an IEnumerable result containing the original enumeration contents plus the number of elements required to complete the multiples of condition.
		/// </summary>
		/// <typeparam name="T">The type of elements in the collection.</typeparam>
		/// <param name="collection">The collection of elements.</param>
		/// <param name="multiples">The grouping requirement of the resulting enumeration.</param>
		/// <param name="createTFunc">A function that instantiates a new T instance.</param>
		/// <returns>Returns an IEnumerable result containing the original enumeration contents plus the number of elements required to complete the multiples of condition.</returns>
		public static IEnumerable<T> MultiplesOf<T>(this IEnumerable<T> collection, int multiples, Func<T> createTFunc)
		{
			if (collection == null) throw new ArgumentNullException(nameof(collection));
			if (multiples <= 0) throw new ArgumentException("Multiples must be greater than zero.", nameof(multiples));
			if (createTFunc == null) throw new ArgumentNullException(nameof(createTFunc));

			var count = 0;

			foreach (var item in collection)
			{
				count++;
				yield return item;
			}

			var returnCount = GetMultiplesOfLength(count, multiples);

			for (var idx = count; idx < returnCount; idx++)
			{
				yield return createTFunc();
			}
		}

		private static int GetMultiplesOfLength(int count, int multiples)
		{
			if (count == 0) return multiples;

			if (count % multiples == 0)
				return count;

			return ((count / multiples) + 1) * multiples;
		}
	}
}
