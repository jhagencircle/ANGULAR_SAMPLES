import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HistoricalStatementsRoutingModule } from './historical-statements-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HistoricalStatementsComponent } from './historical-statements.component';
import { SortableDirectiveModule } from '../shared/modules/sortable-directive.module';

@NgModule({
  declarations: [HistoricalStatementsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HistoricalStatementsRoutingModule,
    NgbModule,
    SortableDirectiveModule,
  ],
})
export class HistoricalStatementsModule {}
