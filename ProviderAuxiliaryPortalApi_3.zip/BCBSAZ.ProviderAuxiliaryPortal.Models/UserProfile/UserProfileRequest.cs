﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models.UserProfile
{
    public class UserProfileRequest
    {
        public UserProfile UserProfile { get; set; }
        public bool PasswordReset { get; set; }
        public string UserId { get; set; }
        public string OrgId { get; set; }
        public IEnumerable<AssignedProvider> Providers { get; set; }
    }
}
