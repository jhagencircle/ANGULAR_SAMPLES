import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BillingFaqsComponent } from './billing-faqs.component';
import { BillingFaqMock } from '../shared/mocks/billing-faq.mock';
import { BillingFaqsService } from './shared/billing-faqs.service';
import { AppConstants } from '../shared/constants/app-constants';
import { IFaq } from './shared/faq.model';

describe('BillingFaqsComponent', () => {
  let component: BillingFaqsComponent;
  let fixture: ComponentFixture<BillingFaqsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [BillingFaqsComponent],
      providers: [{ provide: BillingFaqsService, useClass: BillingFaqMock }],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingFaqsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should make a call to billingFaqsService.get()', () => {
    spyOn(component.billingFaqsService, 'get').and.callThrough();

    component.loadFAQs();

    expect(component.billingFaqsService.get).toHaveBeenCalled();
  });

  it('should have "faqList" populated ', () => {
    expect(component.faqList.length).toBeGreaterThan(0);
    expect(component.faqList).toEqual(BillingFaqMock.mockedBillingFAQ);
  });

  it(`should have the title ${AppConstants.BILLING_FAQ_TITLE}`, () => {
    expect(component.title).toEqual(AppConstants.BILLING_FAQ_TITLE);
  });

  it('should onClickDisplayAnswer(faq) toggle isDisplayed', () => {
    const faq: IFaq = BillingFaqMock.mockedBillingFAQ[0];

    expect(faq.isDisplayed).toBe(false, 'hide answer at first');
    component.onClickDisplayAnswer(faq);
    expect(faq.isDisplayed).toBe(true, 'display answer after click');
    component.onClickDisplayAnswer(faq);
    expect(faq.isDisplayed).toBe(false, 'hide answer after second click');
  });

  it('should hide answer', () => {
    const answer =
      fixture.debugElement.nativeElement.querySelector('div.card-body');
    expect(answer).toBeFalsy();
  });
});
