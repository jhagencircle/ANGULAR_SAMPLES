﻿using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IGroup2Context : IDbContext
	{
		DbSet<GroupName> GroupNames { get; }
	}

	public class Group2Context : DbContext, IGroup2Context
	{
		/// <summary>
		/// Creates a new instance of the Group2 DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public Group2Context(DbContextOptions<Group2Context> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<GroupName>().HasNoKey();
		}

		public DbSet<GroupName> GroupNames { get; protected set; }
	}
}
