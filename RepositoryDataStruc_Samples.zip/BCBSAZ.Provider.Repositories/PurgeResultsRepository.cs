﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using System;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories
{
	public class PurgeResultsRepository : IPurgeResultsRepository
	{
		private readonly IPurgeContext _purgeContext;
		public PurgeResultsRepository(IPurgeContext p) 
		{
			_purgeContext = p;
		}

		public Task PurgeClaimsResultsAsync(int days)
		{
			var dateForPurge = DateTime.Now.AddDays(days * -1);
			return _purgeContext.Database.ExecuteSqlRawAsync(DB.Claims.StoredProcs.PurgeClaimsResults, days == 0 ? dateForPurge as DateTime? : null);
		}

		public Task PurgeEligibilityInquiryResultsAsync(int days)
		{
			var dateForPurge = DateTime.Now.AddDays(days * -1);
			return _purgeContext.Database.ExecuteSqlRawAsync(DB.ProviderInet.StoredProcs.PurgeEligibilityAndBenefitsResults, days == 0 ? dateForPurge as DateTime? : null);
		}
	}
}
