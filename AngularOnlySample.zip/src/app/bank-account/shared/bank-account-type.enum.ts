export enum BankAccountTypeEnum{
    Savings = "savings",
    Checking = "checking"
}