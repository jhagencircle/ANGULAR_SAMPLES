export interface IAutoPayment {
  accountId: string;
  bankAccountId: number;
}
