export class FileUpload{
    file: any;
    is_upload_in_progress: boolean;
    upload_result: any;
}