﻿using System;

namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface IProviderClient : IDisposable
	{
		string GetTest();
		string GetWcfIpAddress();
	}
}
