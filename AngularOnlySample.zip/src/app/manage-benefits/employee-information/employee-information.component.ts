import { Component, OnInit, Input } from '@angular/core';
import { IEmployee } from '../shared/models/employee.model';

@Component({
  selector: 'app-employee-information',
  templateUrl: './employee-information.component.html',
  styleUrls: ['./employee-information.component.scss'],
})
export class EmployeeInformationComponent implements OnInit {
  @Input() employeeInformation: IEmployee;
  employeeName: string = '';
  constructor() {}

  ngOnInit(): void {
    this.employeeName =
      this.employeeInformation.firstName +
      ' ' +
      this.employeeInformation.lastName;
  }
}
