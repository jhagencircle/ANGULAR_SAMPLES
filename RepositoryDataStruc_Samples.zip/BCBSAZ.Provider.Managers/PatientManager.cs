﻿using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Responses.Common;

namespace BCBSAZ.Provider.Managers
{
	public class PatientManager : IPatientManager
	{
		private readonly IPatientRepository _patientRepository;

		public PatientManager(IPatientRepository patientRepository)
		{
			_patientRepository = patientRepository;
		}

		public async Task<Select2Response> GetPatientByOrgAsync(Select2Request request, string orgId)
		{
			// DBContext doesn't allow multiple call simultaneously, here calling them in order.
			var patients = await _patientRepository.SearchPatientsAsync(orgId, request.Query, request.PageNumber, request.PageSize);
			var patientCount = await _patientRepository.GetPatientsCountAsync(orgId, request.Query);

			return new Select2Response()
			{
				Results = patients.Select(x =>
				{
					return new Select2Item()
					{
						Id = $"{x.SubscriberId}|{x.PatientFirstName}|{x.PatientLastName}|{x.DateOfBirth}|{x.IsDependent}|{x.LOB}|{x.PatientGender}|{x.SubscriberFirstName}|{x.SubscriberLastName}",
						Text = $"{x.SubscriberId}|{x.PatientFirstName}|{x.PatientLastName}|{x.DateOfBirth}|{x.IsDependent}|{x.LOB}|{x.PatientGender}|{x.SubscriberFirstName}|{x.SubscriberLastName}",
					};
				}),
				TotalCount = patientCount
			};
		}
	}
}
