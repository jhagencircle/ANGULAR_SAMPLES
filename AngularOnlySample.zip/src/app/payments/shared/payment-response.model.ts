export interface IPaymentResponse {
  transactionId?: number;
  accountId?: string;
  paymentTransactionNumber: string;
  paymentAmount: number;
  paymentTransactionDate: string;
  paymentTransactionOrigin?: string;
  paymentTokenId?: number;
  statusName: string;
  invoiceNumber?: number;
  account: string;
  bankAccount: string;
  billingPeriod: string;
}
