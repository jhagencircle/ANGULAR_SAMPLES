﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Applications
{
	public class ApplicationViewModel
	{
		public ProviderCredentialForm Form { get; set; } 
		public Attachments Attachments { get; set; }

		public string Signature { get; set; }
		public string CaqhIntro { get; set; }
		public string CaqhOutro { get; set; }
		public string CaqhError { get; set; }
		public string ConciergeInfo { get; set; }
		public string AddressesOutro { get; set; }
		public string SuccessContent { get; set; }


		public bool SubmitSuccess { get; internal set; }
		public long ApplicationId { get; internal set; }
		public DateTime SubmittedDate { get; internal set; }

		public bool SubmitFailure { get; internal set; }
		public bool NotValid { get; internal set; }
	}
}
