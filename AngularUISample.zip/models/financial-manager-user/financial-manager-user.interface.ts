export interface IFinancialManagerUser  {
    userId: string;
    lastName: string;
    firstName: string;
    phone: string;
    email: string;
    userName: string;
    password: string;
    securityQuestion: string;
    securityQuestionAnswer: string;
    subOrganization: string;
}
