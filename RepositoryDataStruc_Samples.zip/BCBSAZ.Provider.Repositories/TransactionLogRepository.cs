﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Repositories
{
	public class TransactionLogRepository : ITransactionLogRepository
	{
		private readonly ITransactionLogContext _context;
		private readonly ILogger _logger;

		public TransactionLogRepository(ITransactionLogContext context, ILogger<SystemLogsRepository> logger)
		{
			_context = context;
			_logger = logger;
		}

		public async Task LogTransactionAsync(string systemName, string transactionType, string requestBuffer, string errorCode, DateTime endProcess, double totalProcessTime, double totalEdiProcessTime, double postProcessTime, string userId, string info)
		{
			try
			{
				await _context.Database.ExecuteSqlRawAsync(
					DB.SystemLogs.StoredProcs.LogTransaction,
					endProcess,
					transactionType,
					systemName,
					requestBuffer,
					errorCode,
					totalProcessTime,
					totalEdiProcessTime,
					postProcessTime,
					userId,
					info);
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, "Error writing to Transaction Log");
			}
		}
	}
}
