﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models.UserProfile
{
    public class AssignedProvider
    {
        public bool IsSelected { get; set; }
        public string ProviderId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public ProviderContractStatusEnum Status { get; set; }
    }
}
