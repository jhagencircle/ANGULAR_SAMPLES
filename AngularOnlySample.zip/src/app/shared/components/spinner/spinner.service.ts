import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SpinnerService {
  private _isLoading: boolean;
  private sub = new BehaviorSubject<boolean>(false);

  constructor() {}

  returnAsObservable() {
    return this.sub.asObservable();
  }

  public onLoaderVisibilityChange(): Observable<boolean> {
    return this.sub.asObservable();
  }

  show(isLoading: boolean): void {
    this._isLoading = isLoading;
    this.sub.next(this._isLoading);
  }
}
