﻿using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Requests.FeeSchedule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BCBSAZ.Provider.Managers.RequestValidators.FeeSchedule
{
	internal static class BaseRequestValidator
	{
		/// <summary>
		/// Validates the common properties of the Fee Schedule Requests
		/// </summary>
		/// <param name="request">The fee schedule request to be validated.</param>
		/// <returns>Returns an empty collection if the request is valid, returns validation details if the request is invalid.</returns>
		public static IEnumerable<InvalidModelExceptionDetail> GetViolations(BaseRequest request)
		{
			const string _missingDateMessage = "Search date is required.";
			const string _invalidDateMessage = "The Search date specified is out of the valid search range.";
			const string _missingSiteMessage = "At least one Site of Service code is required.";
			const string _missingSpecialtyOrProcedure = "Either specialty or at least one Procedure code is required.";
			const string _tooManyProcedures = "No more than ten (10) procedure codes may be specified.";

			if (request.Discount < 0m)
				request.Discount = 0m;

			if (request.SearchDate.HasValue)
			{
				// TODO: Is there a lower limit for the search date?  Right now we've set it at 2 years ago, what should it be?
				if ((request.SearchDate.Value < DateTime.Today.AddYears(-2)) || (request.SearchDate.Value > DateTime.Today.AddDays(35)))
					yield return new InvalidModelExceptionDetail(nameof(BaseRequest.SearchDate),
						_invalidDateMessage, new ArgumentOutOfRangeException(nameof(BaseRequest.SearchDate)));
			}
			else
			{
				yield return new InvalidModelExceptionDetail(nameof(BaseRequest.SearchDate),
					_missingDateMessage, new ArgumentException(_missingDateMessage));
			}

			if (string.IsNullOrWhiteSpace(request.SiteOfServiceCodes))
			{
				yield return new InvalidModelExceptionDetail(nameof(BaseRequest.SiteOfServiceCodes),
					_missingSiteMessage, new ArgumentException(_missingSiteMessage));
			}

			if (string.IsNullOrWhiteSpace(request.ProcedureCodes))
			{
				if (string.IsNullOrWhiteSpace(request.Specialty))
				{
					yield return new InvalidModelExceptionDetail(nameof(BaseRequest.ProcedureCodes) + " or " + nameof(BaseRequest.Specialty),
						_missingSpecialtyOrProcedure, new ArgumentException(_missingSpecialtyOrProcedure));
				}
			}
			else
			{
				var procCodes = request.ProcedureCodes.Split(ManagerConstants.CSV, StringSplitOptions.RemoveEmptyEntries);
				if (procCodes.Length > 10)
					yield return new InvalidModelExceptionDetail(nameof(BaseRequest.ProcedureCodes),
						_tooManyProcedures, new ArgumentOutOfRangeException(nameof(BaseRequest.ProcedureCodes)));
			}
		}
	}
}
