﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Requests.FeeSchedule;
using BCBSAZ.Provider.Models.Responses.FeeSchedule;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	/// <summary>
	/// Business Logic for Fee Schedule Api methods.
	/// </summary>
	public interface IFeeScheduleManager
	{
		/// <summary>
		/// Gets Professional Fee Schedules
		/// </summary>
		/// <param name="request">An unvalidated Professional Fees Request</param>
		/// <returns>A result object containing the Professional Fees grouped by Site of Service and DME</returns>
		ProfessionalFeesResponse GetProfessionalFees(ProfessionalFeesRequest request);

		/// <summary>
		/// Gets Outpatient Fee Schedules
		/// </summary>
		/// <param name="request">An unvalidated Outpatient Fees Request</param>
		/// <returns>A result object containing the Outpatient Fees grouped by Site of Service</returns>
		OutpatientFeesResponse GetOutpatientFees(OutpatientFeesRequest request);

		/// <summary>
		/// Gets ASC Fee Schedules
		/// </summary>
		/// <param name="request">An unvalidated ASC Fees Request</param>
		/// <returns>A result object containing the ASC Fees grouped by Site of Service</returns>
		AscFeesResponse GetAscFees(AscFeesRequest request);

		TaxIdsForProviderResponse GetTaxIdsForProvider(TaxIdsForProviderRequest request);

		SpecialtiesResponse GetSpecialties(SpecialtiesRequest request);
	}
}
