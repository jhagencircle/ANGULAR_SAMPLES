import { importType } from '@angular/compiler/src/output/output_ast';
import { Component, Input, OnInit, SimpleChange } from '@angular/core';
import { NotificationType } from 'src/app/shared/enums/notification-type-enum';
import { NotificationService } from './notification.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
})
export class NotificationComponent implements OnInit {
  showNotification = false;
  message = '';
  type: NotificationType;
  notificationType = NotificationType;

  private _notificationServiceSubject$: Subject<void>;

  constructor(private _notificationService: NotificationService) {
    this._notificationServiceSubject$ = new Subject<void>();
  }

  ngOnInit(): void {
    this._notificationService
      .onNotificationVisibilityChange()
      .pipe(takeUntil(this._notificationServiceSubject$))
      .subscribe((visible: boolean) => {
        this.showNotification = visible;
      });
    this._notificationService
      .onConfigNotificationChange()
      .pipe(takeUntil(this._notificationServiceSubject$))
      .subscribe((conf: any) => {
        this.message = conf.message;
        this.type = conf.type;
      });
  }

  ngOnChanges(changes: SimpleChange) {
    console.log(changes);
  }

  closeAlert() {
    this._notificationService.closeNotification();
  }
}
