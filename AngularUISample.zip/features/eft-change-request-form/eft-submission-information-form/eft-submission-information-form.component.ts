import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ValidationRegex } from 'src/app/models/data/validation-regex';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import { FileUpload } from 'src/app/models/data/file-upload.model';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { IProviderInformation } from 'src/app/models/eft-change-request/eft-provider-information.interface';
import { FileUploadService } from 'src/app/services/file-upload.service';
import { Files } from 'ng-bootstrap-icons/icons';
import { Content } from '@angular/compiler/src/render3/r3_ast';

@Component({
  selector: 'app-eft-submission-information-form',
  templateUrl: './eft-submission-information-form.component.html',
  styleUrls: ['./eft-submission-information-form.component.scss', '../eft-change-request-form.component.scss']
})

export class EftSubmissionInformationFormComponent implements OnInit {  

 /*  test = 0;
  callMethod() {
    console.log('successfully executed.');
    this.test++;
  }
  
  @Output() newItemEvent = new EventEmitter<any>();
  @Output() countChanged: EventEmitter<number> = new EventEmitter()

   */
/*   addNewItem(value: string) {
    this.newItemEvent.emit(value);
  } */

  @ViewChild('NgbdDatepicker') datepickerControl: NgbDateStruct;
  model: NgbDateStruct;
  selected_files: FileUpload[] = [];

  @ViewChild("fileSelector", {static: false}) file_selector!: ElementRef;

  file_selection_form: FormGroup;
  
 /*  testin: String

  testing: string = 'pdfSection3'; */
  // Subscriptions
  private file_selection_sub!: Subscription;

  public eftProfile: IProviderInformation;  

  public submissionInformationForm: FormGroup;  

  constructor(private formBuilder: FormBuilder, private http: HttpClient, private fileUploadService: FileUploadService) { 
    this.createForm(); 
    this.file_selection_form = new FormGroup({
        file_selection: new FormControl()
      });
    }

  ngOnInit(): void {   this.trackFileSelection();
    this.fileUploadService.selectedFile={Name: "Test.jpg",Id:"1"}
  }

   openFileSelector(){
    //const numberOfFiles = this.fileUploadService.saveIds(3);
    const file_selection = this.file_selector.nativeElement;
    file_selection.click();    
  } 

   trackFileSelection(){
    this.file_selection_sub = this.file_selection_form.get('file_selection')?.valueChanges.subscribe(
      ()=>{

        const file_selection = this.file_selector.nativeElement;
        this.selectFiles(file_selection.files) ;
        this.file_selector.nativeElement.value = '';
      }
    ) as Subscription;
  } 
  
   selectFiles(incoming_files: any[]){
    
    const jpgRegEx : RegExp = /.+\.jpg$/;
    const pdfRegEx : RegExp = /.+\.pdf$/;  

    let incoming_file_count  = incoming_files.length;
    let maxNumberFiles = incoming_file_count + this.selected_files.length;      

    if(maxNumberFiles <=3){      
      for(let i = 0; i < incoming_file_count; i++){             
        let incoming_file = incoming_files[i];   
          let selected_file = {
            file: incoming_file,
            is_upload_in_progress: false,
            upload_result: null
          };          
          if(jpgRegEx.test(incoming_file.name) || pdfRegEx.test(incoming_file.name)){
            this.selected_files.push(selected_file);
            this.fileUploadService.selected_files.push(selected_file); //save in Service 9/21          
          }
           //return this.http.post((`${environment.apiBaseUrl}/v1/common/time`);
      }       
    }
  }   
 
  inititateFileCancel(index: number){
    let file_for_upload = this.selected_files[index];   
      this.cancelFile(index);
      console.log(file_for_upload.file.name);
  }
  cancelFile(index: number){
    this.selected_files.splice(index, 1);
  }

  createForm(): void{
    this.submissionInformationForm = this.formBuilder.group({
      submissionReason: ['new', { updateOn: 'change', validators: [Validators.required] }],
      submissionOldAccount: ['', { updateOn: 'change' }],
      submissionPersonTitle: ['', { updateOn: 'change', validators: [Validators.required, Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)] }],
      submissionSignature: ['', { updateOn: 'change', validators: [Validators.required, Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)] }],
      submissionEffectiveDate: ['', { updateOn: 'change', validators: [Validators.required]}],
      submissionSignedDate: [{ value: '', disabled: true }],
      submissionAgreement: ['', { updateOn: 'change', validators: [Validators.requiredTrue ]}]     
      
    });
  }

  public isInvalid(control: AbstractControl): boolean {
    if(!control) return false;
    return control.invalid && (control.touched || control.dirty);
  }

  public save(): void{        
    //this.downloadPageSection();
    this.setFormDirty();
  }
  
  public validateOldAccount(): void {
    const reason = this.formControl.submissionReason;
    const oldAccount = this.formControl.submissionOldAccount;

    if (reason.value === "change" || reason.value === "cancel") {
      oldAccount.setValidators([Validators.required, Validators.pattern(ValidationRegex.ALPHA_NUMERIC_SPACE_APOSTROPHE)]);
      oldAccount.updateValueAndValidity();
    }
    else {
      oldAccount.patchValue('');
      oldAccount.clearValidators();
      oldAccount.updateValueAndValidity();
    }
  }

  public setSignedDate(checked: boolean): void {
    const today = moment().format("MM/DD/YYYY");
    if (checked) {
      this.formControl.submissionSignedDate.setValue(today);
    }
  }

  private setFormDirty(): void{
    for (var control in this.submissionInformationForm.controls) {
      this.submissionInformationForm.controls[control].markAsDirty();
    }
  }

  /******************************** GETTERS **************************************/
  
  public get formControl() { return this.submissionInformationForm.controls; }

  /*****************************************************************************/
}
