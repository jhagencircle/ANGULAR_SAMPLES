import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { ISummary } from '../models/summary.model';
@Injectable({
  providedIn: 'root',
})
export class AccountMock {
  constructor() {}
  public static mockedAccount: ISummary = {
    billId: 4,
    voidBillId: 0,
    voidBillIndicator: false,
    accountId: '019867',
    accountName: 'Top Account A',
    totalEmployees: 450,
    statementFrom: '2021-06-01T00:00:00',
    statementTo: '2021-06-30T00:00:00',
    dueDate: '2021-07-12T00:00:00',
    status: 'Due',
    totalPaidAmount: 0,
    totalBilledAmount: 45000,
    totalAdjustedAmount: 0,
    totalDueAmount: 45000,
    asc: false,
    requiresRecalculation: [],
    billingLevel: 'sub',
    subscriptionLevel: 'sub',
    balanceForwardAmount: 0,
    newChargesAmount: 0,
    subSubAccounts: [],
    isSubSubAccountsDisplayed: false,
    isChecked: false,
  };

  /*get(): Observable<any> {
    return of({
      billId: 4,
      voidBillId: 0,
      voidBillIndicator: false,
      accountId: '019867',
      accountName: 'Top Account A',
      totalEmployees: 450,
      statementFrom: '2021-06-01T00:00:00',
      statementTo: '2021-06-30T00:00:00',
      dueDate: '2021-07-12T00:00:00',
      status: 'Due',
      totalPaidAmount: 0,
      totalBilledAmount: 45000,
      totalAdjustedAmount: 0,
      totalDueAmount: 45000,
      asc: false,
      requiresRecalculation: false,
      billingLevel: 'sub',
      subscriptionLevel: 'sub',
      balanceForwardAmount: 0,
      newChargesAmount: 0,
      isChecked: false,
    });
  }*/

  update(): Observable<boolean> {
    return of(true);
  }
  get(): Observable<ISummary> {
    return of(AccountMock.mockedAccount);
  }
}
