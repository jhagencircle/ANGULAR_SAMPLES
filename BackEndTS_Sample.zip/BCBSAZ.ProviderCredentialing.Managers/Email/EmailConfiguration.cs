﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Managers.Email
{
	public class EmailConfiguration
	{
		public string SmtpHost { get; set; }

		public int SmtpPort { get; set; }

	}
}
