import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

import { IPlan } from './models/plan.model';

@Injectable({
  providedIn: 'root',
})
export class PlanService {
  url = `${environment.apiUrl}/api/Employer`;

  constructor(private http: HttpClient) {}

  getByAccountPlanType(accountId: string, planType: string) {
    return this.http.get<IPlan[]>(
      `${this.url}/${accountId}/plans?benefitPlanType=${planType}`
    );
  }
}
