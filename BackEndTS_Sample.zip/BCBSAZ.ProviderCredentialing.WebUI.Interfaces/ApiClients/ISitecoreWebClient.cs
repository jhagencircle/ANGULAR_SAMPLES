﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebUI.Interfaces.ApiClients
{
	public interface ISitecoreWebClient
	{
		Task<string> GetContentAsync(string identifier);
		Task<string> TranslateTextAsync(string key);
	}
}
