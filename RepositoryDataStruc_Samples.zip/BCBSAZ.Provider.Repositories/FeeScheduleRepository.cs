﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.FeeSchedule;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories
{
	/// <summary>
	/// Defines a Fee Schedule Repository which will provide data from a database
	/// </summary>
	public class FeeScheduleRepository : IFeeScheduleRepository
	{
		/// <summary>
		/// The Entity Framework DbContext object used to communicate with the FeeSched database
		/// </summary>
		private readonly IFeeSchedContext _feeSchedContext;

		/// <summary>
		/// The Entity Framework DbContext object used to communicate with the ProviderInet database
		/// </summary>
		private readonly IProviderInetContext _providerContext;

		/// <summary>
		/// Creates a new Fee Schedule Repository connected to a FeeSched database
		/// </summary>
		/// <param name="context">The Entity Framework DbContext object used to communicate with the FeeSched database</param>
		public FeeScheduleRepository(IFeeSchedContext feeSchedContext, IProviderInetContext providerContext)
		{
			_feeSchedContext = feeSchedContext;
			_providerContext = providerContext;
		}

		/// <summary>
		/// Gets Professional Fee Schedules from the FeeSched database.
		/// </summary>
		/// <param name="request">A validated Professional Fees Request</param>
		/// <returns>A result object containing the Professional Fees grouped by Site of Service and DME from the "usp_GetProfessionalFees" Stored Procedure</returns>
		public ProfessionalFee[] GetProfessionalFees(string providerId, string taxId, DateTime? searchDate, string specialty, string procedureCodes, string siteOfServiceCodes, bool isHistoric) =>
			_feeSchedContext.ProfessionalFees.FromSqlRaw(
				DB.FeeSched.StoredProcs.GetProfessionalFees,
					providerId,
					taxId,
					searchDate,
					string.IsNullOrWhiteSpace(specialty) ? null : specialty,
					procedureCodes,
					siteOfServiceCodes,
					isHistoric
				).AsEnumerable().ToArray();

		/// <summary>
		/// Gets Outpatient Fee Schedules from the FeeSched database
		/// </summary>
		/// <param name="request">A validated Outpatient Fees Request</param>
		/// <returns>A result object containing the Outpatient Fees grouped by Site of Service from the "usp_GetOutpatientFees" Stored Procedure</returns>
		public OutpatientFee[] GetOutpatientFees(DateTime? searchDate, string specialty, string procedureCodes, string siteOfServiceCodes, bool isHistoric) =>
			_feeSchedContext.OutpatientFees.FromSqlRaw(
				DB.FeeSched.StoredProcs.GetOutpatientFees,
					searchDate,
					string.IsNullOrWhiteSpace(specialty) ? null : specialty,
					procedureCodes,
					siteOfServiceCodes,
					isHistoric
				).AsEnumerable().ToArray();

		public AscFee[] GetAscFees(DateTime? searchDate, string specialty, string procedureCodes, string siteOfServiceCodes, bool isHistoric) =>
			_feeSchedContext.AscFees.FromSqlRaw(
				DB.FeeSched.StoredProcs.GetAscFees,
					searchDate,
					string.IsNullOrWhiteSpace(specialty) ? null : specialty,
					procedureCodes,
					siteOfServiceCodes,
					isHistoric
				).AsEnumerable().ToArray();

		public ProviderTaxId[] GetTaxIdsForProvider(string providerId, string orgId) =>
			_providerContext.ProviderTaxIds.FromSqlRaw(
				DB.ProviderInet.StoredProcs.GetTaxIdsForProviderAndOrgAsync,
				providerId,
				orgId
			).AsEnumerable().ToArray();

		public Specialty[] GetSpecialties() =>
			_feeSchedContext.Specialties.FromSqlRaw(DB.FeeSched.StoredProcs.GetSpecialties).AsEnumerable().ToArray();
	}
}
