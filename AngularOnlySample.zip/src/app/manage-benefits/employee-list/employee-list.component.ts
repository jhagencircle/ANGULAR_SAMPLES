import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { OverlaySidePanelService } from 'src/app/shared/components/overlay-side-panel/overlay-side-panel.service';
import { EmployeeProfileComponent } from '../employee-profile/employee-profile.component';
import { EmployeeService } from '../shared/employee.service';
import { IPlan } from '../shared/models/plan.model';
import { PlanService } from '../shared/plan.service';
import {
  NgbdSortableHeader,
  SortEvent,
} from '../../shared/directives/sortable.directive';
import { SpinnerService } from '../../shared/components/spinner/spinner.service';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';
import { ISummary } from 'src/app/shared/models/summary.model';
import { IEmployeeRoster } from '../shared/models/employee-roster.model';
import { AccountService } from 'src/app/shared/services/account.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss'],
})
export class EmployeeListComponent implements OnInit, OnDestroy {
  @Input() subaccount: ISummary;
  account: ISummary;
  employees$: Observable<IEmployeeRoster[]>;
  total$: Observable<number>;
  employeeList: IEmployeeRoster[];
  medicalPlans: IPlan[];
  dentalPlans: IPlan[];
  planFilterSelected: string = ''; //plan.Id
  employeeListTEST: IEmployeeRoster[];
  subscriptions: Subscription[] = [];
  @Output() onSaveChanges: EventEmitter<any> = new EventEmitter();

  sortColumnsIco: any = { lastName: 'sort', adjustmentReason: 'sort' };

  @ViewChildren(NgbdSortableHeader) headers: QueryList<NgbdSortableHeader>;

  constructor(
    public employeeService: EmployeeService,
    public overlaySidePanelService: OverlaySidePanelService,
    public planService: PlanService,
    public accountService: AccountService,
    public _spinnerService: SpinnerService
  ) {
    let subscription = this.accountService
      .get()
      .subscribe((account: ISummary) => {
        if (account) {
          this.account = account;
        }
      });
    this.subscriptions.push(subscription);
  }

  ngOnInit(): void {
    this._spinnerService.show(true);
    let subscription = this.employeeService
      .get(this.subaccount?.accountId, this.subaccount?.billId.toString())
      .subscribe(
        (data) => {
          this.employeeService.employeeList = data.map((item) => {
            if (item.plans.length > 0) {
              let medicalPlan = item.plans.find((p) => p?.type == 'Medical');
              let dentalPlan = item.plans.find((p) => p?.type == 'Dental');
              //get medical plan id and dental plan id
              item.medicalPlanId = medicalPlan ? medicalPlan.id : '';
              item.dentalPlanId = dentalPlan ? dentalPlan.id : '';
              //set medical and dental names
              item.medicalPlanName = medicalPlan ? medicalPlan.name : '';
              item.dentalPlanName = dentalPlan ? dentalPlan.name : '';
            }
            return item;
          });

          this.employees$ = this.employeeService.employees$;
          this.total$ = this.employeeService.total$;
          this.employeeService.searchTerm = '';
          this.employeeService.loading$.subscribe((loading) => {
            this._spinnerService.show(loading);
          });
        },
        (error: HttpErrorResponse) => {
          this._spinnerService.show(false);
        }
      );

    this.getAccountPlans();
    this.subscriptions.push(subscription);
  }
  ngOnChanges() {
    //this function will trigger when parent component updates some input property
    this._spinnerService.show(true);
    this.employeeService
      .get(this.subaccount?.accountId, this.subaccount?.billId.toString())
      .subscribe((data) => {
        this.employeeService.employeeList = data.map((item) => {
          if (item.plans.length > 0) {
            let medicalPlan = item.plans.find((p) => p?.type == 'Medical');
            let dentalPlan = item.plans.find((p) => p?.type == 'Dental');
            //get medical plan id and dental plan id
            item.medicalPlanId = medicalPlan ? medicalPlan.id : '';
            item.dentalPlanId = dentalPlan ? dentalPlan.id : '';
            //set medical and dental names
            item.medicalPlanName = medicalPlan ? medicalPlan.name : '';
            item.dentalPlanName = dentalPlan ? dentalPlan.name : '';
          }
          return item;
        });

        this.employees$ = this.employeeService.employees$;
        this.total$ = this.employeeService.total$;
        this.employeeService.searchTerm = '';
        this.employeeService.loading$.subscribe((loading) => {
          this._spinnerService.show(loading);
        });
      });
    this.getAccountPlans();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  onSort({ column, direction }: SortEvent) {
    // resetting other headers

    this.sortColumnsIco[column] = this.setDirectionIco(direction);
    this.headers.forEach((header) => {
      if (header.sortable !== column) {
        header.direction = '';
      }
    });

    this.employeeService.sortColumn = column;
    this.employeeService.sortDirection = direction;
  }

  setDirectionIco(direction: string): string {
    if (direction !== '') {
      return 'sort-' + direction;
    } else {
      return 'sort';
    }
  }
  employeeProfile(employee: IEmployeeRoster): void {
    let subscription = this.employeeService
      .getById(this.subaccount?.accountId, employee.subscriberId)
      .subscribe((data) => {
        this.employeeService.employee = data;
        this.overlaySidePanelService.setContent(EmployeeProfileComponent);
        this.overlaySidePanelService.show();
        this.overlaySidePanelService
          .checkForChanges()
          .subscribe((hasChanges) => {
            if (hasChanges) {
              this.onSaveChanges.emit();
              this.overlaySidePanelService.reportChanges(false);
            }
          });
      });
    this.subscriptions.push(subscription);
  }

  export() {
    this.employeeService.export(this.employeeService.employeeList);
  }

  getAccountPlans() {
    let medicalPlansSubs = this.planService
      .getByAccountPlanType(this.account?.accountId, 'medical')
      .subscribe((data) => {
        this.medicalPlans = data;
      });
    let dentalPlansSubs = this.planService
      .getByAccountPlanType(this.account?.accountId, 'dental')
      .subscribe((data) => {
        this.dentalPlans = data;
      });
    this.subscriptions.push(medicalPlansSubs);
    this.subscriptions.push(dentalPlansSubs);
  }

  changeFilter(planType: string, planValue: string) {
    if (planValue == 'All') {
      this.planFilterSelected = planType + ' ' + planValue;
    } else {
      this.planFilterSelected = planValue;
    }
    if (planType == 'Medical') {
      this.employeeService.planDental = null;
      this.employeeService.planMedical = planValue;
    } else {
      this.employeeService.planMedical = null;
      this.employeeService.planDental = planValue;
    }
  }

  clearFilterSelected() {
    this.planFilterSelected = '';
    this.employeeService.planDental = null;
    this.employeeService.planMedical = null;
  }

  public openPDF(): void {
    this._spinnerService.show(true);
    let DATA = document.getElementById('subAccountPrint');
    html2canvas(DATA!).then((canvas) => {
      let PDF = new jsPDF();
      let fileWidth = PDF.internal.pageSize.getWidth() - 23;
      let fileHeight = (canvas.height * fileWidth) / canvas.width;
      const FILEURI = canvas.toDataURL('image/png');
      let position = 20;
      PDF.addImage(FILEURI, 'PNG', 11, position, fileWidth, fileHeight);
      const data: any = [];
      const columns = [
        [
          'Employee',
          'Employee ID',
          'Medical ID',
          'Dental ID',
          'Amt Billed',
          'Reason',
        ],
      ];
      this.employeeService.employeeList.forEach((employee) => {
        let fullName: string = employee.lastName + ' ' + employee.firstName;
        var temp = [
          fullName,
          employee.employeeId,
          employee.medicalId,
          employee.dentalId,
          employee.amountBilled.toString(),
          employee.adjustmentReason,
        ];
        data.push(temp);
      });
      autoTable(PDF, {
        head: columns,
        body: data,
        startY: fileHeight + 25,
        didDrawPage: (dataArg) => {
          PDF.text('Account Detail', dataArg.settings.margin.left, 10);
        },
      });
      this._spinnerService.show(false);
      window
        .open(
          URL.createObjectURL(PDF.output('blob')),
          '_blank',
          'toolbar=yes,scrollbars=yes,resizable=yes'
        )
        ?.print();
    });
  }
}
