﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Responses.Common;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IPatientManager
	{
		Task<Select2Response> GetPatientByOrgAsync(Select2Request request, string orgId);
	}
}
