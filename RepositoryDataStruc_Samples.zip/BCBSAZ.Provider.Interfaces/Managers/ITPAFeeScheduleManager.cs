﻿using BCBSAZ.Provider.Models.Data.TPA;
using BCBSAZ.Provider.Models.Requests.TPA;
using BCBSAZ.Provider.Models.Responses.Common;
using BCBSAZ.Provider.Models.Responses.TPA;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	/// <summary>
	/// Business Logic for TPA Registration Api methods
	/// </summary>
	public interface ITPAFeeScheduleManager
	{
		public Select2Response GetTpaPlaceOfService(TPAPlaceOfServiceRequest request);

		public TPAFeeScheduleResponse GetTpaFeeScheduleDetail(TPAFeeScheduleRequest request);

		public Task<TpaProviderInstitutionResponse> GetTpaProviderInstitutionAsync(TpaProviderInstitutionRequest request);
	}
}
