import { from, Observable, of } from 'rxjs';
import { IDependent } from 'src/app/manage-benefits/shared/models/dependent.model';

export class DependentMock {
  constructor() {}

  get(): Observable<any> {
    return of({
      isEdit: false,
      firstName: '',
      middleName: '',
      lastName: '',
      dependentType: '',
      dateOfBirth: '',
      ssn: '',
      gender: '',
      benefitSelection: {},
      isRemoved: false,
      removalReason: '',
      effectiveDate: '',
      healthInsurancePlan: {},
    });
  }
  getList(): Observable<any[]> {
    return of([
      {
        firstName: 'Ann',
        middleName: '',
        lastName: 'Boleyn',
        dependentType: 'spouse',
        dateOfBirth: '08-24-1992',
        ssn: '5217445001',
        gender: 'Female',
        benefitSelection: {
          planSelection: [],
          eligibleForMedicare: true,
          medicareNumber: '3555220',
          partAEffectiveDate: '06-30-2021',
          partBEffectiveDate: '06-30-2021',
          lifeInsuranceBenefit: 'false',
          flexibleSpendingSelection: true,
        },
        removalReason: null,
      },
    ]);
  }
}
