export enum MedicareTypeEnum {
  PartA = 'Part A',
  PartB = 'Part B',
  Both = 'Both A and B',
}
