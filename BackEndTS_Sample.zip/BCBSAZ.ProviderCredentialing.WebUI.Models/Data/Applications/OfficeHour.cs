﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class OfficeHour
	{
		public DayOfWeek DayOfWeek { get; set; }

		public string OpenTime { get; set; }

		public string CloseTime { get; set; }
	}
}
