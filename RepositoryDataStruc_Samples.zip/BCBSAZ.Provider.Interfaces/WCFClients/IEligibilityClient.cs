﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Requests.Eligibility.Inquiries;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface IEligibilityClient : IDisposable
	{
		IEnumerable<Task> CreateMVContacts(IEnumerable<Inquiry> inquiries, WebUser user);
	}
}
