import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnDestroy,
} from '@angular/core';
import { IBenefit } from '../shared/models/benefit.model';
import { IDependent } from '../shared/models/dependent.model';
import { EmployeeProfileService } from '../shared/employee-profile.service';
import { IProfileRoster } from '../shared/models/profile-roster.model';
import { ISubscriber, IProducts } from '../shared/models';
import { AppConstants } from '../../shared/constants/app-constants';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-employee-dependent-list',
  templateUrl: './employee-dependent-list.component.html',
  styleUrls: ['./employee-dependent-list.component.scss'],
})
export class EmployeeDependentListComponent implements OnInit, OnDestroy {
  @Input() dependentsInformation: IDependent[] | undefined;
  @Input() benefitSelection: IBenefit;
  showAdd: boolean = false;
  membreProfile: IProfileRoster;
  dependent: ISubscriber;
  products: IProducts[] = [];
  subscriptions: Subscription[] = [];

  constructor(private employeeProfileService: EmployeeProfileService) {}

  ngOnInit(): void {
    this.dependentsInformation = this.dependentsInformation!.map((d) => {
      d.isEdit = false;
      return d;
    });
    let subscription = this.employeeProfileService.get().subscribe((data) => {
      this.membreProfile = data;
    });
    this.subscriptions.push(subscription);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  addDependent(dependent: IDependent) {
    this.dependentsInformation!.push(dependent);
    this.setDependentInformationModel(dependent);
    this.membreProfile.dependents.push(this.dependent);
    this.employeeProfileService.update(this.membreProfile);
  }

  editDependent(dependent: any) {
    this.setDependentInformationModel(dependent.dependentInformation);
    this.membreProfile.dependents.push(this.dependent);
    this.employeeProfileService.update(this.membreProfile);
  }

  setDependentInformationModel(dependent: IDependent) {
    let subAccount = JSON.parse(
      localStorage.getItem(AppConstants.SUB_ACCOUNT_LOCAL_STORAGE_KEY) || ''
    );

    dependent.benefitSelection.planSelection.forEach((item) => {
      this.products.push({
        effectiveDate: new Date(dependent.effectiveDate || ''),
        planType: item.type,
        hccPlanId: null,
        subAccountNumber: subAccount.accountId,
        requiredStartDate: new Date(),
      });
    });

    this.dependent = {
      isDependent: true,
      memberId: null,
      lastName: dependent.lastName,
      dependentType: dependent.dependentType,
      middleName: dependent.middleName,
      firstName: dependent.firstName,
      dateOfBirth: new Date(dependent.dateOfBirth),
      ssn: dependent.ssn,
      itin: null,
      foreignDocumentNumber: null,
      gender: dependent.gender,
      medicareInformation: {
        medicareNumber: dependent.benefitSelection.medicareNumber,
        partAEffectiveDate: dependent.benefitSelection.partAEffectiveDate,
        partBEffectiveDate: dependent.benefitSelection.partBEffectiveDate,
        isElegible: dependent.benefitSelection.eligibleForMedicare,
      },
      products: this.products,
      otherHealthPlanCoverage: {
        effectiveDate: null,
        groupNumber: null,
        productName: null,
        productId: null,
        policyHolderName: null,
        carrierPhone: null,
      },
      tobaccoUsage: null,
      lastTobaccoUseDate: null,
      preferredContactMethod: null,
      preferredLanguage: null,
      autoWithdrawalEnabled: null,
      maritalStatus: null,
      rateAreaId: null,
      rateCountyCode: null,
      dependent: null,
      operation: null,
      isSuccessOperation: null,
      removalReason: null,
    };
  }

  showAddForm() {
    this.showAdd = true;
  }

  hideAddForm() {
    this.showAdd = false;
  }

  onClickEditCell(dependent: IDependent) {
    dependent.isEdit = !dependent.isEdit;
  }
}
