﻿using System;
using System.Collections;
using System.Collections.Generic;
using BCBSAZ.ProviderAuxiliaryPortal.Managers;
using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Logging;
using NSubstitute;
using Serilog;
using Serilog.Events;
using Xunit;

namespace BCBSAZ.ProviderAuxiliaryPortal.UnitTests.Managers
{
    public class LoggingManagerTests
    {
        private readonly ILoggingManager _loggingManager;
        public LoggingManagerTests()
        {
            var logger = Substitute.For<ILogger>();
            _loggingManager = new LoggingManager(logger);
        }

        [Theory]
        [InlineData(LogLevelEnum.Warning)]
        [InlineData(LogLevelEnum.Error)]
        [InlineData(LogLevelEnum.Fatal)]
        [InlineData(LogLevelEnum.Information)]
        public void LogTest_LoggingLevelCorrect_ShouldWork(LogLevelEnum level)
        {
            //Arrange
            var models = new List<LoggingModel>{
                new LoggingModel
                {
                    Level = level
                }
            };

            //Assert
            Assert.All(models, _loggingManager.Log);
        }
    }
}
