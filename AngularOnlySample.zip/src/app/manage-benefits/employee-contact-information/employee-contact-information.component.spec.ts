import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EmployeeMock } from '../../shared/mocks/employee.mock';
import { EmployeeContactInformationComponent } from './employee-contact-information.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('EmployeeContactInformationComponent', () => {
  let component: EmployeeContactInformationComponent;
  let fixture: ComponentFixture<EmployeeContactInformationComponent>;
  let mockEmployeeService: EmployeeMock = new EmployeeMock();
  let compiledDeb: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployeeContactInformationComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeContactInformationComponent);
    component = fixture.componentInstance;

    mockEmployeeService.get().subscribe((data) => {
      component.contactInformation = data.contactInformation;
    });

    fixture.detectChanges();
    compiledDeb = fixture.debugElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
