﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Net;
using System.Net.Http.Headers;

namespace BCBSAZ.ProviderCredentialing.WebUI
{

	/// <summary>
	/// Represents an exception thrown when the Provider Api returns a non-success status code.
	/// </summary>
	[SuppressMessage("Design", "CA1032:Implement standard exception constructors", Justification = "Additional constructors are not required.")]
	public sealed class InvalidApiResponseException : Exception
	{
		/// <summary>
		/// Creates a new Invalid Api Response exception
		/// </summary>
		/// <param name="statusCode">The status code returned by the Api</param>
		/// <param name="reasonPhrase">The reason phrase for the status returned by the Api</param>
		/// <param name="contentType">The content type of the content returned by the Api</param>
		/// <param name="content">The content returned by the Api</param>
		public InvalidApiResponseException(HttpStatusCode statusCode, string reasonPhrase, MediaTypeHeaderValue contentType, string content, string clientName) :
			base(GenerateMessage(clientName, statusCode, reasonPhrase))
		{
			StatusCode = statusCode;
			ReasonPhrase = reasonPhrase;
			ContentType = contentType;
			Content = content;
		}

		/// <summary>
		/// Creates a new Invalid Api Response exception
		/// </summary>
		/// <param name="message"></param>
		/// <param name="innerException"></param>
		public InvalidApiResponseException(string message, Exception innerException) : base(message, innerException) { }

		private static string GenerateMessage(string clientName, HttpStatusCode statusCode, string reasonPhrase)
		{
			return string.Format(CultureInfo.InvariantCulture,
				"The {0} returned a non-success response, see ContentType and Content for additional details: {1} - {2}",
				clientName, (int)statusCode, reasonPhrase);
		}

		/// <summary>
		/// Gets the status code returned by the Api
		/// </summary>
		public HttpStatusCode StatusCode { get; }

		/// <summary>
		/// Gets the reason phrase for the status returned by the Api
		/// </summary>
		public string ReasonPhrase { get; }

		/// <summary>
		/// Gets the content type of the content returned by the Api
		/// </summary>
		public MediaTypeHeaderValue ContentType { get; }

		/// <summary>
		/// Gets the content returned by the Api
		/// </summary>
		public string Content { get; }
	}

}
