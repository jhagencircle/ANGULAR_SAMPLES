import { NgModule } from '@angular/core';
import { InputValidationDirective } from '../directives/input-validation.directive';

@NgModule({
  exports: [InputValidationDirective],
  declarations: [InputValidationDirective],
  providers: [InputValidationDirective],
})
export class ValidationDirectivesModule {}
