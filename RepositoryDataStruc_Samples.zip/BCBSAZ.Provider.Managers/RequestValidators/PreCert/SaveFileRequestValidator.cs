﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.PreCert;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.PreCert
{
	internal static class SaveFileRequestValidator
	{
		public static void Validate(this SaveFileRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(SaveFileRequest request)
		{
			if (request.File == null)
			{
				yield return new InvalidModelExceptionDetail(nameof(SaveFileRequest.File), new ArgumentException("File is Required."));
			}
			else
			{
				if (string.IsNullOrWhiteSpace(request.File.ContentType))
					yield return new InvalidModelExceptionDetail(nameof(SaveFileRequest.File.ContentType), new ArgumentException("File Content Type is Required."));

				if (request.File.Contents.IsNullOrEmpty())
					yield return new InvalidModelExceptionDetail(nameof(SaveFileRequest.File.Contents), new ArgumentException("File has no contents."));
			}
		}
	}
}
