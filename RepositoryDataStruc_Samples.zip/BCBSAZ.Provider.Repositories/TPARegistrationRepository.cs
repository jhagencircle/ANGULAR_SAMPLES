﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.TPA;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.Common;

namespace BCBSAZ.Provider.Repositories
{
	public class TPARegistrationRepository : ITPARegistrationRepository
	{
		private	readonly IProviderInetContext _providerInetContext;
		public TPARegistrationRepository(IProviderInetContext provInetContext) => _providerInetContext = provInetContext;

		public Task AddTpaRegistrationAsync(TpaRegistration tpaRegistration)
		{
			return _providerInetContext.Database.ExecuteSqlRawAsync(DB.ProviderInet.StoredProcs.CreateTpaUser,
				tpaRegistration.LoginId,
				tpaRegistration.Password,
				tpaRegistration.Email		,
				tpaRegistration.FirstName,
				tpaRegistration.LastName,
				tpaRegistration.PhoneNumber,
				tpaRegistration.SecurityQuestion,
				tpaRegistration.SecurityQuestionAnswer,
				tpaRegistration.TpaNumber,
				DateTime.Today
			);
		}
	}
}
