import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankAccountRoutingModule } from './bank-account-routing.module';
import { BankAccountListComponent } from './bank-account-list/bank-account-list.component';
import { BankAccountAddComponent } from './bank-account-add/bank-account-add.component';
import { BankAccountEditComponent } from './bank-account-edit/bank-account-edit.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccountNumberMaskPipe } from './shared/account-number-mask.pipe';
import { ConfirmationDialogModule } from '../shared/components/confirmation-dialog/confirmation-dialog.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { AlertModule } from '../shared/components/alert/alert.module';
import { TooltipModule, TooltipOptions } from 'ng2-tooltip-directive';
import { TooltipDefaultOptions } from '../shared/providers/tooltipDefaultOptions';
import { SpinnerModule } from '../shared/components/spinner/spinner.module';
import { ValidationDirectivesModule } from '../shared/modules/validation-directives.Module';

@NgModule({
  declarations: [
    BankAccountListComponent,
    BankAccountAddComponent,
    BankAccountEditComponent,
    AccountNumberMaskPipe,
  ],
  imports: [
    CommonModule,
    BankAccountRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    ConfirmationDialogModule,
    NgSelectModule,
    AlertModule,
    SpinnerModule,
    TooltipModule.forRoot(TooltipDefaultOptions as TooltipOptions),
    ValidationDirectivesModule,
  ],
  exports: [BankAccountListComponent],
  providers: [AccountNumberMaskPipe],
})
export class BankAccountModule {}
