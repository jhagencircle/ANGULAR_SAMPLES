﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories
{
    public class EftEnrollmentRepository : IEftEnrollmentRepository
    {
        private readonly ProviderEftDbContext _providerEftDbContext;

        public EftEnrollmentRepository(ProviderEftDbContext providerEftDbContext)
        {
            _providerEftDbContext = providerEftDbContext;
        }

        public async Task SaveEftEnrollmentRequestAsync(EftEnrollmentRequest request)
        {            
            _providerEftDbContext.EftEnrollmentRequests.Add(request);
            await _providerEftDbContext.SaveChangesAsync();
        }

        public async Task UpdateEftEnrollmentRequestAsync(EftEnrollmentRequest request)
        {
            _providerEftDbContext.EftEnrollmentRequests.Update(request);
            await _providerEftDbContext.SaveChangesAsync();

           _providerEftDbContext.ProviderIdentifiers.UpdateRange(request.ProvInfo);
           await _providerEftDbContext.SaveChangesAsync();
            
        } 
    }
}
