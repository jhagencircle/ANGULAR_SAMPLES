﻿using BCBSAZ.Provider.Models.Requests.Subscriber;
using BCBSAZ.Provider.Models.Responses.Subscriber;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface ISubscriberService
	{
		Task<IsMemberDelegatedResponse> IsMemberDelegatedAsync(IsMemberDelegatedRequest request);

		Task<IsMemberLocalResponse> IsMemberLocalAsync(IsMemberLocalRequest request);

		Task<ValidatePatientResponse> ValidatePatientAsync(ValidatePatientRequest request);

	}
}
