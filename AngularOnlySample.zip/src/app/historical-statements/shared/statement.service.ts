import { Injectable } from '@angular/core';
import { IStatement } from './statement.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class StatementService {
  private url = `${environment.apiUrl}/api/employer`;
  constructor(private http: HttpClient) {}

  get(accountId: string): Observable<IStatement[]> {
    return this.http.get<IStatement[]>(
      `${this.url}/${accountId}/historicalStatements`
    );
  }

  downloadPDF(statement: IStatement): any {
    const options = {
      responseType: 'blob' as const,
    };
    if (statement.isLegacy) {
      return this.http.get(
        `${environment.apiUrl}/api/Employer/${statement.accountId}
      /StatementFile?billingPeriodStart=${statement.billingPeriodFromDate.toString()}
      &billingPeriodEnd=${statement.billingPeriodToDate.toString()}`,
        options
      );
    } else {
      return this.http.get(
        `${environment.apiUrl}/api/BillingStatement/${statement.billingStatementId}/Document`,
        options
      );
    }
  }
}
