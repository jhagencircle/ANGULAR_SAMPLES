﻿using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.ApiClients;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebUI.Services.ApiClients
{
	// TODO: At some point we need to get items directly from the Sitecore API.  Here are the end-points:
	// https://myblueservice.modoff.services.azblue.com:8793/api/Sitecore/GetSitecoreItem?guid= 
	// https://myblueservice.modoff.services.azblue.com:8793/api/Sitecore/GetRawSitecore?guidWithOptions={guid}%2Fchildren  

	public class SitecoreWebClient : HttpClient, ISitecoreWebClient
	{
		private readonly string _providerUrl;

		private readonly ILogger _logger;
		private readonly IMemoryCache _memoryCache;

		public SitecoreWebClient(IConfiguration configuration, ILogger<SitecoreWebClient> logger, IMemoryCache memoryCache) : base(new HttpClientHandler { UseCookies = false, AllowAutoRedirect = false })
		{
#if DEBUG
			_providerUrl = "https://provider.dev.azblue.com/";
#else
			_providerUrl = configuration["ProviderURL"];
#endif

			if (string.IsNullOrWhiteSpace(_providerUrl)) throw new ArgumentException("Invalid Web Url specified for Provider (Sitecore) Portal.");
			if (!_providerUrl.EndsWith("/")) _providerUrl = _providerUrl + "/";

			BaseAddress = new Uri(_providerUrl);

			_logger = logger;
			_memoryCache = memoryCache;
		}

		public async Task<string> TranslateTextAsync(string key)
		{
			var cacheKey = string.Format(CultureInfo.InvariantCulture, Constants.CacheKeys.SitecoreTranslateText, key);

			if (_memoryCache.TryGetValue(cacheKey, out string text))
				return text;

			var requestUri = string.Format(CultureInfo.InvariantCulture, Constants.SitecoreWebUrls.TranslateText, key);
			try
			{
				var content = await SendRequestAsync(HttpMethod.Post, requestUri);
				var retVal = JsonConvert.DeserializeObject<TranslateTextResult>(content).Text;

				_memoryCache.Set(cacheKey, retVal);

				return retVal;
			}
			catch (SitecoreRequestException ex)
			{
#if DEBUG
				return ex.Message;
#else
				_logger.LogError(ex, "Error retrieving Sitecore content.");
				return "";
#endif
			}
			catch (Exception ex)
			{
#if DEBUG
				return string.Format(CultureInfo.InvariantCulture, "{0}: {1}", ex.GetType().FullName, ex.Message);
#else
				_logger.LogError(ex, "Error retrieving Sitecore content.");
				return "";
#endif
			}
		}

		private class TranslateTextResult
		{
			public string Key { get; set; }
			public string Text { get; set; }
		}

		public async Task<string> GetContentAsync(string identifier)
		{
			string requestUri = string.Format(CultureInfo.InvariantCulture, Constants.SitecoreWebUrls.GetContent, identifier);

			return await SendRequestAsync(HttpMethod.Get, requestUri);
		}

		private async Task<string> SendRequestAsync(HttpMethod method, string requestUri)
		{
			var message = new HttpRequestMessage(method, requestUri);

			var response = await SendAsync(message);

			var content = await response.Content.ReadAsStringAsync();

			if (response.IsSuccessStatusCode)
			{
				if (content.Trim().StartsWith("<!DOCTYPE html>", StringComparison.OrdinalIgnoreCase))
					throw new SitecoreRequestException("Sitecore Content Unavailable.");

				return content;
			}
			else if ((response.StatusCode == HttpStatusCode.Found) || (response.StatusCode == HttpStatusCode.Redirect))
			{
				// TODO: wrap this in an #if DEBUG?
				throw new SitecoreRequestException("Sitecore Content Requires Login.");
			}
			else
			{
				throw new InvalidApiResponseException(response.StatusCode, response.ReasonPhrase, response.Content.Headers.ContentType, content, "Sitecore Web");
			}
		}
	}
}