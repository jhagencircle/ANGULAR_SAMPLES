import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AppConstants } from '../../constants/app-constants';

import { FooterComponent } from './footer.component';

describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;
  const originYear = AppConstants.COPYRIGHT_ORIGIN_YEAR;
  const newYear = new Date().getFullYear().toString();
  const copyrightYear =
    newYear != originYear ? originYear + ' - ' + newYear : originYear;
  const copyrightText =
    AppConstants.COPYRIGHT_SYMBOL +
    copyrightYear +
    AppConstants.COPYRIGHT_DESCRIPTION;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FooterComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render all links for the footer', () => {
    expect(
      fixture.nativeElement.querySelector('#HIPAAPrivacyLink')
    ).toBeTruthy();
    expect(fixture.nativeElement.querySelector('#TermsOfUseLink')).toBeTruthy();
    expect(fixture.nativeElement.querySelector('#WebPrivacyLink')).toBeTruthy();
    expect(fixture.nativeElement.querySelector('#ContactUsLink')).toBeTruthy();
  });

  it('should display the copyright text', () => {
    expect(
      fixture.nativeElement.querySelector('#copyrightDescription')
    ).toBeTruthy();
    expect(component.copyrightText).toEqual(copyrightText);
  });

  // it('link "HIPAA Privacy" should be opened in separate tab', async () => {
  //   spyOn(window, 'open');
  //   const link = fixture.debugElement.nativeElement
  //     .querySelector('#HIPAAPrivacyLink')
  //     .click();
  //   fixture.detectChanges();
  //   fixture.whenStable().then(() => {
  //     expect(link).toHaveBeenCalled();
  //     expect(window.open).toHaveBeenCalledWith(
  //       'https://www.azblue.com/~/media/azblue/files/about/hhs-notice-of-privacy-practices.pdf'
  //     );
  //   });
  // });

  // it('link "Terms of Use" should be opened in separate tab', async () => {
  //   spyOn(window, 'open');
  //   const link = fixture.debugElement.nativeElement
  //     .querySelector('#TermsOfUseLink')
  //     .click();
  //   fixture.detectChanges();
  //   fixture.whenStable().then(() => {
  //     expect(link).toHaveBeenCalled();
  //     expect(window.open).toHaveBeenCalledWith(
  //       'https://www.azblue.com/legal/terms-of-use'
  //     );
  //   });
  // });

  // it('link "Web Privacy" should be opened in separate tab', async () => {
  //   spyOn(window, 'open');
  //   const link = fixture.debugElement.nativeElement
  //     .querySelector('#WebPrivacyLink')
  //     .click();
  //   fixture.detectChanges();
  //   fixture.whenStable().then(() => {
  //     expect(link).toHaveBeenCalled();
  //     expect(window.open).toHaveBeenCalledWith(
  //       'https://www.azblue.com/legal/website-privacy'
  //     );
  //   });
  // });

  // it('link "Contact Us" should be opened in separate tab', async () => {
  //   spyOn(window, 'open');
  //   const link = fixture.debugElement.nativeElement
  //     .querySelector('#ContactUsLink')
  //     .click();
  //   fixture.detectChanges();
  //   fixture.whenStable().then(() => {
  //     expect(link).toHaveBeenCalled();
  //     expect(window.open).toHaveBeenCalledWith(
  //       'https://www.azblue.com/contact-us'
  //     );
  //   });
  // });
});
