﻿using BCBSAZ.ProviderCredentialing.Interfaces.Repositories;
using BCBSAZ.ProviderCredentialing.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.Repositories
{
	public class EmailRepository : IEmailRepository
	{
		private readonly IEmailContext _emailContext;

		public EmailRepository(IEmailContext emailContext) => _emailContext = emailContext;

		public Task QueueEmailAsync(string toAddress, string fromAddress, string subject, string body)
		{
			var cc = string.Empty;
			var bcc = string.Empty;

			return _emailContext.Database.ExecuteSqlRawAsync(DB.Email.StoredProcs.QueueEmail, toAddress, fromAddress, cc, bcc, subject, body);
		}
	}
}
