import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpEvent, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class WelcomeDialogService {
  private welcomeTemplate = 'assets/templates/welcome-dialog.html';
  constructor(private http: HttpClient) {}

  getTemplate(): Observable<string> {
    return this.http.get(this.welcomeTemplate, { responseType: 'text' });
  }
}
