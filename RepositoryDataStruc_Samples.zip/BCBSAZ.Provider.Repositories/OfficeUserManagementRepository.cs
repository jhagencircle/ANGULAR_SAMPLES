﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.OfficeUserManagement;
using BCBSAZ.Provider.Models.Data.PreCert;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Repositories
{
	class OfficeUserManagementRepository : IOfficeUserManagementRepository
	{
		private readonly IProviderInetContext _providerInetContext;
		private readonly ILogger _logger;
		private readonly IHttpContextAccessor _contextAccessor;

		public OfficeUserManagementRepository(IProviderInetContext providerInetContext, ILogger<OfficeUserManagementRepository> logger, IHttpContextAccessor contextAccessor)
		{
			_logger = logger;
			_contextAccessor = contextAccessor;
			_providerInetContext = providerInetContext;
		}

		#region User Methods

		public UserSummary[] GetOrgUsers(string orgId) =>
			_providerInetContext.Users.FromSqlRaw(DB.ProviderInet.StoredProcs.GetOrgUsers, orgId).AsEnumerable().ToArray();

		public UserProfile GetUserProfile(string userId) =>
			_providerInetContext.UserProfiles.FromSqlRaw(DB.ProviderInet.StoredProcs.GetUserProfile, userId).AsEnumerable().FirstOrDefault();

		public void InsertUserProfile(string createdBy, string orgId, UserProfile userProfile, string passwordHash, string answerHash) =>
			_providerInetContext.Database.ExecuteSqlRaw(
				DB.ProviderInet.StoredProcs.InsertUserProfile,
				createdBy,
				orgId,
				userProfile.SubOrg,
				userProfile.Username,
				passwordHash,
				userProfile.Email,
				userProfile.FirstName,
				userProfile.LastName,
				userProfile.Phone,
				userProfile.SecurityQuestion,
				answerHash,
				userProfile.UserRole
			);

		public void UpdateUserProfile(UserProfile userProfile, string passwordHash) =>
			_providerInetContext.Database.ExecuteSqlRaw(
				DB.ProviderInet.StoredProcs.UpdateUserProfile,
				userProfile.SubOrg,
				userProfile.Username,
				passwordHash,
				userProfile.Email,
				userProfile.FirstName,
				userProfile.LastName,
				userProfile.Phone,
				userProfile.UserRole
			);

		public void DeleteUserProfile(string orgId, string userId) =>
			_providerInetContext.Database.ExecuteSqlRaw(DB.ProviderInet.StoredProcs.DeleteUserProfile, orgId, userId);

		public AssignedProvider[] GetProvidersForUser(string orgId, string subOrg, string userId) =>
			_providerInetContext.AssignedProviders.FromSqlRaw(DB.ProviderInet.StoredProcs.GetProvidersForUser, orgId, subOrg, userId).AsEnumerable().ToArray();

		public void SetProvidersForUser(string orgId, string subOrg, string userId, IEnumerable<AssignedProvider> providers)
		{
			var selectedProviders = providers.IsNullOrEmpty() ? string.Empty : string.Join(",",
				from p in providers
				where p.IsSelected
				select p.ProviderId);

			_providerInetContext.Database.ExecuteSqlRaw(DB.ProviderInet.StoredProcs.SetProvidersForUser, orgId, subOrg, userId, selectedProviders);
		}


		#endregion

		#region Sub Org Methods

		public SubOrgSummary[] GetSubOrgs(string orgId) =>
			_providerInetContext.SubOrgSummaries.FromSqlRaw(DB.ProviderInet.StoredProcs.GetSubOrgs, orgId).AsEnumerable().ToArray();

		public SubOrg GetSubOrg(string orgId, string subOrg) =>
			_providerInetContext.SubOrgs.FromSqlRaw(DB.ProviderInet.StoredProcs.GetSubOrg, orgId, subOrg).AsEnumerable().FirstOrDefault();

		public void DeleteSubOrg(string orgId, string subOrg) =>
			_providerInetContext.Database.ExecuteSqlRaw(DB.ProviderInet.StoredProcs.DeleteSubOrg, orgId, subOrg);

		public void UpdateSubOrg(string orgId, SubOrg subOrg) =>
			_providerInetContext.Database.ExecuteSqlRaw(DB.ProviderInet.StoredProcs.UpdateSubOrg, orgId, subOrg.Name, subOrg.Description, subOrg.AssignProviders);

		public void InsertSubOrg(string orgId, SubOrg subOrg) =>
			_providerInetContext.Database.ExecuteSqlRaw(DB.ProviderInet.StoredProcs.InsertSubOrg, orgId, subOrg.Name, subOrg.Description, subOrg.AssignProviders);

		public UserSummary[] GetSubOrgUsers(string orgId, string subOrg) =>
			_providerInetContext.Users.FromSqlRaw(DB.ProviderInet.StoredProcs.GetSubOrgUsers, orgId, subOrg).AsEnumerable().ToArray();

		public void SetProvidersForSubOrg(string orgId, string subOrg, IEnumerable<AssignedProvider> providers)
		{
			var selectedProviders = providers.IsNullOrEmpty() ? string.Empty : string.Join(",",
				from p in providers
				where p.IsSelected
				select p.ProviderId);

			_providerInetContext.Database.ExecuteSqlRaw(DB.ProviderInet.StoredProcs.SetProvidersForSubOrg, orgId, subOrg, selectedProviders);
		}

		public AssignedProvider[] GetProvidersForSubOrg(string orgId, string subOrg) =>
			_providerInetContext.AssignedProviders.FromSqlRaw(DB.ProviderInet.StoredProcs.GetProvidersForSubOrg, orgId, subOrg).AsEnumerable().ToArray();









		#endregion

	}
}
