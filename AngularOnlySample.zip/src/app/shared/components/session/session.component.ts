import { Component, OnInit } from '@angular/core';
import { NgIdleService } from '../../services/ng-idle.service';
import { AuthService } from 'src/app/core/auth/auth.service';
import { OverlayStyle } from '../../enums/overlay-style-enum';

@Component({
  selector: 'session',
  templateUrl: './session.component.html',
  styleUrls: ['./session.component.scss'],
  providers: [NgIdleService],
})
export class SessionComponent implements OnInit {
  secondTimerLeft: string = '2:00';
  showModal: boolean = false;
  resetTimer: boolean = false;
  timeStart: Date;
  overlayStyle: OverlayStyle;

  constructor(private ngIdle: NgIdleService, public authService: AuthService) {
    this.overlayStyle = OverlayStyle.DIM_DARK;
  }

  ngOnInit(): void {
    this.startSession();
  }

  startSession() {
    this.ngIdle.USER_IDLE_TIMER_VALUE_IN_MIN = 18;
    this.ngIdle.FINAL_LEVEL_TIMER_VALUE_IN_MIN = 2;

    this.ngIdle.initilizeSessionTimeout();
    this.ngIdle.userIdlenessChecker?.subscribe((status: string) => {
      this.initiateFirstTimer(status);
    });

    this.ngIdle.secondLevelUserIdleChecker?.subscribe((status: string) => {
      this.initiateSecondTimer(status);
    });
  }

  initiateFirstTimer = (status: string) => {
    switch (status) {
      case 'INITIATE_TIMER':
        this.timeStart = new Date();
        break;

      case 'RESET_TIMER':
        break;

      case 'STOPPED_TIMER':
        this.openModal();
        break;

      default:
        break;
    }
  };

  initiateSecondTimer = (status: string) => {
    switch (status) {
      case 'INITIATE_SECOND_TIMER':
        break;

      case 'SECOND_TIMER_STARTED':
        this.resetTimer = false;
        break;

      case 'SECOND_TIMER_STOPPED':
        break;

      default:
        this.secondTimerLeft = status;
        if (status === '0:00' && !this.resetTimer) {
          this.logOut();
        }
        break;
    }
  };

  stayLoggedIn() {
    this.resetTimer = true;
    this.closeModal();
    this.startSession();
  }

  logOut() {
    this.authService.logout();
  }

  openModal() {
    this.showModal = true;
    document.body.style.overflow = 'hidden';
  }

  closeModal() {
    this.showModal = false;
    document.body.style.removeProperty('overflow');
  }
}
