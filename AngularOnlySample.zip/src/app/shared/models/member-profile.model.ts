export interface IMemberProfile {
  addDependent: any;
  dependents: any[];
  benefits: any;
  terminateCoverage: any;
}
