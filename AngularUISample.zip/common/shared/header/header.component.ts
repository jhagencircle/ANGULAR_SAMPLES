import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/auth.service';
import { OktaAuthService } from '@okta/okta-angular';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  userName?: string;
  constructor(
    public authService: AuthService,  
    public oktaAuth: OktaAuthService
  ) { }

  ngOnInit(): void {
    this.getUserName();
  }
  async getUserName(){
    const userClaims = await this.oktaAuth.getUser();
    this.userName = userClaims.name;
  }

   logOut() {
     this.authService.logout();
  } 

}
