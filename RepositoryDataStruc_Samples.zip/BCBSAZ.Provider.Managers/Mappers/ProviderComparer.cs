﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using BCBSAZ.Provider.Models.Data.Claims;

namespace BCBSAZ.Provider.Managers.Mappers
{
	internal class ProviderComparer : EqualityComparer<ProviderInfo>
	{
		public override bool Equals([AllowNull] ProviderInfo x, [AllowNull] ProviderInfo y)
		{
			if ((x == null) && (y == null)) return true;
			if ((x == null) || (y == null)) return false;

			return
				string.Equals(x.NPI, y.NPI, StringComparison.OrdinalIgnoreCase) &&
				string.Equals(x.FirstName, y.FirstName, StringComparison.OrdinalIgnoreCase) &&
				string.Equals(x.LastName, y.LastName, StringComparison.OrdinalIgnoreCase);
		}

		public override int GetHashCode([DisallowNull] ProviderInfo obj)
		{
			return string.Join('|', obj.NPI, obj.FirstName, obj.LastName).ToLowerInvariant().GetHashCode();
		}
	}
}
