﻿namespace BCBSAZ.ProviderAuxiliaryPortal.Models.Enum
{
    public enum LogLevelEnum
    {
        Information,
        Warning,
        Error,
        Fatal
    }
}
