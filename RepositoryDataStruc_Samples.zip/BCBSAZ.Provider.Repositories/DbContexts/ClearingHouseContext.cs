﻿using BCBSAZ.Provider.Models.Data.Claims;
using BCBSAZ.Provider.Models.Data.Eligibility;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IClearingHouseContext : IDbContext
	{
		DbSet<GroupNumberInfo> IsCHSGroup { get; }
		DbSet<TPAInfo> GetTPAInfo { get; }
	}

	public class ClearingHouseContext : DbContext, IClearingHouseContext
	{
		/// <summary>
		/// Creates a new instance of the ContractIssuance DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public ClearingHouseContext(DbContextOptions<ClearingHouseContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<GroupNumberInfo>().HasNoKey();
			modelBuilder.Entity<TPAInfo>().HasNoKey();
		}

		public DbSet<GroupNumberInfo> IsCHSGroup { get; protected set; }

		public DbSet<TPAInfo> GetTPAInfo { get; protected set; }
	}
}
