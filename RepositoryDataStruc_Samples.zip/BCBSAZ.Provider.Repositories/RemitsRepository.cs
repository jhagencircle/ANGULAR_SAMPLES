﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories
{
	public class RemitsRepository : IRemitsRepository
	{
		private readonly IProviderInetContext _providerInetContext;

		public RemitsRepository(IProviderInetContext providerInetContext)
		{
			_providerInetContext = providerInetContext;
		}

		public async Task<ProviderTaxId[]> GetProviderTaxIdsAvailableForRemitAsync(string orgId)
		{
			return await _providerInetContext.ProviderTaxIds.FromSqlRaw(DB.ProviderInet.StoredProcs.GetAvailableTaxIds, orgId).ToArrayAsync();
		}

	}
}
