﻿using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface ITICustomContext : IDbContext
	{
	}

	public class TICustomContext : DbContext, ITICustomContext
	{
		public TICustomContext(DbContextOptions<TICustomContext> options) : base(options) { }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			/******************** Property Configs ********************/
		}
	}
}
