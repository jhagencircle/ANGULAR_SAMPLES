export class BankAccount {
  constructor(init?: Partial<BankAccount>) {
    Object.assign(this, init);
  }
  id: string;
  accountId: string;
  name: string;
  nameOnAccount: string;
  nickname: string;
  type: string;
  routingNumber: string;
  accountNumber: string;
  isForAutopay: boolean;
  status: string;
  isEdit?: boolean;
  isAutopayment?: boolean;
  isPendingPayment?: boolean;
}
