import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Autopay } from './autopay.model';
import { IAutoPayment } from './autopayment.model';
import { environment } from 'src/environments/environment';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

const httpOptionsPlain = {
  headers: new HttpHeaders({
    Accept: 'text/plain',
    'Content-Type': 'text/plain',
  }),
  responseType: 'text',
};

@Injectable({
  providedIn: 'root',
})
export class AutopaymentService {
  url = `${environment.apiUrl}/api/AutoPayment`;

  public autopayments = new BehaviorSubject<any>(null);

  constructor(private http: HttpClient) {}

  getList(accountId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.url}/account/${accountId}`).pipe(
      catchError((err) => {
        if (err.status === 404) return new Array<any>(undefined);
        return throwError(err);
      })
    );
  }

  get(): Observable<any[]> {
    return this.autopayments.asObservable();
  }

  enroll(autopayment: IAutoPayment): Observable<any> {
    return this.http.post<IAutoPayment>(
      `${this.url}/enroll/${autopayment.accountId}/paymentToken/${autopayment.bankAccountId}`,
      null
    );
  }

  cancel(accountId: string): Observable<any> {
    return this.http.post<Autopay>(`${this.url}/cancel/${accountId}`, null);
  }

  update(autopayments: any[]) {
    this.autopayments.next(autopayments);
  }
}
