﻿using Microsoft.Extensions.Logging;

namespace BCBSAZ.ProviderCredentialing.Models.Requests.Logger
{
	public class InsertLogMessageRequest
	{
		public LogMessage Message { get; set; }
	}
}
