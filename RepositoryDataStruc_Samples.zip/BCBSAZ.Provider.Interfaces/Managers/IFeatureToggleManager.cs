﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.FeatureToggles;
using BCBSAZ.Provider.Models.Responses.FeatureToggles;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IFeatureToggleManager
	{
		FeatureToggleResponse GetStatus(FeatureToggleRequest request);
	}
}
