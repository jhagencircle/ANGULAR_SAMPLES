﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Subscriber;

namespace BCBSAZ.Provider.Managers.RequestValidators.Subscriber
{
	internal static class IsMemberDelegatedRequestValidator
	{
		public static void Validate(this IsMemberDelegatedRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(IsMemberDelegatedRequest request)
		{
			return Enumerable.Empty<InvalidModelExceptionDetail>();
		}
	}
}
