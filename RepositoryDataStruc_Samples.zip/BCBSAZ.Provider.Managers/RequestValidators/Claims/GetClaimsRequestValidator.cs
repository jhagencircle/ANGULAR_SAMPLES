﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Claims;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.Claims
{

	internal static class GetClaimsRequestValidator
	{
		public static void Validate(this GetClaimRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new UnauthorizedAccessException();

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(GetClaimRequest request)
		{
			if (request.RequestId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(GetClaimRequest), new ArgumentException("Not a Valid RequestId."));

			// TODO: Validate request.ClaimsRequest!
		}

	}
}
