﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.TPA;
using BCBSAZ.Provider.Models.Requests.TPA;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface ITpaProviderRepository
	{
		 public Task<IEnumerable<TpaProviderContractStatus>> GetProviderContractStatusAsync(TpaProviderContractStatusRequest request);

		 public Task<TpaProviderInfo> GetProviderInfoAsync(TpaProviderInfoRequest request);
	}
}
