﻿using System;
using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Logging;
using Serilog;
using Serilog.Events;

namespace BCBSAZ.ProviderAuxiliaryPortal.Managers
{
    public class LoggingManager:ILoggingManager
    {
        private readonly ILogger _logger;
        private const string SOURCE_CONTEXT_PROPERTY = "SourceContext";

        public LoggingManager(ILogger logger)
        {
            _logger = logger;
        }
        public void Log(LoggingModel model)
        {
            LoggingFunction(model)(model.ToString());
        }

        private Action<string> LoggingFunction(LoggingModel loggingModel) => loggingModel.Level switch
        {
            LogLevelEnum.Warning => _logger.ForContext(SOURCE_CONTEXT_PROPERTY, loggingModel.Source).Warning,
            LogLevelEnum.Fatal => _logger.ForContext(SOURCE_CONTEXT_PROPERTY, loggingModel.Source).Fatal,
            LogLevelEnum.Error => _logger.ForContext(SOURCE_CONTEXT_PROPERTY, loggingModel.Source).Error,
            LogLevelEnum.Information => _logger.ForContext(SOURCE_CONTEXT_PROPERTY, loggingModel.Source).Information,
            _ => throw new ArgumentOutOfRangeException()
        };
    }
}
