import { TestBed } from '@angular/core/testing';

import { FinancialManagerUserService } from './financial-manager-user.service';

describe('FinancialManagerUserService', () => {
  let service: FinancialManagerUserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FinancialManagerUserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
