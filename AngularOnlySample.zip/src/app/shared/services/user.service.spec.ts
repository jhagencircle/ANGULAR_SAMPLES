import { TestBed } from '@angular/core/testing';
import {
  OktaAuthModule,
  OktaAuthService,
  OKTA_CONFIG,
} from '@okta/okta-angular';
import { AuthService } from 'src/app/core/auth/auth.service';

import { UserService } from './user.service';

describe('UserService', () => {
  let service: UserService;
  const oktaConfig = {
    issuer: 'https://not-real.okta.com',
    clientId: 'fake-client-id',
    redirectUri: 'http://localhost:4200',
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [OktaAuthModule],
      providers: [
        AuthService,
        OktaAuthService,
        { provide: OKTA_CONFIG, useValue: oktaConfig },
      ],
    });
    service = TestBed.inject(UserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
