﻿namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface IWCFClientFactory
	{
		IDocumentClient GetDocumentClient();

		IDocumentSearchClient GetDocumentSearchClient();

		IEdiTransformClient GetEdiTransformClient();

		IIDNumber GetIDNumberClient();

		IProviderClient GetProviderClient();

		IString270Client GetString270Client(string region);

		IClaims5010ServiceClient GetClaims5010ServiceClient();

		IEligibilityClient GetEligibilityClient();

		ISecurityClient GetSecurityServiceClient();
	}
}
