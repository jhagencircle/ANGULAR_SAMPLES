import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { BankAccount } from './bank-account.model';

@Injectable({
  providedIn: 'root',
})
export class BankAccountService {
  url = `${environment.apiUrl}/api/BankAccount`;

  constructor(private http: HttpClient) {}

  save(bankAccount: BankAccount) {
    return this.http.post<number>(this.url, bankAccount);
  }

  get(accountId: string): Observable<BankAccount[]> {
    return this.http.get<BankAccount[]>(`${this.url}/account/${accountId}`);
  }

  getById(id: string): Observable<BankAccount> {
    return this.http.get<BankAccount>(`${this.url}/account/${id}`);
  }

  update(bankAccount: BankAccount) {
    return this.http.put<number>(
      `${this.url}/account/${bankAccount.accountId}/${bankAccount.id}`,
      bankAccount
    );
  }

  delete(accountId: string, id: string) {
    return this.http.delete<boolean>(`${this.url}/account/${accountId}/${id}`);
  }
}
