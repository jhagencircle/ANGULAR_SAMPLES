﻿using System;
using System.Collections.Generic;
using System.Text;
using ApiRequest = BCBSAZ.Provider.Models.API.Claims.Request;
using ApiResponse = BCBSAZ.Provider.Models.API.Claims.Response;
using BCBSAZ.Provider.Models.Data.Claims;
using BCBSAZ.Provider.Models.Requests.Claims;
using System.Linq;
using BCBSAZ.Provider.Models.API.Claims.Response;
using BCBSAZ.Provider.Models.Enums;
using System.Security.Cryptography;
using BCBSAZ.Provider.Services.WCF.Clients.ProviderService;

namespace BCBSAZ.Provider.Managers.Mappers
{
	public static class ClaimsAPIMapper
	{
		private static readonly IEqualityComparer<ProviderInfo> _providerComparer = new ProviderComparer();

		public static IEnumerable<ApiRequest.ClaimsApiRequest> MapToClaimsApiRequest(this ClaimsInquiryRequest request)
		{
			if (request != null)
			{
				foreach (var provider in request.ClaimsRequest.ProvidersList.Distinct(_providerComparer))
				{
					ApiRequest.Member member = null;
					if(request.ClaimsRequest.IsDependent)
					{
						member = new ApiRequest.Member()
						{
							FirstName = request.ClaimsRequest.PatientFirstName?.Trim(),
							LastName = request.ClaimsRequest.PatientLastName?.Trim(),
							DateOfBirth = request.ClaimsRequest.DateOfBirth
						};
					}
						
					var ApiRequest = new ApiRequest.ClaimsApiRequest()
					{
						Region = request.ClaimsRequest.Region?.Trim(),
						AreaPrefix = MapToClaims5010ServiceAreaPrefix(request.ClaimsRequest.LOB),
						IsDependent = request.ClaimsRequest.IsDependent,
						Provider = new ApiRequest.Provider()
						{
							NPI = provider.NPI?.Trim(),
							TaxId = provider.TaxId?.Trim(),
							FirstName = string.IsNullOrWhiteSpace(provider.FirstName) ? null : provider.FirstName.Trim(),
							LastName = provider.LastName?.Trim()
						},
						Subscriber = new ApiRequest.Subscriber()
						{
							Id = request.ClaimsRequest.SubscriberId?.Trim(),
							FirstName = request.ClaimsRequest.MemberFirstName?.Trim(),
							LastName = request.ClaimsRequest.MemberLastName?.Trim(),
							DateOfBirth = request.ClaimsRequest.IsDependent ? (DateTime?)null : request.ClaimsRequest.DateOfBirth
						},
						Member = member,
						Claim = new ApiRequest.Claim()
						{
							BeginningDateOfService = request.ClaimsRequest.StartDate,
							EndDateOfService = request.ClaimsRequest.EndDate
						}
					};

					yield return ApiRequest;
				}
			}
		}

		public static ClaimsResponse MapToClaimsResponse(this IEnumerable<ApiResponse.ClaimsApiResponse> responses, ClaimStatusCode[] claimStatusCodes, ClaimStatusMessage[] claimStatusMessages)
		{
			return new ClaimsResponse()
			{
				ProviderClaims = responses.Select(r => MapProviderClaim(r, claimStatusCodes, claimStatusMessages)).ToArray()
			};
		}

		private static readonly DateTime _defaultDob = new DateTime(1899, 12, 31);
		private static ProviderClaim MapProviderClaim(ClaimsApiResponse response, ClaimStatusCode[] claimStatusCodes, ClaimStatusMessage[] claimStatusMessages)
		{
			return new ProviderClaim()
			{
				Claims = response.Claims.Select(c => MapClaimHeader(c, response.Subscriber, response.Dependent, claimStatusCodes, claimStatusMessages)).ToArray(),

				DOB = response.Dependent?.DateOfBirth ?? response.Subscriber?.DateOfBirth ?? _defaultDob,
				DependentFirstName = response.Dependent?.FirstName,
				DependentLastName = response.Dependent?.LastName,
				
				MemberFirstName = response.Subscriber?.FirstName,
				MemberLastName = response.Subscriber?.LastName,
				MemberId = response.Subscriber?.Id,

				ProviderFirstName = response.Provider?.FirstName,
				ProviderLastName = response.Provider?.LastName,
				ProviderNPI = response.Provider?.Id,
				ProviderTaxId = response.Provider?.TaxId
			};
		}

		private static ClaimHeader MapClaimHeader(Claim claim, Subscriber subscriber, Dependent dependent, ClaimStatusCode[] claimStatusCodes, ClaimStatusMessage[] claimStatusMessages)
		{
			var retVal = new ClaimHeader()
			{
				 Lines = claim.Lines.IsNullOrEmpty() ? new ClaimLine[0] : claim.Lines.Select(c => MapClaimLine(c, claimStatusCodes, claimStatusMessages)).ToArray(),
				 Messages = MapMessages(claim.StatusCodes, claimStatusMessages).Union(MapMessages(claim.Messages)).ToArray(),
				 AllowedAmount = claim.PaymentDetails?.AllowedAmount ?? 0m,
				 BilledType	= claim.TypeOfBill ?? string.Empty,
				 BilledAmount = claim.TotalClaimChargeAmount ?? 0m,
				 CoInsurance = claim.PaymentDetails?.CoinsuranceAmount ?? 0m,
				 Copay = claim.PaymentDetails?.CopayAmount ?? 0m,
				 DatOfService = GetDateOfService(claim.BeginningDateOfService, claim.EndDateOfService),
				 Deductible = claim.PaymentDetails?.DeductibleAmount ?? 0m,
				 ICN = claim.PayerClaimControlNumber ?? string.Empty,
				 PaidAmount = claim.PaymentDetails?.PaidAmount ?? 0m,
				 PatientFirstName = dependent == null ? subscriber?.FirstName : dependent.FirstName,
				 PatientLastName = dependent == null ? subscriber?.LastName : dependent.LastName,
				 PatientAccount = claim.PatientControlNumber ?? string.Empty,
				 PaymentDate = claim.PaidDate ?? DateTime.MinValue,
				 ReceivedDate = claim.ReceivedDate ?? DateTime.MinValue,
				 ClaimStatusDate = claim.StatusDate ?? DateTime.MinValue,
				 Status = claim.StatusCodes.FirstOrDefault()?.ClaimStatusCategoryCode,
				 CheckEft = claim.CheckNumber,
				 TPANumber = claim.TPANumber ?? null,
			};

			retVal.StatusDisplay = (
				from sc in claimStatusCodes
				where sc.IsMatch(retVal.Status)
				select sc.Status).FirstOrDefault();


			return retVal;
		}

		private static ClaimLine MapClaimLine(Line line, ClaimStatusCode[] claimStatusCodes, ClaimStatusMessage[] claimStatusMessages)
		{
			var retVal = new ClaimLine()
			{
				Messages = MapMessages(line.StatusCodes, claimStatusMessages).Union(MapMessages(line.Messages)).ToArray(),
				AllowedAmount = line.PaymentDetails?.AllowedAmount ?? 0m,
				BilledAmount = line.LineItemChargeAmount ?? 0m,
				CoInsurance = line.PaymentDetails?.CoinsuranceAmount ?? 0m,
				Copay = line.PaymentDetails?.CopayAmount ?? 0m,
				DateOfService = GetDateOfService(line.BeginningDateOfService, line.EndingDateOfService),
				Deductible = line.PaymentDetails?.DeductibleAmount ?? 0m,
				PaidAmount = line.PaymentDetails?.PaidAmount ?? 0m,
				RevProcCode = line.ProcedureCode ?? string.Empty,
				Status = line.StatusCodes.IsNullOrEmpty() ? string.Empty : (line.StatusCodes.FirstOrDefault()?.ClaimStatusCategoryCode ?? string.Empty),
				UnitsOfService = line.Units.ToString()
			};

			retVal.StatusDisplay = (
				from sc in claimStatusCodes
				where sc.IsMatch(retVal.Status)
				select sc.Status).FirstOrDefault();


			return retVal;
		}

		private static IEnumerable<ClaimMessage> MapMessages(IEnumerable<Message> messages)
		{
			if (!messages.IsNullOrEmpty())
			{
				foreach (var message in messages)
				{
					yield return new ClaimMessage()
					{
						Code = message.Code,
						MessageValue = message.Description
					};
				}
			}
		}

		private static IEnumerable<ClaimMessage> MapMessages(IEnumerable<StatusCode> statusCodes, ClaimStatusMessage[] claimStatusMessages)
		{
			if (!statusCodes.IsNullOrEmpty())
			{
				foreach (var statusCode in statusCodes)
				{
					yield return new ClaimMessage()
					{
						Code = $"{statusCode.ClaimStatusCategoryCode}:{statusCode.ClaimStatusCode}:{statusCode.EntityCode}",
						MessageValue = string.Join(" - ", GetMessages(statusCode.ClaimStatusCategoryCode, statusCode.ClaimStatusCode, statusCode.EntityCode, claimStatusMessages))
					};
				}
			}
		}

		private static IEnumerable<string> GetMessages(string categoryCode, string statusCode, string entityCode, ClaimStatusMessage[] claimStatusMessages)
		{
			if (!string.IsNullOrWhiteSpace(categoryCode))
				yield return GetMessageValue("507Codes", categoryCode, claimStatusMessages);

			if (!string.IsNullOrWhiteSpace(statusCode))
				yield return GetMessageValue("508Codes", statusCode, claimStatusMessages);

			if (!string.IsNullOrWhiteSpace(entityCode))
				yield return GetMessageValue("EntityCodes", entityCode, claimStatusMessages);
		}

		private static string GetMessageValue(string entityName, string code, ClaimStatusMessage[] claimStatusMessages) => (
			from sm in claimStatusMessages
			where
				sm.EntityName.Equals(entityName, StringComparison.OrdinalIgnoreCase) &&
				sm.Id.Equals(code, StringComparison.OrdinalIgnoreCase)
			select sm.Description).FirstOrDefault();


		private static string GetDateOfService(DateTime? beginningDate, DateTime? endingDate)
		{
			if (beginningDate.HasValue && endingDate.HasValue)
				return $"{beginningDate:yyyyMMdd}-{endingDate:yyyyMMdd}";

			if (beginningDate.HasValue)
				return $"{beginningDate:yyyyMMdd}";

			if (endingDate.HasValue)
				return $"{endingDate:yyyyMMdd}";

			return string.Empty;
		}

		private static ClaimMessage MapToClaimMessage(StatusCode statusCode)
		{
			return new ClaimMessage()
			{
				Code = statusCode.ClaimStatusCode
			};
		}

		private static string MapToClaims5010ServiceAreaPrefix(LOB lob)
		{
			switch (lob)
			{
				case LOB.CHS:
				case LOB.LCL:
					return $"{Claims5010Service.AreaPrefix.LCL}";
				case LOB.OOA:
					return $"{Claims5010Service.AreaPrefix.OOA}";
				case LOB.FEP:
					return $"{Claims5010Service.AreaPrefix.FEP}";
				default:
					return $"{Claims5010Service.AreaPrefix.LCL}";
			}
		}
	}
}
