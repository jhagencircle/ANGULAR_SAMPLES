﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class DeaRegistration
	{
		[DisplayName("Expiration Date")]
		[DataType(DataType.Text)]
		[DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
		public DateTime? ExpirationDate { get; set; }

		[DisplayName("DEA Registration")]
		[MaxLength(9)]
		public string RegistrationNumber { get; set; }
	}
}
