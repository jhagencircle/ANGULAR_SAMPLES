﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BCBSAZ.ProviderCredentialing.WebAPI.Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	public class Address
	{
		public string StreetAddress { get; set; }

		public string City { get; set; }

		public string State { get; set; }

		public string ZipCode { get; set; }

		public string EmailAddress { get; set; }

		public string Phone { get; set; }

		public string Fax { get; set; }
		
		[JsonConverter(typeof(EnumCollectionConverter<AddressType>))]
		public IEnumerable<AddressType> Types { get; set; }
	}
}
