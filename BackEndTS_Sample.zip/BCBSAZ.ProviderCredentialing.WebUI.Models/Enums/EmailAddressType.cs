﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Enums
{
	public enum EmailAddressType
	{
		ApplicationContactInformation,
		BusinessCorrespondence,
		BusinessEmail
	}
}
