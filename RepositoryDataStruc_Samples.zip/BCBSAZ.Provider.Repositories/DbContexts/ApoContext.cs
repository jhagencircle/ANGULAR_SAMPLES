﻿using BCBSAZ.Provider.Models.Data.Common;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IApoContext : IDbContext
	{
		DbSet<ServerInfo> ServerInfo { get; }
		DbSet<ConfigSetting> ConfigSettings { get; }
	}

	public class ApoContext : DbContext, IApoContext
	{
		public ApoContext(DbContextOptions<ApoContext> options) : base(options) { }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<ServerInfo>().HasNoKey();

			modelBuilder.Entity<ConfigSetting>()
				.HasKey(cs => new { cs.Environment, cs.Name });

			/******************** Property Configs ********************/

		}

		public DbSet<ServerInfo> ServerInfo { get; protected set; }

		public DbSet<ConfigSetting> ConfigSettings { get; protected set; }

	}
}
