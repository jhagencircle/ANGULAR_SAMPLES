import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmployeeBenefitSelectionComponent } from './employee-benefit-selection.component';
import { EmployeeMock } from '../../shared/mocks/employee.mock';
import { EmployeeProfileService } from '../shared/employee-profile.service';
import { Observable, of } from 'rxjs';

describe('EmployeeBenefitSelectionComponent', () => {
  let component: EmployeeBenefitSelectionComponent;
  let fixture: ComponentFixture<EmployeeBenefitSelectionComponent>;
  let mockEmployeeService: EmployeeMock;
  let employeeProfileServiceSpy: { update: jasmine.Spy; get: jasmine.Spy };

  beforeEach(async () => {
    employeeProfileServiceSpy = {
      update: jasmine.createSpy('update').and.returnValue(of(true)),
      get: jasmine.createSpy('get').and.returnValue(of(true)),
    };
    mockEmployeeService = new EmployeeMock();
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [EmployeeBenefitSelectionComponent],
      providers: [
        {
          provide: EmployeeProfileService,
          useValue: employeeProfileServiceSpy,
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeBenefitSelectionComponent);
    component = fixture.componentInstance;

    mockEmployeeService
      .get()
      .subscribe(
        (data) => (component.benefitSelection = data.benefitSelection)
      );
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    expect(employeeProfileServiceSpy.get.calls.count()).toBe(1);
    expect(component.subscriptions.length).toBe(1);
  });

  it('should show edit', () => {
    component.editBenefit();
    expect(component.showEdit).toBeTrue();
  });

  it('should close edit', () => {
    component.close();
    expect(component.showEdit).toBeFalse();
  });

  it('should update benefit', () => {
    component.onSendDataChild();
    expect(employeeProfileServiceSpy.update.calls.count()).toBe(1);
  });

  it('should display benefit form', () => {
    component.displayBenefitForm(true);
    expect(component.showEdit).toBeTrue();
  });

  it('should hide benefit form', () => {
    component.displayBenefitForm(false);
    expect(component.showEdit).toBeFalse();
    expect(component.healthInsuranceBenefit).not.toBeNull();
    expect(component.dentalInsuranceBenefit).not.toBeNull();
    expect(component.lifeInsuranceBenefit).not.toBeNull();
  });
});
