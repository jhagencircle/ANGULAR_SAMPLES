﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.PreCert;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.PreCert
{
	internal static class CancelMedicalPreCertRequestValidator
	{
		public static void Validate(this CancelMedicalPreCertRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(CancelMedicalPreCertRequest request)
		{
			if (request.PreCertId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(CancelMedicalPreCertRequest.PreCertId), new ArgumentException("Invalid Medical PreCert Id specified."));
		}
	}
}
