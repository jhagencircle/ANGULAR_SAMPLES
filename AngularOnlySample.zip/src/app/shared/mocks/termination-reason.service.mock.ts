import { from, Observable, of } from 'rxjs';

export class TerminationReasonServiceMock {
  constructor() {}

  get(): Observable<any> {
    return of([
      'Not Specified',
      'Not Applicable',
      'Overdue payment',
      'Qualif Event-Member Term',
      'Mbr No Longer Eligible',
      'Date of Death Auto-Termination policy',
      'Death',
      'Termination of Benefits',
      'Voluntary Withdrawl',
      'Plan Change',
      'Re-Enrollment',
      'Notification Only',
      'No Reason Given',
      'Canceled for Non-Payment',
      'Subscriber Dissatisfied with Customer Service',
      'Employment Status Change',
      'Never Effective',
      'Subscriber newborn cancellation',
      'HIC Cancel',
      'HIC Term',
      'Fraud Cancel',
      'Fraud Term',
      'Group no longer offers insurance',
      'Group transferred to individual',
      'Group company out of business',
      'Group company sold',
      'Administrative decision to cancel',
      'APTC term for non payment',
      'Subscriber dependent split off',
      'Group change to sub or dependent eligibility',
      'Group rate change or reallocation',
      'Group benefit change',
      'Group rate and benefit change',
      'Group correct rate segment',
      'Group correct coverage segment',
      'Group correct other segments',
      'Group Renew with no or minor change',
      'Group Renew with eligibility change',
      'Group Renew with rate change',
      'Group Renew with benefit change',
      'Group renewal (with rate and benefit change)',
      'APTC term Never Effective for non-payment',
    ]);
  }

  update(): Observable<boolean> {
    return of(true);
  }
}
