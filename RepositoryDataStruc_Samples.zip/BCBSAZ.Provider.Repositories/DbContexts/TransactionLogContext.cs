﻿using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface ITransactionLogContext : IDbContext
	{
	}

	public class TransactionLogContext : DbContext, ITransactionLogContext
	{
		/// <summary>
		/// Creates a new instance of the SystemLogs DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public TransactionLogContext(DbContextOptions<TransactionLogContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the SystemLogs database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			/******************** Property Configs ********************/
		}

	}
}
