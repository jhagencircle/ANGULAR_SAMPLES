﻿using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Responses.Common;
using BCBSAZ.Provider.Models.Responses.Settings;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface ICommonService
	{
		Task<MessageCountResponse> GetMessageCountAsync(string userId);

		IEnumerable<string> GetRegions();

		Task<Select2Response> GetNpis(Select2Request request);

		Task<Select2Response> GetNpisForTpa(Select2Request request);

		Task<DoesUsernameExistResponse> CheckUsername(DoesUsernameExistRequest username);
	}
}
