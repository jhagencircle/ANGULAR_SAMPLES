export interface IAddress {
  addressType: string | null;
  address1: string | null;
  address2: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
  county: string | null;
}
