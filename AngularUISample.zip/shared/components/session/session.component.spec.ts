import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AuthService } from 'src/app/core/auth.service';
import { NgIdleService } from 'src/app/services/ng-idle.service';
import { MockAuthService } from '../../mocks/mockAuthService';
import { SessionComponent } from './session.component';

class MockNgIdleService { }

describe('SessionComponent', () => {
  let component: SessionComponent;
  let fixture: ComponentFixture<SessionComponent>;
  let authService: AuthService;
  let ngIdService: NgIdleService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SessionComponent],
      providers: [{ provide: AuthService, useClass: MockAuthService }, { provide: NgIdleService, useClass: MockNgIdleService }]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SessionComponent);
    authService = TestBed.inject(AuthService);
    ngIdService = TestBed.inject(NgIdleService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
