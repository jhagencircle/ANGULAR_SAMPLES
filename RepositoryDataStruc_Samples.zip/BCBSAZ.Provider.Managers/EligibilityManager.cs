﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Processors;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Interfaces.WCFClients;
using BCBSAZ.Provider.Managers.RequestValidators.Common;
using BCBSAZ.Provider.Managers.RequestValidators.Eligibility;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.Eligibility;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Data.Settings;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Requests.Common;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;
using BCBSAZ.Provider.Models.Requests.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Responses.Common;
using BCBSAZ.Provider.Models.Responses.Eligibility.Details;
using BCBSAZ.Provider.Models.Responses.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Xml271Processor;
using BCBSAZ.Provider.Models.Xml271Processor.Codes.BCBSAZ.Provider.Models.Xml271Processor.Codes;
using BCBSAZ.Provider.Utilities;
using BCBSAZ.Provider.Xml271;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Managers
{
	public partial class EligibilityManager : IEligibilityManager
	{
		private readonly IEligibilityRepository _repository;
		private readonly IXml271Deserializer _xml271Processor;
		private readonly IWCFClientFactory _wcfClientFactory;
		private readonly ISettingsManager _settingsManager;
		private readonly string _x12Environment;
		private readonly ILogger<EligibilityManager> _logger;
		private readonly IProviderRepository _providerRepository;
		private readonly IHttpContextAccessor _contextAccessor;
		private readonly ITransactionLogRepository _transitionsLogRepository;
		private readonly IEligibilityApiClient _eligibilityApiClient;
		private readonly IPlanProfileApiClient _planProfileApiClient;
		private readonly IPlanProfileManager _planProfileManager;

		public EligibilityManager(IEligibilityRepository repository, IXml271Deserializer xml271Processor, IWCFClientFactory wcfClientFactory, ITransactionLogRepository transactionLogRepository,
			IEligibilityApiClient eligibilityApiClient, ISettingsManager settingsManager, IConfiguration config, ILogger<EligibilityManager> logger, IProviderRepository providerRepository, IHttpContextAccessor contextAccessor,
			IPlanProfileApiClient planProfileApiClient, IPlanProfileManager planProfileManager)
		{
			_repository = repository ?? throw new ArgumentNullException(nameof(repository));
			_xml271Processor = xml271Processor ?? throw new ArgumentNullException(nameof(xml271Processor));
			_wcfClientFactory = wcfClientFactory;
			_x12Environment = config.GetValue<string>("X12Environment");
			_logger = logger;
			_providerRepository = providerRepository;
			_contextAccessor = contextAccessor;
			_transitionsLogRepository = transactionLogRepository;
			_settingsManager = settingsManager;
			_eligibilityApiClient = eligibilityApiClient;
			_planProfileApiClient = planProfileApiClient;
			_planProfileManager = planProfileManager;
		}

		#region Eligibility Details
		public async Task<COBResponse> GetCOBsAsync(COBRequest request)
		{
			request.Validate();

			return new COBResponse()
			{
				CoordinationOfBenefits = await _repository.GetCOBsAsync(request.ResponseId)
			};
		}

		public async Task<EligibilitySummaryResponse> GetEligibilitySummaryAsync(EligibilitySummaryRequest request)
		{
			request.Validate();

			return new EligibilitySummaryResponse()
			{
				EligibilitySummary = await _repository.GetEligibilitySummaryAsync(request.ResponseId)
			};
		}

		public async Task<InquiryInfoResponse> GetInquiryAsync(InquiryInfoRequest request)
		{
			request.Validate();

			return new InquiryInfoResponse()
			{
				Inquiry = await _repository.GetInquiryAsync(request.ResponseId)
			};
		}

		public async Task<DisclaimerResponse> GetDisclaimer(DisclaimerRequest request)
		{
			request.Validate();

			return new DisclaimerResponse
			{
				Disclaimer = await _repository.GetDisclaimerAsync(request.ResponseId)
			};
		}

		public async Task<InsuranceInfoResponse> GetInsuranceInfoAsync(InsuranceInfoRequest request)
		{
			request.Validate();

			return new InsuranceInfoResponse()
			{
				Insurance = await _repository.GetInsuranceInfoAsync(request.ResponseId)
			};
		}

		public async Task<PatientDetailResponse> GetPatientDetailAsync(PatientDetailRequest request)
		{
			request.Validate();

			return new PatientDetailResponse()
			{
				PatientDetail = await _repository.GetPatientDetailAsync(request.ResponseId)
			};
		}

		public async Task<DeductiblesResponse> GetDeductiblesAsync(DeductiblesRequest request)
		{
			request.Validate();

			return new DeductiblesResponse(await _repository.GetDeductiblesAsync(request.ResponseId));
		}

		public async Task<ServiceTypeResponse> GetServiceTypeBenefitsAsync(ServiceTypeRequest request)
		{
			request.Validate();

			return new ServiceTypeResponse(await _repository.GetFullNetworkServiceTypeAsync(request.ResponseId));
		}

		public async Task<BooksRidersResponse> GetBooksAndRidersAsync(BooksRidersRequest request)
		{
			request.Validate();

			return new BooksRidersResponse()
			{
				BooksRiders = await _repository.GetBooksAndRidersAsync(request.ResponseId)
			};
		}

		public async Task<GeneralInformationResponse> GetGeneralInformationAsync(GeneralInformationRequest request)
		{
			request.Validate();

			return new GeneralInformationResponse(await _repository.GetGeneralInformationAsync(request.ResponseId));
		}

		public CanViewIDCardResponse CanViewIDCard(CanViewIDCardRequest request)
		{
			request.Validate();
			var suppressedPrefixs = new string[] { "K8Y", "K8Z" };
			var alphaPrefix = request.SubscriberId.Substring(0, 3);

			if (suppressedPrefixs.Contains(alphaPrefix))
				return new CanViewIDCardResponse() { CanViewIDCard = false };

			return new CanViewIDCardResponse()
			{
				CanViewIDCard = _repository.CanViewIDCard(request.SubscriberId, request.DateOfService, request.FirstName, request.LastName, request.DateOfBirth)
			};
		}
		#endregion

		#region Process Edi Test Tool Request

		public async Task<ConvertEdiResponse> ProcessAndSaveEdiRequestAsync(ConvertEdiRequest request, WebUser user)
		{
			request.Validate(user);

			var xml = request.TestTool.EDIInquiry.StartsWith('<') ? request.TestTool.EDIInquiry : (await TransformEdiToXmlAsync(request.TestTool.EDIInquiry));

			if (string.IsNullOrWhiteSpace(xml))
				throw new ArgumentException("The posted EDI text did not produce a valid Xml Document.", nameof(request));

			var inquiryResponse = new Models.Data.Eligibility.Inquiries.InquiryResponse()
			{
				ServiceType = "30",
				DateOfService = request.TestTool.DateOfService ?? DateTime.Today,
				ControlNumber = 0,
				InquiryEDI = "Test Tool",
				ResponseXml = xml,
				Result = _xml271Processor.DeserializeXml(xml)
			};

			_repository.PopulateResponseInfo(inquiryResponse);

			var inquiryRequest = new InquiryRequest()
			{
				OrgId = user.OrgId,
				UserId = user.UserId,
				ProviderId = request.TestTool.ProviderId,
				DateOfService = request.TestTool.DateOfService ?? DateTime.Today,
				InquiryType = InquiryTypes.TestSearch,
				SubscriberId = request.TestTool.MemberId,
				FirstName = string.IsNullOrWhiteSpace(request.TestTool.DependentFirstName) ? request.TestTool.FirstName : request.TestTool.DependentFirstName,
				LastName = string.IsNullOrWhiteSpace(request.TestTool.DependentLastName) ? request.TestTool.LastName : request.TestTool.DependentLastName,
				DateOfBirth = request.TestTool.DateOfBirth ?? new DateTime(1980, 1, 1),
				Gender = request.TestTool.Gender == Gender.Male ? "M" : (request.TestTool.Gender == Gender.Female ? "F" : "U"),
				IsDependent = request.TestTool.Dependent,
				SubscriberFirstName = request.TestTool.FirstName,
				SubscriberLastName = request.TestTool.LastName,
				InsertDate = DateTime.Now,
				Responses = new List<InquiryResponse>()
				{
					inquiryResponse
				}
			};

			await _repository.SaveEligibilityInquiriesAsync(inquiryRequest);
			var serviceTypes = _providerRepository.GetServiceTypes();

			return new ConvertEdiResponse()
			{
				Request = new EligibilityRequest()
				{
					RequestId = inquiryRequest.RequestId,
					DateOfService = inquiryRequest.DateOfService,
					SubscriberId = inquiryRequest.SubscriberId,
					FirstName = inquiryRequest.FirstName,
					LastName = inquiryRequest.LastName,
					DateOfBirth = inquiryRequest.DateOfBirth,
					SubscriberFirstName = inquiryRequest.SubscriberFirstName,
					SubscriberLastName = inquiryRequest.SubscriberLastName,
					ErrorMessages = (
						from res in inquiryRequest.Responses
						where !res.Errors.IsNullOrEmpty()
						from err in res.Errors
						where err != null
						select $"{err.Code} - {err.Message}"
					),
					Responses = (
						from res in inquiryRequest.Responses
						select new EligibilityResponse()
						{
							ResponseId = res.ResponseId,
							HasEligibility = true,
							ServiceTypeCode = res.ServiceType,
							ServiceTypeName = (
								from st in serviceTypes
								where st.Code.Equals(res.ServiceType, StringComparison.OrdinalIgnoreCase)
								select st.Description).FirstOrDefault() ?? res.ServiceType,
						}
					)
				}
			};
		}

		private bool UseNewEligibilityApi(string subscriberId)
		{
			if (string.IsNullOrWhiteSpace(subscriberId) || subscriberId.Length < 3) return false; // Use old WCF service, with an invalid SubId it'll fail either way.

			// Feature Toggle:
			// 0 = Use WCF for all requests (Do not use Connect API)
			// 1 = Use Connect API for ITS MA, SoAZ, IU65 (by prefix) only, Use WCF for all other requests
			// 2 = Use Connect API for all requests.

			var prefix = subscriberId.Substring(0, 3);

			return (_UseNewEligibilityApiToggle.AsInt()) switch
			{
				1 => _planProfileManager.GetItsMaAllPrefixes().Result.Contains(prefix),
				2 => true,
				// 0 and all others
				_ => false,
			};
		}

		private async Task<string> TransformEdiToXmlAsync(string ediText)
		{
			if (string.IsNullOrWhiteSpace(ediText))
				return null;

			using (var client = _wcfClientFactory.GetEdiTransformClient())
			{
				return await client.TransformEdiToXml(ediText);
			}
		}

		#endregion

		#region Submit Inquiries Test
		public async Task<SubmitInquiriesTestResponse> SubmitInquiriesTestAsync(SubmitInquiriesRequest request, WebUser user)
		{
			request.Validate(user);

			if (request.Inquiries.Count() != 1)
				throw new InvalidOperationException("Invalid Inquiry Count for Test Submission (please submit one inquiry with one service type at a time).");

			var inquiry = request.Inquiries.First();
			if (inquiry.Violations.Any())
				throw new InvalidOperationException($"Invalid Inquiry specified: {string.Join("; ", GetErrorMessages(inquiry.Violations))}");

			if (inquiry.ServiceTypes.Count() != 1)
				throw new InvalidOperationException("Invalid Service Type Count for Test Submission (please submit one inquiry with one service type at a time).");


			var inquiryRequest = CreateInquiryRequest(inquiry, user);
			var response = inquiryRequest.Responses.First();

			var retVal = new SubmitInquiriesTestResponse(inquiry, response.InquiryEDI);

			using (_ediClient = _wcfClientFactory.GetString270Client(request.Region))
			{
				var wcfTask = ProcessTestWcfInquiry(retVal);
				var apiTask = ProcessTestApiInquiry(retVal, request.Region);

				await Task.WhenAll(wcfTask, apiTask);
			}

			return retVal;
		}

		private void ProcessTestResult(SubmitInquiriesTest test, string xmlResult, string testType)
		{
			if (string.IsNullOrWhiteSpace(xmlResult) || (xmlResult == "999"))
			{
				test.Success = false;

				if (string.IsNullOrWhiteSpace(test.ExceptionMessage))
					test.ExceptionMessage = $"{testType} Service returned a '999' response.";
			}
			else
			{
				test.Errors = GetErrorMessages(xmlResult);
				test.Success = !test.Errors.Any();
				test.Result = _xml271Processor.DeserializeXml(xmlResult);
			}
		}

		private async Task ProcessTestWcfInquiry(SubmitInquiriesTestResponse response)
		{
			try
			{
				response.WCF.ResponseEDI = "Not Available for WCF";
				ProcessTestResult(response.WCF, await _ediClient.Get271(response.RequestEDI, response.WCF), "WCF");
			}
			catch (Exception ex)
			{
				response.WCF.Success = false;
				response.WCF.ExceptionType = ex.GetType().FullName;
				response.WCF.ExceptionMessage = ex.GetFullMessage(Environment.NewLine);
			}
		}

		private async Task ProcessTestApiInquiry(SubmitInquiriesTestResponse response, string region)
		{
			try
			{
				ProcessTestResult(response.API, await GetResponseXml(response.RequestEDI, region, new StringBuilder(), "testapicorrid", response.API), "API");
			}
			catch (Exception ex)
			{
				response.API.Success = false;
				response.API.ExceptionType = ex.GetType().FullName;
				response.API.ExceptionMessage = ex.GetFullMessage(Environment.NewLine);
			}
		}
		#endregion

		#region Submit Inquiries
		private IString270Client _ediClient = null;
		private SettingValue _UseNewEligibilityApiToggle;


		public async Task<SubmitInquiriesResponse> SubmitInquiriesAsync(SubmitInquiriesRequest request, WebUser user)
		{
			request.Validate(user);
			var failure = false;

			_UseNewEligibilityApiToggle = await _settingsManager.GetSettingValueAsync(Constants.Settings.Names.UseNewEligibilityApi, Constants.Settings.Defaults.Use5010Bridge, user);

			/*************************************************************************************************************
			 * IMPORTANT!  Everything that happens between here and "await Task.WhenAll(tasks)"
			 * MUST not have any DbContext calls (including in called methods)
			 * All of these tasks are occuring in parallel and will cause Entity Framework errors when two (or more)
			 * "threads" collide.
			*************************************************************************************************************/
			Task<SubmitInquiryRequest>[] inquiryTasks;

			using (_ediClient = _wcfClientFactory.GetString270Client(request.Region))
			{
				inquiryTasks = (
					from inquiry in request.Inquiries
					select ProcessInquiry(inquiry, user, request.Region)).ToArray();

				await Task.WhenAll(inquiryTasks);
			}

			/*************************************************************************************************************
			 * IMPORTANT!  Everything that happens now MUST use await operators on ANY task that calls a DbContext object
			 * All of the below MUST occur synchronously or it will cause Entity Framework errors when two (or more)
			 * "threads" collide.
			*************************************************************************************************************/

			var selectedServiceTypes = request.Inquiries.LastOrDefault()?.ServiceTypes;

			if (selectedServiceTypes != null)
				await _providerRepository.UpdateSelectedServiceTypeAsync(user.UserId, string.Join(",", selectedServiceTypes));

			var validRequests = (
				from t in inquiryTasks
				where !t.Result.Inquiry.Violations.Any()
				select t.Result).ToArray();

			var serviceTypes = _providerRepository.GetServiceTypes();
			validRequests.ForEach(AddMiscInfoNodesToXml, serviceTypes);

			try
			{
				await _repository.SaveEligibilityInquiriesAsync((
						from r in validRequests
						select r.Request
					).ToArray());

			}
			catch (Exception ex)
			{
				failure = true;
				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Saving E&B Results");
			}

			var hasErrors = (
				from requests in validRequests
				from r in requests.Request?.Responses
				where !r.Errors.IsNullOrEmpty()
				select r).Any();

			try
			{
				if (!failure && !hasErrors)
				{
					await CreateOrUpdatePatientListAsync(user, validRequests);
				}

			}

			catch (Exception ex)
			{
				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Saving Patient List");
			}

			var endTime = DateTime.Now;

			foreach (var task in inquiryTasks)
			{
				foreach (var result in task.Result.ProcessResult)
				{
					var totalProcessTime = endTime.Subtract(result.ProcessStart).TotalSeconds;
					var postProcessTime = totalProcessTime - result.TotalServiceTime;

					await _transitionsLogRepository.LogTransactionAsync(Environment.MachineName, "P_ET", result.InquiryEDI, result.ErrorCode, endTime, totalProcessTime, result.TotalServiceTime, postProcessTime, user.UserId, result.Info.ToString());
				}
			}

			return new SubmitInquiriesResponse()
			{
				Failure = failure,
				Requests = (
					from task in inquiryTasks
					select GenerateEligibilityRequest(task.Result, serviceTypes)
				)
			};
		}

		private async Task CreateOrUpdatePatientListAsync(WebUser user, SubmitInquiryRequest[] validRequests)
		{
			var patients = ((
						from r in validRequests
						select new Patient
						{
							SubscriberId = r.Request.SubscriberId,
							PatientFirstName = r.Request.FirstName,
							PatientLastName = r.Request.LastName,
							DateOfBirth = r.Request.DateOfBirth.Date,
							IsDependent = r.Request.IsDependent,
							SubscriberFirstName = r.Request.SubscriberFirstName,
							SubscriberLastName = r.Request.SubscriberLastName,
							PatientGender = r.Request.Gender,
							LOB = r.Request.Lob ?? (int)LOB.INVALID
						}).ToArray());

			var records = await _repository.GetOrCreatePatientsAsync(patients);

			foreach (var record in records)
			{
				var orgPatient = (
					from o in record.Orgs
					where o.OrgId.Equals(user.OrgId, StringComparison.OrdinalIgnoreCase)
					select o
					).FirstOrDefault();

				var userPatient = (
							from u in record.Users
							where u.UserId.Equals(user.UserId, StringComparison.OrdinalIgnoreCase)
							select u
				).FirstOrDefault();

				if (orgPatient == null)
				{

					orgPatient = new PatientOrg()
					{
						PatientId = record.PatientId,
						OrgId = user.OrgId,
						LastUsed = DateTime.Now
					};

					record.Orgs.Add(orgPatient);
				}

				else
				{
					orgPatient.LastUsed = DateTime.Now;
				}


				if (userPatient == null)
				{

					userPatient = new PatientUser()
					{
						PatientId = record.PatientId,
						UserId = user.UserId,
						LastUsed = DateTime.Now
					};

					record.Users.Add(userPatient);
				}
				else
				{
					userPatient.LastUsed = DateTime.Now;
				}
			}

			await _repository.SaveChangesAsync();
		}

		private static EligibilityRequest GenerateEligibilityRequest(SubmitInquiryRequest request, Models.Data.Common.ServiceType[] serviceTypes)
		{
			if ((request.Request == null) || (request.Request.Responses == null))
			{
				return new EligibilityRequest()
				{
					Index = request.Inquiry.Index,
					DateOfService = request.Inquiry.DateOfService,
					SubscriberId = request.Inquiry.SubscriberId,
					FirstName = request.Inquiry.Patient.FirstName,
					LastName = request.Inquiry.Patient.LastName,
					SubscriberFirstName = request.Inquiry.Subscriber.FirstName,
					SubscriberLastName = request.Inquiry.Subscriber.LastName,
					ErrorMessages = request.ErrorMessages
				};
			}
			else
			{
				return new EligibilityRequest()
				{
					Index = request.Inquiry.Index,
					RequestId = request.Request.RequestId,
					DateOfService = request.Request.DateOfService,
					SubscriberId = request.Request.SubscriberId,
					FirstName = request.Request.FirstName,
					LastName = request.Request.LastName,
					DateOfBirth = request.Request.DateOfBirth,
					SubscriberFirstName = request.Request.SubscriberFirstName,
					SubscriberLastName = request.Request.SubscriberLastName,
					ErrorMessages = request.ErrorMessages.Union(
						from res in request.Request.Responses
						where !res.Errors.IsNullOrEmpty()
						from err in res.Errors
						where err != null
						select $"{err.Code} - {err.Message}"
					),
					Responses = (
						from res in request.Request.Responses
						select new EligibilityResponse()
						{
							ResponseId = res.ResponseId,
							HasEligibility = true,
							ServiceTypeCode = res.ServiceType,
							ServiceTypeName = (
								from st in serviceTypes
								where st.Code.Equals(res.ServiceType, StringComparison.OrdinalIgnoreCase)
								select st.Description).FirstOrDefault() ?? res.ServiceType,
						}
					)
				};
			}
		}


		private async Task<SubmitInquiryRequest> ProcessInquiry(Inquiry inquiry, WebUser user, string region)
		{
			var request = CreateInquiryRequest(inquiry, user);

			var results = Enumerable.Empty<ProcessInquiryResult>();

			if (!inquiry.Violations.Any())
			{
				var tasks = (from response in request.Responses
										 select ProcessInquiry(inquiry, response, region)).ToArray();

				// Wait for the EDI Responses.
				await Task.WhenAll(tasks);

				results = tasks.Select(s => s.Result);
			}

			return new SubmitInquiryRequest()
			{
				ProcessResult = results,
				Inquiry = inquiry,
				Request = request,
				ErrorMessages = GetErrorMessages(inquiry.Violations)
			};
		}

		private async Task<string> GetResponseXml(string requestEdi, string region, StringBuilder info, string correlationId, SubmitInquiriesTest test = null)
		{
			const string success = "Success";
			const string x12_271Document = "X12_271";

			var request = new VelocityEligibilityRequest()
			{
				CorrelationID = correlationId,
				PayloadID = RandomGenerator.RandomInt(),
				RoutingDestination = (region ?? string.Empty).StartsWith("P", StringComparison.OrdinalIgnoreCase) ? null : region,
				Payload = requestEdi
			};

			info.Insert(0, $"Correlation ID={correlationId} ");
			string ediText = null;
			var sw = Stopwatch.StartNew();

			try
			{
				var response = (await _eligibilityApiClient.Get271Response(request))?.Response;

				if (!response.PayloadType.StartsWith(x12_271Document, StringComparison.OrdinalIgnoreCase))
				{
					_logger.LogError($"A non 271 response was returned for Correlation ID: {request.CorrelationID}, PayloadType: {response.PayloadType}");
					return null;
				}

				if (success.Equals(response?.ErrorCode, StringComparison.OrdinalIgnoreCase) || string.IsNullOrWhiteSpace(response?.ErrorCode))
				{
					ediText = response.Payload;

					if (test != null)
						test.ResponseEDI = ediText;
				}
				else
				{
					_logger.LogError($"Error response returned from Eligibility API: {response?.ErrorCode} - {response?.ErrorMessage} Correlation ID: {correlationId}");

					if (test != null)
						test.ExceptionMessage = $"Error response returned from Eligibility API: {response?.ErrorCode} - {response?.ErrorMessage} Correlation ID: {correlationId}";
				}
			}
			catch (Exception ex)
			{
				info.AppendLine($"Error communicating with Eligibility API: {ex.Message}  Correlation ID: {correlationId}");
				_logger.LogError(ex, _contextAccessor?.HttpContext, $"Error communicating with Eligibility API  Correlation ID: {correlationId}");

				if (test != null)
				{
					test.ExceptionType = ex.GetType().FullName;
					test.ExceptionMessage = $"Error communicating with Eligibility API: {ex.Message} Correlation ID: {correlationId}";
				}
			}
			finally
			{
				sw.Stop();
				info.AppendLine($"Response from Inquiry API in {sw.Elapsed.TotalMilliseconds:0.00} milliseconds.");
			}

			sw.Reset();
			sw.Start();

			try
			{
				return await TransformEdiToXmlAsync(ediText);
			}
			catch (Exception ex)
			{
				info.AppendLine($"Error transforming EDI to XML: {ex.Message}  Correlation ID: {correlationId}");
				_logger.LogError(ex, _contextAccessor?.HttpContext, $"Error transforming EDI to XML. Correlation ID: {correlationId}");

				if ((test != null) && string.IsNullOrWhiteSpace(test.ExceptionMessage))
				{
					test.ExceptionType = ex.GetType().FullName;
					test.ExceptionMessage = $"Error transforming EDI to XML: {ex.Message} Correlation ID: {correlationId}";
				}

				return null;
			}
			finally
			{
				sw.Stop();
				info.AppendLine($"Response from EDI to XML WCF Service in {sw.Elapsed.TotalMilliseconds:0.00} milliseconds.");
			}
		}

		private async Task<ProcessInquiryResult> ProcessInquiry(Inquiry inquiry, InquiryResponse response, string region)
		{
			var info = new StringBuilder();
			var processStart = DateTime.Now;
			var useNewEligibilityApi = UseNewEligibilityApi(inquiry.SubscriberId);

			info.AppendLine($"Using {(useNewEligibilityApi ? "API" : "WCF")} for Inquiry");

			if (useNewEligibilityApi)
				response.CorrelationId = RandomGenerator.GenerateCorrelationId();

			response.ResponseXml = useNewEligibilityApi ?
				await GetResponseXml(response.InquiryEDI, region, info, response.CorrelationId) :
				await _ediClient.Get271(response.InquiryEDI);

			var totalServiceTime = DateTime.Now.Subtract(processStart).TotalSeconds;

			if (response.ResponseXml == "999") response.ResponseXml = null;

			response.Errors = GetErrorMessages(response.ResponseXml);

			if (response.ResponseXml == null)
			{
				// No response, populate info from Inquiry so that results page has MemberId/Name info
				info.AppendLine("No Response from service.");
				response.SubscriberId = inquiry.SubscriberId;
				response.SubscriberFirstName = inquiry.Subscriber.FirstName;
				response.SubscriberLastName = inquiry.Subscriber.LastName;
				response.DateOfBirth = inquiry.Patient.DateOfBirth;
				response.FirstName = inquiry.Patient.FirstName;
				response.LastName = inquiry.Patient.LastName;
			}
			else
			{
				try
				{
					info.AppendLine($"Length of XML Response: {response.ResponseXml.Length}");
					response.Result = _xml271Processor.DeserializeXml(response.ResponseXml);

					response.Result.DateOfService = response.DateOfService;
					response.Result.ServiceType = response.ServiceType;

					_repository.PopulateResponseInfo(response);
				}
				catch (Xml271ProcessorException ex)
				{
					_logger.LogError(ex, _contextAccessor?.HttpContext, "Error deserializing Xml Response");

					if (!response.Errors.Any())
						response.Errors = GetDefaultError();
				}
			}

			return new ProcessInquiryResult(info)
			{
				ProcessStart = processStart,
				TotalServiceTime = totalServiceTime,
				InquiryEDI = response.InquiryEDI,
				ErrorCode = response.Errors.FirstOrDefault()?.Code ?? string.Empty
			};
		}

		private void AddMiscInfoNodesToXml(SubmitInquiryRequest request, Models.Data.Common.ServiceType[] serviceTypes)
		{
			if (!(request?.Request?.Responses?.IsNullOrEmpty() ?? true))
			{
				foreach (var response in request.Request.Responses)
				{
					if (response.Result != null)
					{
						response.Result.Miscellaneous = _repository.GenerateMiscellaneous(request.Request, response, serviceTypes);

						var wrapper = new MiscWrapper(response.Result.Miscellaneous);

						var index = response.ResponseXml.LastIndexOf("<");
						response.ResponseXml = response.ResponseXml.Substring(0, index) + wrapper.ToXml() + response.ResponseXml.Substring(index);

					}
				}
			}
		}

		private static readonly XNamespace xmlNS2 = "http://EDI/Transaction";

		// This needs to always return a new List with a new Error object in it,
		//  otherwise Entity Framework sets it's ErrorId and subsequent use fails.
		private static List<Error> GetDefaultError()
		{
			return new List<Error>() {
				new Error()
				{
					Code = ErrorCodes.AAA_42,
					Message = ErrorCodes.GetErrorName(ErrorCodes.AAA_42)
				}
			};
		}

		private static List<Error> GetErrorMessages(string ediResponse)
		{
			if (string.IsNullOrWhiteSpace(ediResponse))
				return GetDefaultError();

			var xdoc = XDocument.Parse(ediResponse);

			var retVal = (from item in xdoc.Descendants()
										where item.Name.LocalName.Contains("AAA03")
										select new Error()
										{
											Code = item.Value,
											Message = ErrorCodes.GetErrorName(item.Value)
										}).ToList();

			if (retVal.Count != 0)
				return retVal;

			return xdoc.Descendants(xmlNS2 + "BHT").Any() ? new List<Error>() : GetDefaultError();
		}

		private InquiryRequest CreateInquiryRequest(Inquiry inquiry, WebUser user)
		{
			if (inquiry.Violations.Any())
				return null;

			var request = new InquiryRequest()
			{
				DateOfService = inquiry.DateOfService,
				InquiryType = inquiry.InquiryType,
				InsertDate = DateTime.Now,
				UserId = user.UserId,
				OrgId = user.OrgId,
				DateOfBirth = inquiry.Patient.DateOfBirth,
				FirstName = inquiry.Patient.FirstName,
				LastName = inquiry.Patient.LastName,
				Gender = inquiry.Patient.Gender,
				IsDependent = inquiry.IsDependent,
				ProviderId = inquiry.ProviderId,
				SubscriberId = inquiry.SubscriberId,
				Lob = inquiry.Lob,
				SubscriberFirstName = inquiry.Subscriber.FirstName,
				SubscriberLastName = inquiry.Subscriber.LastName,
				InpatientStatus = inquiry.InpatientStatus,
				InpatientDiagnosisCode = inquiry.InpatientDiagnosisCode,
				InpatientProviderFirstName = inquiry.InpatientProviderFirstName,
				InpatientProviderLastName = inquiry.InpatientProviderLastName,
				InpatientNPI = inquiry.InpatientNPI,
				InpatientTaxId = inquiry.InpatientTaxId,
				ValuesEntered = inquiry.ValuesEntered
			};

			request.Responses = (
				from serviceType in inquiry.ServiceTypes
				select new InquiryResponse()
				{
					Request = request,
					ServiceType = serviceType,
					DateOfService = inquiry.DateOfService,
					ControlNumber = GenerateControlNumber()
				}).ToList();

			request.Responses.ForEach(GenerateEDI, request);

			return request;
		}

		private IEnumerable<string> GetErrorMessages(IEnumerable<InvalidModelExceptionDetail> violations)
		{
			return (
				from violation in violations
				select $"Invalid value for '{violation.PropertyName}': {violation.Message}");
		}

		private void GenerateEDI(InquiryResponse response, InquiryRequest request)
		{
			response.InquiryEDI = request.IsDependent ?
				GenerateDependentEDI(request, response.ServiceType) :
				GenerateSubscriberEDI(request, response.ServiceType);
		}

		private const string GsDateFormat = "yyyyMMdd";
		private const string IsaDateFormat = "yyMMdd";
		private const string IsaTimeFormat = "HHmm";

		private class EDIInfo
		{
			public EDIInfo(string providerId)
			{
				DateTime now = DateTime.Now;

				GsDate = now.ToString(GsDateFormat);
				IsaDate = now.ToString(IsaDateFormat);
				IsaTime = now.ToString(IsaTimeFormat);
				ProviderIdQualifier = (providerId.StartsWith("P") ? "SV" : "XX");
			}

			public string GsDate { get; }
			public string IsaDate { get; }
			public string IsaTime { get; }
			public string ProviderIdQualifier { get; }
		}

		private static Random rnd = new Random();
		private static int GenerateControlNumber()
		{
			return rnd.Next(100000000, 1000000000);
		}
		#endregion

		public async Task DeleteInquiriesAsync(IEnumerable<long> requestIds)
		{
			await _repository.DeleteEligibilityInquiriesAsync(requestIds);
		}

		#region Save Eligibility Requests
		public async Task<SaveInquiriesResponse> SaveInquiriesAsync(SaveInquiriesRequest request)
		{
			try
			{
				await _repository.SaveEligibilityInquiriesAsync(request.Requests.ToArray());

				var requestIds = (
					from r in request.Requests
					select r.RequestId).ToArray();

				return new SaveInquiriesResponse()
				{
					RequestIds = requestIds
				};
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, _contextAccessor?.HttpContext, "Error Saving E&B Results");

				var sb = new StringBuilder();
				var err = ex;
				while (err != null)
				{
					sb.AppendLine(err.GetType().FullName);
					sb.AppendLine(err.Message);
					err = err.InnerException;
				}

				sb.AppendLine(ex.StackTrace);

				return new SaveInquiriesResponse()
				{
					Failure = true,
					ErrorMessage = sb.ToString()
				};
			}
		}
		#endregion

		#region Get Inquiry Request
		public async Task<InquiryRequest> GetInquiryRequestAsync(long requestId)
		{
			return await _repository.GetInquiryRequestAsync(requestId);
		}
		#endregion

		public async Task<EligibilityResultsResponse> GetEligibilityResultsAsync(EligibilityResultsRequest request)
		{
			request.Validate();

			var serviceTypes = _providerRepository.GetServiceTypes();

			return new EligibilityResultsResponse()
			{
				Requests = await _repository.GetEligibilityRequestsAsync(request.OrgId, request.Days, serviceTypes)
			};
		}

		public IsValidGroupNumberResponse IsValidGroupNumber(string groupNum)
		{
			var groupNumberInfo = _repository.IsValidGroupNumber(groupNum);

			if (groupNumberInfo == null)
			{
				return new IsValidGroupNumberResponse()
				{
					GroupNumber = new GroupNumberInfo()
					{
						IsCHSGroup = false,
						IsError = true,
						Url = "",
						GroupName = "",
						Message = "Group number not found. Please try again."
					}
				};
			}
			else
			{
				groupNumberInfo.IsCHSGroup = true;
				groupNumberInfo.Message = (string.IsNullOrWhiteSpace(groupNumberInfo.Url)) ? "The group number you entered does not have a website. Please contact your TPA directly." : "";

				return new IsValidGroupNumberResponse()
				{
					GroupNumber = groupNumberInfo
				};
			}
		}

		public Select2Response GetDiagnosisCodes(Select2Request request)
		{
			request.ValidateRequest();

			var codes = _repository.GetDiagnosisCodes(request.Query, request.PageSize, request.PageNumber, out var totalCount);

			return new Select2Response()
			{
				Results = (
				 from code in codes
				 select new Select2Item()
				 {
					 Id = code.Code,
					 Text = $"{code.Code} {code.Description}"
				 }),
				TotalCount = totalCount
			};
		}

		public Task<string> ConvertEdiToXml(string content) =>
			TransformEdiToXmlAsync(content);

		public async Task<InquiryResult> ConvertEdiOrXmlToJson(string content)
		{
			const string serviceNs3 = "http://azblue.com/services/internet/271ServiceResponse";
			const string testNs3 = "http://azblue.com/services/internet/271TestServiceResponse";

			var xml = content.StartsWith('<') ? content : (await TransformEdiToXmlAsync(content));

			if (string.IsNullOrWhiteSpace(xml))
				throw new ArgumentException("The posted EDI text did not produce a valid Xml Document.", nameof(content));

			return _xml271Processor.DeserializeXml(xml.Replace(testNs3, serviceNs3));
		}

		public async Task<EligibilityResultListResponse> GetEligibilityResultsListAsync(int[] requestIds)
		{
			var result = await _repository.GetEligibilityResultsAsync(requestIds.Select(idArray => (long)idArray).ToArray());
			return new EligibilityResultListResponse { Response = result };
		}

	}
}
