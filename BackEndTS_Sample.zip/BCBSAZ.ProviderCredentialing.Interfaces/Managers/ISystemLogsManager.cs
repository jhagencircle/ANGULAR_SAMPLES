﻿using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.Models.Data.Common;
using BCBSAZ.ProviderCredentialing.Models.Requests.Logger;

namespace BCBSAZ.ProviderCredentialing.Interfaces.Managers
{
	public interface ISystemLogsManager
	{
		VoidResult InsertLogMessage(InsertLogMessageRequest request);
	}
}
