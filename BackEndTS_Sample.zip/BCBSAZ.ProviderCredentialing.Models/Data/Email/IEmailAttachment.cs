﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Email
{
	public interface IEmailAttachment
	{
		byte[] Contents { get; set; }

		string FileName { get; set; }

		string ContentType { get; set; }
	}
}
