import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ISummary } from 'src/app/shared/models/summary.model';
import { AccountService } from 'src/app/shared/services/account.service';
import { BankAccountService } from '../../bank-account/shared/bank-account.service';
import { Subject, Subscription } from 'rxjs';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { PaymentSectionEnum } from 'src/app/shared/enums/payment-section-enum';
import { BillService } from 'src/app/shared/services/bill.service';
import { SpinnerService } from '../../shared/components/spinner/spinner.service';
import { AccountLevelEnum } from 'src/app/shared/enums/account-level-enum';

@Component({
  selector: 'app-make-payment-sub-account',
  templateUrl: './make-payment-sub-account.component.html',
  styleUrls: ['./make-payment-sub-account.component.scss'],
})
export class MakePaymentSubAccountComponent implements OnInit, OnDestroy {
  subAccountSummaryList: ISummary[];
  subaccounts: any[] = [];
  bankAccounts: any;
  account: ISummary;
  submitted: boolean;
  sendPaymentForm: Subject<void> = new Subject<void>();
  subAccountPayment: any = [];
  subscriptions: Subscription[] = [];
  showSubaccountList: boolean = false;
  accountLevelEnum = AccountLevelEnum;
  subAccountSummaryLevel: string;
  minDate: Date;
  maxDate: Date;
  futureDate: Date;

  constructor(
    private router: Router,
    private bankAccountService: BankAccountService,
    private accountService: AccountService,
    private billService: BillService,
    private spinnerService: SpinnerService
  ) {
    this.minDate = new Date();
    this.futureDate = new Date();
    this.futureDate.setDate(
      this.futureDate.getDate() +
        AppConstants.ADD_DAYS_MAX_PAYMENT_DATE_SMALL_ACCOUNT
    );
    this.maxDate = this.futureDate;

    let subAcountsJson: string | null = localStorage.getItem(
      AppConstants.PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY
    );
    this.spinnerService.show(true);
    let accountSubs = this.accountService
      .get()
      .subscribe((account: ISummary) => {
        if (account) {
          this.account = account;
          if (this.account.asc) {
            console.log('Main Account');
            console.log(this.account);
            this.futureDate = new Date();
            this.futureDate.setDate(
              this.futureDate.getDate() +
                AppConstants.ADD_DAYS_MAX_PAYMENT_DATE_LARGE_ACCOUNT
            );
            this.maxDate = this.futureDate;
          }
        }
      });

    let bankAccountSubs = this.bankAccountService
      .get(this.account.accountId)
      .subscribe((data) => {
        this.bankAccounts = data;
      });

    if (subAcountsJson !== null) {
      this.subaccounts = JSON.parse(subAcountsJson);
      this.spinnerService.show(false);
    } else {
      this.billService.get(this.account.accountId).subscribe((data) => {
        this.account = data.accountSummary!;
        this.showSubaccountList = true;
        let subAccountSummaryData = data.subAccountSummary!.map((d) => ({
          isSubSubAccountsDisplayed: false,
          isChecked: false,
          ...d,
        }));

        this.subAccountSummaryLevel =
          this.account.billingLevel == AccountLevelEnum.TopAccount
            ? AccountLevelEnum.SubAccount
            : this.account.billingLevel;

        if (this.subAccountSummaryLevel == AccountLevelEnum.SubAccount) {
          let subAccounts = subAccountSummaryData.filter(
            (s) => s.accountId.split('-').length == 2
          );
          subAccounts.forEach((s) => {
            let subSubAccounts = subAccountSummaryData.filter((ssa) => {
              let idParts = ssa.accountId.split('-');
              let idSize = idParts.length;
              if (idSize == 3 && idParts[0] + '-' + idParts[1] == s.accountId) {
                return true;
              } else {
                return false;
              }
            });

            if (subSubAccounts) {
              s.subSubAccounts = subSubAccounts;
            }
          });
          this.subAccountSummaryList = subAccounts;
        } else {
          let subSubAccountList = subAccountSummaryData.filter(
            (s) => s.accountId.split('-').length == 3
          );

          this.subAccountSummaryList = subSubAccountList;
        }
        this.spinnerService.show(false);
      });
    }

    this.subscriptions.push(accountSubs);
    this.subscriptions.push(bankAccountSubs);
  }

  ngOnInit(): void {}

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  onFormSubmit(paymentForm: any) {
    if (!paymentForm.hasError) {
      let currentAccount = this.subaccounts.find(
        (element: any) => element.accountId === paymentForm.accountId
      );
      currentAccount = { ...currentAccount, payment: paymentForm };
      this.subAccountPayment.push(currentAccount);
      if (this.subaccounts.length === this.subAccountPayment.length) {
        this.goToReview();
      }
    } else {
      this.subAccountPayment = [];
    }
  }

  cancel() {
    localStorage.removeItem(AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY);
    this.router.navigate(['/landing-page']);
  }

  onSubmit() {
    if (
      localStorage.getItem(
        AppConstants.PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY
      ) === null
    ) {
      localStorage.setItem(
        AppConstants.PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY,
        JSON.stringify(
          this.subaccounts.sort(function (a: any, b: any) {
            if (a.billId < b.billId) return -1;
            else return 1;
          })
        )
      );
      window.location.reload();
    } else {
      this.sendPaymentForm.next();
    }
  }

  goToReview() {
    localStorage.setItem(
      AppConstants.PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY,
      JSON.stringify(this.subAccountPayment)
    );
    let currentSection = localStorage.getItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );
    localStorage.setItem(
      AppConstants.PREVIOUS_PAYMENT_SECTION_LOCAL_STORAGE_KEY,
      currentSection ?? PaymentSectionEnum.Account
    );
    localStorage.setItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
      PaymentSectionEnum.Review
    );
    window.location.reload();
  }

  onSelect(account: any) {
    if (!account.isChecked) {
      this.subaccounts.push(account);
    } else {
      let removeIndex = this.subaccounts
        .map((item: any) => item['accountId'])
        .indexOf(account.accountId);
      this.subaccounts.splice(removeIndex, 1);
    }
  }
}
