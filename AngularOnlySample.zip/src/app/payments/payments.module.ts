import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaymentsRoutingModule } from './payments-routing.module';
import { NavigationComponent } from './navigation/navigation.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PaymentsComponent } from './payments.component';
import { RouterModule } from '@angular/router';
import { MakePaymentComponent } from './make-payment/make-payment.component';
import { PaymentActivityComponent } from './payment-activity/payment-activity.component';
import { ManageBankAccountsComponent } from './manage-bank-accounts/manage-bank-accounts.component';
import { ClaimsInvoicePaymentComponent } from './claims-invoice-payment/claims-invoice-payment.component';
import { BankAccountModule } from '../bank-account/bank-account.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MakePaymentAccountComponent } from './make-payment-account/make-payment-account.component';
import { MakePaymentSubAccountComponent } from './make-payment-sub-account/make-payment-sub-account.component';
import { MakePaymentSubAccountSummaryComponent } from './make-payment-sub-account-summary/make-payment-sub-account-summary.component';
import { ReviewPaymentComponent } from './review-payment/review-payment.component';
import { ReviewPaymentSummaryComponent } from './review-payment-summary/review-payment-summary.component';
import { SpinnerModule } from '../shared/components/spinner/spinner.module';
import { PaymentConfirmationComponent } from './payment-confirmation/payment-confirmation.component';
import { PaymentConfirmationAccountComponent } from './payment-confirmation-account/payment-confirmation-account.component';
import { PaymentConfirmationSubAccountComponent } from './payment-confirmation-sub-account/payment-confirmation-sub-account.component';
import { NgxPrintModule } from 'ngx-print';
import { ClaimsInvoicePaymentAddComponent } from './claims-invoice-payment-add/claims-invoice-payment-add.component';
import { ManageAutopayComponent } from './manage-autopay/manage-autopay.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { TooltipModule, TooltipOptions } from 'ng2-tooltip-directive';
import { TooltipDefaultOptions } from '../shared/providers/tooltipDefaultOptions';
import { AutopayModule } from '../autopay/autopay.module';
import { PaymentConfirmationClaimsInvoiceComponent } from './payment-confirmation-claims-invoice/payment-confirmation-claims-invoice.component';
import { AlertModule } from '../shared/components/alert/alert.module';
import { AngularMaterialModule } from '../shared/modules/angular-material.module';
import { AutopayCardComponent } from './autopay-card/autopay-card.component';
import { BankAccountCardComponent } from './bank-account-card/bank-account-card.component';
import { ScheduledPaymentEditComponent } from './scheduled-payment-edit/scheduled-payment-edit.component';
import { ScheduledPaymentListComponent } from './scheduled-payment-list/scheduled-payment-list.component';
import { ValidationDirectivesModule } from '../shared/modules/validation-directives.Module';
import { SortableDirectiveModule } from '../shared/modules/sortable-directive.module';
import { NotificationComponent } from '../shared/components/notification/notification.component';

@NgModule({
  declarations: [
    NavigationComponent,
    PaymentsComponent,
    MakePaymentComponent,
    PaymentActivityComponent,
    ManageBankAccountsComponent,
    ClaimsInvoicePaymentComponent,
    MakePaymentAccountComponent,
    MakePaymentSubAccountComponent,
    MakePaymentSubAccountSummaryComponent,
    PaymentConfirmationComponent,
    PaymentConfirmationAccountComponent,
    PaymentConfirmationSubAccountComponent,
    ReviewPaymentComponent,
    ReviewPaymentSummaryComponent,
    ClaimsInvoicePaymentAddComponent,
    ManageAutopayComponent,
    PaymentConfirmationClaimsInvoiceComponent,
    AutopayCardComponent,
    BankAccountCardComponent,
    ScheduledPaymentEditComponent,
    ScheduledPaymentListComponent,
    NotificationComponent,
  ],
  imports: [
    CommonModule,
    PaymentsRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild([]),
    BankAccountModule,
    SpinnerModule,
    NgxPrintModule,
    NgSelectModule,
    TooltipModule.forRoot(TooltipDefaultOptions as TooltipOptions),
    AutopayModule,
    AlertModule,
    AngularMaterialModule,
    ValidationDirectivesModule,
    SortableDirectiveModule,
  ],
  providers: [NgxPrintModule],
})
export class PaymentsModule {}
