import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/internal/Observable';
import { SortableDirective, SortEvent } from 'src/app/common/directives/sortable.directive';
import { IFinancialManagerUser } from 'src/app/models/financial-manager-user/financial-manager-user.interface';
import { FinancialManagerUserService } from 'src/app/services/financial-manager-user.service';
import { FinancialManagerUserDeleteConfirmationComponent } from './financial-manager-user-delete-confirmation/financial-manager-user-delete-confirmation.component';

@Component({
  selector: 'app-financial-manager-user',
  templateUrl: './financial-manager-user.component.html',
  styleUrls: ['./financial-manager-user.component.scss']
})
export class FinancialManagerUserComponent implements OnInit {

  financialManagerUsers$!: Observable<IFinancialManagerUser[]>;
  total$!: Observable<number>;

  @ViewChildren(SortableDirective) headers!: QueryList<SortableDirective>;

  constructor(public financialManagerUserService: FinancialManagerUserService, private modalService: NgbModal) { }

  ngOnInit(): void {
    this.financialManagerUsers$ = this.financialManagerUserService.users$;
    this.total$ = this.financialManagerUserService.total$;
  }

  onSort({column, direction}: any): void {
    // resetting other headers
    this.headers.forEach(header => {
      if (header.appSortable !== column) {
        header.direction = '';
      }
    });

    this.financialManagerUserService.sortColumn = column;
    this.financialManagerUserService.sortDirection = direction;
  }

  deleteUser(user: IFinancialManagerUser): void {
    const modalRef = this.modalService.open(FinancialManagerUserDeleteConfirmationComponent);
    modalRef.componentInstance.userId = user.userId;

    // Result = true when delete request succeeded
    // Result = false when delete request failed
    // Result = null when delete cancelled
    modalRef.result.then((result?: boolean) => {
      if (result != null) {
        if (result) {
          this.financialManagerUserService.deleteUser(user).subscribe(() => {
            this.financialManagerUserService.refreshResearchResult();
          });
        }
        else {
          // Throw error message
          // this.popupNotificationService.pushErrorMessage(this.genericDeletePaymentProfileErrorMessage, false);
        }
      }
    });
  }

  editUser(user: IFinancialManagerUser): void {
  }
}
