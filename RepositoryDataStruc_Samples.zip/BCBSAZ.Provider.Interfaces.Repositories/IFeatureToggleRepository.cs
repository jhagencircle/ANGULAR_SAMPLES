﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.FeatureToggles;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IFeatureToggleRepository
	{
		FeatureToggle[] GetFeatureToggles(string applicationName, string environmentName);
	}
}
