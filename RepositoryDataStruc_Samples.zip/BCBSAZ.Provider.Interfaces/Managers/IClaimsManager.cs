﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Claims;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Requests.Claims;
using BCBSAZ.Provider.Models.Requests.ClaimsDetails;
using BCBSAZ.Provider.Models.Responses.ClaimDetails;
using BCBSAZ.Provider.Models.Responses.Claims;
using BCBSAZ.Provider.Models.Responses.Claims.Test;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IClaimsManager
	{
		Task<ClaimsInquiryResponse> SaveClaimsInquiryAsync(ClaimsInquiryRequest request, WebUser webUser);

		Task<TestResponse> TestClaimsApiResponseAsync(ClaimsInquiryRequest request);

		Task<ClaimsInquiryResponse> SubmitClaimsInquiryAsync(ClaimsInquiryRequest request, WebUser webUser);

		Task<GetClaimResponse> GetClaimAsync(GetClaimRequest request, WebUser user);

		ClaimStatusMessagesResponse GetClaimStatusMessages(ClaimStatusMessagesRequest request);

		ClaimStatusCodesResponse GetClaimStatusCodes(ClaimStatusCodesRequest request);

		Task<ClaimDetailsHeaderResponse> GetClaimDetailsHeader(ClaimDetailsHeaderRequest request, WebUser user);

		Task<ClaimsHistoryResponse> GetClaimsHistoryResultsAsync(WebUser webUser);
	}
}
