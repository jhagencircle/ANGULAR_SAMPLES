import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BankAccountEditComponent } from './bank-account-edit.component';
import { AccountNumberMaskPipe } from '../shared/account-number-mask.pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BankAccountService } from '../shared/bank-account.service';
import { BankAccount } from '../shared/bank-account.model';
import { BankAccountMock } from 'src/app/shared/mocks/bank-account.mock';

describe('BankAccountEditComponent', () => {
  let component: BankAccountEditComponent;
  let fixture: ComponentFixture<BankAccountEditComponent>;
  let mockBankAccountModel: BankAccountMock = new BankAccountMock();
  let bankAccounts: BankAccount[];
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, ReactiveFormsModule, FormsModule],
      declarations: [BankAccountEditComponent, AccountNumberMaskPipe],
      providers: [
        { provide: BankAccountService, useValue: mockBankAccountModel },
        AccountNumberMaskPipe,
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BankAccountEditComponent);
    component = fixture.componentInstance;

    mockBankAccountModel
      .get()
      .subscribe((data) => (component.bankAccount = data[0]));

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get form data', () => {
    expect(component.form.value).not.toBeNull();
  });

  it('should bankAccount name be equal to bankName', () => {
    expect(component.bankAccount.name).toEqual(component.form.value.bankName);
  });

  it('should get form data', () => {
    expect(component.form.valid).toBeTruthy();
  });

  it('should save form', () => {
    component.save();
    expect(component.bankAccount.isEdit).toBeFalsy;
  });
});
