﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface ISamlApiClient
	{
		/// <summary>
		/// Posts the specifed data nd retrieves the content provided by the Evicore Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Evicore Api method</typeparam>
		/// <param name="requestUri">The url route for the Evicore Api method (including all route/query-string parameters)</param>
		/// <param name="data">The data to be posted to the Api method.</param>
		/// <returns>Returns the deserialized (TResult) response from the Evicore Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Evicore Api response.
		/// </remarks>
		[SuppressMessage("Design", "CA1054:Uri parameters should not be strings", Justification = "Expected Url is partial and therefore not a valid Uri.")]
		Task<TResult> PostAsync<TResult>(string requestUri, object data) where TResult : class;
	}
}
