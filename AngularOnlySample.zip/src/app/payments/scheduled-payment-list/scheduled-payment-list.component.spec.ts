import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AccountMock } from 'src/app/shared/mocks/account.mock';
import { PaymentServiceMock } from 'src/app/shared/mocks/payment.service.mock';
import { AccountService } from 'src/app/shared/services/account.service';
import { PaymentsService } from '../shared/payments.service';
import { ConfirmationDialogService } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.service';
import { ScheduledPaymentListComponent } from './scheduled-payment-list.component';

describe('ScheduledPaymentListComponent', () => {
  let component: ScheduledPaymentListComponent;
  let fixture: ComponentFixture<ScheduledPaymentListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [ScheduledPaymentListComponent],
      providers: [
        ConfirmationDialogService,
        { provide: PaymentsService, useClass: PaymentServiceMock },
        { provide: AccountService, useClass: AccountMock },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduledPaymentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the title "Scheduled Payments"', () => {
    expect(
      fixture.nativeElement.querySelector('#lbl_scheduledPayment').textContent
    ).toContain('Scheduled Payments');
  });

  it('should make a call to accountService.get()', () => {
    spyOn(component.accountService, 'get').and.callThrough();

    component.loadScheduledPayments();
    expect(component.accountService.get).toHaveBeenCalled();
  });

  it('should have "scheduledPayments" populated ', () => {
    expect(component.scheduledPayments.length).toBeGreaterThan(0);
    expect(component.scheduledPayments).toEqual(
      PaymentServiceMock.mockedScheduledPayments
    );
  });

  it('should display Scheduled Payments table', () => {
    const element = fixture.debugElement.nativeElement.querySelector(
      '#scheduled-payment-table'
    );
    expect(element).toBeTruthy();
  });

  it('should check Scheduled Payments table headers', () => {
    expect(
      fixture.nativeElement.querySelector('#th_paymentDate').textContent
    ).toContain('Payment Date');
    expect(
      fixture.nativeElement.querySelector('#th_payToAccount').textContent
    ).toContain('Pay-to Account');
    expect(
      fixture.nativeElement.querySelector('#th_bankAccount').textContent
    ).toContain('Bank Account');
    expect(
      fixture.nativeElement.querySelector('#th_statusName').textContent
    ).toContain('Status');
    expect(
      fixture.nativeElement.querySelector('#th_paymentAmt').textContent
    ).toContain('Payment Amt');
  });

  it('should check table row is populated with data', () => {
    let trs = fixture.nativeElement.querySelectorAll('tbody tr');
    let row1 = trs[0];
    expect(row1.cells[0].innerHTML).toBe('Jul 10, 2021');
    expect(row1.cells[1].innerHTML).toBe('Account A');
    expect(row1.cells[2].innerHTML).toBe('WF');
    expect(row1.cells[3].innerHTML).toBe('Scheduled');
    expect(row1.cells[4].innerHTML).toBe('$77.00');
  });

  it('should display the informative message "Payments can be edited or deleted any time before 8:00 p.m. (MST) the day before the scheduled payment date."', () => {
    expect(
      fixture.nativeElement.querySelector('#lbl_scheduledPaymentsNote')
        .textContent
    ).toContain(
      'Payments can be edited or deleted any time before 8:00 p.m. (MST) the day before the scheduled payment date.'
    );
  });
});
