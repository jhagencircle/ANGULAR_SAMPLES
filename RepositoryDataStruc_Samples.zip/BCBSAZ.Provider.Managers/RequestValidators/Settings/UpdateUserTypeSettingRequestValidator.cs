﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Settings;

namespace BCBSAZ.Provider.Managers.RequestValidators.Settings
{
	internal static class UpdateUserTypeSettingRequestValidator
	{
		public static void Validate(this UpdateUserTypeSettingRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(UpdateUserTypeSettingRequest request)
		{
			if (request.UserTypeSetting == null)
				yield return new InvalidModelExceptionDetail(nameof(UpdateUserTypeSettingRequest.UserTypeSetting), new ArgumentException("Setting is missing."));

			if (request.UserTypeSetting.UserTypeSettingId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(UpdateUserTypeSettingRequest.UserTypeSetting.UserTypeSettingId), new ArgumentException("Invalid UserTypeSettingId specified."));

			if (request.UserTypeSetting.SettingId == 0)
				yield return new InvalidModelExceptionDetail(nameof(UpdateUserTypeSettingRequest.UserTypeSetting.SettingId), new ArgumentException("Invalid SettingId specified; non-zero parent SettingId expected."));

			var context = new ValidationContext(request.UserTypeSetting);
			var results = new List<ValidationResult>();

			if (!Validator.TryValidateObject(request.UserTypeSetting, context, results))
			{
				foreach (var result in results)
				{
					yield return new InvalidModelExceptionDetail(result.MemberNames.FirstOrDefault() ?? nameof(UpdateUserTypeSettingRequest.UserTypeSetting), new ArgumentException(result.ErrorMessage));
				}
			}
		}
	}
}
