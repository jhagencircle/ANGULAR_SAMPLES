﻿using BCBSAZ.ProviderCredentialing.Models.Responses;
using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.ApiClients;
using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.Services;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Requests;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebUI.Services
{
	public class ApplicationService : IApplicationService
	{
		private readonly IWebApiClient _webApiClient;

		public ApplicationService(IWebApiClient webApiClient) =>
			_webApiClient = webApiClient;

		public Task<SubmitApplicationResponse> SubmitApplicationAsync(ProviderCredentialForm form, IEnumerable<FileAttachment> attachments)
		{
			var request = new SubmitApplicationRequest()
			{
				Form = form,
				Attachments = attachments
			};

			return _webApiClient.PostAsync<SubmitApplicationResponse>(Constants.WebApiUrls.Application.Submit, request);
		}
	}
}
