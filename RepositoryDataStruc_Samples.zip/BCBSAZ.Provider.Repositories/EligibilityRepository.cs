﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.Eligibility;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Data.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Exceptions;
using BCBSAZ.Provider.Models.Xml271Processor;
using BCBSAZ.Provider.Models.Xml271Processor.Codes;
using BCBSAZ.Provider.Models.Xml271Processor.Interfaces;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace BCBSAZ.Provider.Repositories
{
	public class EligibilityRepository : IEligibilityRepository
	{
		private readonly IEligibilityContext _eligibilityContext;
		private readonly IProviderInetContext _providerInetContext;
		private readonly IPatientsContext _patientsContext;
		private readonly IMemoryCache _memoryCache;
		private readonly IContractIssuanceContext _contractIssuanceContext;
		private readonly IGroup2Context _group2Context;
		private readonly IBcbsazSqlContext _bcbsazSqlContext;
		private readonly IClearingHouseContext _clearingHouseContext;
		private readonly ICodesContext _codesContext;
		private readonly ICommonRepository _commonRepository;
		private readonly ILogger _logger;

		public EligibilityRepository(IEligibilityContext eligibilityContext, IProviderInetContext providerInetContext, IPatientsContext patientsContext, IMemoryCache memoryCache, IContractIssuanceContext contractIssuanceContext,
			IGroup2Context group2Context, IBcbsazSqlContext bcbsazSqlContext, IClearingHouseContext clearingHouseContext, ICodesContext codesContext, ICommonRepository commonRepository, ILogger<EligibilityRepository> logger)
		{
			_eligibilityContext = eligibilityContext;
			_providerInetContext = providerInetContext;
			_patientsContext = patientsContext;
			_memoryCache = memoryCache;
			_contractIssuanceContext = contractIssuanceContext;
			_group2Context = group2Context;
			_bcbsazSqlContext = bcbsazSqlContext;
			_clearingHouseContext = clearingHouseContext;
			_codesContext = codesContext;
			_commonRepository = commonRepository;
			_logger = logger;
		}

		#region Eligibility Inquiry Detail methods (LINQ queries)
		public async Task<IEnumerable<CoordinationOfBenefits>> GetCOBsAsync(long responseId)
		{
			var inquiry = await GetEligibilityInquiryAsync(responseId);
			var entity = inquiry.GetInsuredEntity();

			if (entity == null) return Enumerable.Empty<CoordinationOfBenefits>();

			return (
				from benefit in entity.EligibilityBenefits
				where
					BenefitInfoTypes.Other_or_Additional_Payor.Equals(benefit.BenefitInformation?.EligibilityOrBenefitInformation, StringComparison.OrdinalIgnoreCase) &&
					!(benefit.BenefitRelatedEntity?.Records).IsNullOrEmpty()
				from r in benefit.BenefitRelatedEntity.Records
				where !r.Name.EntityCode.Equals(NameTypes.Insured_or_Subscriber, StringComparison.OrdinalIgnoreCase)
				select new CoordinationOfBenefits
				{
					ResponseId = responseId,
					CarrierName = ($"{r.Name.FirstName} {r.Name.LastName}").ToTitleCase().NaIfNullOrWhitespace(),
					Address = r.GetAddress(),
					PhoneNumber = r.GetPhoneNumber().ConvertToReadablePhoneNumber(),
					FirstName = benefit.GetCobFirstName(),
					LastName = benefit.GetCobLastName(),
					MemberId = benefit.GetCobMemberId(),
					VerifiedDate = benefit.GetBenefitDateWithQualifier(DateTypes.Coordination_of_Benefits)
				});
		}

		public async Task<string> GetDisclaimerAsync(long responseId)
		{
			var inquiry = await GetEligibilityInquiryAsync(responseId);
			var entity = inquiry.GetInsuredEntity();

			if (entity == null) return string.Empty;
		
			return (
				from benefit in entity.EligibilityBenefits
				where
					BenefitInfoTypes.Benefit_Disclaimer.Equals(benefit.BenefitInformation?.EligibilityOrBenefitInformation, StringComparison.OrdinalIgnoreCase) &&
					!benefit.Messages.IsNullOrEmpty()
				from message in benefit.Messages
				select message.Text).FirstOrDefault() ?? string.Empty;
		}

		public async Task<EligibilitySummary> GetEligibilitySummaryAsync(long responseId)
		{
			var inquiry = await GetEligibilityInquiryAsync(responseId);
			var entity = inquiry.GetInsuredEntity();

			if (entity == null) return new EligibilitySummary();

			return new EligibilitySummary()
			{
				ResponseId = responseId,

				PaidThrough = new NullableRange<DateTime>()
				{
					From = entity.GetDateWithQualifier(DateTypes.Premium_Paid_to_Date_Begin),
					To = entity.GetDateWithQualifier(DateTypes.Premium_Paid_to_Date_End)
				},

				GracePeriod = SelectGracePeriodQualifier(entity),

				TerminationDate = entity.GetTerminationDate(),

				PreExistingEnd = entity.EligibilityBenefits.IsNullOrEmpty() ? null : (
					from info in entity.EligibilityBenefits
					where info.BenefitInformation.EligibilityOrBenefitInformation == BenefitInfoTypes.Pre_Existing_Condition
					select info.GetBenefitDateWithQualifier(DateTypes.Completion)).FirstOrDefault(),
				PlanInfo = (
					from d in entity.Dates
					where d.Qualifier == DateTypes.Plan
					select new PlanInfo()
					{
						Name = DateTypes.I.Find(x => x.Code == d.Qualifier).Name,
						Date = DateFormats.Date_Expressed_in_Format_CCYYMMDD == d.Format ? d.Period.Parse271Date() : null,
						StartDate = DateFormats.Range_of_Dates_Expressed_in_Format_CCYYMMDDCCYYMMDD == d.Format ? d.Period.Substring(0, 8).Parse271Date() : null,
						EndDate = DateFormats.Range_of_Dates_Expressed_in_Format_CCYYMMDDCCYYMMDD == d.Format ? d.Period.Substring(9, 8).Parse271Date() : null
					}).FirstOrDefault()
			};
		}

		private static NullableRange<DateTime> SelectGracePeriodQualifier(IInsuredEntity entity)
		{
			{

				var graceDateGracQualifiers = (from d in entity.EligibilityBenefits
																	 from x in d.BenefitDates
																	 select x.Qualifier);

				var qualifierBegDate = (from d in entity.EligibilityBenefits 
																from x in d.BenefitDates where x.Qualifier.Equals(DateTypes.Period_Start)
																select x.Period);

				var qualifierEndDate = (from d in entity.EligibilityBenefits
																from x in d.BenefitDates where x.Qualifier.Equals(DateTypes.Period_End)
																select x.Period);

				var gracePeriodQualiers = new string[] { DateTypes.Period_Start, DateTypes.Period_End };
				bool hasAdditionalQualifiers = graceDateGracQualifiers.Except(gracePeriodQualiers).Any();


				if (hasAdditionalQualifiers)
					return new NullableRange<DateTime>()
					{

						From = entity.GetDateWithQualifierAndDateType(DateTypes.Period_Start, qualifierBegDate),

						To = entity.GetDateWithQualifierAndDateType(DateTypes.Period_End, qualifierEndDate),
					};
				
				return new NullableRange<DateTime>()
				{
					From = entity.EligibilityBenefits.IsNullOrEmpty() ? null : (
								from info in entity.EligibilityBenefits
								select info.GetBenefitDateWithQualifier(DateTypes.Period_Start)).FirstOrDefault(),

					To = entity.EligibilityBenefits.IsNullOrEmpty() ? null : (
								from info in entity.EligibilityBenefits
								select info.GetBenefitDateWithQualifier(DateTypes.Period_End)).FirstOrDefault()
				};
			}
		}
		public async Task<InquiryRequest> GetInquiryRequestAsync(long requestId)
		{
			return await (
				from request in _eligibilityContext.InquiryRequests
				where request.RequestId == requestId
				select request
				).FirstOrDefaultAsync();
		}

		public async Task<InquiryInfo> GetInquiryAsync(long responseId)
		{
			var inquiry = await GetEligibilityInquiryAsync(responseId);
			var entity = inquiry.GetInsuredEntity();

			if (entity == null) return new InquiryInfo();

			var memberId = inquiry.GetMemberId();
			var startDate = entity.GetEffectiveDate();
			var endDate = entity.GetTerminationDate();
			var isActive = entity.EligibilityBenefits.GetEligibilityStatus() == EligibilityStatus.Active &&
				((startDate <= DateTime.Now) && (DateTime.Now <= (endDate ?? DateTime.MaxValue)));

			return new InquiryInfo
			{
				ResponseId = responseId,
				MemberId = memberId,
				CanViewIDCard = CanViewIDCard(memberId, inquiry.DateOfService, entity.GetFirstName(), entity.GetLastName(), entity.Demographic?.BirthDate.Parse271Date(true)),
				EffectiveStartDate = startDate,
				EffectiveEndDate = endDate,
				LastName = entity.GetLastName(),
				FirstName = entity.GetFirstName(),
				IsActive = isActive,
				DateOfService = inquiry.DateOfService,
				ServiceTypes = inquiry.GetServiceTypes(),
				HasBenefits = true, // per requirements all members should at least have a benefit book
				Status = isActive ? "Active" : "Inactive"
			};
		}

		public void PopulateResponseInfo(InquiryResponse response)
		{
			if (response == null) throw new ArgumentNullException(nameof(response));
			if (response.Result == null) throw new ArgumentNullException(nameof(InquiryResponse.Result));

			var entity = response.Result.GetInsuredEntity();
			var subscriber = response.Result.GetSubscriber();

			response.SubscriberId = response.Result.GetMemberId();
			response.FirstName = entity.GetFirstName();
			response.LastName = entity.GetLastName();
			response.DateOfBirth = entity.Demographic?.BirthDate.Parse271Date(true);
			response.Gender = entity.Demographic?.Gender;
			response.SubscriberFirstName = subscriber.GetFirstName();
			response.SubscriberLastName = subscriber.GetLastName();
		}

		public async Task<InsuranceInfo> GetInsuranceInfoAsync(long responseId)
		{
			var inquiry = await GetEligibilityInquiryAsync(responseId);
			var entity = inquiry.GetInsuredEntity();
			var subscriber = inquiry.GetSubscriber();

			var alphaPrefixs = _commonRepository.GetConfigSetting("ProviderGroupPCP").Value.Split(",");

			var memberId = inquiry.GetMemberId();
			var memberAlphaPrefix = string.IsNullOrWhiteSpace(memberId) ? string.Empty : memberId.Substring(0, memberId.Length > 3 ? 3 : memberId.Length);

			var (groupId, groupName) = entity.GetGroupInformation();
			var planNumber = entity.GetPlanNumber();
			var issueNumber = entity.GetIssueNumber();

			var priorIdentifierNumber = entity.GetPriorIdentificationNumber();
			var primaryPayerInformation = entity.GetPrimaryPayerInformation();

			return new InsuranceInfo()
			{
				ResponseId = responseId,
				FirstName = subscriber.GetFirstName(),
				LastName = subscriber.GetLastName(),
				MiddleName = subscriber.GetMiddleName(),
				GroupNumber = GetGroupNumber(memberId, groupId),
				GroupName = GetGroupName(memberId, groupId) ?? groupName.ToTitleCase(),
				IssueNumber = issueNumber,
				PlanNumber = planNumber,
				PriorIdentifierNumber = priorIdentifierNumber,

				MedicalAssistanceCategory = subscriber.EligibilityBenefits.IsNullOrEmpty() ? null : (
					from subcriberInfo in subscriber.EligibilityBenefits
					where !subscriber.AdditionalIdentification.IsNullOrEmpty()
					from medAsstInfo in subcriberInfo.AdditionalIdentification
					where ReferenceTypes.Medical_Assistance_Category.Equals(medAsstInfo.ReferenceIdentificationQualifier, StringComparison.OrdinalIgnoreCase)
					select medAsstInfo.InformationReceiverAdditionalIdentifier).FirstOrDefault().NaIfNullOrWhitespace(),

				PrimaryPayerInformation = primaryPayerInformation,

				InsuranceType = entity.EligibilityBenefits.IsNullOrEmpty() ? null : (
					from benefit in entity.EligibilityBenefits
					where !string.IsNullOrWhiteSpace(benefit.BenefitInformation?.InsuranceType)
					join it in InsuranceTypes.I on benefit.BenefitInformation.InsuranceType equals it.Code
					where !BenefitInfoTypes.Other_or_Additional_Payor.Equals(benefit.BenefitInformation.EligibilityOrBenefitInformation, StringComparison.OrdinalIgnoreCase)
					select it.Name).FirstOrDefault().ToTitleCase().NaIfNullOrWhitespace(),

				ProductName = entity.EligibilityBenefits.IsNullOrEmpty() ? null : (
					from benefit in entity.EligibilityBenefits
					where
						benefit.BenefitInformation != null &&
						!BenefitInfoTypes.Other_or_Additional_Payor.Equals(benefit.BenefitInformation.EligibilityOrBenefitInformation, StringComparison.OrdinalIgnoreCase) &&
						!string.IsNullOrWhiteSpace(benefit.BenefitInformation.PlanCoverageDescription)
					select benefit.BenefitInformation.PlanCoverageDescription).FirstOrDefault().ToTitleCase().NaIfNullOrWhitespace(),

				IsHMO = !memberId.IsNullOrEmpty() && alphaPrefixs.Contains(memberAlphaPrefix)
			};
		}

		private string GetGroupName(string memberId, string number)
		{
			var groupNumber = GetGroupNumber(memberId, number);

			var response = _group2Context.GroupNames.FromSqlRaw(
					 DB.Group2.StoredProcs.GetGroupNameByGroupNumber,
					 groupNumber
			).AsEnumerable().FirstOrDefault();

			return (response?.Name).ToTitleCase().NaIfNullOrWhitespace();
		}

		private static readonly Regex FEPRegex = new Regex("^R[0-9]{8}$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

		private string GetGroupNumber(string memberId, string groupNumber)
		{
			if (string.IsNullOrWhiteSpace(groupNumber))
				return groupNumber.NaIfNullOrWhitespace();

			return FEPRegex.IsMatch(memberId) ? "FEP " + groupNumber : groupNumber;
		}

		public async Task<PatientDetail> GetPatientDetailAsync(long responseId)
		{
			var inquiry = await GetEligibilityInquiryAsync(responseId);
			var entity = inquiry.GetInsuredEntity();

			var valuesEntered = GetValuesEnteredFromRequest(await (
				from res in _eligibilityContext.InquiryResponses
				where res.ResponseId == responseId
				select res.Request).FirstOrDefaultAsync());

			var pcpToDate = entity.GetTerminationDate();
			var pcpFromDate = entity.GetEffectiveDate();

			return new PatientDetail()
			{
				ResponseId = responseId,
				FirstName = entity.GetFirstName(),
				LastName = entity.GetLastName(),
				MiddleName = entity.GetMiddleName(),
				Gender = entity.Demographic?.Gender,
				DateOfBirth = entity.Demographic?.BirthDate.Parse271Date(),
				Address = entity.GetAddress(),
				Relationship = entity.GetRelationship(),
				Pcp = entity.EligibilityBenefits?.GetPrimaryCareProvider(pcpFromDate, pcpToDate),
				MPI = GetMPI(entity),
				ValueEnteredReturned = inquiry.GetValueEnteredReturned(valuesEntered)
			};
		}

		public Miscellaneous GenerateMiscellaneous(InquiryRequest request, InquiryResponse response, Models.Data.Common.ServiceType[] serviceTypes)
		{
			const string dtFormat = "MM/dd/yyyy";

			if (response == null) return new Miscellaneous();

			var insuredEntity = response.Result.GetInsuredEntity();
			var subscriberEntity = response.Result.GetSubscriber();

			var subscriberId = subscriberEntity.GetPrimaryId();
			var insuredFirst = insuredEntity.GetFirstName();
			var insuredLast = insuredEntity.GetLastName();
			var insuredDOB = insuredEntity.Demographic?.BirthDate.Parse271Date();

			var benefitsEffective = insuredEntity.GetEffectiveDate();
			var terminationDate = insuredEntity.GetTerminationDate();
			var groupNumber = insuredEntity.AdditionalIdentification.IsNullOrEmpty() ? null : (
				from addInfo in insuredEntity.AdditionalIdentification
				where ReferenceTypes.Group_Number.Equals(addInfo.ReferenceIdentificationQualifier, StringComparison.OrdinalIgnoreCase)
				select addInfo.InformationReceiverAdditionalIdentifier
				).FirstOrDefault();

			var canViewIdCard = CanViewIDCard(subscriberId, response.DateOfService, insuredFirst, insuredLast, insuredDOB);

			var serviceType = (
				from st in serviceTypes
				where st.Code.Equals(response.ServiceType, StringComparison.OrdinalIgnoreCase)
				select st).FirstOrDefault();

			return new Miscellaneous()
			{
				DateOfService = response.DateOfService.ToString(dtFormat),
				BenefitsEffectiveDate = benefitsEffective.HasValue ? benefitsEffective.Value.ToString(dtFormat) : string.Empty,
				TerminationDate = terminationDate.HasValue ? terminationDate.Value.ToString(dtFormat) : string.Empty,
				GroupNumber = groupNumber ?? string.Empty,
				GroupName = groupNumber == null ? string.Empty : GetGroupName(subscriberId, groupNumber),
				ViewIDCard = canViewIdCard ? "Y" : "N",
				ServiceType = serviceType.Description,
				IsInPatient = serviceType.IsHospital ? "Y" : "N",
				BooksRiderLinks = GetMiscellaneousBooksAndRiders(response.Result),
				ChangedDemographicInformation = GetChangedDemographicInformation(response.Result, GetValuesEnteredFromRequest(request))
			};
		}

		private List<DemographicInformation> GetChangedDemographicInformation(InquiryResult result, ValuesEntered valuesEntered)
		{
			var valuesEnteredReturned = GetValueEnteredReturned(result, valuesEntered);

			var member = new DemographicInformation() { Type = "Member", ChangedAttributes = new List<ChangedAttribute>() };
			var patient = new DemographicInformation() { Type = "Patient", ChangedAttributes = new List<ChangedAttribute>() };

			foreach (var value in valuesEnteredReturned)
			{
				switch (value.Key.ToLowerInvariant())
				{
					case "member first name":
						member.ChangedAttributes.Add(new ChangedAttribute("First Name", value));
						break;
					case "member last name":
						member.ChangedAttributes.Add(new ChangedAttribute("Last Name", value));
						break;
					case "patient first name":
						patient.ChangedAttributes.Add(new ChangedAttribute("First Name", value));
						break;
					case "patient last name":
						patient.ChangedAttributes.Add(new ChangedAttribute("Last Name", value));
						break;
					case "patient date of birth":
						patient.ChangedAttributes.Add(new ChangedAttribute("Date of Birth", value));
						break;
					default:
						member.ChangedAttributes.Add(new ChangedAttribute("Member ID", value));
						break;
				}
			}

			var retVal = new List<DemographicInformation>();

			if (member.ChangedAttributes.Count != 0)
				retVal.Add(member);

			if (patient.ChangedAttributes.Count != 0)
				retVal.Add(patient);

			return retVal.Count == 0 ? null : retVal;
		}

		private BooksRiderLink GetMiscellaneousBooksAndRiders(InquiryResult result)
		{
			var booksAndRiders = GetBooksAndRiders(result);

			if (booksAndRiders.IsNullOrEmpty())
				return null;

			return new BooksRiderLink()
			{
				HasMedical = "True",
				DocumentLinks = (
					from bar in booksAndRiders
					select new DocumentLink()
					{
						DocType = bar.BenefitType,
						DocId = bar.Url
					}
				).ToList()
			};
		}

		private static ValuesEntered GetValuesEnteredFromRequest(InquiryRequest request)
		{
			if (request == null) return new ValuesEntered();

			return new ValuesEntered()
			{
				SubscriberId = string.IsNullOrWhiteSpace(request.ValuesEntered?.SubscriberId) ? request.SubscriberId : request.ValuesEntered.SubscriberId,
				SubscriberFirstName = string.IsNullOrWhiteSpace(request.ValuesEntered?.SubscriberFirstName) ? request.SubscriberFirstName : request.ValuesEntered.SubscriberFirstName,
				SubscriberLastName = string.IsNullOrWhiteSpace(request.ValuesEntered?.SubscriberLastName) ? request.SubscriberLastName : request.ValuesEntered.SubscriberLastName,
				PatientDateOfBirth = request.DateOfBirth,
				PatientFirstName = string.IsNullOrWhiteSpace(request.ValuesEntered?.PatientFirstName) ? request.FirstName : request.ValuesEntered.PatientFirstName,
				PatientLastName = string.IsNullOrWhiteSpace(request.ValuesEntered?.PatientLastName) ? request.LastName : request.ValuesEntered.PatientLastName
			};
		}

		private MilitaryPersonnelInfo GetMPI(IInsuredEntity entity)
		{
			if ((entity.MilitaryPersonnel != null) &&
				(
					(!string.IsNullOrWhiteSpace(entity.MilitaryPersonnel.Status)) ||
					(!string.IsNullOrWhiteSpace(entity.MilitaryPersonnel.EmploymentStatus)) ||
					(!string.IsNullOrWhiteSpace(entity.MilitaryPersonnel.ServiceAffiliation)) ||
					(!string.IsNullOrWhiteSpace(entity.MilitaryPersonnel.Description)) ||
					(!string.IsNullOrWhiteSpace(entity.MilitaryPersonnel.MilitaryRank)) ||
					(!string.IsNullOrWhiteSpace(entity.MilitaryPersonnel.Period))
				))
			{

				var MPI = new MilitaryPersonnelInfo()
				{
					InformationStatus = (
						from c in InformationStatus.I
						where c.Code.Equals(entity.MilitaryPersonnel.Status, StringComparison.OrdinalIgnoreCase)
						select c.Name).FirstOrDefault().NaIfNullOrWhitespace(),

					EmploymentStatus = (
						from c in EmploymentStatus.I
						where c.Code.Equals(entity.MilitaryPersonnel.EmploymentStatus, StringComparison.OrdinalIgnoreCase)
						select c.Name).FirstOrDefault().NaIfNullOrWhitespace(),

					GovernmentAffiliatedService = (
						from c in GovernmentServiceAffiliated.I
						where c.Code.Equals(entity.MilitaryPersonnel.ServiceAffiliation, StringComparison.OrdinalIgnoreCase)
						select c.Name).FirstOrDefault().NaIfNullOrWhitespace(),

					Description = entity.MilitaryPersonnel.Description.NaIfNullOrWhitespace(),

					ServiceRank = (
						from c in ServiceRank.I
						where c.Code.Equals(entity.MilitaryPersonnel.MilitaryRank, StringComparison.OrdinalIgnoreCase)
						select c.Name).FirstOrDefault().NaIfNullOrWhitespace(),

					ServiceDate = SetMilitaryServiceDate(entity.MilitaryPersonnel.Format, entity.MilitaryPersonnel.Period)
				};
				return MPI;
			}
			return null;
		}

		private NullableRange<DateTime> SetMilitaryServiceDate(string qualifier, string period)
		{
			if (string.IsNullOrEmpty(period))
				return new NullableRange<DateTime>() { From = null, To = null };

			var serviceDate = new NullableRange<DateTime>()
			{
				From = period.Parse271Date(true),
				To = DateFormats.Range_of_Dates_Expressed_in_Format_CCYYMMDDCCYYMMDD.Equals(qualifier, StringComparison.OrdinalIgnoreCase) ? period.Parse271Date(false) : null
			};

			return serviceDate;
		}

		public async Task<Dictionary<string, Dictionary<string, IEnumerable<Cost>>>> GetDeductiblesAsync(long responseId)
		{
			var inquiry = await GetEligibilityInquiryAsync(responseId);
			var insuredEntity = inquiry.GetInsuredEntity();

			return inquiry.GetEligibilityTabs(
				getInNetworkTabs: insuredEntity.GetDeductibles,
				getTieredRegularInNetwork: insuredEntity.GetTieredRegularInNetworkDeductibles,
				getOutOfNetworkTabs: insuredEntity.GetDeductibles,
				getNetworkUnknownTabs: insuredEntity.GetDeductibles,
				getNetworkNotApplicableTabs: insuredEntity.GetDeductibles,
				getTieredRegularNotApplicable: insuredEntity.GetTieredRegularInNetworkDeductibles);
		}

		public async Task<Dictionary<string, ServiceTypeBenefitDictionary>> GetFullNetworkServiceTypeAsync(long responseId)
		{
			var inquiry = await GetEligibilityInquiryAsync(responseId);
			var entity = inquiry.GetInsuredEntity();

			var serviceTypes = (entity?.EligibilityBenefits).IsNullOrEmpty() ? Enumerable.Empty<LookupCode>() : (
				from eb in entity.EligibilityBenefits
				where !(eb.BenefitInformation?.ServiceTypeCodes).IsNullOrEmpty()
				from s in eb.BenefitInformation.ServiceTypes
				where !eb.BenefitInformation.ServiceTypeCodes.Contains(ServiceTypes.Plan_Waiting_Period)
				join st in ServiceTypes.I on s.Code equals st.Code
				select st).Distinct(new LookupCodeComparer());

			return new Dictionary<string, ServiceTypeBenefitDictionary>(
				serviceTypes.Select(st => new KeyValuePair<string, ServiceTypeBenefitDictionary>(st.Name, CreateServiceTypeBenefitDictionary(inquiry, entity, st)))
			);
		}

		private ServiceTypeBenefitDictionary CreateServiceTypeBenefitDictionary(InquiryResult inquiry, IInsuredEntity entity, LookupCode serviceTypeCode)
		{
			try
			{
				return new ServiceTypeBenefitDictionary(
					inquiry.GetEligibilityTabs(
						getOutOfNetworkTabs: entity.GetServiceTypeBenefits,
						getTieredRegularInNetwork: entity.GetTieredRegularInNetwork,
						getNetworkNotApplicableTabs: entity.GetServiceTypeBenefits,
						getInNetworkTabs: entity.GetServiceTypeBenefits,
						getNetworkUnknownTabs: entity.GetServiceTypeBenefits,
						getTieredRegularNotApplicable: entity.GetTieredRegularInNetwork,
						serviceType: serviceTypeCode.Name));
			}
			catch (Exception ex)
			{
				var message = $"Error reading information for {serviceTypeCode.Name}";
				_logger.LogError(ex, message);
				return new ServiceTypeBenefitDictionary($"{message}: {ex.Message}");
			}
		}

		public async Task<Dictionary<string, IEnumerable<GeneralInformation>>> GetGeneralInformationAsync(long responseId)
		{
			var inquiry = await GetEligibilityInquiryAsync(responseId);
			var entity = inquiry.GetInsuredEntity();

			var codesList = new Dictionary<string, IEnumerable<GeneralInformation>>();


			//CPTCodes
			var cptCodes = (
				from e in entity.EligibilityBenefits
				where
					e.BenefitInformation?.CompositMedicalProcedure != null &&
					!string.IsNullOrWhiteSpace(e.BenefitInformation.CompositMedicalProcedure.ProcedureCode) &&
					GeneralInfoCodes.Current_Procedural_Terminology_CPT_Codes.Equals(e.BenefitInformation.CompositMedicalProcedure.ServiceQualifier, StringComparison.OrdinalIgnoreCase)
				select GetGeneralInfoForMedicalProcedure(e.BenefitInformation.CompositMedicalProcedure));

			if (!cptCodes.IsNullOrEmpty())
				codesList.Add("CPT Codes", cptCodes);


			//HCPCS Codes
			var hcpcCodes = (
				from e in entity.EligibilityBenefits
				where
					e.BenefitInformation?.CompositMedicalProcedure != null &&
					!string.IsNullOrWhiteSpace(e.BenefitInformation.CompositMedicalProcedure.ProcedureCode) &&
					GeneralInfoCodes.Health_Care_Financing_Administration_Common_Procedural_Coding_System_HCPCS_Codes.Equals(e.BenefitInformation.CompositMedicalProcedure.ServiceQualifier, StringComparison.OrdinalIgnoreCase)
				select GetGeneralInfoForMedicalProcedure(e.BenefitInformation.CompositMedicalProcedure));

			if (!hcpcCodes.IsNullOrEmpty())
				codesList.Add("HCPCS Codes", hcpcCodes);


			//Diagnosis Codes
			var diagCodes = (
				from e in entity.EligibilityBenefits
				where e.BenefitInformation?.CompositDiagnosis != null
				from g in GetGeneralInfoItemsForHealthcareCode(e.BenefitInformation.CompositDiagnosis, entity.HealthcareDiagnosis.HealthcareCodes)
				select g);

			if (diagCodes.Any())
				codesList.Add("Diagnosis Codes", diagCodes);


			//Other Codes
			var otherCodes = (
				from e in entity.EligibilityBenefits
				where
					e.BenefitInformation?.CompositMedicalProcedure != null &&
					!string.IsNullOrWhiteSpace(e.BenefitInformation.CompositMedicalProcedure.ProcedureCode) &&
					!GeneralInfoCodes.Current_Procedural_Terminology_CPT_Codes.Equals(e.BenefitInformation.CompositMedicalProcedure.ServiceQualifier, StringComparison.OrdinalIgnoreCase) &&
					!GeneralInfoCodes.Health_Care_Financing_Administration_Common_Procedural_Coding_System_HCPCS_Codes.Equals(e.BenefitInformation.CompositMedicalProcedure.ServiceQualifier, StringComparison.OrdinalIgnoreCase)
				select GetGeneralInfoForMedicalProcedure(e.BenefitInformation.CompositMedicalProcedure));


			if (!otherCodes.IsNullOrEmpty())
				codesList.Add("Other Codes", otherCodes);

			return (codesList.Count != 0) ? codesList : null;
		}

		public GeneralInformation GetGeneralInfoForMedicalProcedure(CompositMedicalProcedure compositMedicalProcedure)
		{
			return new GeneralInformation()
			{
				Code = string.IsNullOrWhiteSpace(compositMedicalProcedure.ServiceId) ? compositMedicalProcedure.ProcedureCode : $"{compositMedicalProcedure.ProcedureCode}-{compositMedicalProcedure.ServiceId}",
				Description = compositMedicalProcedure.Description.NaIfNullOrWhitespace(),
				Modifiers = GetModifiers(compositMedicalProcedure)
			};
		}

		private IEnumerable<string> GetModifiers(CompositMedicalProcedure compositMedicalProcedure)
		{
			if (!string.IsNullOrWhiteSpace(compositMedicalProcedure.ProcedureModifier))
				yield return compositMedicalProcedure.ProcedureModifier.Trim();

			if (!string.IsNullOrWhiteSpace(compositMedicalProcedure.ProcedureModifier2))
				yield return compositMedicalProcedure.ProcedureModifier.Trim();

			if (!string.IsNullOrWhiteSpace(compositMedicalProcedure.ProcedureModifier3))
				yield return compositMedicalProcedure.ProcedureModifier.Trim();

			if (!string.IsNullOrWhiteSpace(compositMedicalProcedure.ProcedureModifier4))
				yield return compositMedicalProcedure.ProcedureModifier.Trim();
		}

		private IEnumerable<GeneralInformation> GetGeneralInfoItemsForHealthcareCode(CompositDiagnosis compositDiagnosis, List<HealthcareCode> healthcareCodes)
		{
			if (compositDiagnosis != null)
			{
				if (!string.IsNullOrWhiteSpace(compositDiagnosis.DiagnosisCode))
					yield return GetGeneralInfoForHealthcareCode(healthcareCodes[int.Parse(compositDiagnosis.DiagnosisCode) - 1]);

				if (!string.IsNullOrWhiteSpace(compositDiagnosis.DiagnosisCode2))
					yield return GetGeneralInfoForHealthcareCode(healthcareCodes[int.Parse(compositDiagnosis.DiagnosisCode2) - 1]);

				if (!string.IsNullOrWhiteSpace(compositDiagnosis.DiagnosisCode3))
					yield return GetGeneralInfoForHealthcareCode(healthcareCodes[int.Parse(compositDiagnosis.DiagnosisCode3) - 1]);

				if (!string.IsNullOrWhiteSpace(compositDiagnosis.DiagnosisCode4))
					yield return GetGeneralInfoForHealthcareCode(healthcareCodes[int.Parse(compositDiagnosis.DiagnosisCode4) - 1]);
			}
		}

		private GeneralInformation GetGeneralInfoForHealthcareCode(HealthcareCode hCode)
		{
			return new GeneralInformation()
			{
				Code = hCode.Diagnosis,
				Description = (
					from d in DiagnosisCodeTypes.I
					where d.Name.Equals(hCode.DiagnosisType, StringComparison.OrdinalIgnoreCase)
					select d.Code).FirstOrDefault().NaIfNullOrWhitespace()
			};
		}

		#endregion

		public async Task SaveEligibilityInquiriesAsync(params InquiryRequest[] inquiries)
		{
			var newInquiries = (
				from inquiry in inquiries
				where inquiry.RequestId <= 0
				select inquiry);

			await _eligibilityContext.InquiryRequests.AddRangeAsync(newInquiries);
			await _eligibilityContext.SaveChangesAsync();
		}

		public async Task DeleteEligibilityInquiriesAsync(IEnumerable<long> requestIds)
		{
			var requests = _eligibilityContext.InquiryRequests.Where(x => requestIds.Contains(x.RequestId));
			var responses = _eligibilityContext.InquiryResponses.Where(x => requestIds.Contains(x.RequestId));

			_eligibilityContext.InquiryResponses.RemoveRange(responses);
			_eligibilityContext.InquiryRequests.RemoveRange(requests);
			await _eligibilityContext.SaveChangesAsync();
		}


		public async Task<BooksRiders[]> GetBooksAndRidersAsync(long responseId) =>
			GetBooksAndRiders(await GetEligibilityInquiryAsync(responseId));

		public BooksRiders[] GetBooksAndRiders(InquiryResult inquiryresult)
		{
			var benefitBooks = GetBenefitDocs((inquiryresult.GetMemberId().Length == 12) ? inquiryresult.GetMemberId().Substring(3, 9) : inquiryresult.GetMemberId(), inquiryresult.DateOfService);

			return (
				from info in benefitBooks
				join br in BooksRidersTypes.I on info.Type equals br.Code
				where BooksRidersTypes.ValidBooksAndRiders.Contains(info.Type)
				select new BooksRiders()
				{
					ImageType = info.DocType,
					Name = br.Name,
					Url = info.DocID.ToString()
				}).ToArray();
		}

		public async Task<InquiryResult> GetEligibilityInquiryAsync(long responseId)
		{
			return _memoryCache == null ?
				await GetInquiryResultAsync(responseId) :
				await _memoryCache.GetOrCreateAsync(
					string.Format(Constants.CacheKeys.EligibilityInquiry, responseId),
					Constants.Cache.SlidingHalfHour(CacheItemPriority.Low), GetInquiryResultAsync, responseId);
		}

		private async Task<InquiryResult> GetInquiryResultAsync(long responseId)
		{
			var response = await (
					from r in _eligibilityContext.InquiryResponses
					where r.ResponseId == responseId
					select r).FirstOrDefaultAsync();

			if (response == null)
				throw new RecordNotFoundException("The specified Response record was not found.");

			if (string.IsNullOrWhiteSpace(response.SerializedData))
				throw new RecordNotFoundException("The specified Response record has no data.");

			return JsonConvert.DeserializeObject<InquiryResult>(response.SerializedData);
		}


		public async Task<IEnumerable<EligibilityRequest>> GetEligibilityRequestsAsync(string orgId, int days, Models.Data.Common.ServiceType[] serviceTypes)
		{
			var startDate = DateTime.Today.AddDays(0 - days);

			var requests = await (
				from req in _eligibilityContext.InquiryRequests
				where (req.InsertDate >= startDate) && req.OrgId == orgId
				select req).ToArrayAsync();

			return (
				from req in requests
				where !req.Responses.IsNullOrEmpty()
					&& req.Responses.Any(r => !string.IsNullOrWhiteSpace(r.ResponseXml))
					&& req.Responses.Any(r => !r.Errors.Any())
				orderby req.InsertDate descending
				select new EligibilityRequest()
				{
					RequestId = req.RequestId,
					InquiryDate = req.InsertDate,
					SubscriberId = req.SubscriberId,
					FirstName = req.FirstName,
					LastName = req.LastName,
					SubscriberFirstName = req.SubscriberFirstName,
					SubscriberLastName = req.SubscriberLastName,
					DateOfBirth = req.DateOfBirth,
					DateOfService = req.DateOfService,
					Responses = (
						from res in req.Responses
						where !string.IsNullOrWhiteSpace(res.ResponseXml)
						select GetEligibilityResponse(res, serviceTypes)
					)
				});
		}

		public async Task<string[]> GetEligibilityResultsAsync(long[] responseIds)
		{
			var result = await _eligibilityContext.InquiryResponses.Where(e => responseIds.Contains(e.ResponseId)).Select(s => s.ResponseXml).ToArrayAsync();
			return result;
		}

		private EligibilityResponse GetEligibilityResponse(InquiryResponse response, Models.Data.Common.ServiceType[] serviceTypes)
		{
			var insured = response.Result.GetInsuredEntity();

			var serviceType = (
				from st in serviceTypes
				where st.Code.Equals(response.ServiceType, StringComparison.OrdinalIgnoreCase)
				select st).FirstOrDefault() ?? new Models.Data.Common.ServiceType() { Code = response.ServiceType, Description = response.ServiceType };

			return new EligibilityResponse()
			{
				ResponseId = response.ResponseId,
				ServiceTypeCode = serviceType.Code,
				ServiceTypeName = serviceType.Description,
				TermDate = insured.GetTerminationDate(),
				HasEligibility = true, // per requirements all members should at least have a benefit book
			};
		}

		public bool CanViewIDCard(string subscriberId, DateTime dateOfService, string firstname, string lastName, DateTime? dateOfBirth)
		{
			if (dateOfService == DateTime.MinValue)
				dateOfService = DateTime.Today;

			var results = _bcbsazSqlContext.CanViewIDCard.FromSqlRaw(
				DB.BCBSAZSQl.StoredProcs.IsIdCardSuppressedForProvider,
				(subscriberId.Length == 12) ? subscriberId.Substring(3, 9) : subscriberId,
				dateOfService,
				firstname,
				lastName,
				dateOfBirth
			).AsEnumerable();

			return results.Any() ? results.Select(r => !r.IsIDCardSuppressed).FirstOrDefault() : true;
		}

		public IEnumerable<ValueEnteredReturned> GetValueEnteredReturned(InquiryResult inquiryResult, ValuesEntered valuesEntered)
		{
			return inquiryResult.GetValueEnteredReturned(valuesEntered);
		}

		private IEnumerable<BenefitBooksDoc> GetBenefitDocs(string subscriberID, DateTime dateOfService) =>
			_contractIssuanceContext.BenefitBookDoc.FromSqlRaw(
				DB.ContractIssuance.StoredProcs.GetBenefitBookDoc,
				dateOfService,
				subscriberID
			).AsEnumerable();

		public GroupNumberInfo IsValidGroupNumber(string GroupNum) =>
			_clearingHouseContext.IsCHSGroup.FromSqlRaw(
				DB.ClearingHouse.StoredProcs.CHSGroupNumber, GroupNum
			).AsEnumerable().FirstOrDefault();

		public DiagnosisCodes[] GetDiagnosisCodes(string query, int pageSize, int pageNumber, out int totalCount)
		{
			// NOTE: Because we are dealing with a Stored Proc which uses an Output Parameter, we must use SqlParameters
			var totalCountParam = new SqlParameter()
			{
				ParameterName = "@TotalCount",
				DbType = System.Data.DbType.Int32,
				Size = 4,
				Direction = System.Data.ParameterDirection.Output
			};

			var beginsWithParam = new SqlParameter("@beginsWith", query);
			var pageSizeParam = new SqlParameter("@PageSize", pageSize);
			var pageNumberParam = new SqlParameter("@PageNumber", pageNumber);

			var retVal = _codesContext.DiagnosisCodes.FromSqlRaw(
				DB.Codes.StoredProcs.GetDiagnosisCodes,
				beginsWithParam, pageSizeParam, pageNumberParam, totalCountParam
			).AsEnumerable().ToArray();

			totalCount = (int)totalCountParam.Value;

			return retVal;
		}

		public async Task PurgeEligibilityInquiryResultsAsync(int days)
		{
			var dateForPurge = DateTime.Now.AddDays(days * -1);
			await _eligibilityContext.Database.ExecuteSqlRawAsync(DB.ProviderInet.StoredProcs.PurgeEligibilityAndBenefitsResults, days == 0 ? dateForPurge.ToString("yyyy-MM-dd") : null);
		}


		public Task SaveChangesAsync() => _patientsContext.SaveChangesAsync();


		public async Task<IEnumerable<Patient>> GetOrCreatePatientsAsync(Patient[] patients)
		{
			var retVal = GetPatients(patients).ToList();

			var missing = (from p in patients
										 where !Contains(p, retVal)
										 select p).ToArray();

			if (missing.Any())
			{
				retVal.AddRange(AddNavigationProperties(missing));
				await _patientsContext.Patients.AddRangeAsync(missing);
			}

			return retVal;

			bool Contains(Patient p, List<Patient> patients)
			{
				return (
					from patient in patients
					where
						p.SubscriberId.Equals(patient.SubscriberId, StringComparison.OrdinalIgnoreCase) &&
						p.PatientFirstName.Equals(patient.PatientFirstName, StringComparison.OrdinalIgnoreCase) &&
						p.PatientLastName.Equals(patient.PatientLastName, StringComparison.OrdinalIgnoreCase) &&
						p.DateOfBirth.Date.Equals(patient.DateOfBirth.Date)
					select patient).Any();
			}
		}

		private IEnumerable<Patient> AddNavigationProperties(Patient[] patients)
		{
			foreach (var patient in patients)
			{
				patient.Orgs = new List<PatientOrg>();
				patient.Users = new List<PatientUser>();
				yield return patient;
			}
		}

		private IEnumerable<Patient> GetPatients(Patient[] patients)
		{
			foreach (var patient in patients)
			{
				var retVal = (

						from p in _patientsContext.Patients
						where
							p.SubscriberId == patient.SubscriberId &&
							p.PatientFirstName == patient.PatientFirstName &&
							p.PatientLastName == patient.PatientLastName &&
							p.DateOfBirth.Date == patient.DateOfBirth.Date
						select p).FirstOrDefault();

				if (retVal != null)
					yield return retVal;

			}
		}
	}
}
