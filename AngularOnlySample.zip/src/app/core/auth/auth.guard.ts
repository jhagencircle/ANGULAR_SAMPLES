import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  RouterStateSnapshot,
  ActivatedRouteSnapshot,
  UrlTree,
  CanActivateChild,
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { OktaAuthService } from '@okta/okta-angular';
import { AccountService } from 'src/app/shared/services/account.service';
import { ISummary } from 'src/app/shared/models/summary.model';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {
  authenticated: boolean = false;
  groups: string[];

  public account: ISummary;

  constructor(
    private authService: AuthService,
    private router: Router,
    public oktaAuth: OktaAuthService,
    private accountService: AccountService
  ) {}

  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    this.authenticated = await this.authService.isAuthenticated();

    if (this.authenticated) {
      return true;
    } else {
      this.router.navigate(['/log-in']);
      return false;
    }
  }

  async canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ) {
    let isValid = false;
    this.accountService.get().subscribe((account: ISummary) => {
      if (account) {
        this.account = account;
        isValid = this.account.asc;
      }
    });
    if (!isValid) {
      this.router.navigate(['/landing-page']);
    }
    return isValid;
  }
}
