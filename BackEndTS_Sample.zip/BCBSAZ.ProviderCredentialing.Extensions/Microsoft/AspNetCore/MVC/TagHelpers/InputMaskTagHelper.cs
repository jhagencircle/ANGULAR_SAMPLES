﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Microsoft.AspNetCore.MVC.TagHelpers
{
	[HtmlTargetElement("input", Attributes = "asp-for")]
	public class InputMaskTagHelper : TagHelper
	{
		public override int Order { get; } = 1;

		[HtmlAttributeName("asp-for")]
		public ModelExpression For { get; set; }

		public override void Process(TagHelperContext context, TagHelperOutput output)
		{
			if (context == null) throw new ArgumentNullException(nameof(context));
			if (output == null) throw new ArgumentNullException(nameof(output));

			base.Process(context, output);

			// Process only if 'data-inputmask' attr is not present
			if (context.AllAttributes["data-inputmask"] == null)
			{
				// Attempt to check for a InputMask annotation
				var inputMask = GetInputMask(For.ModelExplorer.Metadata.ValidatorMetadata);
				if (!string.IsNullOrWhiteSpace(inputMask))
				{
					output.Attributes.Add("data-inputmask", inputMask);
					//output.Attributes.Add("maxlength", inputMask.Length);
				}
			}

		}

		private static string GetInputMask(IReadOnlyList<object> validatorMetadata)
		{
			for (var i = 0; i < validatorMetadata.Count; i++)
			{
				if (validatorMetadata[i] is InputMaskAttribute inputMaskAttribute && !string.IsNullOrWhiteSpace(inputMaskAttribute.InputMask))
					return inputMaskAttribute.InputMask;
			}
			return string.Empty;
		}
	}
}
