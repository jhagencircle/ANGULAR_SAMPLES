﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.TPA;
using BCBSAZ.Provider.Models.Requests.TPA;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories
{
	public class TpaProviderRepository : ITpaProviderRepository
	{
		private readonly IProviderInetContext _providerInetContext;

		public TpaProviderRepository(IProviderInetContext providerInetContext) => _providerInetContext = providerInetContext;


		public async Task<TpaProviderInfo> GetProviderInfoAsync(TpaProviderInfoRequest request)
			=> (await _providerInetContext.TpaProviderInfo.FromSqlRaw(DB.ProviderInet.StoredProcs.TpaGetProviderInfo, request.Network, request.TaxId, request.ProviderId).ToListAsync()).FirstOrDefault();
		

		public async Task<IEnumerable<TpaProviderContractStatus>> GetProviderContractStatusAsync(TpaProviderContractStatusRequest request) 
			=> await _providerInetContext.TpaProviderContractStatus.FromSqlRaw(DB.ProviderInet.StoredProcs.TpaGetProviderContractStatus, request.Network, request.TaxId, request.ProviderId, request.EndDateLaterThan).ToListAsync();
	}
}
