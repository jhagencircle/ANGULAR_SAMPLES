﻿using BCBSAZ.Provider.Models.Data.FeeSchedule;
using BCBSAZ.Provider.Models.Data.TPA;
using BCBSAZ.Provider.Repositories.Converters;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IFeeSchedContext : IDbContext
	{
		/// <summary>
		/// Gets the DbSet object for Professional Fees
		/// </summary>
		DbSet<ProfessionalFee> ProfessionalFees { get; }

		/// <summary>
		/// Gets the DbSet object for Outpatient Fees
		/// </summary>
		DbSet<OutpatientFee> OutpatientFees { get; }

		/// <summary>
		/// Gets the DbSet object for Asc Fees
		/// </summary>
		DbSet<AscFee> AscFees { get; }

		/// <summary>
		/// Gets the DbSet object for Specialties
		/// </summary>
		DbSet<Specialty> Specialties { get; }

		DbSet<TpaFeeDetail> TpaFeeDetail { get; }

	}

	/// <summary>
	/// Defines the Entity Framework DbContext object for the FeeSched database
	/// </summary>
	public class FeeSchedContext : DbContext, IFeeSchedContext
	{
		/// <summary>
		/// Creates a new instance of the FeeSched DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public FeeSchedContext(DbContextOptions<FeeSchedContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<ProfessionalFee>().HasNoKey();
			modelBuilder.Entity<OutpatientFee>().HasNoKey();
			modelBuilder.Entity<AscFee>().HasNoKey();
			modelBuilder.Entity<Specialty>().HasNoKey();
			modelBuilder.Entity<TpaFeeDetail>().HasNoKey();

			/******************** Property Configs ********************/

			modelBuilder.Entity<ProfessionalFee>()
				.Property(p => p.IsDME).HasConversion<int>();

			modelBuilder.Entity<ProfessionalFee>()
				.Property(p => p.SiteCode).HasConversion(new TrimStringConverter());

			modelBuilder.Entity<ProfessionalFee>()
				.Property(p => p.ProcedureCode).HasConversion(new StringToUpperCaseConverter());

			modelBuilder.Entity<ProfessionalFee>()
				.Property(p => p.Description).HasConversion(new StringToSentenceCaseConverter());



			modelBuilder.Entity<OutpatientFee>()
				.Property(p => p.SiteCode).HasConversion(new TrimStringConverter());

			modelBuilder.Entity<OutpatientFee>()
				.Property(p => p.ProcedureCode).HasConversion(new StringToUpperCaseConverter());

			modelBuilder.Entity<OutpatientFee>()
				.Property(p => p.Description).HasConversion(new StringToSentenceCaseConverter());


			modelBuilder.Entity<AscFee>()
				.Property(p => p.SiteCode).HasConversion(new TrimStringConverter());

			modelBuilder.Entity<AscFee>()
				.Property(p => p.ProcedureCode).HasConversion(new StringToUpperCaseConverter());

			modelBuilder.Entity<AscFee>()
				.Property(p => p.Description).HasConversion(new StringToSentenceCaseConverter());


			modelBuilder.Entity<Specialty>()
				.Property(p => p.Description).HasConversion(new StringToSentenceCaseConverter());


			modelBuilder.Entity<TpaFeeDetail>()
				.Property(p => p.Description).HasConversion(new StringToSentenceCaseConverter());

		}

		/// <summary>
		/// Gets the DbSet object for Professional Fees
		/// </summary>
		public DbSet<ProfessionalFee> ProfessionalFees { get; protected set; }

		/// <summary>
		/// Gets the DbSet object for Outpatient Fees
		/// </summary>
		public DbSet<OutpatientFee> OutpatientFees { get; protected set; }

		/// <summary>
		/// Gets the DbSet object for Asc Fees
		/// </summary>
		public DbSet<AscFee> AscFees { get; protected set; }

		/// <summary>
		/// Gets the DbSet object for Specialties
		/// </summary>
		public DbSet<Specialty> Specialties { get; protected set; }

		public DbSet<TpaFeeDetail> TpaFeeDetail { get; protected set; }

	}
}
