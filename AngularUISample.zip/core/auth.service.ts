import { Injectable } from '@angular/core';
import { OktaAuthService } from '@okta/okta-angular';

@Injectable({
    providedIn: 'root',
})
export class AuthService {
    authenticated: boolean = false;

    get isLogged(): boolean {
        return this.authenticated;
    }

    constructor(public oktaAuth: OktaAuthService) {
        this.isAuthenticated();
    }

    async isAuthenticated(): Promise<boolean> {
        const validGroup = 'ProviderAux';
        let isOktaAuthenticated: boolean = await this.oktaAuth.isAuthenticated();
        let isValidRole: boolean = false;
        if (isOktaAuthenticated) {
            const userClaims = await this.oktaAuth.getUser();
            let groups = userClaims.employerGroups;
            isValidRole = groups.some((group: string) => group === validGroup);
            if (isValidRole) {
                this.authenticated = true;
            }
        }
        return this.authenticated;
    }

    logout() {
        this.oktaAuth.signOut();
    }
}
