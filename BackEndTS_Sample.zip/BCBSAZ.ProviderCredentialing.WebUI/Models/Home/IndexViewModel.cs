﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Home
{
	public class IndexViewModel
	{
		public string[] BulletPoints { get; set; }

		public string MainHeader { get; set; }

		public string SubHeader { get; set; }

		public string Note { get; set; }
	}
}
