import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bank-account-card',
  templateUrl: './bank-account-card.component.html',
  styleUrls: ['./bank-account-card.component.scss'],
})
export class BankAccountCardComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit(): void {}

  goToManageAccounts() {
    this.router.navigate(['/payments/manage-bank-accounts']);
  }
}
