export interface IPhone {
  number: string;
  phoneType: string;
}
