﻿export class OfficeHour {
	dayOfWeek: string;
	startTime: string;
	closeTime: string;

	constructor(dayOfWeek: string, sTime: string, cTime: string) {
		this.dayOfWeek = dayOfWeek;
		this.startTime = sTime;
		this.closeTime = cTime;
	}
}