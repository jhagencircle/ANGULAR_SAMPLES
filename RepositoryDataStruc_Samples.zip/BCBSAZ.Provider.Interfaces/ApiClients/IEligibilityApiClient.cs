﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Responses.Eligibility.Inquiries;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface IEligibilityApiClient
	{
		Task<VelocityEligibilityResponse> Get271Response(VelocityEligibilityRequest request);
	}
}
