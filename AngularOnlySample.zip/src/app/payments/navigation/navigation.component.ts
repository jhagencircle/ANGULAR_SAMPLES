import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ISummary } from 'src/app/shared/models/summary.model';
import { AccountService } from 'src/app/shared/services/account.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss'],
})
export class NavigationComponent implements OnInit, OnDestroy {
  public currentItem: string;
  public account: ISummary;
  subscriptions: Subscription[] = [];

  constructor(private router: Router, private accountService: AccountService) {
    this.setCurrentSection();

    let subscription = this.accountService
      .get()
      .subscribe((account: ISummary) => {
        if (account) {
          this.account = account;
        }
      });
    this.subscriptions.push(subscription);
  }

  ngOnInit(): void {}

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  ngDoCheck(): void {
    this.setCurrentSection();
  }

  setCurrentSection(): void {
    const param = window.location.pathname
      .replace('/payments', '')
      .replace('/asc', '')
      .replace('/', '');

    this.currentItem = param;
  }
}
