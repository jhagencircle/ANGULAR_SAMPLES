﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.Models.Data.Applications;

namespace BCBSAZ.ProviderCredentialing.Interfaces.Repositories
{
	public interface IApplicationRepository
	{
		Task SaveApplicationAsync(Application application);
	}
}
