import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { IBenefit } from '../shared/models/benefit.model';
import { EmployeeProfileService } from '../shared/employee-profile.service';
import { IEmployee } from '../shared/models/employee.model';
import { IPlan } from '../shared/models/plan.model';
import { IProfileRoster } from '../shared/models/profile-roster.model';
import { Subscription } from 'rxjs';
import { supportsScrollBehavior } from '@angular/cdk/platform';

@Component({
  selector: 'app-employee-benefit-selection',
  templateUrl: './employee-benefit-selection.component.html',
  styleUrls: ['./employee-benefit-selection.component.scss'],
})
export class EmployeeBenefitSelectionComponent implements OnInit, OnDestroy {
  @Input() benefitSelection: IBenefit;
  @Input() employeeInformation: IEmployee;
  healthInsuranceBenefit: IPlan | undefined;
  dentalInsuranceBenefit: IPlan | undefined;
  lifeInsuranceBenefit: IPlan | undefined;

  showEdit: boolean = false;
  employeeProfile: IProfileRoster;
  subscriptions: Subscription[] = [];

  constructor(private employeeProfileService: EmployeeProfileService) {}

  ngOnInit(): void {
    this.getBenefitPlans();
    let subscription = this.employeeProfileService
      .get()
      .subscribe((data) => (this.employeeProfile = data));
    this.subscriptions.push(subscription);
  }
  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  editBenefit() {
    this.showEdit = true;
  }
  displayBenefitForm(isDisplayed: boolean) {
    this.showEdit = isDisplayed;
    if (!isDisplayed) {
      this.getBenefitPlans();
    }
  }
  close() {
    this.showEdit = false;
  }

  onSendDataChild() {
    this.employeeProfileService.update(this.employeeProfile);
  }

  getBenefitPlans() {
    this.healthInsuranceBenefit = this.benefitSelection?.planSelection.find(
      (p) => {
        if (p.type.toLowerCase().includes('medical')) {
          return p;
        } else return null;
      }
    );
    this.dentalInsuranceBenefit = this.benefitSelection?.planSelection.find(
      (p) => {
        if (p.type.toLowerCase().includes('dental')) {
          return p;
        } else return null;
      }
    );
    this.lifeInsuranceBenefit = this.benefitSelection?.planSelection.find(
      (p) => {
        if (p.type.toLowerCase().includes('life')) {
          return p;
        } else return null;
      }
    );
  }
}
