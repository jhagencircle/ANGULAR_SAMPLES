import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { OktaAuthService } from '@okta/okta-angular';
import { AuthService } from 'src/app/core/auth/auth.service';
import { AppConstants } from '../../constants/app-constants';
import { AuthServiceMock } from '../../mocks/auth.service.mock';
import { NavbarComponent } from './navbar.component';

describe('NavbarComponent', () => {
  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;
  let oktaAuthService: OktaAuthService;
  let authServiceMock = new AuthServiceMock();
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [NavbarComponent],
      providers: [
        { provide: OktaAuthService, useValue: oktaAuthService },
        { provide: AuthService, useValue: authServiceMock },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display Pay Bill menu', () => {
    AuthServiceMock.authenticatedMock = true;
    fixture.detectChanges();
    const spanElement =
      fixture.debugElement.nativeElement.querySelector('span.menu-title');
    const dropDownMenu =
      fixture.debugElement.nativeElement.querySelector('#navbarDropdown');
    const landingPageLink =
      fixture.debugElement.nativeElement.querySelector('#landing-page-link');
    const historicalStatementsLink =
      fixture.debugElement.nativeElement.querySelector(
        '#historical-statements-link'
      );
    const paymentsLink =
      fixture.debugElement.nativeElement.querySelector('#payments-link');
    const faqLink =
      fixture.debugElement.nativeElement.querySelector('#faq-link');
    expect(dropDownMenu).toBeTruthy();
    expect(landingPageLink).toBeTruthy();
    expect(historicalStatementsLink).toBeTruthy();
    expect(paymentsLink).toBeTruthy();
    expect(faqLink).toBeTruthy();
    expect(spanElement.innerHTML).toContain('Pay Bill');
  });

  it(' Account Overview option renders the correct routerLink attribute', () => {
    AuthServiceMock.authenticatedMock = true;
    fixture.detectChanges();
    const link =
      fixture.debugElement.nativeElement.querySelector('#landing-page-link');
    expect(link['href']).toContain('/landing-page');
  });

  it(' Historical Statements option renders the correct routerLink attribute', () => {
    AuthServiceMock.authenticatedMock = true;
    fixture.detectChanges();
    const link = fixture.debugElement.nativeElement.querySelector(
      '#historical-statements-link'
    );
    expect(link['href']).toContain('/historical-statements');
  });

  it(' Payments option renders the correct routerLink attribute', () => {
    AuthServiceMock.authenticatedMock = true;
    fixture.detectChanges();
    const link =
      fixture.debugElement.nativeElement.querySelector('#payments-link');
    expect(link['href']).toContain('/payments');
  });

  it(' Billing FAQs option renders the correct routerLink attribute', () => {
    AuthServiceMock.authenticatedMock = true;
    fixture.detectChanges();
    const link = fixture.debugElement.nativeElement.querySelector('#faq-link');
    expect(link['href']).toContain('/billing-faqs');
  });

  it('should update paymentSection local storage ', () => {
    AuthServiceMock.authenticatedMock = true;
    fixture.detectChanges();
    component.paymentsClick();
    let storage = localStorage.getItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );
    expect(storage).toContain('account');
  });

  it('should hide navigation', () => {
    AuthServiceMock.authenticatedMock = false;
    fixture.detectChanges();
    const dropDownMenu =
      fixture.debugElement.nativeElement.querySelector('#navbarDropdown');
    expect(dropDownMenu).toBeFalsy();
  });
});
