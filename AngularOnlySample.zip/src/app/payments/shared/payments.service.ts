import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject, of } from 'rxjs';
import { debounceTime, delay, switchMap, tap } from 'rxjs/operators';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { environment } from 'src/environments/environment';
import { IPaymentHistory } from './payment-history.model';
import { IPaymentState } from './payment-state';
import { SortDirection } from '../../shared/directives/sortable.directive';
import { IPaymentsSearchResult } from './payments-search-result';
import { IPayment } from './payment.model';
import { IPaymentResponse } from './payment-response.model';
import { IScheduledPayment } from './scheduled-payment.model';

const compare = (v1: string | number | any, v2: string | number | any) =>
  v1 < v2 ? -1 : v1 > v2 ? 1 : 0;

function sort(
  payments: IPaymentHistory[],
  column: string,
  direction: string
): IPaymentHistory[] {
  if (direction === '' || column === '') {
    return payments;
  } else {
    return [...payments].sort((a: any, b: any) => {
      const res = compare(a[column], b[column]);
      return direction === 'asc' ? res : -res;
    });
  }
}

@Injectable({
  providedIn: 'root',
})
export class PaymentsService {
  url = `${environment.apiUrl}/api/payment`;

  private _loading$ = new BehaviorSubject<boolean>(true);
  private _payments$ = new BehaviorSubject<IPaymentHistory[]>([]);
  private _total$ = new BehaviorSubject<number>(0);
  private _paymentsHistoryList: IPaymentHistory[] = [];
  private _payment: IPaymentHistory;
  private _search$ = new Subject<void>();

  private _state: IPaymentState = {
    page: 1,
    pageSize: 10,
    sortColumn: '',
    sortDirection: '',
  };

  constructor(private http: HttpClient) {
    this._search$
      .pipe(
        tap(() => this._loading$.next(true)),
        debounceTime(200),
        switchMap(() => this._search()),
        delay(200),
        tap(() => this._loading$.next(false))
      )
      .subscribe((result) => {
        this._payments$.next(result.payments);
        this._total$.next(result.total);
      });

    this._search$.next();
  }

  private _search(): Observable<IPaymentsSearchResult> {
    const { sortColumn, sortDirection, pageSize, page } = this._state;

    // 1. sort
    let payments = sort(this.paymentsHistoryList, sortColumn, sortDirection);

    const total = payments.length;

    // 2. paginate
    payments = payments.slice(
      (page - 1) * pageSize,
      (page - 1) * pageSize + pageSize
    );

    return of({ payments: payments, total });
  }

  search() {
    this._search$.next();
  }
  get payments$() {
    return this._payments$.asObservable();
  }
  get total$() {
    return this._total$.asObservable();
  }
  get loading$() {
    return this._loading$.asObservable();
  }
  get page() {
    return this._state.page;
  }
  get pageSize() {
    return this._state.pageSize;
  }
  get paymentsHistoryList(): IPaymentHistory[] {
    return this._paymentsHistoryList;
  }
  get payment(): IPaymentHistory {
    return this._payment;
  }

  set page(page: number) {
    this._set({ page });
  }
  set pageSize(pageSize: number) {
    this._set({ pageSize });
  }
  set sortColumn(sortColumn: string) {
    this._set({ sortColumn });
  }
  set sortDirection(sortDirection: SortDirection) {
    this._set({ sortDirection });
  }
  set paymentsHistoryList(el: IPaymentHistory[]) {
    this._paymentsHistoryList = el;
  }
  set payment(emp: IPaymentHistory) {
    this._payment = emp;
  }

  private _set(patch: Partial<IPaymentState>) {
    Object.assign(this._state, patch);
    this._search$.next();
  }

  getList(accountId: string): Observable<IPaymentHistory[]> {
    return this.http.get<IPaymentHistory[]>(`${this.url}/account/${accountId}`);
  }

  setPaymentConfirmation(paymentConfirmation: IPaymentResponse[]) {
    localStorage.setItem(
      AppConstants.PAYMENT_CONFIRMATION_LOCAL_STORAGE_KEY,
      JSON.stringify(paymentConfirmation)
    );
  }

  getPaymentConfirmation(): IPaymentResponse[] {
    return JSON.parse(
      localStorage.getItem(
        AppConstants.PAYMENT_CONFIRMATION_LOCAL_STORAGE_KEY
      ) || ''
    );
  }

  postPayment(payments: IPayment[]): Observable<IPaymentResponse[]> {
    return this.http.post<IPaymentResponse[]>(this.url, payments);
  }

  postClaimsPayment(payments: IPayment): Observable<IPaymentResponse> {
    return this.http.post<IPaymentResponse>(`${this.url}/Claims`, payments);
  }

  getScheduledPayments(accountId: string): Observable<IScheduledPayment[]> {
    return this.http.get<IScheduledPayment[]>(
      `${this.url}/account/${accountId}/scheduled`
    );
  }

  deleteScheduledPayment(
    accountId: string,
    transactionId: string
  ): Observable<Object> {
    return this.http.delete(
      `${this.url}/account/${accountId}/scheduled/${transactionId}`
    );
  }

  updateScheduledPayment(
    accountId: string,
    payment: IScheduledPayment
  ): Observable<Object> {
    return this.http.put(`${this.url}/account/${accountId}/scheduled`, {
      transactionId: payment.transactionId,
      transactionDate: payment.paymentTransactionDate,
      paymentAmount: payment.paymentAmount,
      paymentTokenId: payment.paymentTokenId,
    });
  }

  // Common functions
  goToReview(): void {
    let currentSection = localStorage.getItem('paymentSection');
    localStorage.setItem(
      'previousPaymentSection',
      currentSection ?? 'accounts'
    );
    localStorage.setItem('paymentSection', 'review');
    window.location.reload();
  }

  parseNumber(input: string): number {
    input = input.replace('$', '');
    while (input.includes(',')) {
      input = input.replace(',', '');
    }
    return parseFloat(input);
  }

  parseCurrency(input: number): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(input);
  }
}
