﻿namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Responses.Common
{
	public class TestResponse
	{
		public string ApiEnvironment { get; set; }
		public string ApiDescription { get; set; }
		public string ApiVersion { get; set; }

		public string WebEnvironment { get; set; }
		public string WebDescription { get; set; }
		public string WebVersion { get; set; }
	}
}
