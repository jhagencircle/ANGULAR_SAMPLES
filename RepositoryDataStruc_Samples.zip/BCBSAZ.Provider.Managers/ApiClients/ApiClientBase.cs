﻿using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Models.Exceptions;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace BCBSAZ.Provider.Managers.ApiClients
{
	public abstract class ApiClientBase : HttpClient
	{
		private readonly IOktaApiClient _oktaClient;
		private readonly JsonSerializerSettings _serializerSettings;

		protected ApiClientBase(IOktaApiClient oktaClient)
		{
			_oktaClient = oktaClient;
			_serializerSettings = GetJsonSerializerSettings();
		}

		/// <summary>
		/// Gets the Name of the Api Client
		/// </summary>
		protected abstract string Name { get; }

		protected virtual JsonSerializerSettings GetJsonSerializerSettings() =>
			new JsonSerializerSettings()
			{
				DateFormatString = "yyyy-MM-dd",
				Formatting = Formatting.Indented,
				NullValueHandling = NullValueHandling.Ignore,
				ContractResolver = new CamelCasePropertyNamesContractResolver()
			};

		/// <summary>
		/// Gets the current Authentication Token from Okta
		/// </summary>
		/// <returns></returns>
		protected virtual (string tokenType, string token) GetApiTokenAuthentication()
		{
			var response = _oktaClient.GetApiToken();
			return (response.TokenType, response.Token);
		}

		/// <summary>
		/// Sends the request provided to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestMessage">The request message for the Provider Web Api method</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		protected async Task<TResult> SendRequestAsync<TResult>(HttpRequestMessage requestMessage, Func<HttpResponseMessage,TResult> notFoundHandler = null) where TResult : class
		{
			var response = await SendAsync(requestMessage);

			// Shortcut, if the caller is requesting the HttpResponseMessage as the result, just return it
			// (consuming code is responsible for checking status code & response content)
			if (response is TResult)
				return response as TResult;

			var content = await response.Content.ReadAsStringAsync();

			if (response.IsSuccessStatusCode)
			{
				return JsonConvert.DeserializeObject<TResult>(content);
			}
			else if ((response.StatusCode == HttpStatusCode.NotFound) && (notFoundHandler != null))
			{
				return notFoundHandler(response);
			}
			else
			{
				throw new InvalidApiResponseException(response.StatusCode, response.ReasonPhrase, response.Content.Headers.ContentType, content, Name);
			}
		}

		/// <summary>
		/// Gets the content provided by the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		/// <exception cref="InvalidApiResponseException">If the response from the Web Api is not a Success status code (200) this exception will be thrown containing the details of the non-success response from the WebApi</exception>
		public Task<TResult> GetAsync<TResult>(string requestUri) where TResult : class =>
			SendRequestAsync<TResult>(new HttpRequestMessage(HttpMethod.Get, requestUri).AddTokenAuthentication(GetApiTokenAuthentication));

		/// <summary>
		/// Post the content provided by the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		/// <exception cref="InvalidApiResponseException">If the response from the Web Api is not a Success status code (200) this exception will be thrown containing the details of the non-success response from the WebApi</exception>
		public Task<TResult> PostAsync<TResult>(string requestUri, object body, Func<HttpResponseMessage, TResult> notFoundHandler = null) where TResult : class =>
			SendRequestAsync<TResult>(CreatePostRequest(requestUri, body).AddTokenAuthentication(GetApiTokenAuthentication), notFoundHandler);

		public HttpRequestMessage CreatePostRequest(string requestUri, object body)
		{
			var requestMessage = new HttpRequestMessage(HttpMethod.Post, requestUri);

			if (body != null)
			{
				var json = JsonConvert.SerializeObject(body, _serializerSettings);
				requestMessage.Content = new StringContent(json, Encoding.UTF8, "application/json");
			}

			return requestMessage;
		}

		/// <summary>
		/// Puts the specified content to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <param name="body">The object to be serialized for the body content of the request, or preserialized data in the form of a string.</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		public Task<TResult> PutAsync<TResult>(string requestUri, object body) where TResult : class
		{
			var requestMessage = new HttpRequestMessage(HttpMethod.Put, requestUri);

			if (body != null)
			{
				requestMessage.Content = new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json");
			}

			return SendRequestAsync<TResult>(requestMessage.AddTokenAuthentication(GetApiTokenAuthentication));
		}

		/// <summary>
		/// Submits a Delete Request to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		public Task<TResult> DeleteAsync<TResult>(string requestUri) where TResult : class =>
			SendRequestAsync<TResult>(new HttpRequestMessage(HttpMethod.Delete, requestUri).AddTokenAuthentication(GetApiTokenAuthentication));
	}
}
