import { IProviderInformation } from "src/app/models/eft-change-request/eft-provider-information.interface";

export class EftSubmissionInformationFormMockFinancialManagerUserServiceMock {
    public static mockUserList: IProviderInformation[] = [
        /* {
         providerName: 'TestMedical',
         providerDba: 'string',
         providerAddress: 'string',
         providerCity: 'string',
         providerState: 'string',
         providerZipCode: 'string',
         providerTin: 'string',
         providerNpi: 'string',
         providerContactName: 'string',
         providerPhone: 555-555-1234,
         providerPhoneExt: 1234,
         providerEmailAddress: 'string',
         providerFax: 555-444-1234,
        } */
  
        
    ];
}