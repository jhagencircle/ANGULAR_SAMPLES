﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using BCBSAZ.Provider.Managers.RequestValidators.PreCert;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.PreCert;
using BCBSAZ.Provider.Models.Data.PreCert.Pharmacy;
using BCBSAZ.Provider.Models.Requests.PreCert;
using BCBSAZ.Provider.Models.Responses.PreCert;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Managers
{
	public partial class PreCertManager
	{
		private string _pharmacyFromAddress;
		private string _pharmacyStaffAddress;

		private void InitializePharmacy(IConfiguration configuration)
		{
			_pharmacyFromAddress = configuration.GetValue<string>("PharmacyPreCert_FromAddress");
			_pharmacyStaffAddress = configuration.GetValue<string>("PharmacyPreCert_StaffAddress");
		}

		public async Task<GetPharmacyPreCertResponse> GetPharmacyPreCertAsync(GetPharmacyPreCertRequest request, WebUser webUser)
		{
			request.Validate(webUser);

			var preCert = await _preCertRepository.GetPharmacyPreCertByIdAsync(request.PreCertId);

			if (!IsInternal(webUser) && (preCert.UserId != webUser.UserId))
				throw new UnauthorizedAccessException();

			var precertResponse = new GetPharmacyPreCertResponse(preCert);

			PopulateCommentsUserName(precertResponse);
			PopulateStatusesUserName(precertResponse);

			await AddDownloadHashes(precertResponse, webUser);

			return precertResponse;
		}

		private async Task AddDownloadHashes(GetPharmacyPreCertResponse response, WebUser webUser)
		{
			await Task.WhenAll(response.Attachments.ForEachReturn(AddDownloadHash, webUser));
		}

		private async Task AddDownloadHash(Attachment attachment, WebUser webUser)
		{
			var fileHash = await _preCertRepository.GetUploadedFileHashAsync(attachment.FileId);
			using (var sha = SHA256.Create())
			{
				// Generate a download hash using the UserId and File Hash.  This hash will be validated when the user attempts
				// to download a file.  If the user changes the file Id (or username) part of the URL, then the hash won't match
				// and we will return a 403 response.
				attachment.DownloadHash = sha.GenerateHashHexString($"{ webUser.UserId }|{ fileHash }");
			}
		}

		public ViewPharmacyPreCertsResponse ViewPharmacyPreCertResults(ViewPharmacyPreCertsRequest request, WebUser webUser)
		{
			request.Validate(webUser);

			return new ViewPharmacyPreCertsResponse()
			{
				PharmacySummaries = _preCertRepository.ViewPharmacyPreCertResults(webUser.UserId, webUser.OrgId, request.Status, request.FromDate, request.ToDate, IsInternal(webUser))
			};
		}

		#region Save PreCert
		public async Task<SavePharmacyPreCertResponse> SavePharmacyPreCertAsync(SavePharmacyPreCertRequest request, WebUser webUser)
		{
			request.Validate(webUser);

			var updateDate = DateTime.Now;

			request.Form.UserId = webUser.UserId;
			request.Form.InsertDate = updateDate;

			var preCert = await _preCertRepository.GetPharmacyPreCertByIdAsync(request.PreCertId);

			if (request.PreCertId == 0)
			{
				preCert.UserId = webUser.UserId;
			}
			else if (!IsInternal(webUser) && (preCert.UserId != webUser.UserId))
			{
				throw new UnauthorizedAccessException();
			}

			var currentForm = ProcessForm(request, preCert);

			ProcessAttachments(preCert, request.Attachments, webUser.UserId, updateDate);
			ProcessComments(preCert, request.Form.FormComments, webUser.UserId, updateDate);
			var newStatus = ProcessStatus(preCert, request.Status, currentForm, webUser.UserId, updateDate);

			await _preCertRepository.SaveAllChangesAsync();

			await SendStatusEmailAsync(newStatus, preCert, updateDate);

			return new SavePharmacyPreCertResponse(preCert, updateDate);
		}

		private void ProcessComments(PharmacyPreCert preCert, string formComments, string userId, DateTime updateDate)
		{
			if (string.IsNullOrWhiteSpace(formComments))
				return;

			preCert.Comments.Add(new Comments()
			{
				CommentText = formComments,
				UserId = userId,
				InsertDate = updateDate
			});
		}

		#region Process Form

		private Form ProcessForm(SavePharmacyPreCertRequest request, PharmacyPreCert preCert)
		{
			var oldForm = (
				from f in preCert.Forms
				orderby f.InsertDate descending
				select f).FirstOrDefault();

			return (request.Status == PreCertStatus.Unsubmitted) ?
				UpdateForm(preCert, oldForm, request.Form) :
				AddFormIfNew(preCert, oldForm, request.Form);
		}

		private Form UpdateForm(PharmacyPreCert preCert, Form oldForm, Form newForm)
		{
			if (oldForm == null)
			{
				preCert.Forms.Add(newForm);
				return newForm;
			}
			else
			{
				oldForm.UpdateForm(newForm);
				return oldForm;
			}
		}

		private Form AddFormIfNew(PharmacyPreCert preCert, Form oldForm, Form newForm)
		{
			if (oldForm == null)
			{
				preCert.Forms.Add(newForm);
				return newForm;
			}
			else if (!oldForm.IsEqual(newForm))
			{
				newForm.PreviousId = oldForm.FormId;
				preCert.Forms.Add(newForm);
				return newForm;
			}
			else
			{
				return oldForm;
			}
		}

		#endregion

		#region Process Attachments

		private void ProcessAttachments(PharmacyPreCert preCert, IEnumerable<Attachment> attachments, string userId, DateTime updateDate)
		{
			var deleted = (
				from existing in preCert.Attachments
				join a in attachments on existing.FileId equals a.FileId
				where a.IsRemoved
				select existing);

			var added = (
				from a in attachments
				where IsNewAttachment(a, preCert.Attachments)
				select a);

			deleted.ForEach(DeleteAttachment, userId, updateDate);
			added.ForEach(AddAttachment, preCert, userId, updateDate);
		}

		private static bool IsNewAttachment(Attachment attachment, IEnumerable<Attachment> existingAttachments)
		{
			if (attachment.IsRemoved || attachment.AttachmentId != 0)
				return false;

			return !(from e in existingAttachments
							 where e.FileId == attachment.FileId
							 select e).Any();
		}

		private static void DeleteAttachment(Attachment attachment, string userId, DateTime updateDate)
		{
			attachment.IsRemoved = true;
			attachment.RemovedByUserId = userId;
			attachment.DateRemoved = updateDate;
		}

		private static void AddAttachment(Attachment attachment, PharmacyPreCert preCert, string userId, DateTime updateDate)
		{
			attachment.FileName = Path.GetFileName(attachment.FileName);

			attachment.IsRemoved = false;
			attachment.AddedByUserId = userId;
			attachment.DateAdded = updateDate;

			preCert.Attachments.Add(attachment);
		}

		#endregion

		#region Process Status

		private PreCertStatus ProcessStatus(PharmacyPreCert preCert, PreCertStatus status, Form form, string userId, DateTime updateDate)
		{
			var currentStatus = (
				from f in preCert.Forms
				from s in f.Statuses
				orderby s.InsertDate descending
				select s).FirstOrDefault();

			if ((currentStatus == null) || (currentStatus.FormStatus != status))
			{
				if ((currentStatus != null) && (currentStatus.FormStatus != PreCertStatus.Unsubmitted) && (status == PreCertStatus.Unsubmitted))
				{
					throw new InvalidRequestException(new InvalidModelExceptionDetail[]
					{
						new InvalidModelExceptionDetail(nameof(SaveMedicalPreCertRequest.Status), new ArgumentException("Attempted to set a Submitted Form to Unsubmitted Status."))
					});
				}

				if (((currentStatus == null) || (currentStatus.FormStatus == PreCertStatus.Unsubmitted)) && (status == PreCertStatus.Pending))
				{
					// Form is being submitted, set the userId to the user submitting the form.
					preCert.UserId = userId;
				}

				form.Statuses.Add(new Status()
				{
					FormStatus = status,
					UserId = userId,
					InsertDate = updateDate
				});

				return status;
			}

			return PreCertStatus.Unsubmitted;
		}

		#endregion

		#endregion

		#region Send Email

		private async Task SendStatusEmailAsync(PreCertStatus status, PharmacyPreCert preCert, DateTime updateDate)
		{
			if ((status != PreCertStatus.Unsubmitted) && !string.IsNullOrWhiteSpace(preCert.UserId))
			{
				var toAddress = await _preCertRepository.GetEmailAddressForUserAsync(preCert.UserId);
				var preCertId = string.Format(CultureInfo.InvariantCulture, "P{0:00000000}", preCert.PharmacyPreCertId);

				switch (status)
				{
					case PreCertStatus.Approved:
						await _emailProcessor.SendPreCertApprovedAsync(_pharmacyFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.Canceled:
						await _emailProcessor.SendPreCertCancelledAsync(_pharmacyFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.Denied:
						await _emailProcessor.SendPreCertDeniedAsync(_pharmacyFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.Incomplete:
						await _emailProcessor.SendPreCertIncompleteAsync(_pharmacyFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.NotRequired:
						await _emailProcessor.SendPreCertNotRequiredAsync(_pharmacyFromAddress, toAddress, preCertId);
						break;
					case PreCertStatus.Pending:
						await _emailProcessor.SendPreCertSubmittedAsync(_pharmacyFromAddress, toAddress, preCertId);
						await _emailProcessor.SendPreCertNewRequestAsync(_pharmacyFromAddress, _pharmacyStaffAddress, preCertId, _providerPortalUrl, updateDate);
						break;
				}
			}
		}

		#endregion

		#region Cancel PreCert

		public async Task<CancelPharmacyPreCertResponse> CancelPharmacyPreCertAsync(CancelPharmacyPreCertRequest request, WebUser webUser)
		{
			request.Validate(webUser);

			var preCert = await _preCertRepository.GetPharmacyPreCertByIdAsync(request.PreCertId);
			var updateDate = DateTime.Now;

			var form = (
				from f in preCert.Forms
				orderby f.InsertDate descending
				select f).FirstOrDefault();

			form.Statuses.Add(new Status()
			{
				FormStatus = PreCertStatus.Canceled,
				InsertDate = updateDate,
				UserId = webUser.UserId
			});

			await _preCertRepository.SaveAllChangesAsync();
			await SendStatusEmailAsync(PreCertStatus.Canceled, preCert, updateDate);

			return new CancelPharmacyPreCertResponse()
			{
				PreCertId = preCert.PharmacyPreCertId,
				UpdateDate = updateDate
			};
		}

		#endregion

		public async Task<DownloadFileResponse> GetPharmacyFileContentsAsync(DownloadFileRequest request)
		{
			request.Validate();

			var attachment = await _preCertRepository.GetPharmacyAttachmentByIdAsync(request.AttachmentId);
			var file = await _preCertRepository.GetUploadedFileByIdAsync(attachment.FileId);

			using (var sha = SHA256.Create())
			{
				// Validate the download hash. If the user changes the file Id (or username) part of the URL, then the hash won't match
				// and we will return a 403 response.
				var downloadHash = sha.GenerateHashHexString($"{ request.UserId }|{ file.FileHash }");
				if (downloadHash != request.DownloadHash)
					throw new UnauthorizedAccessException();
			}

			return new DownloadFileResponse
			{
				FileName = attachment.FileName,
				FileContents = file.Contents,
				ContentType = file.ContentType
			};
		}
		private void PopulateCommentsUserName(GetPharmacyPreCertResponse precertResponse)
		{
			var userIds = (
				from comment in precertResponse.Comments
				select comment.UserId).Distinct().ToArray();

			var users = _preCertRepository.GetUserNameByUserId(userIds);

			precertResponse.Comments.ForEach(AddUserInfoToComment, users);
		}

		private void PopulateStatusesUserName(GetPharmacyPreCertResponse precertResponse)
		{
			var userIds = (
				from status in precertResponse.StatusHistory
				select status.UserId).Distinct().ToArray();

			var users = _preCertRepository.GetUserNameByUserId(userIds);

			precertResponse.StatusHistory.ForEach(AddUserInfoToStatus, users);
		}

		private void AddUserInfoToComment(Comments comment, User[] users)
		{
			var user = (
				from u in users
				where u.UserId.Equals(comment.UserId, StringComparison.OrdinalIgnoreCase)
				select u
			).FirstOrDefault();

			comment.UserFirstName = user?.FirstName;
			comment.UserLastName = user?.LastName;

			if (string.IsNullOrWhiteSpace(comment.UserFirstName) && string.IsNullOrWhiteSpace(comment.UserLastName))
				comment.UserFirstName = user?.UserId;
		}

		private void AddUserInfoToStatus(Status status, User[] users)
		{
			var user = (
				from u in users
				where u.UserId.Equals(status.UserId, StringComparison.OrdinalIgnoreCase)
				select u
			).FirstOrDefault();

			status.UserFirstName = user?.FirstName;
			status.UserLastName = user?.LastName;

			if (string.IsNullOrWhiteSpace(status.UserFirstName) && string.IsNullOrWhiteSpace(status.UserLastName))
				status.UserFirstName = user?.UserId;
		}
	}
}
