﻿using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.ProviderCredentialing.Interfaces.Repositories
{
	public interface ISystemLogsRepository
	{
		Task InsertLogMessageAsync(LogMessage message);
	}
}
