import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/auth/auth.service';
import { AppConstants } from '../../constants/app-constants';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  constructor(public authService: AuthService) {}

  ngOnInit(): void {}

  paymentsClick() {
    localStorage.setItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
      'account'
    );
  }
}
