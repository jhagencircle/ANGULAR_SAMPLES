﻿using System.ComponentModel.DataAnnotations;

namespace BCBSAZ.ProviderCredentialing.WebAPI.Models.Enums
{
	public enum FacilityType
	{
		Active,
		Courtesy,
		Delivery,
		Provisional
	}
}
