﻿using BCBSAZ.ProviderCredentialing.Interfaces.Managers;
using BCBSAZ.ProviderCredentialing.Interfaces.Processors;
using BCBSAZ.ProviderCredentialing.Interfaces.Repositories;
using BCBSAZ.ProviderCredentialing.Models;
using BCBSAZ.ProviderCredentialing.Models.Data.Applications;
using BCBSAZ.ProviderCredentialing.Models.Requests;
using BCBSAZ.ProviderCredentialing.Models.Responses;
using BCBSAZ.ProviderCredentialing.WebAPI.Models.Enums;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.Managers
{
	public class ApplicationManager : IApplicationManager
	{
		private readonly IApplicationRepository _repository;
		private readonly IEmailProcessor _emailProcessor;

		private readonly string _fromAddress;
		private readonly string _staffAddress;

		public ApplicationManager(IApplicationRepository repository, IEmailProcessor emailProcessor, IConfiguration configuration)
		{
			_repository = repository;
			_emailProcessor = emailProcessor;

			_fromAddress = configuration.GetValue<string>("Email_FromAddress");
			_staffAddress = configuration.GetValue<string>("Email_StaffAddress");
		}

		public async Task<SubmitApplicationResponse> SubmitApplicationAsync(SubmitApplicationRequest request)
		{
			var insertDate = DateTime.Now;
			var name = (
				from n in request.Form.Names
				where n.Types.Contains(NameType.ProviderInformation)
				select n).FirstOrDefault();

			var contactAddress = (
				from e in request.Form.EmailAddresses
				where e.Types.Contains(EmailAddressType.ApplicationContactInformation)
				select e.Address
				).FirstOrDefault();

			if (name == null)
				throw new InvalidRequestException(new InvalidModelExceptionDetail("ProviderInformation", new ArgumentNullException()));

			if (string.IsNullOrWhiteSpace(contactAddress))
				throw new InvalidRequestException(new InvalidModelExceptionDetail("ContactEmail", new ArgumentNullException()));

			var application = new Application()
			{
				FirstName = name.FirstName,
				LastName = name.LastName,
				InsertDate = insertDate,
				JsonData = JsonConvert.SerializeObject(request.Form),
				Attachments = request.Attachments.ToList()
			};

			await _repository.SaveApplicationAsync(application);

			var sendSubmitEmailTask = _emailProcessor.SendCredentialingSubmittedAsync(_fromAddress, _staffAddress, name.FirstName, name.LastName, insertDate, request.Attachments);
			var sendThankYouEmailTask = _emailProcessor.SendCredentialingThankYouAsync(_fromAddress, contactAddress);

			await Task.WhenAll(sendSubmitEmailTask, sendThankYouEmailTask);

			return new SubmitApplicationResponse()
			{
				ApplicationId = application.ApplicationId,
				SubmittedDate = insertDate
			};
		}
	}
}
