export interface IProviderInformation {
    eftUserProfile: {
        requestId : number,
        userId: string,
        firstName: string,
        middleInitial: string,
        lastName: string,
        dateOfBirth: string,
        ipAddress: string,
        insertDate: string
      }
}