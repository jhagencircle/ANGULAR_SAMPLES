import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';

import { ManageBenefitsRoutingModule } from './manage-benefits-routing.module';
import { EmployeeProfileComponent } from './employee-profile/employee-profile.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeInformationComponent } from './employee-information/employee-information.component';
import { EmployeeContactInformationComponent } from './employee-contact-information/employee-contact-information.component';
import { EmployeeBenefitSelectionComponent } from './employee-benefit-selection/employee-benefit-selection.component';
import { EmployeeDependentListComponent } from './employee-dependent-list/employee-dependent-list.component';
import { EmployeeTerminateCoverageComponent } from './employee-terminate-coverage/employee-terminate-coverage.component';
import { LandingPageModule } from '../landing-page/landing-page.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ManageBenefitsComponent } from './manage-benefits.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeBenefitSelectionEditComponent } from './employee-benefit-selection-edit/employee-benefit-selection-edit.component';
import { OverlaySidePanelModule } from '../shared/components/overlay-side-panel/overlay-side-panel.module';
import { SpinnerModule } from '../shared/components/spinner/spinner.module';
import { NgxPrintModule } from 'ngx-print';
import { EmployeeDependentEditComponent } from './employee-dependent-edit/employee-dependent-edit.component';
import { EmployeeTerminateCoverageEditComponent } from './employee-terminate-coverage-edit/employee-terminate-coverage-edit.component';
import { EmployeeDependentAddComponent } from './employee-dependent-add/employee-dependent-add.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { AlertModule } from '../shared/components/alert/alert.module';
import { TooltipModule, TooltipOptions } from 'ng2-tooltip-directive';
import { TooltipDefaultOptions } from '../shared/providers/tooltipDefaultOptions';
import { AngularMaterialModule } from '../shared/modules/angular-material.module';
import { ValidationDirectivesModule } from '../shared/modules/validation-directives.Module';
import { SortableDirectiveModule } from '../shared/modules/sortable-directive.module';

@NgModule({
  declarations: [
    EmployeeProfileComponent,
    EmployeeListComponent,
    EmployeeInformationComponent,
    EmployeeContactInformationComponent,
    EmployeeBenefitSelectionComponent,
    EmployeeDependentListComponent,
    EmployeeTerminateCoverageComponent,
    ManageBenefitsComponent,
    EmployeeBenefitSelectionEditComponent,
    EmployeeDependentEditComponent,
    EmployeeTerminateCoverageEditComponent,
    EmployeeDependentAddComponent,
  ],
  imports: [
    CommonModule,
    NgbModule,
    ManageBenefitsRoutingModule,
    LandingPageModule,
    FormsModule,
    ReactiveFormsModule,
    OverlaySidePanelModule,
    SpinnerModule,
    NgxPrintModule,
    NgSelectModule,
    AlertModule,
    TooltipModule.forRoot(TooltipDefaultOptions as TooltipOptions),
    AngularMaterialModule,
    ValidationDirectivesModule,
    SortableDirectiveModule,
  ],
})
export class ManageBenefitsModule {}
