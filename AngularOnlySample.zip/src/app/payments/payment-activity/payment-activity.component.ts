import {
  Component,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { PaymentsService } from '../shared/payments.service';
import { IPaymentHistory } from '../shared/payment-history.model';
import { Observable, Subscription } from 'rxjs';
import { SpinnerService } from 'src/app/shared/components/spinner/spinner.service';
import {
  NgbdSortableHeader,
  SortEvent,
} from '../../shared/directives/sortable.directive';
import { ISummary } from 'src/app/shared/models/summary.model';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-payment-activity',
  templateUrl: './payment-activity.component.html',
  styleUrls: ['./payment-activity.component.scss'],
})
export class PaymentActivityComponent implements OnInit, OnDestroy {
  paymentsHistory: IPaymentHistory[];
  total$: Observable<number>;
  payments$: Observable<IPaymentHistory[]>;
  sortColumnsIco: any = {
    paymentTransactionDate: 'sort',
    accountName: 'sort',
    statusName: 'sort',
  };
  account: ISummary;
  subscriptions: Subscription[] = [];
  @ViewChildren(NgbdSortableHeader) headers: QueryList<NgbdSortableHeader>;

  constructor(
    public paymentsService: PaymentsService,
    private _spinnerService: SpinnerService
  ) {
    this.account = JSON.parse(localStorage.getItem('account') || '[]');
    _spinnerService.show(true);
    let subscription = this.paymentsService
      .getList(this.account.accountId)
      .subscribe(
        (data) => {
          this.paymentsService.paymentsHistoryList = data!;
          this.payments$ = paymentsService.payments$;
          this.total$ = paymentsService.total$;
          paymentsService.search();
          paymentsService.loading$.subscribe({
            next(loading) {
              _spinnerService.show(loading);
            },
          });
        },
        (error: HttpErrorResponse) => {
          _spinnerService.show(false);
        }
      );
    this.subscriptions.push(subscription);
  }

  ngOnInit(): void {}
  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }
  onSort({ column, direction }: SortEvent) {
    this.sortColumnsIco[column] = this.setDirectionIco(direction, column);
    this.headers.forEach((header) => {
      if (header.sortable !== column) {
        header.direction = '';
        this.sortColumnsIco[header.sortable] = this.setDirectionIco(
          header.direction,
          header.sortable
        );
      }
    });

    this.paymentsService.sortColumn = column;
    this.paymentsService.sortDirection = direction;
  }

  setDirectionIco(direction: string, column: string): string {
    if (direction !== '') {
      return 'sort-' + direction;
    } else {
      return 'sort';
    }
  }
}
