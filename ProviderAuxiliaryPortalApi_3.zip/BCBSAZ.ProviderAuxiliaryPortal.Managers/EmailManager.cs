﻿using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using System.Collections.Generic;
using System.Net.Mail;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Managers
{
    public class EmailManager : IEmailManager
    {
        private readonly IEmailRepository _emailRepository;
        
        public EmailManager(IEmailRepository emailRepository)
        {
            _emailRepository = emailRepository;
        }

        public async Task<bool> SendExternalMessageAsync(string fromAddress, string toAddress, string subject, string body)
        {
            return await _emailRepository.SendExternalEmailAsync(fromAddress, toAddress, subject, body);
        }

        public async Task<bool> SendInternalMessageAsync(string fromAddress, string toAddress, string subject, string body, IEnumerable<Attachment> attachments)
        {
            return await _emailRepository.SendInternalEmailAsync(fromAddress, toAddress, subject, body, attachments);
        }
    }
}
