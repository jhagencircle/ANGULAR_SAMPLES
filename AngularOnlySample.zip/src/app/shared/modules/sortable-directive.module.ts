import { NgModule } from '@angular/core';
import { NgbdSortableHeader } from '../directives/sortable.directive';

@NgModule({
  exports: [NgbdSortableHeader],
  declarations: [NgbdSortableHeader],
  providers: [NgbdSortableHeader],
})
export class SortableDirectiveModule {}
