﻿using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Managers.Mappers;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Remits;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Managers.ApiClients
{
	public class OnlineRemitsApiClient : ApiClientBase, IOnlineRemitsApiClient
	{
		protected override string Name => "Online Remits API";

		public OnlineRemitsApiClient(IConfiguration configuration, IOktaApiClient oktaClient) : base(oktaClient)
		{
			base.Timeout = new TimeSpan(0, 0, configuration.GetValue<int>(Constants.Configuration.Timeouts.OnlineRemitsTimeout));
			var serviceUrl = configuration.GetValue<string>(Constants.Configuration.OnlineRemitsApiUrl);

			if (string.IsNullOrWhiteSpace(serviceUrl))
				throw new ArgumentException("Invalid Service Url specified for Online Remits API.");

			BaseAddress = new Uri(serviceUrl.EnsureEndsWith('/'));

			DefaultRequestHeaders.Clear();
			DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
		}

		public async Task<IEnumerable<ProviderRemittance>> GetRemitsAsync(RemitSearchRequest request)
		{
			try
			{
				ProviderRemittanceRequest convertedRequest = OnlineRemitsMapper.ConvertAPIRequest(request);
				IEnumerable<ProviderRemittanceResponse> response = await PostAsync<IEnumerable<ProviderRemittanceResponse>>(Constants.OnlineRemitsApis.ProviderRemits, convertedRequest);

				//TODO: We may want to go ahead and return it in the right format 
				return OnlineRemitsMapper.ConvertApiResponse(response);
			}
			catch (InvalidApiResponseException ex)
			{
				if (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
				{
					return new List<ProviderRemittance>();
				}
				else
				{
					throw;
				}
			}
		}
	}
}
