﻿using System;
using System.Collections.Generic;
using System.Text;
using BCBSAZ.Provider.Models.Xml271Processor.Interfaces;

namespace BCBSAZ.Provider.Repositories.Mapper
{
	public interface IBenefitMapper<out T>
	{
		IEnumerable<T> Map(IEligibilityBenefit[] benefitsA, IEligibilityBenefit[] benefitsB);
	}
}
