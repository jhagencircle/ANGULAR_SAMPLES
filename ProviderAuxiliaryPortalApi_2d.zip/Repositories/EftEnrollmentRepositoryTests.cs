﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using Microsoft.EntityFrameworkCore;
using NSubstitute;
using System;
using Xunit;

namespace BCBSAZ.ProviderAuxiliaryPortal.UnitTests.Repositories
{
    public class EftEnrollmentRepositoryTests
    {
        private readonly IEftEnrollmentRepository _eftEnrollmentRepository;
        private readonly ProviderEftDbContext _providerEftDbContext;


        public EftEnrollmentRepositoryTests()
        {
            var option = new DbContextOptionsBuilder<ProviderEftDbContext>()
              .UseInMemoryDatabase("Test.DB").Options;

            _providerEftDbContext = Substitute.For<ProviderEftDbContext>(option);
            _eftEnrollmentRepository = new EftEnrollmentRepository(_providerEftDbContext);
        }

        [Fact]
        
        public void CreateEftRecord_Success()
        {
            //Arrange            
            EftEnrollmentRequest getdata = new EftEnrollmentRequest()
            {
                ProviderAddress = "Tonya"
            };
                                 
            // Act
            var result = _eftEnrollmentRepository.SaveEftEnrollmentRequestAsync(getdata);

            // Assert
              result.Equals(true);
        }

}
}
