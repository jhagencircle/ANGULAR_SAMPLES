﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace BCBSAZ.ProviderCredentialing.WebUI
{
	[SuppressMessage("Design", "CA1032:Implement standard exception constructors", Justification = "Additional constructors are not required.")]
	public class SitecoreRequestException : Exception
	{
		public SitecoreRequestException(string message) : base(message) { }
	}
}
