﻿using BCBSAZ.ProviderCredentialing.WebUI.Models.Enums;
using System.Collections.Generic;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{

	/// <summary>
	/// 
	/// </summary>
	/// <remarks>
	/// Used to separate the difference between normal addresses (with required fields) and
	/// Addtional Address (with non-required fields)
	/// </remarks>
	public interface IAddress
	{
		string City { get; set; }

		string EmailAddress { get; set; }

		string Fax { get; set; }

		string Phone { get; set; }

		string State { get; set; }

		string StreetAddress { get; set; }

		string ZipCode { get; set; }

		ICollection<AddressType> Types { get; set; }

	}
}