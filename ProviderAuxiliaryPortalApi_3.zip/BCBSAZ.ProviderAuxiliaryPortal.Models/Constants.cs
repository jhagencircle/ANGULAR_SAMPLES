﻿using System;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models
{
    public static class Constants
    {
        public static class StoredProcedure
        {
            public static class Email
            {
                public const string QUEQUE_EMAIL = "dbo.usp_QueueEmail @p0, @p1, @p2, @p3, @p4, @p5";
            }

            public static class ProviderInet
            {
                public const string GET_USERPROFILE = "oum.GetUserProfile @p0";
                public const string INSERT_USERPROFILE = "oum.InsertUserProfile @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11";
                public const string SET_PROVIDERS_FOR_USER = "oum.SetProvidersForUser @p0, @p1, @p2, @p3";
                public const string UPDATE_USERPROFILE = "oum.UpdateUserProfile @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7";
                public const string DELETE_USERPROFILE = "oum.DeleteUserProfile @p0, @p1";
            }
        }
    }
}
