﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Microsoft.Extensions.Logging
{
	public class LogMessageQueueProcessor : BackgroundService
	{
		private readonly LogMessageQueue _logMessages;
		private readonly ILogMessageStorage _storage;

		public LogMessageQueueProcessor(LogMessageQueue logMessages, IServiceProvider services)
		{
			_logMessages = logMessages;
			_storage = services.GetService<ILogMessageStorage>();
		}

		protected override async Task ExecuteAsync(CancellationToken stoppingToken)
		{
			if (_storage == null)
				return;

			while (!stoppingToken.IsCancellationRequested)
			{
				while (_logMessages.TryDequeue(out LogMessage logMessage))
				{
					await _storage.StoreAsync(logMessage);
				}

				await Task.Delay(1000, stoppingToken);
			}
		}
	}
}
