﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models.Data.Eligibility;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Xml271Processor.Codes;
using BCBSAZ.Provider.Models.Xml271Processor.Interfaces;

namespace BCBSAZ.Provider.Repositories.Mapper
{
	internal class ServiceTypeMapper : IBenefitMapper<ServiceTypeDeductible>
	{
		/// <summary>
		/// Maps a deductible limit object for a service type with a matching remaining 
		/// </summary>
		/// <param name="limitArr">array of limit 271 objects</param>
		/// <param name="remainingArr">array of remaining 271 objects</param>
		/// <returns>Enumerable collection of ServiceTypeBenefit objects</returns>
		public IEnumerable<ServiceTypeDeductible> Map(IEligibilityBenefit[] limitArr, IEligibilityBenefit[] remainingArr)
		{
			for (var i = 0; i < limitArr.Length; i++)
			{
				var limit = limitArr.ElementAt(i);
				var limitAdditionalBenefitInfo = limitArr.ElementAtOrDefault(i)?.AdditionalBenefitInformation;
				var remaining = remainingArr.ElementAtOrDefault(i);
				var messages = new List<string>(from x in limitArr[i].Messages select x.Text);

				if (remaining != null)
					messages.AddRangeIfNotNullOrEmpty(from x in remaining.Messages select x.Text);

				yield return new ServiceTypeDeductible()
				{
#if DEBUG
					EbLoopSegment = limit.BenefitInformation.EligibilityOrBenefitInformation,
#endif
					IsOutOfPocket = limit.BenefitInformation.EligibilityOrBenefitInformation.Equals(BenefitInfoTypes.Out_of_Pocket_Stop_Loss_, StringComparison.OrdinalIgnoreCase),
					CoverageLevel = CoverageLevel.I.Find(x => x.Code.Equals(limit.BenefitInformation.CoverageLevel, StringComparison.OrdinalIgnoreCase))?.Name ?? "N/A",
					PlaceOfService = limitAdditionalBenefitInfo.GetPlaceOfService(),
					TimePeriod = (limit.BenefitInformation.TimePeriodQualifier != null) ? TimePeriod.I.Find(x => x.Code == limit.BenefitInformation.TimePeriodQualifier).Name : "N/A",
					Limit = new Limit
					{
						Amount = decimal.TryParse(limit.BenefitInformation.BenefitAmount, out var limitAmt) ? (decimal?)limitAmt : null,
						IsLimitCurrency = true,
						LimitDescription = (limit.BenefitInformation.TimePeriodQualifier != null) ? TimePeriod.I.Find(x => x.Code == limit.BenefitInformation.TimePeriodQualifier).Name : null,
						AuthorizationStatus = limit.BenefitInformation.GetAuthorizationStatus()
					},
					Remaining = new Remaining
					{
						Amount = decimal.TryParse(remaining?.BenefitInformation.BenefitAmount, out var remainingAmt) ? (decimal?)remainingAmt : null,
						AuthorizationStatus = remaining?.BenefitInformation.GetAuthorizationStatus()
					},					
					AdditionalInformation = new AdditionalInformation
					{
						HealthCareServiceDeliveries = limit.GetHealthCareServicesDelivery(),
						Other = messages.Distinct()
					}
				};
			}
		}
	}
}
