import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { IPlan } from '../shared/models/plan.model';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { IBenefit } from '../shared/models/benefit.model';
import { IEmployee } from '../shared/models/employee.model';
import { ISummary } from 'src/app/shared/models/summary.model';
import { PlanService } from '../shared/plan.service';
import { AccountService } from 'src/app/shared/services/account.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ICoverage } from '../shared/models/coverage.model';
import { CoverageService } from '../shared/coverage.service';
import { SpinnerService } from 'src/app/shared/components/spinner/spinner.service';
import { MedicareTypeEnum } from '../shared/medicare-type.enum';
import { HealthPlanTypeEnum } from '../shared/health-plan-type-enum';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-employee-benefit-selection-edit',
  templateUrl: './employee-benefit-selection-edit.component.html',
  styleUrls: ['./employee-benefit-selection-edit.component.scss'],
})
export class EmployeeBenefitSelectionEditComponent
  implements OnInit, OnDestroy
{
  @Input() benefitSelection: IBenefit;
  @Input() employeeInformation: IEmployee;
  @Output() showBenefitEdit = new EventEmitter<boolean>();
  @Output() sendForm = new EventEmitter<any>();

  healthPlan: IPlan | undefined;
  dentalPlan: IPlan | undefined;
  lifePlan: IPlan | undefined;
  account: ISummary;
  healthInsurancePlans: IPlan[];
  dentalInsurancePlans: IPlan[];
  lifeInsurancePlans: IPlan[];
  coverages: ICoverage[];
  dentalCoverages: string;
  activeSave: boolean = false;
  medicareTypes = MedicareTypeEnum;
  subscriptions: Subscription[] = [];
  form: FormGroup;

  get f() {
    return this.form.controls;
  }

  constructor(
    public fb: FormBuilder,
    public planService: PlanService,
    public accountService: AccountService,
    private coverageService: CoverageService,
    public _spinnerService: SpinnerService
  ) {}

  loadAccounts() {
    let subscription = this.accountService
      .get()
      .subscribe((account: ISummary) => {
        if (account) {
          this.account = account;
          this.getBenefitLists();
        }
      });
    this.subscriptions.push(subscription);
  }

  ngOnInit(): void {
    this.createForm();
    this.loadAccounts();
    this.setFormValues();
    this.onChanges();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  onChanges(): void {
    this.form.valueChanges.subscribe((val) => {
      this.activeSave = true;
    });
  }

  createForm() {
    this.form = this.fb.group({
      healthInsuranceBenefit: ['', [Validators.required]],
      healthCoverage: ['', [Validators.required]],
      dentalInsuranceBenefit: ['', [Validators.required]],
      dentalCoverage: ['', [Validators.required]],
      lifeInsuranceBenefit: ['', [Validators.required]],
      lifeCoverage: ['', [Validators.required]],
      hasMedicare: ['', [Validators.required]],

      flexibleSpendingSelection: [{ value: '', disabled: true }],
      medicareType: [''],
      medicareNumber: [''],
      partAEffectiveDate: [''],
      partBEffectiveDate: [''],
    });
  }

  setFormValues() {
    let medicareType;
    let medicareKeys = Object.keys(MedicareTypeEnum);
    let medicareValues = Object.values(MedicareTypeEnum);

    if (
      this.benefitSelection?.partAEffectiveDate &&
      this.benefitSelection?.partBEffectiveDate
    ) {
      medicareType =
        medicareKeys[medicareValues.indexOf(MedicareTypeEnum.Both)];
    } else if (this.benefitSelection?.partAEffectiveDate) {
      medicareType =
        medicareKeys[medicareValues.indexOf(MedicareTypeEnum.PartA)];
    } else if (this.benefitSelection?.partBEffectiveDate) {
      medicareType =
        medicareKeys[medicareValues.indexOf(MedicareTypeEnum.PartB)];
    }

    this.healthPlan = this.benefitSelection?.planSelection.find((p) => {
      if (p.type.toLowerCase().includes(HealthPlanTypeEnum.Medical)) {
        return p;
      } else return null;
    });
    this.dentalPlan = this.benefitSelection?.planSelection.find((p) => {
      if (p.type.toLowerCase().includes(HealthPlanTypeEnum.Dental)) {
        return p;
      } else return null;
    });
    this.lifePlan = this.benefitSelection?.planSelection.find((p) => {
      if (p.type.toLowerCase().includes(HealthPlanTypeEnum.Life)) {
        return p;
      } else return null;
    });
    let coverageSubscription = this.coverageService.get().subscribe((data) => {
      this.coverages = data;
    });
    this.subscriptions.push(coverageSubscription);
    this.form.setValue({
      healthInsuranceBenefit: this.healthPlan ? this.healthPlan.id : '',
      healthCoverage:
        this.healthPlan && this.healthPlan.coverageID
          ? this.healthPlan.coverageID
          : '',
      dentalInsuranceBenefit: this.dentalPlan ? this.dentalPlan.id : '',
      dentalCoverage:
        this.dentalPlan && this.dentalPlan.coverageID
          ? this.dentalPlan.coverageID
          : '',
      lifeInsuranceBenefit: this.lifePlan ? this.lifePlan?.id : '',
      lifeCoverage:
        this.lifePlan && this.lifePlan.coverageID
          ? this.lifePlan.coverageID
          : '',
      hasMedicare: this.benefitSelection.eligibleForMedicare
        ? this.benefitSelection?.eligibleForMedicare.toString()
        : 'false',
      medicareNumber: this.benefitSelection?.medicareNumber
        ? this.benefitSelection?.medicareNumber
        : '',

      partAEffectiveDate: this.benefitSelection?.partAEffectiveDate
        ? new Date(this.benefitSelection?.partAEffectiveDate)
        : null,
      partBEffectiveDate: this.benefitSelection?.partBEffectiveDate
        ? new Date(this.benefitSelection?.partBEffectiveDate)
        : null,

      flexibleSpendingSelection: this.benefitSelection.flexibleSpendingSelection
        ? this.benefitSelection?.flexibleSpendingSelection.toString()
        : 'false',
      medicareType: medicareType ? medicareType : '',
    });
  }

  getBenefitLists() {
    this._spinnerService.show(true);
    let medicalPlansSubscription = this.planService
      .getByAccountPlanType(this.account.accountId, HealthPlanTypeEnum.Medical)
      .subscribe(
        (data) => {
          this._spinnerService.show(false);
          this.healthInsurancePlans = data.map((h) => {
            h.type = HealthPlanTypeEnum.Medical;
            return h;
          });
          if (this.healthInsurancePlans) {
            this.f.healthInsuranceBenefit.enable();
            this.f.healthCoverage.enable();
          } else {
            this.f.healthInsuranceBenefit.disable();
            this.f.healthCoverage.disable();
          }
        },
        (error: HttpErrorResponse) => {
          if (error.status == 404) {
            //There aren't health plans for the account
            this.f.healthInsuranceBenefit.disable();
            this.f.healthCoverage.disable();
          }
        }
      );
    this._spinnerService.show(true);
    let dentalPlansSubscription = this.planService
      .getByAccountPlanType(this.account.accountId, HealthPlanTypeEnum.Dental)
      .subscribe(
        (data) => {
          this._spinnerService.show(false);
          this.dentalInsurancePlans = data;
          if (this.dentalInsurancePlans) {
            this.f.dentalInsuranceBenefit.enable();
            this.f.dentalCoverage.enable();
          } else {
            this.f.dentalInsuranceBenefit.disable();
            this.f.dentalCoverage.disable();
          }
        },
        (error: HttpErrorResponse) => {
          if (error.status == 404) {
            //There aren't life plans for the account
            this.f.dentalInsuranceBenefit.disable();
            this.f.dentalCoverage.disable();
          }
        }
      );
    this._spinnerService.show(true);
    let lifePlansSubscription = this.planService
      .getByAccountPlanType(this.account.accountId, HealthPlanTypeEnum.Life)
      .subscribe(
        (data) => {
          this._spinnerService.show(false);
          this.lifeInsurancePlans = data;
          if (this.lifeInsurancePlans) {
            this.f.lifeInsuranceBenefit.enable();
            this.f.lifeCoverage.enable();
          } else {
            this.f.lifeInsuranceBenefit.disable();
            this.f.lifeCoverage.disable();
          }
        },
        (error: HttpErrorResponse) => {
          if (error.status == 404) {
            //There aren't life plans for the account
            this.f.lifeInsuranceBenefit.disable();
            this.f.lifeCoverage.disable();
          }
        }
      );
    this.subscriptions.push(medicalPlansSubscription);
    this.subscriptions.push(dentalPlansSubscription);
    this.subscriptions.push(lifePlansSubscription);
  }

  close() {
    this.showBenefitEdit.emit(false);
  }

  save() {
    this.addFieldValidations();
    if (this.form.valid) {
      let healthPlan = this.healthInsurancePlans
        ? this.healthInsurancePlans.find(
            (p) => p.id == this.f.healthInsuranceBenefit.value
          )!
        : null;

      let healthPlanCoverage = this.f.healthCoverage.value;

      let dentalPlan = this.dentalInsurancePlans
        ? this.dentalInsurancePlans.find(
            (p) => p.id == this.f.dentalInsuranceBenefit.value
          )!
        : null;

      let dentalPlanCoverage = this.f.dentalCoverage.value;
      let lifePlan = this.lifeInsurancePlans
        ? this.lifeInsurancePlans.find(
            (p) => p.id == this.f.lifeInsuranceBenefit.value
          )!
        : null;
      let lifePlanCoverage = this.f.lifeCoverage.value;

      let effectiveDatePartA = this.f.partAEffectiveDate.value;
      let effectiveDatePartB = this.f.partBEffectiveDate.value;

      this.benefitSelection.planSelection = [];
      if (healthPlan) {
        healthPlan.coverageID = healthPlanCoverage;
        this.benefitSelection.planSelection.push(healthPlan);
      }
      if (dentalPlan) {
        dentalPlan.coverageID = dentalPlanCoverage;
        this.benefitSelection.planSelection.push(dentalPlan);
      }
      if (lifePlan) {
        lifePlan.coverageID = lifePlanCoverage;
        this.benefitSelection.planSelection.push(lifePlan);
      }
      this.benefitSelection.eligibleForMedicare = this.f.hasMedicare.value;

      this.benefitSelection.medicareNumber =
        this.f.hasMedicare.value == false ? '' : this.f.medicareNumber.value;
      this.benefitSelection.partAEffectiveDate =
        this.f.hasMedicare.value == false ? '' : effectiveDatePartA;
      this.benefitSelection.partBEffectiveDate =
        this.f.hasMedicare.value == false ? '' : effectiveDatePartB;

      this.close();
    }
    this.sendForm.emit({
      benefitSelection: this.benefitSelection,
    });
    this.activeSave = false;
  }

  changeMedicare(e: any) {
    if (e.target.value == false) {
      this.f.medicareNumber.setValue('');
      this.f.medicareType.setValue('');
      this.f.partAEffectiveDate.setValue(null);
      this.f.partBEffectiveDate.setValue(null);
    }
  }

  changeMedicareType(e: any) {
    this.f.partAEffectiveDate.setValue(null);
    this.f.partBEffectiveDate.setValue(null);
  }

  addFieldValidations() {
    this.f.medicareNumber.clearValidators();
    this.f.medicareNumber.updateValueAndValidity();
    this.f.medicareType.clearValidators();
    this.f.medicareType.updateValueAndValidity();
    this.f.partAEffectiveDate.clearValidators();
    this.f.partAEffectiveDate.updateValueAndValidity();
    this.f.partBEffectiveDate.clearValidators();
    this.f.partBEffectiveDate.updateValueAndValidity();
    if (this.f.hasMedicare.value) {
      this.f.medicareNumber.setValidators([Validators.required]);
      this.f.medicareNumber.updateValueAndValidity();
      this.f.medicareType.setValidators([Validators.required]);
      this.f.medicareType.updateValueAndValidity();
      if (
        this.f.medicareType.value == MedicareTypeEnum.Both ||
        this.f.medicareType.value == MedicareTypeEnum.PartA
      ) {
        this.f.partAEffectiveDate.setValidators([Validators.required]);
        this.f.partAEffectiveDate.updateValueAndValidity();
      }
      if (
        this.f.medicareType.value == MedicareTypeEnum.Both ||
        this.f.medicareType.value == MedicareTypeEnum.PartB
      ) {
        this.f.partBEffectiveDate.setValidators([Validators.required]);
        this.f.partBEffectiveDate.updateValueAndValidity();
      }
    }
  }
}
