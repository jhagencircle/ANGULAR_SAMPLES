﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System
{
	public static class NullableDateExtensions
	{
		public static string ToString(this DateTime? value, string format, string defaultValue = "")
		{
			return value.HasValue ? value.Value.ToString(format) : defaultValue;
		}
	}
}
