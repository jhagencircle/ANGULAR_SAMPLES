import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { IStatement } from 'src/app/historical-statements/shared/statement.model';
import { ICurrentBill } from '../models/current-bill.model';

@Injectable({
  providedIn: 'root',
})
export class HistoricalStatementMock {
  constructor() {}
  public static mockedHistoricalStatement: IStatement[] = [
    {
      billingPeriodFromDate: new Date('2020-07-01'),
      billingPeriodToDate: new Date('2020-07-31'),
      statementDate: new Date('2020-07-01'),
      dueDate: new Date('2020-07-01'),
      isLegacy: true,
      billingStatementId: '1234',
      accountName: 'Account 01',
      accountNickName: 'Account 01',
      status: 'Due',
      paymentAmount: 8000.0,
      accountId: '01',
      isLoading: false,
    },
    {
      billingPeriodFromDate: new Date('2020-06-01'),
      billingPeriodToDate: new Date('2020-06-30'),
      statementDate: new Date('2020-07-01'),
      dueDate: new Date('2020-07-01'),
      isLegacy: true,
      billingStatementId: '4321',
      accountName: 'Account 02',
      accountNickName: 'Account 02',
      status: 'Due',
      paymentAmount: 18300.0,
      accountId: '02',
      isLoading: false,
    },
    {
      billingPeriodFromDate: new Date('2020-06-01'),
      billingPeriodToDate: new Date('2020-06-31'),
      statementDate: new Date('2020-06-01'),
      dueDate: new Date('2020-06-01'),
      isLegacy: true,
      billingStatementId: '2143',
      accountName: 'Account 01',
      accountNickName: 'Account 01',
      status: 'Due',
      paymentAmount: 7009.0,
      accountId: '01',
      isLoading: false,
    },
  ];

  public get(accountId: string): Observable<IStatement[]> {
    accountId = '01';
    return of(
      HistoricalStatementMock.mockedHistoricalStatement.filter(
        (s) => s.accountId == accountId
      )
    );
  }
}
