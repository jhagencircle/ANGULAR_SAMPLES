﻿using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Models.UserProfile;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.WebAPI.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class UserProfileController : ControllerBase
    {
        private readonly IUserProfileManager _userProfileManager;

        public UserProfileController(IUserProfileManager userProfileManager)
        {
            _userProfileManager = userProfileManager;
        }

        /// <summary>
        /// This is used to create a user profile
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="orgId"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("Create")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public async Task<ActionResult> CreateUserProfile([FromBody] UserProfileRequest request)
        {
            try
            {
                var result = await _userProfileManager.CreateUserProfileAsync(request);
                return  StatusCode(201, "User Profile successfully created.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }


        /// <summary>
        /// Used to retrieve a user profile  akafred
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpGet("{userId}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public async Task<ActionResult> ReadUserProfile([FromRoute] string userId)
        {
            try
            {
                var response = await _userProfileManager.GetUserProfileAsync(userId);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }

        }

        /// <summary>
        /// Used to Update user profile
        /// </summary>
        /// <returns></returns>
        [HttpPost("Update")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public async Task<ActionResult> UpdateUserProfile([FromBody] UserProfileRequest request)
        {
            try
            {
                var response = await _userProfileManager.UpdateUserProfileAsync(request);
                return Ok("User profile successfully update");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        /// <summary>
        /// Remove user profile
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="orgId"></param>
        /// <returns></returns>
        [HttpDelete("Remove/{userId}/{orgId}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public async Task<ActionResult> DeleteUserProfile([FromRoute] string userId, [FromRoute] string orgId)
        {
            try
            {
                var result = await _userProfileManager.DeleteUserProfileAsync(orgId, userId);
                return Ok("User Profile successfully deleted");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }
    }
}
