import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { PaymentConfirmationClaimsInvoiceComponent } from './payment-confirmation-claims-invoice.component';
import { RouterTestingModule } from '@angular/router/testing';
import { DecimalPipe } from '@angular/common';

describe('PaymentConfirmationClaimsInvoiceComponent', () => {
  let component: PaymentConfirmationClaimsInvoiceComponent;
  let fixture: ComponentFixture<PaymentConfirmationClaimsInvoiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [PaymentConfirmationClaimsInvoiceComponent, DecimalPipe],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(
      PaymentConfirmationClaimsInvoiceComponent
    );
    component = fixture.componentInstance;
    var store = [
      {
        account: 'Top Account A',
        bankAccount: 'NB,1706',
        billingPeriod: 'July, 2021',
        paymentAmount: 1,
        paymentTransactionDate: '2021-08-09T07:00:00.000Z',
        paymentTransactionNumber: 'RXI4N87JKRUKNZAB',
        statusName: 'PENDING',
      },
    ];
    var storeSintringify = JSON.stringify(store);
    spyOn(localStorage, 'getItem').and.callFake((key: string): any => {
      return storeSintringify;
    });

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
