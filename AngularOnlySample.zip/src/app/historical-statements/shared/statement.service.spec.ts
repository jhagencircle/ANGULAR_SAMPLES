import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { StatementService } from './statement.service';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { IStatement } from './statement.model';
import { HistoricalStatementMock } from 'src/app/shared/mocks/historical-statement.mock';
import { of } from 'rxjs';

describe('StatementService', () => {
  let service: StatementService;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let testUrl: string = '';
  let baseUrl: string = '';
  let httpClientSpy: { get: jasmine.Spy };

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [HttpClientTestingModule] });

    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    //service = TestBed.inject(StatementService);
    service = new StatementService(httpClientSpy as any);

    // Inject the http service and test controller for each test
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);

    baseUrl = `${environment.apiUrl}/api`;
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get Historical Statements', () => {
    const testData: IStatement[] =
      HistoricalStatementMock.mockedHistoricalStatement;
    const accountId = '01';
    testUrl = `${baseUrl}/Employer/${accountId}/historicalStatements`;

    httpClient
      .get<IStatement[]>(testUrl)
      .subscribe((data) => expect(data).toEqual(testData));

    const req = httpTestingController.expectOne(testUrl);

    expect(req.request.method).toEqual('GET');

    req.flush(testData);
  });

  it('should get statement file', () => {
    const testData: IStatement[] =
      HistoricalStatementMock.mockedHistoricalStatement;
    const statement = testData[0];
    httpClientSpy.get.and.returnValue(of(true));
    service
      .downloadPDF(statement)
      .subscribe((result: any) => expect(result).toBeTruthy, fail);
    expect(httpClientSpy.get.calls.count()).toBe(1);
  });
});
