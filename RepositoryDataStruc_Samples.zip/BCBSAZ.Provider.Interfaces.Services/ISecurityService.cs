﻿using BCBSAZ.Provider.Models.Data.Security;
using BCBSAZ.Provider.Models.Responses.Security;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface ISecurityService
	{
		Task<AuthenticateUserResponse> AuthenticateUserAsync(string userId);
		Task<AuthenticateUserResponse> AuthenticateTokenUserAsync(PortalUser precertUser);
		Task<RefreshAuthenticationResponse> RefreshAuthenticationAsync(string userId);
		Task<AuthenticateUserResponse> AuthenticateUserFromTokenAsync(string token);
	}
}
