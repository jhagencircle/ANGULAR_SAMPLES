﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.PreCert;
using BCBSAZ.Provider.Models.Requests.PreCert;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.PreCert
{
	internal static class SavePharmacyPreCertRequestValidator
	{
		public static void Validate(this SavePharmacyPreCertRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(SavePharmacyPreCertRequest request)
		{
			if (request.Status == PreCertStatus.Pending)
			{
				if (string.IsNullOrWhiteSpace(request.Form.MemberFirstName))
					yield return new InvalidModelExceptionDetail(nameof(SavePharmacyPreCertRequest.Form.MemberFirstName), new ArgumentException("Member's first name is Required."));


				// TODO: check the rest of the required fields.

			}
		}
	}
}
