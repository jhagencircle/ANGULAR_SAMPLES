﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System.ComponentModel.DataAnnotations
{
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, AllowMultiple = false)]
	public class InputMaskAttribute : ValidationAttribute
	{
		public InputMaskAttribute() { }

		public InputMaskAttribute(string value)
		{
			InputMask = value ?? throw new ArgumentNullException("InputMask");
		}

		public string InputMask { get; set; }

		protected override ValidationResult IsValid(object value, ValidationContext validationContext)
		{
			return ValidationResult.Success;
		}

	}
}
