﻿namespace BCBSAZ.Provider.Managers
{
	internal static class ManagerConstants
	{
		public const char CSV = ',';

		public static class FeeSchedule
		{
			public const string ProfNonFacilityCode = "PNF";
			public const string ProfASCFacilityCode = "PAF";
			public const string ProfNonASCFacilityCode = "NAF";

			public const string OutpatientCode = "OP";

			public const string AscCode = "ASC";

			/// <summary>
			/// Gets the list of valid Professional Site of Service Codes
			/// </summary>
			public static readonly string[] ProfessionalSOSCodes = new string[] { ProfNonFacilityCode, ProfASCFacilityCode, ProfNonASCFacilityCode };

			/// <summary>
			/// Gets the list of valid Outpatient Site of Service Codes
			/// </summary>
			public static readonly string[] OutpatientSOSCodes = new string[] { OutpatientCode };

			public static readonly string[] AscSOSCodes = new string[] { AscCode };
		}
	}
}
