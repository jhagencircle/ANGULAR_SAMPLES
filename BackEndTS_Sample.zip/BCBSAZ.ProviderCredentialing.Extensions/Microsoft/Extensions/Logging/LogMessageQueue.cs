﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Microsoft.Extensions.Logging
{
	public class LogMessageQueue : Queue<LogMessage>
	{
	}
}
