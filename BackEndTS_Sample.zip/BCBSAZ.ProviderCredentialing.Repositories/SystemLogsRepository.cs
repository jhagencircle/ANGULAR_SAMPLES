﻿using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.Interfaces.Repositories;
using BCBSAZ.ProviderCredentialing.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.ProviderCredentialing.Repositories
{
	public class SystemLogsRepository : ISystemLogsRepository
	{
		private readonly ISystemLogsContext _context;

		public SystemLogsRepository(ISystemLogsContext context) => _context = context;

		public async Task InsertLogMessageAsync(LogMessage message)
		{
			await _context.Database.ExecuteSqlRawAsync(
				DB.SystemLogs.StoredProcs.LogException,
				message.ParentException,
				message.IsHandled,
				message.UserId,
				message.SessionId,
				message.Source,
				message.Member,
				message.Url,
				message.RefererUrl,
				message.HttpUserAgent,
				message.Form,
				message.QueryString,
				message.Message,
				message.StackTrace,
				message.AdditionalInfo);
		}
	}
}
