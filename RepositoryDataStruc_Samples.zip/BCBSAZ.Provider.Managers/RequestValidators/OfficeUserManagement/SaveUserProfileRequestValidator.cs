﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.OfficeUserManagement;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.OfficeUserManagement
{
	internal static class SaveUserProfileRequestValidator
	{
		public static void Validate(this SaveUserProfileRequest request, WebUser webUser)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (webUser == null)
				throw new ArgumentNullException(nameof(webUser));

			var violations = Violations(request, webUser);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static readonly Regex _nonNumeric = new Regex("[^0-9]", RegexOptions.Compiled);

		private static IEnumerable<InvalidModelExceptionDetail> Violations(SaveUserProfileRequest request, WebUser webUser)
		{
			if (string.IsNullOrWhiteSpace(webUser.OrgId))
				yield return new InvalidModelExceptionDetail(nameof(WebUser.OrgId), new ArgumentException("Invalid OrgId specified."));

			if (request.UserProfile == null)
			{
				yield return new InvalidModelExceptionDetail(nameof(SaveUserProfileRequest.UserProfile), new ArgumentException("No User Profile provided."));
			}
			else
			{
				if (string.IsNullOrWhiteSpace(request.UserProfile.Username))
					yield return new InvalidModelExceptionDetail(nameof(SaveUserProfileRequest.UserProfile.Username), new ArgumentException("Invalid Username specified."));

				if (request.PasswordReset)
				{
					if (string.IsNullOrWhiteSpace(request.UserProfile.Password))
						yield return new InvalidModelExceptionDetail(nameof(SaveUserProfileRequest.UserProfile.Password), new ArgumentException("Invalid Password specified."));

					if (!string.Equals(request.UserProfile.Password, request.UserProfile.ConfirmPassword, StringComparison.Ordinal)) // Needs to be a Case Sensitive Comparison!
						yield return new InvalidModelExceptionDetail(nameof(SaveUserProfileRequest.UserProfile.Password), new ArgumentException("Confirm Password does not match Password."));
				}

				request.UserProfile.Phone = _nonNumeric.Replace(request.UserProfile.Phone, string.Empty);

			}
		}
	}
}
