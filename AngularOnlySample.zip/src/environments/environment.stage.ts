export const environment = {
  production: false,
  apiUrl: 'https://olbp.stage.services.azblue.com:8893',
  oktaRedirectCallbackUrl: 'https://olbp.stage.secure.azblue.com/login/callback',
  oktaPostLogoutRedirectUri: 'https://olbp.stage.secure.azblue.com/',
  loginUrl: 'https://employer.stage.secure.azblue.com/log-in'
};
