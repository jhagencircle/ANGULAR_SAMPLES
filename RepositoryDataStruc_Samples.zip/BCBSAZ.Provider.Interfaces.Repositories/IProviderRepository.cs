﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.Subscriber;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IProviderRepository
	{
		ProviderTaxId[] GetTaxIdsForOrg(string orgId);

		ServiceType[] GetServiceTypes();

		NPI[] GetNpisByOrg(string orgId, string userId, string query, int pageNumber, int pageSize, out int totalCount);

		NPI[] GetNpisByOrgForTPA(string query, int pageNumber, int pageSize, out int totalCount);
		
		PreviouslySelectedServiceType[] GetPreviouslySelectedServiceTypes(string userId);

		ProviderInfo GetProviderInfo(string providerId, string taxId, string orgId, string userName);


		Task<bool> DoesMemberExistAsync(string v, DateTime dateOfBirth);

		Task UpdateSelectedServiceTypeAsync(string uid, string selectedServiceTypeIds);

		Task<bool> DoesUsernameExist(string username);

		DateTime? GetMemberCutoffDate(string prefix);
	}
}
