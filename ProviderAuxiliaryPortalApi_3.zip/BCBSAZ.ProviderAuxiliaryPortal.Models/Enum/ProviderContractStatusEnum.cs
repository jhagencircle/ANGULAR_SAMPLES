﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models.Enum
{
     public enum ProviderContractStatusEnum
    {
        Unknown,
        Contracted,
        [Display(Name = "Non-Contracted")]
        NonContracted,
        Cancelled
    }
   
}
