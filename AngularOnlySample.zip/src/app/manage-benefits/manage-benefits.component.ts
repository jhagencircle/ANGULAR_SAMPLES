import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AlertService } from '../shared/components/alert/alert.service';
import { OverlaySidePanelService } from '../shared/components/overlay-side-panel/overlay-side-panel.service';
import { ISummary } from '../shared/models/summary.model';
import { AccountService } from '../shared/services/account.service';
import { BillService } from '../shared/services/bill.service';
import { SubAccountService } from '../shared/services/sub-account.service';
import { EmployeeProfileComponent } from './employee-profile/employee-profile.component';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { AccountLevelEnum } from '../shared/enums/account-level-enum';

@Component({
  selector: 'app-manage-benefits',
  templateUrl: './manage-benefits.component.html',
  styleUrls: ['./manage-benefits.component.scss'],
})
export class ManageBenefitsComponent implements OnInit, OnDestroy {
  subAccount: ISummary;
  showAlert: boolean;
  billId: string = '';
  subscriptions: Subscription[] = [];
  mainAccount: ISummary;
  subAccountList: ISummary[];

  constructor(
    private subAccountService: SubAccountService,
    private router: Router,
    private overlaySidePanelService: OverlaySidePanelService,
    public alertService: AlertService,
    private billService: BillService,
    private accountService: AccountService
  ) {}

  openAlert() {
    this.showAlert = true;
  }

  closeAlert() {
    this.showAlert = false;
  }

  ngOnInit(): void {
    this.loadPage();
  }
  loadPage() {
    this.getEmployeeRosterAccount();
    this.getMainAccount();
    this.getSubAccountSummary();
  }
  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  getSubAccount() {
    let subscription = this.subAccountService.get().subscribe((data) => {
      this.subAccount = data;
    });
    this.subscriptions.push(subscription);
  }
  getEmployeeRosterAccount() {
    const account = localStorage.getItem(
      AppConstants.EMPLOYEE_ROSTER_ACCOUNT_LOCAL_STORAGE_KEY
    );
    if (account) {
      this.subAccount = JSON.parse(account);
    }
  }

  getMainAccount() {
    //it is the user account
    let subscription = this.accountService
      .get()
      .subscribe((account: ISummary) => {
        if (account) {
          this.mainAccount = account;
          if (account.requiresRecalculation.length > 0) {
            this.openAlert();
          }
        }
      });
    this.subscriptions.push(subscription);
  }
  getSubAccountSummary() {
    //subAccountService
    let subscription = this.subAccountService
      .getList()
      .subscribe((accountList: ISummary[]) => {
        if (accountList) {
          this.subAccountList = accountList;
        }
      });
    this.subscriptions.push(subscription);
  }

  goToLandigPage() {
    this.router.navigate(['/landing-page']);
  }

  public showEmployeeProfile(): void {
    this.overlaySidePanelService.setContent(EmployeeProfileComponent);
    this.overlaySidePanelService.show();
  }

  recalculateBill() {
    //if account billing level is top account, recalculate top account bill id
    if (this.mainAccount.billingLevel == AccountLevelEnum.TopAccount) {
      let subscription = this.billService
        .recalculate(
          this.mainAccount.accountId,
          this.mainAccount.billId.toString()
        )
        .subscribe(() => {
          this.closeAlert();
          //refresh account information; call to current bill endpoint
          this.billService.get(this.mainAccount.accountId).subscribe((data) => {
            let subAccountSummaryList = data.subAccountSummary!;
            let subAccount = subAccountSummaryList.find((s) => {
              if (s.accountId == this.subAccount.accountId) {
                return s;
              } else return undefined;
            });
            if (subAccount) {
              //load current subaccount information
              this.subAccountService.update(subAccount!);
              this.subAccount = subAccount!;
            }
          });
        });

      this.subscriptions.push(subscription);
    } else {
      //if account billing level is sub account or sub sub account, recalculate all bill ids in requiresRecalcualtion array
      for (let i = 0; i < this.mainAccount.requiresRecalculation.length; i++) {
        //get sub/subsub account by billId
        let subAccount = this.subAccountList.filter(
          (s) => s.billId == this.mainAccount.requiresRecalculation[0]
        );
        if (subAccount) {
          let subscription = this.billService
            .recalculate(
              this.subAccount.accountId,
              this.mainAccount.requiresRecalculation[i].toString()
            )
            .subscribe(() => {
              //this.closeAlert();
              //refresh account information; call to current bill endpoint
              this.billService
                .get(this.mainAccount.accountId)
                .subscribe((data) => {
                  let subAccountSummaryList = data.subAccountSummary!;
                  let subAccount = subAccountSummaryList.find((s) => {
                    if (s.accountId == this.subAccount.accountId) {
                      return s;
                    } else return undefined;
                  });
                  if (subAccount) {
                    //load current subaccount information
                    this.subAccountService.update(subAccount!);
                    this.subAccount = subAccount!;
                  }
                });
            });

          this.subscriptions.push(subscription);
        }
      }
      this.closeAlert();
    }
  }
}
