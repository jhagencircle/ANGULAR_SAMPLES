﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;
using BCBSAZ.Provider.Models.Requests.Subscriber;
using BCBSAZ.Provider.Models.Responses.Eligibility.Details;
using BCBSAZ.Provider.Models.Responses.Subscriber;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface ISubscriberManager
	{

		Task<IsMemberDelegatedResponse> IsMemberDelegatedAsync(IsMemberDelegatedRequest request);

		Task<IsMemberLocalResponse> IsMemberLocalAsync(IsMemberLocalRequest request);

		Task<IdCardResponse> GetIdCardAsync(IdCardRequest request);

		Task<VelocityIdCardResponse> GetVelocityIdCardAsync(VelocityIdCardRequest request);

		Task<string> CheckPrefixAsync(string prefix);

		Task<ValidatePatientResponse> ValidatePatientAsync(ValidatePatientRequest request);

	}
}
