﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.ApiClient
{
    public interface IEmailClient
    {
        Task<bool> SendEmailAsync(string toAddress, string fromAddress, string subject, string body, IEnumerable<Attachment> attachments = null, string cc = null, string bcc = null);
    }
}
