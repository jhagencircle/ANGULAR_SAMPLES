﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.ClaimsDetails;
using BCBSAZ.Provider.Models.Requests.Claims;
using BCBSAZ.Provider.Models.Requests.ClaimsDetails;
using BCBSAZ.Provider.Models.Responses.ClaimDetails;
using BCBSAZ.Provider.Models.Responses.Claims;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface IClaimsService
	{

		Task<IEnumerable<RemitInfo>> GetRemitsAsync(string subscriberId);

		Task<IEnumerable<RemitInfo>> GetNewRemitsAsync(string subscriberId);

		Task<ClaimsInquiryResponse> SubmitInquiry(ClaimsInquiryRequest request);
		Task<ClaimDetailsHeaderResponse> GetHeader(ClaimDetailsHeaderRequest request);
		Task<ClaimStatusResponse> GetClaimStatus(string requestId);
		Task<ClaimsHistoryResponse> GetClaimsStatusHistoryAsync();
	}
}
