import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BillingFaqsRoutingModule } from './billing-faqs-routing.module';
import { BillingFaqsComponent } from './billing-faqs.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [BillingFaqsComponent],
  imports: [
    CommonModule,
    BillingFaqsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class BillingFaqsModule {}
