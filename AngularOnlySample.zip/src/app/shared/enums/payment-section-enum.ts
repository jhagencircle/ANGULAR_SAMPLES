export enum PaymentSectionEnum {
  Account = 'account',
  SubAccount = 'subaccount',
  Review = 'review',
  Autopayment = 'autopayment',
  ClaimsInvoice = 'claimsInvoice',
}
