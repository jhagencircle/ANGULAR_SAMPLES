import { Injectable } from '@angular/core';
import {
    CanActivate,
    Router,
    RouterStateSnapshot,
    ActivatedRouteSnapshot,
    UrlTree,
    CanActivateChild,
} from '@angular/router';
import { AuthService } from './auth.service';
import { OktaAuthService } from '@okta/okta-angular';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {
    authenticated: boolean = false;
    groups: string[];


    constructor(
        private authService: AuthService,
        private router: Router,
        public oktaAuth: OktaAuthService,
    ) { }

    async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        this.authenticated = await this.authService.isAuthenticated();

        if (this.authenticated) {
            return true;
        } else {
            this.router.navigate(['/login']);
            return false;
        }
    }

    async canActivateChild(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ) {
        return this.canActivate(route, state);
    }
}
