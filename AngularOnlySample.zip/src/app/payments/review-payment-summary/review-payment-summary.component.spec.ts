import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReviewPaymentSummaryComponent } from './review-payment-summary.component';
import { DecimalPipe } from '@angular/common';

describe('ReviewPaymentSummaryComponent', () => {
  let component: ReviewPaymentSummaryComponent;
  let fixture: ComponentFixture<ReviewPaymentSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [ReviewPaymentSummaryComponent, DecimalPipe],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewPaymentSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
