import { IAdjustment } from './adjustment.model';
import { IBillingRecipient } from './billing-recipient.model';

export interface ISummary {
  billId: number;
  voidBillId: number;
  voidBillIndicator: boolean;
  accountId: string;
  accountName?: string;
  totalEmployees: number;
  statementFrom: string;
  statementTo: string;
  dueDate: string;
  status?: string;
  totalPaidAmount: number;
  totalBilledAmount: number;
  totalAdjustedAmount: number;
  totalDueAmount: number;
  asc: boolean;
  requiresRecalculation: number[];
  billingLevel: string;
  subscriptionLevel: string;
  balanceForwardAmount: number;
  newChargesAmount: number;
  subSubAccounts?: ISummary[];
  isSubSubAccountsDisplayed?: boolean;
  isChecked?: boolean;
}
