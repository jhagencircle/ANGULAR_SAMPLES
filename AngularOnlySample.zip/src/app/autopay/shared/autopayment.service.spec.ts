import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { AutopaymentService } from './autopayment.service';
import { AutopayMock } from 'src/app/shared/mocks/autopay.mock';
import { IAutoPayment } from './autopayment.model';
import { BehaviorSubject, of } from 'rxjs';

describe('AutopaymentService', () => {
  let service: AutopaymentService;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let testUrl: string = '';
  let baseUrl: string = '';
  let httpClientSpy: {
    get: jasmine.Spy;
    post: jasmine.Spy;
  };

  beforeEach(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    //service = TestBed.inject(AutopaymentService);
    service = new AutopaymentService(httpClientSpy as any);
    // Inject the http service and test controller for each test
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
    baseUrl = `${environment.apiUrl}/api/AutoPayment`;
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return mockList', () => {
    httpClientSpy.get.and.returnValue(of(AutopayMock.mockedAutoPayList));
    service
      .getList('1000')
      .subscribe(
        (items) =>
          expect(items).toEqual(
            AutopayMock.mockedAutoPayList,
            'expected autopayments'
          ),
        fail
      );
    expect(httpClientSpy.get.calls.count()).toBe(1);
  });

  it('should enroll an autopay', () => {
    const testData: IAutoPayment = { accountId: '', bankAccountId: 0 };
    httpClientSpy.post.and.returnValue(of(true));
    service
      .enroll(testData)
      .subscribe((result) => expect(result).toBeTruthy, fail);
    expect(httpClientSpy.post.calls.count()).toBe(1);
  });

  it('should cancel an autopay', () => {
    httpClientSpy.post.and.returnValue(of(true));
    service.cancel('1').subscribe((result) => expect(result).toBeTruthy, fail);
    expect(httpClientSpy.post.calls.count()).toBe(1);
  });

  it('should return a behavior subject', () => {
    service.update(AutopayMock.mockedAutoPayList);
    expect(service.autopayments).toBeTruthy();

    service
      .get()
      .subscribe(
        (items) =>
          expect(items).toEqual(
            AutopayMock.mockedAutoPayList,
            'expected autopayments'
          ),
        fail
      );
  });
});
