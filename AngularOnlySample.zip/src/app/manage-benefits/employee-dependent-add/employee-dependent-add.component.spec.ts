import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeDependentAddComponent } from './employee-dependent-add.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RelationshipService } from '../shared/relationship.service';
import { RelationshipServiceMock } from 'src/app/shared/mocks/relationship.service.mock';
import { TerminationReasonService } from '../shared/termination-reason.service';
import { TerminationReasonServiceMock } from 'src/app/shared/mocks/termination-reason.service.mock';
import { EmployeeMock } from '../../shared/mocks/employee.mock';

describe('EmployeeDependentAddComponent', () => {
  let component: EmployeeDependentAddComponent;
  let fixture: ComponentFixture<EmployeeDependentAddComponent>;
  let relationshipServiceMock: any = new RelationshipServiceMock();
  let terminationReasonServiceMock: any = new TerminationReasonServiceMock();
  let mockEmployeeService: EmployeeMock;

  beforeEach(async () => {
    mockEmployeeService = new EmployeeMock();
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        NgbModule,
        HttpClientTestingModule,
      ],
      declarations: [EmployeeDependentAddComponent],
      providers: [
        { provide: RelationshipService, useValue: relationshipServiceMock },
        {
          provide: TerminationReasonService,
          useValue: terminationReasonServiceMock,
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeDependentAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should cancel', () => {
    spyOn(component.close, 'emit');
    component.cancel();
    expect(component.close.emit).toHaveBeenCalledWith(null);
  });

  it('should save', () => {
    mockEmployeeService
      .get()
      .subscribe(
        (data) => (component.benefitSelection = data.benefitSelection)
      );
    component.getFormListsData();
    component.form.setValue({
      firstName: 'test',
      lastName: 'test',
      ssn: '123456789',
      relationship: 'spouse',
      dateOfBirth: '12/12/12',
      gender: 'male',
      heatlthInsurancePlan: '0',
    });
    spyOn(component.onSuccessfulAdd, 'emit');
    spyOn(component.close, 'emit');
    component.save();
    expect(component.onSuccessfulAdd.emit).toHaveBeenCalledWith({
      firstName: 'test',
      lastName: 'test',
      ssn: '123456789',
      dateOfBirth: '12/12/12',
      gender: 'male',
      middleName: '',
      dependentType: 'spouse',
      benefitSelection: Object({
        planSelection: [],
        eligibleForMedicare: false,
        lifeInsuranceBenefit: '',
        medicareNumber: undefined,
        partAEffectiveDate: undefined,
        partBEffectiveDate: undefined,
      }),
      removalReason: '',
      isEdit: false,
      isRemoved: false,
      effectiveDate: null,
    });
    expect(component.close.emit).toHaveBeenCalledWith(null);
  });
});
