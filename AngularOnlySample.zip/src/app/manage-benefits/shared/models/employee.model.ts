import { IContact } from './contact.model';
import { IBenefit } from './benefit.model';
import { IDependent } from './dependent.model';
import { ITerminationCoverage } from './termination-coverage.model';

export interface IEmployee {
  subscriberId: string;
  memberId: string;
  accountId: string;
  subAccountId: string;
  firstName: string;
  lastName: string;
  employeeId: string;
  location: string;
  dateOfBirth: string;
  ssn: string;
  maritalStatus: string;
  gender: string;
  effectiveDateOfPolicy: string;
  contactInformation: IContact;
  benefitSelection: IBenefit;
  dependents: IDependent[];
  terminateCoverage: ITerminationCoverage;
}
