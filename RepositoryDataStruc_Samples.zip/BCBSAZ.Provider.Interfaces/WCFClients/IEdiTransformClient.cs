﻿using System;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface IEdiTransformClient : IDisposable
	{
		Task<string> TransformEdiToXml(string edi);
	}
}
