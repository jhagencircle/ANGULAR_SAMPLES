import { BehaviorSubject, from, Observable, of, Subject } from 'rxjs';
import { Injectable } from '@angular/core';
import { IMemberProfile } from '../../shared/models/member-profile.model';
import { IProfileRoster } from './models/profile-roster.model';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class EmployeeProfileService {
  private ProfileRoster = new BehaviorSubject<IProfileRoster>({
    terminateCoverage: null,
    subscriber: null,
    contact: null,
    dependents: ([] = []),
    receivedDate: null,
    topAccountId: null,
    billId: 0,
  });
  private applyChange = new BehaviorSubject<boolean>(false);
  url = `${environment.apiUrl}/Adjustments`;
  constructor(private http: HttpClient) {}

  update(profile: IProfileRoster) {
    this.ProfileRoster.next(profile);
    this.applyChange.next(true);
  }

  get(): Observable<IProfileRoster> {
    return this.ProfileRoster.asObservable();
  }

  hasChanged(): Observable<boolean> {
    return this.applyChange.asObservable();
  }

  cancel() {
    this.ProfileRoster.next({
      terminateCoverage: null,
      subscriber: null,
      contact: null,
      dependents: ([] = []),
      receivedDate: null,
      topAccountId: null,
      billId: 0,
    });
    this.applyChange.next(false);
  }

  save(): Observable<any> {
    this.applyChange.next(false);
    return this.http.post<any>(`${this.url}`, this.ProfileRoster.value);
  }
}
