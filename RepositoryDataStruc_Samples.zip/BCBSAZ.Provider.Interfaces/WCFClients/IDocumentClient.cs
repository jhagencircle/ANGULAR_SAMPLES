﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;

namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface IDocumentClient : IDisposable
	{
		Task<IEnumerable<IdCard>> GetSubscriberIdCardImages(string subscriberId);
	}
}
