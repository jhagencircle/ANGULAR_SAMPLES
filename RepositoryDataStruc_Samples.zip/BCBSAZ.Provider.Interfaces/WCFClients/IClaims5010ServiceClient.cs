﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Claims;
using BCBSAZ.Provider.Models.Requests.Claims;

namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface IClaims5010ServiceClient : IDisposable
	{
		Task<ClaimsResponse> GetClaims(ClaimsInquiryRequest request);
	}
}
