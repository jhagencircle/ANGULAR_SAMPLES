﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Claims;

namespace BCBSAZ.Provider.Managers.RequestValidators.Claims
{
	internal static class ClaimStatusCodesRequestValidator
	{
		public static void Validate(this ClaimStatusCodesRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(ClaimStatusCodesRequest request)
		{
			return Enumerable.Empty<InvalidModelExceptionDetail>();
		}
	}
}
