export const environment = {
  production: false,
  apiUrl: 'https://olbp.modoff.services.azblue.com:8793',
  oktaRedirectCallbackUrl:
    'https://olbp.modoff.secure.azblue.com/login/callback',
  oktaPostLogoutRedirectUri: 'https://olbp.modoff.secure.azblue.com/',
  loginUrl: 'https://employer.modoff.secure.azblue.com/log-in',
};
