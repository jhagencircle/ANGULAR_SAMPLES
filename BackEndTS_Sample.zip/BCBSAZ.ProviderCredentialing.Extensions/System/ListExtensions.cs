﻿using System.Collections.Generic;

namespace System
{
	public static class ListExtensions
	{
		public static void AddRangeIfNotNullOrEmpty<T>(this List<T> list, IEnumerable<T> itemsToAdd)
		{
			if (list == null) throw new ArgumentNullException(nameof(list));
			if (itemsToAdd.IsNullOrEmpty()) return;

			list.AddRange(itemsToAdd);
		}
	}
}
