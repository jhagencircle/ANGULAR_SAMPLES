import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LandingPageService } from './shared/landing-page.service';
import { ISummary } from '../shared/models/summary.model';
import { AccountService } from '../shared/services/account.service';
import { BillService } from '../shared/services/bill.service';
import { SubAccountService } from '../shared/services/sub-account.service';
import { UserService } from '../shared/services/user.service';
import { User } from '../shared/models/user.model';
import { SpinnerService } from '../shared/components/spinner/spinner.service';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { AccountLevelEnum } from '../shared/enums/account-level-enum';
import { Subscription } from 'rxjs';
import { PaymentSectionEnum } from 'src/app/shared/enums/payment-section-enum';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss'],
})
export class LandingPageComponent implements OnInit, OnDestroy {
  subAccountSummaryList: ISummary[];
  subAccountList: ISummary[];
  userAccount: string;
  isAuthenticated: boolean = false;
  userName?: string;
  checkAll: boolean = false;

  subaccounts: any = [];

  account: ISummary; //Account of the user
  statementFrom: Date;
  statementTo: Date;
  billDueDate: Date;
  informativeMessage = '';
  accountLevelEnum = AccountLevelEnum;
  subAccountSummaryLevel: string;
  subscriptions: Subscription[] = [];
  currentUrl: string = '';

  constructor(
    private billService: BillService,
    private accountService: AccountService,
    private landingPageService: LandingPageService,
    private router: Router,
    public userService: UserService,
    public _spinnerService: SpinnerService,
    private subaccountService: SubAccountService
  ) {}

  async ngOnInit() {
    localStorage.removeItem(
      AppConstants.PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY
    );
    const user: User = await this.userService.get();
    this.userAccount = user.accountId;
    this.currentUrl = window.location.href;

    this.getCurrentBill();
  }
  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }
  getCurrentBill() {
    this._spinnerService.show(true);
    let subscription = this.billService
      .get(this.userAccount)
      .subscribe((data) => {
        this.account = data.accountSummary!;

        if (this.currentUrl.includes('olbp.dev')) {
          this.account.asc = false;
        }

        let subAccountSummaryData = data.subAccountSummary!.map((d) => ({
          isSubSubAccountsDisplayed: false,
          isChecked: false,
          ...d,
        }));

        this.subAccountSummaryLevel =
          this.account.billingLevel == AccountLevelEnum.TopAccount
            ? AccountLevelEnum.SubAccount
            : this.account.billingLevel;

        if (this.subAccountSummaryLevel == AccountLevelEnum.SubAccount) {
          //get list of sub accounts with its sub sub account list

          let subAccounts = subAccountSummaryData.filter(
            (s) => s.accountId.split('-').length == 2
          );
          subAccounts.forEach((s) => {
            let subSubAccounts = subAccountSummaryData.filter((ssa) => {
              let idParts = ssa.accountId.split('-');
              let idSize = idParts.length;
              if (idSize == 3 && idParts[0] + '-' + idParts[1] == s.accountId) {
                return true;
              } else {
                return false;
              }
            });

            if (subSubAccounts) {
              s.subSubAccounts = subSubAccounts;
            }
          });
          this.subAccountSummaryList = subAccounts;
        } else {
          //get list of sub sub accounts

          let subSubAccountList = subAccountSummaryData.filter(
            (s) => s.accountId.split('-').length == 3
          );

          this.subAccountSummaryList = subSubAccountList;
        }
        localStorage.setItem(
          AppConstants.SUB_ACCOUNT_SUMMARY_LIST_LOCAL_STORAGE_KEY,
          JSON.stringify(this.subAccountSummaryList)
        );

        //persist account (main account) from current bill endpoint
        this.accountService.update(data.accountSummary!);

        //persist sub account list/ sub sub account list from current bills endpoint
        this.subaccountService.updateList(this.subAccountSummaryList);

        this.statementFrom = new Date(this.account.statementFrom);
        this.statementTo = new Date(this.account.statementTo);
        this.billDueDate = new Date(this.account.dueDate);

        switch (this.account.billingLevel) {
          case AccountLevelEnum.TopAccount:
            if (this.account.subscriptionLevel == AccountLevelEnum.TopAccount) {
              this.informativeMessage =
                AppConstants.MESSAGE_TOP_ACCOUNT_BILLING_SUBSCRIPTION;
            } else {
              this.informativeMessage =
                AppConstants.MESSAGE_TOP_ACCOUNT_BILLING;
            }
            break;
          case AccountLevelEnum.SubSubAccount:
            this.informativeMessage =
              AppConstants.MESSAGE_SUB_SUB_ACCOUNT_BILLING_SUBSCRIPTION;
            break;
          default:
            this.informativeMessage = '';
            break;
        }

        this._spinnerService.show(false);
      });
    this.subscriptions.push(subscription);
  }

  export() {
    this.landingPageService.export(this.subAccountSummaryList);
  }

  makePayment() {
    switch (this.account?.billingLevel) {
      case AccountLevelEnum.TopAccount:
        this.router.navigate(['/payments']);
        localStorage.setItem(
          AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
          PaymentSectionEnum.Account
        );
        break;
      case AccountLevelEnum.SubAccount:
      case AccountLevelEnum.SubSubAccount:
        localStorage.setItem(
          AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
          PaymentSectionEnum.SubAccount
        );
        localStorage.setItem(
          AppConstants.PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY,
          JSON.stringify(
            this.subaccounts.sort(function (a: any, b: any) {
              if (a.billId < b.billId) return -1;
              else return 1;
            })
          )
        );
        this.router.navigate(['/payments']);
        break;
      //TODO: case AccountLevelEnum.SubSubAccount:
    }
  }

  onSelectedSubaccounts(subaccount: any) {
    if (subaccount.isChecked) {
      this.subaccounts.push(subaccount);
      if (this.subaccounts.length === this.subAccountSummaryList.length)
        this.checkAll = true;
    } else {
      this.checkAll = false;
      let removeIndex = this.subaccounts
        .map((item: any) => item['accountId'])
        .indexOf(subaccount.accountId);
      this.subaccounts.splice(removeIndex, 1);
    }
  }

  onSelectAll() {
    this.subaccounts = [];
    this.subAccountSummaryList.map((item) => {
      item.isChecked = !this.checkAll;
      if (!this.checkAll) {
        this.subaccounts.push(item);
      }
    });
  }
  public openPDF(): void {
    this._spinnerService.show(true);
    let DATA = document.getElementById('landingPagePrint');

    html2canvas(DATA!).then((canvas) => {
      let fileWidth = 208;
      let fileHeight = (canvas.height * fileWidth) / canvas.width;
      const FILEURI = canvas.toDataURL('image/png');
      let PDF = new jsPDF();

      let position = 0;
      PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight);

      this._spinnerService.show(false);
      window
        .open(
          URL.createObjectURL(PDF.output('blob')),
          '_blank',
          'toolbar=yes,scrollbars=yes,resizable=yes'
        )
        ?.print();
    });
  }
}
