﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories
{
	public class EmailRepository : IEmailRepository
	{
		private readonly IEmailContext _emailContext;

		public EmailRepository(IEmailContext emailContext) => _emailContext = emailContext;

		public Task QueueEmailAsync(string toAddress, string fromAddress, string subject, string body)
		{
			var cc = string.Empty;
			var bcc = string.Empty;

			return _emailContext.Database.ExecuteSqlRawAsync(DB.Email.StoredProcs.QueueEmail, toAddress, fromAddress, cc, bcc, subject, body);
		}
	}
}
