﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.PreCert;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.PreCert
{
	internal static class CancelPharmacyPreCertRequestValidator
	{
		public static void Validate(this CancelPharmacyPreCertRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(CancelPharmacyPreCertRequest request)
		{
			if (request.PreCertId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(CancelPharmacyPreCertRequest.PreCertId), new ArgumentException("Invalid Pharmacy PreCert Id specified."));
		}
	}
}
