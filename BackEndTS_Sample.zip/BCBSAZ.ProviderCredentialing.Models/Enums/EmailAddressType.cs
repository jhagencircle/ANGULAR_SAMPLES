﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.WebAPI.Models.Enums
{
	public enum EmailAddressType
	{
		ApplicationContactInformation,
		BusinessCorrespondence,
		BusinessEmail
	}
}
