import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { AuthService } from 'src/app/core/auth/auth.service';
import { ConfirmationDialogService } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.service';
import { WelcomeDialogService } from '../../services/welcome-dialog.service';
import { AppConstants } from '../../constants/app-constants';
import { ModalSize } from '../../enums/modal-size-enum';

@Component({
  selector: 'app-welcome-dialog',
  templateUrl: './welcome-dialog.component.html',
  styleUrls: ['./welcome-dialog.component.scss'],
})
export class WelcomeDialogComponent implements OnInit {
  showModal: boolean = false;
  constructor(
    private cookieService: CookieService,
    public authService: AuthService,
    private confirmationDialogService: ConfirmationDialogService,
    private welcomeDialogService: WelcomeDialogService
  ) {}

  ngOnInit(): void {
    let localValue = localStorage.getItem(
      AppConstants.WS_AUX_LOCAL_STORAGE_KEY
    );
    let wsId = this.cookieService.get(AppConstants.WS_COOKIE_KEY);
    if (!localValue && !wsId) {
      let currentSession = JSON.parse(
        localStorage.getItem(AppConstants.OKTA_TOKEN_STORAGE) || ''
      );
      let userId = currentSession?.accessToken.claims.uid;
      if (wsId) {
        if (wsId !== userId) {
          this.cookieService.delete(AppConstants.WS_COOKIE_KEY);
        }
      }
      let expiredDate = new Date();
      expiredDate.setDate(expiredDate.getFullYear() + 1);
      this.cookieService.set(AppConstants.WS_COOKIE_KEY, userId, expiredDate);
      localStorage.setItem(AppConstants.WS_AUX_LOCAL_STORAGE_KEY, userId);
      this.openConfirmationDialog();
    } else {
      if (localValue)
        localStorage.removeItem(AppConstants.WS_AUX_LOCAL_STORAGE_KEY);
    }
  }

  public openConfirmationDialog() {
    this.welcomeDialogService.getTemplate().subscribe((template) => {
      let modalHeader: string = AppConstants.WELCOME_TITLE;
      let modalbody: string = template;
      let btnOkText: string = AppConstants.GOT_IT;
      let btnCancelText: string | null = null;
      let modalSize: string = ModalSize.MEDIUM;
      this.confirmationDialogService.confirm(
        modalHeader,
        modalbody,
        btnOkText,
        btnCancelText,
        modalSize
      );
    });
  }

  public decline() {
    this.showModal = true;
  }
}
