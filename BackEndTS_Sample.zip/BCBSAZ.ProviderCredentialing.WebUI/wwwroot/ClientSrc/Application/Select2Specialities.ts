﻿export class Select2Specialities {
	 id: string
	 text: string

}