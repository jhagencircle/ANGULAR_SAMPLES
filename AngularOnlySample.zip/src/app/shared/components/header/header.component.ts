import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthService } from 'src/app/core/auth/auth.service';
import { AppConstants } from '../../constants/app-constants';
import { ISummary } from '../../models/summary.model';
import { AccountService } from '../../services/account.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit, OnDestroy {
  isAuthenticated: boolean = false;
  userName?: string;
  accountName?: string;
  title: string = AppConstants.HEADER_TITLE;
  subscriptions: Subscription[] = [];

  constructor(
    public authService: AuthService,
    public accountService: AccountService
  ) {}

  ngOnInit(): void {
    this.getAccontName();
  }
  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }
  logOut() {
    this.authService.logout();
  }
  getAccontName() {
    let subscription = this.accountService
      .get()
      .subscribe((account: ISummary) => {
        if (account) {
          this.accountName = account.accountName;
        }
      });
    this.subscriptions.push(subscription);
  }
}
