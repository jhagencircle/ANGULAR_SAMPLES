﻿using System;
using System.Globalization;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Models.Requests.Eligibility.Inquiries;
using BCBSAZ.Provider.Models.Responses.Eligibility.Inquiries;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Managers.ApiClients
{
	public class EligibilityApiClient : ApiClientBase, IEligibilityApiClient
	{
		private readonly string _routeMessageCode;
		private const string CorrelationIdHeader = "X-Correlation-ID";

		public EligibilityApiClient(IConfiguration configuration, IOktaApiClient oktaClient) : base(oktaClient)
		{
			base.Timeout = new TimeSpan(0, 0, configuration.GetValue<int>(Constants.Configuration.Timeouts.EligibilityTimeout));
			_routeMessageCode = configuration.GetValue<string>(Constants.Configuration.EligibilityMessageCode);
			var serviceUrl = configuration.GetValue<string>(Constants.Configuration.EligibilityApiUrl);

			if (string.IsNullOrWhiteSpace(serviceUrl))
				throw new ArgumentException("Invalid Service Url specified for Velocity API.");

			BaseAddress = new Uri(serviceUrl.EnsureEndsWith('/'));

			DefaultRequestHeaders.Clear();
			DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
		}

		protected override string Name => "Eligibility API";

		public Task<VelocityEligibilityResponse> Get271Response(VelocityEligibilityRequest request)
		{
			if (base.DefaultRequestHeaders.Contains(CorrelationIdHeader))
				base.DefaultRequestHeaders.Remove(CorrelationIdHeader);

			base.DefaultRequestHeaders.Add(CorrelationIdHeader, request.CorrelationID);

			return PostAsync<VelocityEligibilityResponse>(string.Format(CultureInfo.InvariantCulture, Constants.EligibilityApiUrls.Inquiry, _routeMessageCode), request);
		}

		// INFO: Remove this method if end-point authentication changes to use Okta, or replace if other authentication is required.
		protected override (string tokenType, string token) GetApiTokenAuthentication() =>
			(string.Empty, string.Empty);
	}
}
