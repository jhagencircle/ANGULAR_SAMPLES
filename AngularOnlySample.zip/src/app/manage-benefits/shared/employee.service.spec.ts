import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmployeeService } from './employee.service';
import { DecimalPipe } from '@angular/common';
import { EmployeeServiceMock } from 'src/app/shared/mocks/employee.service.mock';
import { IEmployeeRoster } from './models';
import { of } from 'rxjs';

describe('EmployeeService', () => {
  let service: EmployeeService;
  let mockEmployeeService: EmployeeServiceMock = new EmployeeServiceMock();
  let mockedEmployees: any[] = [];
  let httpClientSpy: {
    get: jasmine.Spy;
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [DecimalPipe],
    });
    service = TestBed.inject(EmployeeService);
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    mockEmployeeService.get().subscribe((data) => (mockedEmployees = data));
    service = new EmployeeService(httpClientSpy as any);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return mockList', () => {
    httpClientSpy.get.and.returnValue(of(mockedEmployees));
    service
      .get('01', '001')
      .subscribe(
        (items) => expect(items).toEqual(mockedEmployees, 'expected employees'),
        fail
      );
    expect(httpClientSpy.get.calls.count()).toBe(1);
  });
});
