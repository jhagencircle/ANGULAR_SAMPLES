export enum AccountLevelEnum {
  TopAccount = 'top',
  SubAccount = 'sub',
  SubSubAccount = 'sub-sub',
}
