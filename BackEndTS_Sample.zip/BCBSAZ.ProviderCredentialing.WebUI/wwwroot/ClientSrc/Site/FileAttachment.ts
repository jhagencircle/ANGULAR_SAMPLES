﻿export class FileAttachment {
	public Contents: string;
	public fileName: string;
	public ContentType: string;
}