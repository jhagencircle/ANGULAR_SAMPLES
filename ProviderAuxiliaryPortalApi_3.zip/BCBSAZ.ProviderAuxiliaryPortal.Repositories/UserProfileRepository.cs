﻿using BCBSAZ.ProviderAuxiliaryPortal.Extensions;
using BCBSAZ.ProviderAuxiliaryPortal.Models.UserProfile;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static BCBSAZ.ProviderAuxiliaryPortal.Models.Constants;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories
{
    public class UserProfileRepository : IUserProfileRepository
    {
        private readonly ProviderInetContext _providerInetContext;

        public UserProfileRepository(ProviderInetContext providerInetContext)
        {
            _providerInetContext = providerInetContext;
        }


        public async Task<UserProfile> GetUserProfileAsync(string userId)
        {
            var profile = (await _providerInetContext.UserProfiles.FromSqlRaw(StoredProcedure.ProviderInet.GET_USERPROFILE, userId).ToListAsync()).FirstOrDefault();
            return profile;
        }
        public async Task UpdateUserProfileAsync(UserProfile userProfile, string passwordHash) {
            await _providerInetContext.Database.ExecuteSqlRawAsync(
                      StoredProcedure.ProviderInet.UPDATE_USERPROFILE,
                      userProfile.SubOrg,
                      userProfile.Username,
                      passwordHash,
                      userProfile.Email,
                      userProfile.FirstName,
                      userProfile.LastName,
                      userProfile.Phone,
                      userProfile.UserRole
                  );
        }
               

        public async Task InsertUserProfileAsync(string createdBy, string orgId, UserProfile userProfile, string passwordHash, string answerHash) =>
             await _providerInetContext.Database.ExecuteSqlRawAsync(
                StoredProcedure.ProviderInet.INSERT_USERPROFILE,
                createdBy,
                orgId,
                userProfile.SubOrg,
                userProfile.Username,
                passwordHash,
                userProfile.Email,
                userProfile.FirstName,
                userProfile.LastName,
                userProfile.Phone,
                userProfile.SecurityQuestion,
                answerHash,
                userProfile.UserRole
            );

        public async Task SetProvidersForUserAsync(string orgId, string subOrg, string userId, IEnumerable<AssignedProvider> providers)
        {
            var selectedProviders = String.Join(",", providers.EmptyIfNull().Where(x => x.IsSelected).Select(x => x.ProviderId));
                
            await _providerInetContext.Database.ExecuteSqlRawAsync(StoredProcedure.ProviderInet.SET_PROVIDERS_FOR_USER, orgId, subOrg, userId, selectedProviders);
        }

        public async Task DeleteUserProfileAsync(string orgId, string userId)
        {
            await _providerInetContext.Database.ExecuteSqlRawAsync(StoredProcedure.ProviderInet.DELETE_USERPROFILE, orgId, userId);
        }          
    }
}
