﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft
{

    [Table("EftEnrollmentRequest")]
    public class EftEnrollmentRequest
    {
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
		public long RequestId { get; set; }
		public string SubmissionReason { get; set; }
		public string OktaSessionId { get; set; }
		public bool IsOldAcctNumber { get; set; }
		public int EnrollmentDocType { get; set; } 
		public string ProviderName { get; set; } 
		public string ProviderAddress { get; set; } 
		public string ProviderCity { get; set; } 
		public string ProviderState { get; set; }
		public string ProviderZip { get; set; }
		public ProviderEftTinEinTaxIdTypeEnum ProviderTinEinIdType { get; set; }
		public string ProviderNPI { get; set; }
		public string ProviderContactName { get; set; } 
		public string ProviderTelephoneNumber { get; set; }
		public string ProviderTelephoneExt { get; set; } 
		public string ProviderEmail { get; set; } 
		public string ProviderFaxNumber { get; set; } 
		public string FinInstitutionName { get; set; }
		public string FinInstitutionAddress { get; set; } 
		public string FinInstitutionCity { get; set; } 
		public string FinInstitutionState { get; set; } 
		public string FinInstitutionZip { get; set; }
		public string RoutingNumber { get; set; }
		public string AccountNumber { get; set; }
		public  ProviderEftAccountTypeEnum  AccountType { get; set; }
		public ProviderEftStatusEnum Status { get; set; }
		public DateTime? InsertDate { get; set; }
		public virtual ICollection<ProviderIdentifier> ProvInfo { get; set; }

		[NotMapped]
		[JsonIgnore]
		public IEnumerable<string> AttachedFileNames { get; set; }
		
		[NotMapped]
		[JsonIgnore]
		public FileAttachment[] FileAttachments { get; set; }
	}
}
