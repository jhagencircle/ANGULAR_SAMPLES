﻿using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Models.UserProfile;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Managers
{
    public class UserProfileManager : IUserProfileManager
    {
        private readonly IUserProfileRepository _userProfileRepository;

        public UserProfileManager(IUserProfileRepository userProfileRepository)
        {
            _userProfileRepository = userProfileRepository;
        }

        private string HashString(string value)
        {
            using (var hash = new SHA256Managed())
            {
                var bytes = hash.ComputeHash(Encoding.Unicode.GetBytes(value));
                return string.Join(string.Empty, bytes.Select(b => b.ToString("x2")));
            }
        }

        public async Task<bool> CreateUserProfileAsync(UserProfileRequest request)
        {
            request.PasswordReset = true;
            var hashedPassword = HashString(request.UserProfile.Username.Trim() + request.UserProfile.Password.Trim());
            var createdBy = $"OUM - {request.UserId}";

            await _userProfileRepository.InsertUserProfileAsync(createdBy, request.OrgId, request.UserProfile, hashedPassword, HashString(request.UserProfile.SecurityQuestionAnswer));
            await _userProfileRepository.SetProvidersForUserAsync(request.OrgId, request.UserProfile.SubOrg, request.UserProfile.Username, request.Providers);


            //TODO:
            //var result = await _securityClient.ResetOtherUserPasswordAsync(request.UserProfile.Username, request.UserProfile.Password, request.UserProfile.Password);
            //return result ? FailedProfileResponse() : SuccessfulProfileResponse();
            return true;
        }

        public async Task<bool> DeleteUserProfileAsync(string orgId, string userId)
        {
            await _userProfileRepository.DeleteUserProfileAsync(orgId, userId);
            return true;
        }

        public async Task<UserProfile> GetUserProfileAsync(string userId)
        {
            var userProfile = await _userProfileRepository.GetUserProfileAsync(userId);
            return userProfile;
        }

        public async Task<bool> UpdateUserProfileAsync(UserProfileRequest request)
        {
            var passwordHash = request.PasswordReset ? HashString(request.UserProfile.Username.Trim() + request.UserProfile.Password.Trim()) : null;

            await _userProfileRepository.UpdateUserProfileAsync(request.UserProfile, passwordHash);
            await _userProfileRepository.SetProvidersForUserAsync(request.OrgId, request.UserProfile.SubOrg, request.UserProfile.Username, request.Providers);

            if (!string.IsNullOrEmpty(request.UserProfile.Password))
            {
                //TODO:

                //var result = await _securityClient.ResetOtherUserPasswordAsync(request.UserProfile.Username, request.UserProfile.Password, request.UserProfile.Password);
                //return result ? FailedProfileResponse() : SuccessfulProfileResponse();
            }

            return true;
        }
    }
}
