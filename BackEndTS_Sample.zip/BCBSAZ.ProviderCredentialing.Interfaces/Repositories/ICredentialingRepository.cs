﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Interfaces.Repositories
{
	public interface ICredentialingRepository
	{
	}
}
