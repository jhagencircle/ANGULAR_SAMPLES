import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AppConstants } from '../shared/constants/app-constants';
import { BillingFaqsService } from './shared/billing-faqs.service';
import { IFaq } from './shared/faq.model';

@Component({
  selector: 'app-billing-faqs',
  templateUrl: './billing-faqs.component.html',
  styleUrls: ['./billing-faqs.component.scss'],
})
export class BillingFaqsComponent implements OnInit, OnDestroy {
  faqList: IFaq[];
  subscriptions: Subscription[] = [];
  title: string = AppConstants.BILLING_FAQ_TITLE;

  constructor(public billingFaqsService: BillingFaqsService) {}

  ngOnInit(): void {
    this.loadFAQs();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  loadFAQs() {
    let subscription = this.billingFaqsService.get().subscribe((data) => {
      this.faqList = data.map((d) => ({ isDisplayed: false, ...d }));
    });
    this.subscriptions.push(subscription);
  }

  onClickDisplayAnswer(faq: IFaq) {
    faq.isDisplayed = !faq.isDisplayed;
    if (faq.isDisplayed) {
      //close other
      this.faqList.forEach((q) => {
        if (q.question !== faq.question) {
          q.isDisplayed = false;
        }
      });
    }
  }
}
