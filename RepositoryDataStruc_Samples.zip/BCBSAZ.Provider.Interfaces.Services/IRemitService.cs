﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Remits;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface IRemitService
	{
		Task<ProviderMergedRemittanceResponse> GetProviderRemitsAsync(RemitSearchRequest request);
		Task<RemitDocumentResponse> GetRemitDocumentAsync(RemitDocumentRequest request);

		Task<RemitDocumentResponse> GetVelocityRemitDocumentAsync(RemitDocumentVelocityRequest request);

	}
}
