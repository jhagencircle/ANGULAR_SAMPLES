import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TerminationReasonService } from './termination-reason.service';

describe('TerminationReasonService', () => {
  let service: TerminationReasonService;

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [HttpClientTestingModule] });
    service = TestBed.inject(TerminationReasonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
