import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { BaseValidation } from '../base-class/base-validation';
import { AbstractControl } from '@angular/forms';

@Directive({
  selector: '[appInputValidation]',
})
export class InputValidationDirective extends BaseValidation {
  constructor() {
    super();
  }

  @Input('appInputValidation') validatorName: string;
  @Input() appInput: AbstractControl | null;

  @HostListener('keydown', ['$event'])
  public onKeyDown(event: any): void {
    super.onKeyDown(event);
  }

  @HostListener('focus', ['$event'])
  public onFocus(event: any): void {
    this.appInput?.markAsUntouched({ onlySelf: true });
  }

  @HostListener('paste', ['$event'])
  public onPaste(event: any): void {
    let regex: RegExp | null = null;
    switch (this.validatorName) {
      case 'alphaNumber':
        regex = /[^0-9A-Za-z]/g;
        break;
      case 'alphaNumberAndSpace':
        regex = /[^0-9A-Za-z ]/g;
        break;
      case 'alphaAndSpace':
        regex = /[^A-Za-z ]/g;
        break;
      case 'alphaOnly':
        regex = /[^A-Za-z]/g;
        break;
      case 'numberOnly':
        regex = /\D/g;
        break;
      case 'date':
        regex = /[0-9\/]/g;
        break;
      case 'decimal':
        regex = /^\d+(\.\d+)?$/;
        break;
    }
    this.formatInput(event, regex, this.appInput);
  }

  public enforceValidation(event: any): void {
    let isPreventDefaultRequired = false;

    switch (this.validatorName) {
      case 'alphaNumber':
        isPreventDefaultRequired =
          !this.isAlphaNumberInput(event) && !this.isModifierKey(event);
        break;
      case 'alphaNumberAndSpace':
        isPreventDefaultRequired =
          !this.isAlphaNumberInput(event) &&
          event.keyCode !== 32 &&
          !this.isModifierKey(event);
        break;
      case 'alphaAndSpace':
        isPreventDefaultRequired =
          !this.isAlphaInput(event) &&
          event.keyCode !== 32 &&
          !this.isModifierKey(event);
        break;
      case 'alphaOnly':
        isPreventDefaultRequired =
          !this.isAlphaInput(event) && !this.isModifierKey(event);
        break;
      case 'numberOnly':
        isPreventDefaultRequired =
          !this.isNumericInput(event) && !this.isModifierKey(event);
        break;
      case 'decimal':
        isPreventDefaultRequired =
          !this.isNumericInput(event) &&
          !this.isModifierKey(event) &&
          event.keyCode !== 110;
        break;
      case 'calendarOnly':
        isPreventDefaultRequired = true;
        break;
    }
    if (isPreventDefaultRequired) {
      event.preventDefault();
    }
  }
}
