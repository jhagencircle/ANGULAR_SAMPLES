import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy,
} from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { PaymentsService } from '../shared/payments.service';
import { IPayment } from '../shared/payment.model';
import { IAutoPayment } from '../../autopay/shared/autopayment.model';
import { IPaymentResponse } from '../shared/payment-response.model';
import { AutopaymentService } from '../../autopay/shared/autopayment.service';
import { PaymentSectionEnum } from 'src/app/shared/enums/payment-section-enum';
import { AppConstants } from '../../shared/constants/app-constants';
import { Subscription } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-review-payment',
  templateUrl: './review-payment.component.html',
  styleUrls: ['./review-payment.component.scss'],
})
export class ReviewPaymentComponent implements OnInit, OnDestroy {
  @Input() accounts: any;
  @Input() title: string;
  @Input() submitButtonText: string;
  @Output() paymentEnrolled = new EventEmitter<boolean>();
  termsCheck: boolean = false;
  previousPaymentSection: string | null;
  payments: IPayment[] = [];
  autopayment: IAutoPayment;
  paymentResponse: IPaymentResponse[] = [];
  paymentGroup = new FormGroup({
    termsAndConditions: new FormControl(false),
  });
  loading: boolean = false;
  subscriptions: Subscription[] = [];

  constructor(
    private router: Router,
    private paymentsService: PaymentsService,
    private autopaymentService: AutopaymentService
  ) {
    this.previousPaymentSection = localStorage.getItem(
      AppConstants.PREVIOUS_PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );
  }

  ngOnInit(): void {}
  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }
  cancel() {
    if (localStorage.getItem(AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY)) {
      localStorage.setItem(
        AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
        this.previousPaymentSection ?? PaymentSectionEnum.ClaimsInvoice
      );
    } else {
      localStorage.setItem(
        AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
        this.previousPaymentSection ?? PaymentSectionEnum.Account
      );
    }
    window.location.reload();
  }

  onPaymentSubmit() {
    if (this.previousPaymentSection !== PaymentSectionEnum.ClaimsInvoice) {
      this.loading = true;

      if (this.previousPaymentSection === PaymentSectionEnum.Autopayment) {
        this.autopayment = {
          accountId: this.accounts[0].accountId,
          bankAccountId: this.accounts[0].payment.bankAccount.id,
        };
        let subscription = this.autopaymentService
          .enroll(this.autopayment)
          .subscribe(
            (response) => {
              if (response.message === AppConstants.AUTOPAY_ENROLL_SUCCESS) {
                this.loading = false;
                localStorage.setItem(
                  AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
                  this.previousPaymentSection ?? PaymentSectionEnum.Autopayment
                );
                this.paymentEnrolled.emit(true);
              }
            },
            (error: HttpErrorResponse) => {
              this.paymentEnrolled.emit(false);
            }
          );
        this.subscriptions.push(subscription);
      } else {
        this.payments = this.accounts.map((item: any) => {
          return {
            tokenId: item.payment.bankAccount.id,
            accountId: item.accountId,
            billId: item.billId,
            paymentTransactionDate: item.payment.date,
            paymentAmount: item.payment.totalAmount,
          };
        });

        let subscription = this.paymentsService
          .postPayment(this.payments)
          .subscribe((data) => {
            this.loading = false;
            this.setConfirmation(data);
            this.goToConfirmation();
          });
        this.subscriptions.push(subscription);
      }
    } else {
      //Claims invoice payment
      this.loading = true;
      this.payments = this.accounts.map((item: any) => {
        return {
          tokenId: item.payment.bankAccount.id,
          accountId: item.accountId,
          billId: item.billId,
          paymentTransactionDate: item.payment.date,
          paymentAmount: item.payment.totalAmount,
          billFromDate: item.payment.billFromDate,
          billToDate: item.payment.billToDate,
        };
      });

      let subscription = this.paymentsService
        .postClaimsPayment(this.payments[0])
        .subscribe((data) => {
          this.loading = false;
          this.setClaimsConfirmation(data, this.payments[0]);
          this.goToConfirmation();
        });
      this.subscriptions.push(subscription);
    }
  }

  goToConfirmation() {
    this.router.navigate(['/payments/payment-confirmation'], {
      skipLocationChange: true,
    });
  }

  setConfirmation(paymentResponse: IPaymentResponse[]) {
    this.paymentResponse = paymentResponse.map((item: IPaymentResponse) => {
      let account = this.accounts.find(
        (element: any) => element.accountId === item.accountId
      );
      item.account = account.accountName;
      item.bankAccount = `${account.payment.bankAccount.nickname.toUpperCase()},${
        account.payment.bankAccount.routingNumber
      }`;
      item.billingPeriod = account.payment.billingPeriod;
      return item;
    });

    this.paymentsService.setPaymentConfirmation(this.paymentResponse);
  }

  setClaimsConfirmation(response: any, payment: any) {
    let account = this.accounts[0];
    let accountName = account.accountName;
    let bankAccountName = `${account.payment.bankAccount.nickname.toUpperCase()},${
      account.payment.bankAccount.routingNumber
    }`;
    let billingPeriod = account.payment.billingPeriod;

    let claimPaymentConfirmation: IPaymentResponse = {
      account: accountName,
      paymentTransactionDate: payment.paymentTransactionDate,
      billingPeriod: billingPeriod,
      bankAccount: bankAccountName,
      paymentTransactionNumber: response.paymentTransactionNumber,
      paymentAmount: payment.paymentAmount,
      statusName: response.statusName,
    };

    this.paymentResponse.push(claimPaymentConfirmation);

    this.paymentsService.setPaymentConfirmation(this.paymentResponse);
  }
}
