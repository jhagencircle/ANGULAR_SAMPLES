import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CoverageService } from './coverage.service';
import { CoverageServiceMock } from 'src/app/shared/mocks/coverage.service.mock';
import { ICoverage } from './models/coverage.model';
import { of } from 'rxjs';

describe('CoverageService', () => {
  let service: CoverageService;

  let httpClientSpy: {
    get: jasmine.Spy;
    delete: jasmine.Spy;
    post: jasmine.Spy;
  };
  let mockedCoverages: ICoverage[] = [];
  let mockCoverageService = new CoverageServiceMock();

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [HttpClientTestingModule] });
    service = TestBed.inject(CoverageService);
    httpClientSpy = jasmine.createSpyObj('HttpClient', [
      'get',
      'delete',
      'post',
    ]);
    mockCoverageService.get().subscribe((data) => (mockedCoverages = data));
    service = new CoverageService(httpClientSpy as any);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return mockList', () => {
    httpClientSpy.get.and.returnValue(of(mockedCoverages));
    service
      .get()
      .subscribe(
        (items) => expect(items).toEqual(mockedCoverages, 'expected coverages'),
        fail
      );
    expect(httpClientSpy.get.calls.count()).toBe(1);
  });
});
