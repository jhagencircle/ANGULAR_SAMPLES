import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BankAccountListComponent } from './bank-account-list.component';
import { AccountNumberMaskPipe } from '../shared/account-number-mask.pipe';
import { ConfirmationDialogService } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.service';
import { AccountService } from 'src/app/shared/services/account.service';
import { BankAccount } from '../shared/bank-account.model';
import { BankAccountService } from '../shared/bank-account.service';
import { AccountMock } from '../../shared/mocks/account.mock';
import { BankAccountMock } from '../../shared/mocks/bank-account.mock';
import { PaymentServiceMock } from '../../shared/mocks/payment.service.mock';
import { By } from '@angular/platform-browser';
import { PaymentsService } from 'src/app/payments/shared/payments.service';
import { AutopayMock } from '../../shared/mocks/autopay.mock';
import { AutopaymentService } from 'src/app/autopay/shared/autopayment.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('BankAccountListComponent', () => {
  let component: BankAccountListComponent;
  let fixture: ComponentFixture<BankAccountListComponent>;
  let mockConfirmationDialogService: ConfirmationDialogService;
  let mockAccountService: any = new AccountMock();
  let mockBankAccountModel: BankAccountMock;
  let bankAccounts: BankAccount[];
  let mockPaymentService: PaymentServiceMock;
  let mockAutopayService: any = new AutopayMock();

  beforeEach(async () => {
    mockBankAccountModel = new BankAccountMock();
    mockPaymentService = new PaymentServiceMock();
    mockBankAccountModel.get().subscribe((data) => (bankAccounts = data));
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [BankAccountListComponent, AccountNumberMaskPipe],
      providers: [
        { provide: BankAccountService, useValue: mockBankAccountModel },
        { provide: AccountService, useValue: mockAccountService },
        {
          provide: ConfirmationDialogService,
          useValue: mockConfirmationDialogService,
        },
        {
          provide: PaymentsService,
          useValue: mockPaymentService,
        },
        {
          provide: AutopaymentService,
          useValue: mockAutopayService,
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BankAccountListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();

    expect(component.bankAccounts).toEqual(bankAccounts);
  });

  it('should delete bank card', () => {
    component.bankAccounts = bankAccounts;
    component.deleteBankAccount(component.bankAccounts[0]);

    expect(component.bankAccounts).toEqual(bankAccounts);
  });

  it('should show add form', () => {
    component.showAddForm();
    expect(component.isAddFormVisible).toBeTruthy();
  });

  it('should hide add form', () => {
    component.hideAddForm();
    expect(component.isAddFormVisible).toBeFalsy();
  });

  it('should show edit form', () => {
    component.showEditForm();
    expect(component.isEditFormVisible).toBeTruthy();
  });

  it('should hide edit form', () => {
    component.hideEditForm(false);
    expect(component.isEditFormVisible).toBeFalsy();
  });

  it('should show delete enabled', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.link.disabled').textContent).toContain(
      'Delete'
    );
  });

  it('should show delete disabled', () => {
    component.bankAccounts[0].isEdit = true;
    const compiledDeb = fixture.debugElement;
    const linkDeb = compiledDeb.queryAll(By.css('td'));
    const lnk = linkDeb[1].nativeElement;
    expect(lnk.textContent).toEqual('boa');
  });
});
