﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.Models.Requests;
using BCBSAZ.ProviderCredentialing.Models.Responses;

namespace BCBSAZ.ProviderCredentialing.Interfaces.Managers
{
	public interface IApplicationManager
	{
		Task<SubmitApplicationResponse> SubmitApplicationAsync(SubmitApplicationRequest request);
	}
}
