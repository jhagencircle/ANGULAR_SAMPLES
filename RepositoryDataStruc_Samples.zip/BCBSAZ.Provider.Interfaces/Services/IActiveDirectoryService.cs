﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface IActiveDirectoryService
	{
		Role[] GetInternalUserInfoAndRoles(WebUser webUser, ref string email);
	}
}