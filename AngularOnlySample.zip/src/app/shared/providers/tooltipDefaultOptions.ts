import { TooltipOptions } from 'ng2-tooltip-directive';

export const TooltipDefaultOptions: TooltipOptions = {
  theme: 'light',
};
