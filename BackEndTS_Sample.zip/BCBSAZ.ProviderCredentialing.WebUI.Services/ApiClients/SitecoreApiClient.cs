﻿using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.ApiClients;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebUI.Services.ApiClients
{
	public class SitecoreApiClient : HttpClient, ISitecoreApiClient
	{

		public SitecoreApiClient(IConfiguration configuration)
		{

			var serviceUrl = configuration.GetValue<string>(Constants.Configuration.SitecoreApiUrl);

			if (string.IsNullOrWhiteSpace(serviceUrl)) throw new ArgumentException("Invalid Service Url specified for Sitecore Web API.");

			BaseAddress = new Uri(serviceUrl.EnsureEndsWith('/'));

			DefaultRequestHeaders.Clear();
			DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
		}

		/// <summary>
		/// Gets the content provided by the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		/// <exception cref="InvalidApiResponseException">If the response from the Web Api is not a Success status code (200) this exception will be thrown containing the details of the non-success response from the WebApi</exception>
		public async Task<TResult> GetAsync<TResult>(string requestUri) where TResult : class
		{
			var message = new HttpRequestMessage(HttpMethod.Get, requestUri);

			var response = await SendAsync(message);

			// Shortcut, if the caller is requesting the HttpResponseMessage as the result, just return it
			// (consuming code is responsible for checking status code & response content)
			if (response is TResult) return response as TResult;

			var content = await response.Content.ReadAsStringAsync();

			if (response.IsSuccessStatusCode)
			{
				return JsonConvert.DeserializeObject<TResult>(content);
			}
			else
			{
				throw new InvalidApiResponseException(response.StatusCode, response.ReasonPhrase, response.Content.Headers.ContentType, content, "Sitecore API");
			}
		}
	}
}
