﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Provider;
using BCBSAZ.Provider.Models.Responses.Common;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface IProviderManager
	{
		TaxIdsForOrgResponse GetTaxIdsForOrg(TaxIdsForOrgRequest request);

		ProviderInfoResponse GetProviderInfoForCurrentUser(WebUser user);

		ProviderInfoResponse GetProviderInfo(string providerId, string taxId, WebUser user);
	}
}
