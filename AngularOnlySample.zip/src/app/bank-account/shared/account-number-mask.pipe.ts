import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'accountNumberMask'
})
export class AccountNumberMaskPipe implements PipeTransform {

  transform(accountNumber: string, visibleDigits: number = 4): string {
    let maskedSection = accountNumber.slice(0,-visibleDigits);
    let visibleSection = accountNumber.slice(-visibleDigits);
    return maskedSection.replace(/./g,'X') + visibleSection;
  }

}
