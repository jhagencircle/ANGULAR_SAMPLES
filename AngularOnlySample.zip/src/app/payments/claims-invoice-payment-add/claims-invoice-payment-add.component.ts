import { Component, OnInit, Input } from '@angular/core';
import { Subject } from 'rxjs';
import { Router } from '@angular/router';
import { PaymentSectionEnum } from 'src/app/shared/enums/payment-section-enum';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BankAccount } from 'src/app/bank-account/shared/bank-account.model';
import { BankAccountService } from 'src/app/bank-account/shared/bank-account.service';
import { ISummary } from 'src/app/shared/models/summary.model';
import { Observable, Subscription } from 'rxjs';
import { AccountService } from 'src/app/shared/services/account.service';
import { SubAccountService } from '../../shared/services/sub-account.service';
import { PaymentsService } from '../shared/payments.service';
import { AccountLevelEnum } from 'src/app/shared/enums/account-level-enum';

@Component({
  selector: 'app-claims-invoice-payment-add',
  templateUrl: './claims-invoice-payment-add.component.html',
  styleUrls: ['./claims-invoice-payment-add.component.scss'],
})
export class ClaimsInvoicePaymentAddComponent implements OnInit {
  subaccounts: any | null;
  currentBillTotalAmount: string;
  accountPaymentForm: FormGroup;
  subAccountPayment: any = [];
  bankAccounts: BankAccount[];
  account: ISummary;
  subscriptions: Subscription[] = [];
  payToAccount: any[] = [];
  accountBilling: string;
  subAccountSummaryList: ISummary[] = [];
  amount: string;
  currentAccount: any;
  accountLevelEnum = AccountLevelEnum;
  appConstants = AppConstants;
  date: string;

  constructor(
    private bankAccountService: BankAccountService,
    private accountService: AccountService,
    private router: Router,
    public fb: FormBuilder,
    public paymentsService: PaymentsService,
    private subaccountService: SubAccountService
  ) {
    this.loadSubAccounts();
    this.createForm();
    this.loadAccounts();
  }

  loadSubAccounts() {
    let subAcountsJson: string | null = localStorage.getItem(
      AppConstants.PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY
    );
    if (subAcountsJson != null) {
      this.subaccounts = JSON.parse(subAcountsJson);
    }
  }

  loadAccounts() {
    if (!this.account) {
      let subscription = this.accountService
        .get()
        .subscribe((account: ISummary) => {
          if (account) {
            this.account = account;
            this.accountBilling = account.billingLevel;
          }
        });
      this.subscriptions.push(subscription);
    }

    if (this.accountBilling === AccountLevelEnum.TopAccount) {
      this.payToAccount.push({
        name: this.account.accountName,
        value: this.account.accountId,
      });
      this.subAccountSummaryList.push(this.account);
      this.f.subAccount.setValue(this.account.accountId);
    }
    if (
      this.accountBilling === AccountLevelEnum.SubAccount ||
      this.accountBilling === AccountLevelEnum.SubSubAccount
    ) {
      this.subaccountService.getList().subscribe((subaccounts) => {
        if (subaccounts) {
          subaccounts.map((s) =>
            this.payToAccount.push({
              name: s.accountName,
              value: s.accountId,
            })
          );
          this.subAccountSummaryList = subaccounts;
        }
      });
    }
  }

  get f() {
    return this.accountPaymentForm.controls;
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  createForm() {
    this.accountPaymentForm = this.fb.group({
      bankAccount: ['', [Validators.required]],
      subAccount: ['', [Validators.required]],
      billingPeriod: ['', [Validators.required]],
      date: ['', [Validators.required]],
      amount: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {
    this.getBankAccounts();
  }

  getBankAccounts() {
    let bankAccountSubs = this.bankAccountService
      .get(this.account.accountId)
      .subscribe((data) => {
        this.bankAccounts = data;
      });
    this.subscriptions.push(bankAccountSubs);
  }

  cancel() {
    localStorage.removeItem(AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY);
    this.router.navigate(['/landing-page']);
  }

  onSubmit() {
    if (this.accountPaymentForm.valid) {
      this.setPaymentData();
      this.subAccountPayment.push(this.currentAccount);
      this.goToReview();
    }
  }

  onInputClick() {
    this.amount = this.amount
      ? this.paymentsService.parseNumber(this.amount).toString()
      : '';
  }

  setPaymentData() {
    //get Billint period
    var currentDate = new Date();
    let year = currentDate.getFullYear();
    let month = this.f.billingPeriod.value;
    let fromDate = new Date(year, month, 1);
    let toDate = new Date(year, month + 1, 0);
    let period = AppConstants.months.find((m) => m.id === month);

    this.currentAccount = this.subAccountSummaryList.find(
      (item: any) => item.accountId === this.f.subAccount.value
    );

    this.currentAccount['payment'] = {
      totalAmount: this.f.amount.value
        ? this.paymentsService.parseNumber(this.f.amount.value)
        : 0,
      bankAccount: this.bankAccounts.find(
        (element: any) => element.id === parseInt(this.f.bankAccount.value)
      ),

      date: this.f.date.value,
      billingPeriod: `${period.name}, ${currentDate.getFullYear()}`,
      accountId: this.f.subAccount.value,
      billFromDate: fromDate,
      billToDate: toDate,
    };
  }

  goToReview() {
    localStorage.setItem(
      AppConstants.PAYMENT_SUBSECTION_ACCOUNTS_LOCAL_STORAGE_KEY,
      JSON.stringify(this.subAccountPayment)
    );
    let currentSection = localStorage.getItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );
    localStorage.setItem(
      AppConstants.PREVIOUS_PAYMENT_SECTION_LOCAL_STORAGE_KEY,
      currentSection ?? PaymentSectionEnum.ClaimsInvoice
    );
    localStorage.setItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
      PaymentSectionEnum.Review
    );
    window.location.reload();
  }

  inputAmountFocusOut() {
    let amountFloat = this.paymentsService.parseNumber(this.amount);
    if (amountFloat <= 0 || isNaN(amountFloat)) {
      amountFloat = 1;
    }
    this.amount = this.paymentsService.parseCurrency(amountFloat);
  }
}
