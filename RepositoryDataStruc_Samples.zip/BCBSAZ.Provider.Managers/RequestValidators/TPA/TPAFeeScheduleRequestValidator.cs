﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.TPA;
using BCBSAZ.Provider.Models.Requests.TPA;

namespace BCBSAZ.Provider.Managers.RequestValidators.TPA
{
	internal static class TPAFeeScheduleRequestValidator
	{
		public static void Validate(this TPAFeeScheduleRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetVoilations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetVoilations(TPAFeeScheduleRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.TaxId))
				yield return new InvalidModelExceptionDetail(nameof(TPAFeeScheduleRequest.TaxId), new ArgumentException("TaxId is missing."));

			if (request.ProcCodes.IsNullOrEmpty())
				yield return new InvalidModelExceptionDetail(nameof(TPAFeeScheduleRequest.ProcCodes), new ArgumentException("Proc Codes are empty or missing."));

			foreach(var row in request.ProcCodes)
			{
				if (string.IsNullOrEmpty(row.Code))
				{
					yield return new InvalidModelExceptionDetail(nameof(ProcedureCode.Code), new ArgumentException("Proc Code row is missing code."));
					break;
				}

				if (!row.DateOfService.HasValue)
				{
					yield return new InvalidModelExceptionDetail(nameof(ProcedureCode.DateOfService), new ArgumentException("Proc Code row is missing Date of Service."));
					break;
				}

				if (string.IsNullOrEmpty(row.PlaceOfService))
				{
					yield return new InvalidModelExceptionDetail(nameof(ProcedureCode.Code), new ArgumentException("Proc Code row is missing Place of Service."));
					break;
				}
			}
		}
	}
}

