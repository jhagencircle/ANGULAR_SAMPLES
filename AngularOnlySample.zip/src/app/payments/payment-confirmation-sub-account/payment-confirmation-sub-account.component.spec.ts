import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DecimalPipe } from '@angular/common';
import { PaymentConfirmationSubAccountComponent } from './payment-confirmation-sub-account.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('PaymentConfirmationSubAccountComponent', () => {
  let component: PaymentConfirmationSubAccountComponent;
  let fixture: ComponentFixture<PaymentConfirmationSubAccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [PaymentConfirmationSubAccountComponent, DecimalPipe],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentConfirmationSubAccountComponent);
    component = fixture.componentInstance;
    var store = [
      {
        account: 'Sub-sub-account A',
        accountId: '021375-001-001',
        bankAccount: 'TB,1706',
        invoiceNumber: 611,
        paymentAmount: 15000,
        paymentTokenId: 25147,
        paymentTransactionDate: '2021-08-06T17:32:29Z',
        paymentTransactionNumber: 'RXI4N87JKRUKNZAN',
        paymentTransactionOrigin: 'Web',
        statusName: 'PENDING',
        transactionId: null,
      },
      {
        account: 'Sub-sub-account B',
        accountId: '021375-001-002',
        bankAccount: 'TEST,1706',
        invoiceNumber: 612,
        paymentAmount: 7500,
        paymentTokenId: 15103,
        paymentTransactionDate: '2021-08-06T17:32:29Z',
        paymentTransactionNumber: 'RXMBND90KRUOUZXA',
        paymentTransactionOrigin: 'Web',
        statusName: 'PENDING',
        transactionId: null,
      },
    ];
    var storeSintringify = JSON.stringify(store);
    spyOn(localStorage, 'getItem').and.callFake((key: string): any => {
      return storeSintringify;
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
