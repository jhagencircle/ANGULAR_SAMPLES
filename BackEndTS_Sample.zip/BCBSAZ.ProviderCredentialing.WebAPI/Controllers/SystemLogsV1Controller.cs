﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.Interfaces.Managers;
using BCBSAZ.ProviderCredentialing.Models;
using BCBSAZ.ProviderCredentialing.Models.Data.Common;
using BCBSAZ.ProviderCredentialing.Models.Requests.Logger;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.ProviderCredentialing.WebAPI.Controllers
{
	[ApiController]
	[Route("api/v1/SystemLogs")]
	public class SystemLogsV1Controller : ControllerBase
	{
		private readonly ISystemLogsManager _manager;

		public SystemLogsV1Controller(ISystemLogsManager manager) => _manager = manager;

		[HttpPost("Insert")]
		public VoidResult InsertLogMessage([FromBody]InsertLogMessageRequest request)
		{
			if (ModelState.IsValid)
			{
				return _manager.InsertLogMessage(request);
			}
			else
			{
				throw new InvalidRequestException(ModelState.ToInvalidModelExceptionDetails());
			}
		}

		[HttpGet("LogMessages")]
		public IEnumerable<LogMessage> GetLogMessages([FromServices]LogMessageQueue queue, [FromServices]IHostEnvironment hostEnvironment, bool clear = false)
		{
			if (hostEnvironment.IsDevelopment())
			{
				var retVal = queue.ToArray();

				if (clear)
					queue.Clear();

				return retVal;
			}
			else
			{
				return Enumerable.Empty<LogMessage>();
			}
		}
	}
}