﻿using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.FeatureToggles;
using BCBSAZ.Provider.Models.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Repositories.Mocks
{
	public class MockFeatureToggleRepository : IFeatureToggleRepository
	{
		public FeatureToggle[] GetFeatureToggles(string applicationName, string environmentName)
		{
			return GetMockData(applicationName, environmentName).ToArray();
		}

		private static IEnumerable<FeatureToggle> GetMockData(string applicationName, string environmentName)
		{
			yield return new FeatureToggle() { ApplicationName = applicationName, EnvironmentName = environmentName, FeatureName = "US8811_ASC_Link", IsFeatureActive = true, Toggle = true };
			yield return new FeatureToggle() { ApplicationName = applicationName, EnvironmentName = environmentName, FeatureName = "US8811_ASC_Search", IsFeatureActive = true, Toggle = true };
		}
	}
}
