import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ManageBenefitsComponent } from './manage-benefits.component';
import { OverlaySidePanelService } from '../shared/components/overlay-side-panel/overlay-side-panel.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SubAccountService } from '../shared/services/sub-account.service';
import { MockSubAccount } from 'src/app/shared/mocks/sub-account.mock';

describe('ManageBenefitsComponent', () => {
  let component: ManageBenefitsComponent;
  let fixture: ComponentFixture<ManageBenefitsComponent>;
  let overlaySidePanelService: OverlaySidePanelService;
  let mockSubAccount: any = new MockSubAccount();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      declarations: [ManageBenefitsComponent],
      providers: [
        { provide: OverlaySidePanelService, useValue: overlaySidePanelService },
        { provide: SubAccountService, useValue: mockSubAccount },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageBenefitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    console.log('subAccount', component.subAccount);
    expect(component).toBeTruthy();
  });
});
