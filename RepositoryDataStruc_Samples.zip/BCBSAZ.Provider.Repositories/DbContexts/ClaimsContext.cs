﻿using BCBSAZ.Provider.Models.Data.Claims;
//using BCBSAZ.Provider.Models.Data.Claims.ClaimStatus;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IClaimsContext : IDbContext
	{

		DbSet<ClaimsRequest> ClaimsRequest { get; set; }

		DbSet<ClaimsResponse> ClaimsResponse { get; set; }

		DbSet<ClaimStatusCode> StatusCodes { get; set; }

		DbSet<ClaimStatusMessage> MessageCodes { get; set; }

	}

	public class ClaimsContext : DbContext, IClaimsContext
	{
		/// <summary>
		/// Creates a new instance of the PreCert DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public ClaimsContext(DbContextOptions<ClaimsContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the PreCert database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<ClaimStatusCode>().HasNoKey();
			modelBuilder.Entity<ClaimStatusMessage>().HasNoKey();
			modelBuilder.Entity<ClaimsRequest>().Property(e => e.InsertDate).HasDefaultValueSql("GetDate()");

			/******************** Property Configs ********************/
		}



		public DbSet<ClaimsRequest> ClaimsRequest { get; set; }

		public DbSet<ClaimsResponse> ClaimsResponse { get; set; }


		public DbSet<ClaimStatusCode> StatusCodes { get; set; }

		public DbSet<ClaimStatusMessage> MessageCodes { get; set; }

	}

}
