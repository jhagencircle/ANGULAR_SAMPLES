﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Settings;

namespace BCBSAZ.Provider.Managers.RequestValidators.Settings
{
	internal static class GetAllUserSettingsRequestValidator
	{
		public static void Validate(this GetAllUserSettingsRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(GetAllUserSettingsRequest request)
		{
			if (request.SettingId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(GetAllUserSettingsRequest.SettingId), new ArgumentException("SettingId is not valid."));
		}
	}
}
