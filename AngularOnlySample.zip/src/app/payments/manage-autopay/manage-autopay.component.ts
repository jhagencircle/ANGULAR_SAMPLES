import { Component, OnInit } from '@angular/core';
import { AlertService } from 'src/app/shared/components/alert/alert.service';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { PaymentSectionEnum } from 'src/app/shared/enums/payment-section-enum';
import { NotificationService } from 'src/app/shared/components/notification/notification.service';
import { NotificationType } from 'src/app/shared/enums/notification-type-enum';

@Component({
  selector: 'app-manage-autopay',
  templateUrl: './manage-autopay.component.html',
  styleUrls: ['./manage-autopay.component.scss'],
})
export class ManageAutopayComponent implements OnInit {
  paymentSubsectionComponent: string | null;
  previousPaymentSection: string | null;
  accounts: any;
  reviewTitle: string = AppConstants.REVIEW_AUTOPAY_TITLE;
  reviewSubmitText: string = AppConstants.REVIEW_AUTOPAY_SUBMIT_TEXT;

  constructor(
    public alertService: AlertService,
    public notificationService: NotificationService
  ) {
    this.paymentSubsectionComponent = localStorage.getItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );
    this.previousPaymentSection = localStorage.getItem(
      AppConstants.PREVIOUS_PAYMENT_SECTION_LOCAL_STORAGE_KEY
    );

    if (
      this.previousPaymentSection &&
      this.previousPaymentSection === PaymentSectionEnum.Account
    ) {
      localStorage.setItem(
        AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
        this.previousPaymentSection
      );
    }

    let subbAcountsJson: string | null = localStorage.getItem(
      AppConstants.PAYMENT_SUBSECTION_ACCOUNTS_LOCAL_STORAGE_KEY
    );
    if (subbAcountsJson != null) {
      this.accounts = JSON.parse(subbAcountsJson);
    }

    let saap: string | null = localStorage.getItem(
      AppConstants.CANCEL_ACCOUNT_NAME_LOCAL_STORAGE_KEY
    );
    if (saap !== null) {
      this.notificationService.configNotification(
        AppConstants.AUTOPAY_CANCEL_MESSAGE.replace('${saap}', saap),
        NotificationType.Success,
        true
      );

      localStorage.removeItem(
        AppConstants.CANCEL_ACCOUNT_NAME_LOCAL_STORAGE_KEY
      );
    }

    if (
      this.paymentSubsectionComponent === null ||
      (this.paymentSubsectionComponent === PaymentSectionEnum.Review &&
        this.accounts === undefined)
    ) {
      localStorage.setItem(
        AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
        PaymentSectionEnum.Autopayment
      );
      this.paymentSubsectionComponent = PaymentSectionEnum.Autopayment;
    }
  }

  ngOnInit(): void {}

  ngOnDestroy(): void {
    localStorage.removeItem(AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY);
    localStorage.removeItem(
      AppConstants.PAYMENT_SUBSECTION_ACCOUNTS_LOCAL_STORAGE_KEY
    );
  }

  autopaymentDeleted(event: string) {
    localStorage.setItem(
      AppConstants.CANCEL_ACCOUNT_NAME_LOCAL_STORAGE_KEY,
      event
    );
    window.location.reload();
  }

  paymentEnrolled(event: boolean) {
    localStorage.setItem(
      AppConstants.PAYMENT_SECTION_LOCAL_STORAGE_KEY,
      PaymentSectionEnum.Autopayment
    );
    if (event) {
      this.notificationService.configNotification(
        AppConstants.ENROLL_AUTOPAYMENT_SUCCESS,
        NotificationType.Success,
        true
      );
    } else {
      this.notificationService.configNotification(
        AppConstants.ENROLL_AUTOPAYMENT_FAILED,
        NotificationType.Error,
        true
      );
    }
    this.paymentSubsectionComponent = PaymentSectionEnum.Autopayment;
  }
}
