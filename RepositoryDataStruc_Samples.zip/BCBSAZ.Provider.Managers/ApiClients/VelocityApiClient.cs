﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Models.Data.Velocity;
using BCBSAZ.Provider.Models.Exceptions;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Remits;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Managers.ApiClients
{
	public class VelocityApiClient : ApiClientBase, IVelocityApiClient
	{
		private readonly ILogger<VelocityApiClient> _logger;

		public VelocityApiClient(IConfiguration configuration, IOktaApiClient oktaClient, ILogger<VelocityApiClient> logger) : base(oktaClient)
		{
			base.Timeout = new TimeSpan(0, 0, configuration.GetValue<int>(Constants.Configuration.Timeouts.VelocityTimeout));
			var serviceUrl = configuration.GetValue<string>(Constants.Configuration.VelocityApiUrl);

			if (string.IsNullOrWhiteSpace(serviceUrl))
				throw new ArgumentException("Invalid Service Url specified for Velocity API.");

			BaseAddress = new Uri(serviceUrl.EnsureEndsWith('/'));

			DefaultRequestHeaders.Clear();
			DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			_logger = logger;
		}

		protected override string Name => "Velocity API Client";


		public async Task<byte[]> GetRemitDocumentAsync(int doucmentId)
		{
			var url = string.Format(CultureInfo.InvariantCulture, Constants.VelocityApis.RemitDocument, doucmentId);
			var response = await GetAsync<HttpResponseMessage>(url);

			if (response.IsSuccessStatusCode)
			{
				return await response.Content.ReadAsByteArrayAsync();
			}
			else
			{
				throw new InvalidApiResponseException(response.StatusCode, response.ReasonPhrase, response.Content.Headers.ContentType, url, this.Name);
			}
		}

		public async Task<IEnumerable<SearchVelocityRemitDocumentResponse>> SearchRemitDocumentAsync(SearchVelocityRemitDocumentRequest request)
		{
			Func<HttpResponseMessage, IEnumerable<SearchVelocityRemitDocumentResponse>> getEmptyRemitList = (x) => new List<SearchVelocityRemitDocumentResponse>();
			var response = await PostAsync(Constants.VelocityApis.SearchDocument, request, getEmptyRemitList);

			return response;
		}


		public async Task<bool> IsMemberInHrpAsync(string subscriberId)
		{
			try
			{
				var url = string.Format(CultureInfo.InvariantCulture, Constants.VelocityApis.Subscriber, subscriberId);
				_ = await GetAsync<SubscriberMember>(url);

				return true;				
			}
			catch (InvalidApiResponseException ex)
			{
				if (ex.StatusCode != HttpStatusCode.NotFound) // Only log if it wasn't a 404
					_logger.LogError($"Velocity's IsMemberInHrpAsync throw a Error: {ex.StatusCode}, with Message: {ex.Message}");

				return false;
			}
			catch (RecordNotFoundException ex)
			{
				return false;
			}
		}


	}
}
