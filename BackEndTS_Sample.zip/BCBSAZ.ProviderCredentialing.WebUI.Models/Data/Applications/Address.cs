﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class Address : IAddress
	{
		public Address() =>
			Types = new List<AddressType>();

		public Address(params AddressType[] addressTypes) =>
			Types = new List<AddressType>(addressTypes);


		[Required(ErrorMessage = "Address is required")]
		[DataType(DataType.MultilineText)]
		[RegularExpression("[A-Za-z0-9\\s. #-]*", ErrorMessage = "Please enter a valid Address")]
		[DisplayName("Address")]
		[MaxLength(200)] // Per USPS Regulations, there are a maximum of 5 lines allowed with 35 characters per line (175 characters total not including carriage return/line feed)
		public string StreetAddress { get; set; }

		[Required(ErrorMessage = "City is required")]
		[RegularExpression("^[A-Za-z A-Za-z]*[A-Za-z]*$", ErrorMessage = "Please enter a valid City")]
		[DisplayName("City")]
		[MaxLength(25)]
		public string City { get; set; }

		[Required(ErrorMessage = "State is required")]
		[RegularExpression("^[A-Za-z]{2}$", ErrorMessage = "Please enter a valid State")]
		[DisplayName("State")]
		[MaxLength(2)]
		public string State { get; set; }

		[Required(ErrorMessage = "ZIP Code is required")]
		[DisplayName("ZIP Code")]
		[DataType(DataType.Text)]
		[RegularExpression("^[0-9]{5}$", ErrorMessage = "Please enter a valid ZIP Code")]
		[MaxLength(5)]
		public string ZipCode { get; set; }

		[DisplayName("Email Address")]
		[Required(ErrorMessage = "Email Address is required")]
		[RegularExpression(@"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$", ErrorMessage = "Please enter a valid Email Address")]
		[MaxLength(50)]
		public string EmailAddress { get; set; }

		[Required(ErrorMessage = "Phone is required")]
		[DataType(DataType.PhoneNumber)]
		[DisplayName("Phone (Patient Scheduling Number)")]
		[InputMask("'mask': '999-999-9999'")]
		[RegularExpression("^[0-9]{3}-[0-9]{3}-[0-9]{4}", ErrorMessage = "Please enter a valid Phone")]
		public string Phone { get; set; }

		[Required(ErrorMessage = "Fax is required")]
		[DataType(DataType.PhoneNumber)]
		[DisplayName("Fax")]
		[InputMask("'mask': '999-999-9999'")]
		[RegularExpression("^[0-9]{3}-[0-9]{3}-[0-9]{4}", ErrorMessage = "Please enter a valid Fax")]
		public string Fax { get; set; }



		public ICollection<AddressType> Types { get; set; }

	}
}
