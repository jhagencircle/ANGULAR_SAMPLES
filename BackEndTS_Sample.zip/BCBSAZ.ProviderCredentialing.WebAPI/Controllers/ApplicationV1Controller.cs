﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.Interfaces.Managers;
using BCBSAZ.ProviderCredentialing.Models;
using BCBSAZ.ProviderCredentialing.Models.Requests;
using BCBSAZ.ProviderCredentialing.Models.Responses;
using Microsoft.AspNetCore.Mvc;

namespace BCBSAZ.ProviderCredentialing.WebAPI.Controllers
{
	[Route("api/v1/Application")]
	[ApiController]
	public class ApplicationV1Controller : ControllerBase
	{

		private readonly IApplicationManager _manager;

		public ApplicationV1Controller(IApplicationManager manager) =>
			_manager = manager;

		[HttpPost("Submit")]
		public Task<SubmitApplicationResponse> SubmitApplication(SubmitApplicationRequest request)
		{
			if (ModelState.IsValid)
			{
				return _manager.SubmitApplicationAsync(request);
			}
			else
			{
				throw new InvalidRequestException(ModelState.ToInvalidModelExceptionDetails());
			}
		}
	}
}