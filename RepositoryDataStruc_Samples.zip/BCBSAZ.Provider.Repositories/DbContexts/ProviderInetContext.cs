﻿#define PERF_TEST
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.Settings;
using BCBSAZ.Provider.Models.Data.Eligibility;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Data.Security;
using BCBSAZ.Provider.Models.Data.Subscriber;
using BCBSAZ.Provider.Repositories.Converters;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using BCBSAZ.Provider.Models.Data.TPA;
using BCBSAZ.Provider.Models.Data.OfficeUserManagement;
using System;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IProviderInetContext : IDbContext
	{
		/// <summary>
		/// Gets the DbSet object for Provider Tax Ids
		/// </summary>
		DbSet<ProviderTaxId> ProviderTaxIds { get; }

		/// <summary>
		/// Gets the DbSet object for Application Users
		/// </summary>
		DbSet<WebUser> ApiUsers { get; }

		/// <summary>
		/// Gets the DbSet object for User Roles
		/// </summary>
		DbSet<Role> Roles { get; }

		DbSet<ValuesEntered> ValuesEntered { get; }

		DbSet<ServiceType> ServiceTypes { get; }

		DbSet<PortalUser> PrecertUsers { get; }

		DbSet<NPI> NPIs { get; }

		DbSet<PreviouslySelectedServiceType> SavedServiceTypes { get; }

		DbSet<ProviderInfo> Providers { get; }

		DbSet<TPAPlaceOfService> TPAPlacesOfService { get; }

		DbSet<TpaProvider> TpaProvider { get; }

		DbSet<UserSummary> Users { get; }

		DbSet<UserProfile> UserProfiles { get; }

		DbSet<SubOrgSummary> SubOrgSummaries { get; }

		DbSet<SubOrg> SubOrgs { get; }

		DbSet<AssignedProvider> AssignedProviders { get; }

		DbSet<MemberCutoffDate> CutoffDate { get; }

		/// <summary>
		/// Gets the DbSet object for Provider Contract Status
		/// </summary>
		DbSet<TpaProviderContractStatus> TpaProviderContractStatus { get; }


		/// <summary>
		/// Gets the DbSet object for Provider Contract Status
		/// </summary>
		DbSet<TpaProviderInfo> TpaProviderInfo { get; }
	}

	/// <summary>
	/// Defines the Entity Framework DbContext object for the FeeSched database
	/// </summary>
	public class ProviderInetContext : DbContext, IProviderInetContext
	{
		/// <summary>
		/// Creates a new instance of the FeeSched DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public ProviderInetContext(DbContextOptions<ProviderInetContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the FeeSched database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<ProviderTaxId>().HasNoKey();
			modelBuilder.Entity<WebUser>().HasNoKey();
			modelBuilder.Entity<Role>().HasNoKey();
			modelBuilder.Entity<ValuesEntered>().HasNoKey();
			modelBuilder.Entity<ServiceType>().HasNoKey();
			modelBuilder.Entity<PortalUser>().HasNoKey();
			modelBuilder.Entity<NPI>().HasNoKey();
			modelBuilder.Entity<PreviouslySelectedServiceType>().HasNoKey();
			modelBuilder.Entity<ProviderInfo>().HasNoKey();
			modelBuilder.Entity<TPAPlaceOfService>().HasNoKey();
			modelBuilder.Entity<TpaProvider>().HasNoKey();
			modelBuilder.Entity<UserSummary>().HasNoKey();
			modelBuilder.Entity<UserProfile>().HasNoKey();
			modelBuilder.Entity<SubOrgSummary>().HasNoKey();
			modelBuilder.Entity<SubOrg>().HasNoKey();
			modelBuilder.Entity<AssignedProvider>().HasNoKey();
			modelBuilder.Entity<TpaProviderContractStatus>().HasNoKey();
			modelBuilder.Entity<TpaProviderInfo>().HasNoKey();
			modelBuilder.Entity<MemberCutoffDate>().HasNoKey();

			/******************** Property Configs ********************/

			modelBuilder.Entity<ProviderTaxId>()
				.Property(p => p.TaxId).HasConversion(new TrimStringConverter());
		}

		/// <summary>
		/// Gets the DbSet object for Provider Tax Ids
		/// </summary>
		public DbSet<ProviderTaxId> ProviderTaxIds { get; protected set; }

		/// <summary>
		/// Gets the DbSet object for Application Users
		/// </summary>
		public DbSet<WebUser> ApiUsers { get; protected set; }

		/// <summary>
		/// Gets the DbSet object for User Roles
		/// </summary>
		public DbSet<Role> Roles { get; protected set; }

		public DbSet<ValuesEntered> ValuesEntered { get; protected set; }

		public DbSet<ServiceType> ServiceTypes { get; protected set; }

		public DbSet<PortalUser> PrecertUsers { get; protected set; }

		public DbSet<NPI> NPIs { get; protected set; }

		public DbSet<PreviouslySelectedServiceType> SavedServiceTypes { get; protected set; }

		public DbSet<ProviderInfo> Providers { get; protected set; }

		public DbSet<TPAPlaceOfService> TPAPlacesOfService { get; protected set; }

		public DbSet<TpaProvider> TpaProvider { get; protected set; }

		public DbSet<UserSummary> Users { get; protected set; }

		public DbSet<UserProfile> UserProfiles { get; protected set; }

		public DbSet<SubOrgSummary> SubOrgSummaries { get; protected set; }

		public DbSet<SubOrg> SubOrgs { get; protected set; }

		public DbSet<AssignedProvider> AssignedProviders { get; protected set; }

		public DbSet<TpaProviderContractStatus> TpaProviderContractStatus { get; protected set; }
		public DbSet<TpaProviderInfo> TpaProviderInfo { get; protected set; }
		public DbSet<MemberCutoffDate> CutoffDate { get; protected set; }

	}
}
