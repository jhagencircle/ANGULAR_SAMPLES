import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AutopayAddComponent } from './autopay-add.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccountMock } from '../../shared/mocks/account.mock';
import { AccountService } from 'src/app/shared/services/account.service';
import { RouterTestingModule } from '@angular/router/testing';
import { SubAccountService } from '../../shared/services/sub-account.service';
import { MockSubAccount } from '../../shared/mocks/sub-account.mock';
import { AutopaymentService } from '../shared/autopayment.service';
import { AutopaymentServiceMock } from 'src/app/shared/mocks/autopayment.service.mock';

describe('AutopayAddComponent', () => {
  let component: AutopayAddComponent;
  let fixture: ComponentFixture<AutopayAddComponent>;
  let mockAccountService: any = new AccountMock();
  let mockSubAccount: any = new MockSubAccount();
  let autopaymentService: any = new AutopaymentServiceMock();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        ReactiveFormsModule,
        FormsModule,
        RouterTestingModule,
      ],
      declarations: [AutopayAddComponent],
      providers: [
        {
          provide: AccountService,
          useValue: mockAccountService,
        },
        { provide: SubAccountService, useValue: mockSubAccount },
        { provide: AutopaymentService, useValue: autopaymentService },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutopayAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should has required validator', fakeAsync(() => {
    expect(component.form.valid).toBeFalsy();

    component.form.controls.bankAccount.setValue('Test');
    component.form.controls.subAccount.setValue('01');

    expect(component.form.valid).toBeTruthy();
  }));

  it('Clicking on Cancel button emits cancelClick event', fakeAsync(() => {
    let valEmitted: string | undefined;
    component.cancelClick.subscribe((value: any) => (valEmitted = value));
    expect(valEmitted).toBeFalsy();
  }));

  it('Should display Pay to Account list', () => {
    component.account.billingLevel = 'sub';
    fixture.detectChanges();
    const element = fixture.debugElement.nativeElement.querySelector(
      '#payToAccountSection'
    );
    expect(element).toBeTruthy();
  });

  it('Should hide Pay to Account list', () => {
    component.account.billingLevel = 'top';
    fixture.detectChanges();
    const element = fixture.debugElement.nativeElement.querySelector(
      '#payToAccountSection'
    );
    expect(element).toBeFalsy();
  });

  it('"goToReview" method should be called', fakeAsync(() => {
    spyOn(component, 'goToReview');
    let saveButton =
      fixture.debugElement.nativeElement.querySelector('#btnSave');
    saveButton.click();
    fixture.whenStable().then(() => {
      expect(component.goToReview).toHaveBeenCalled();
    });
  }));
});
