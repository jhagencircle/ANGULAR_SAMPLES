import { CdkStep } from '@angular/cdk/stepper';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AbstractControl, FormBuilder, FormsModule } from '@angular/forms';
import { MatStepperModule } from '@angular/material/stepper';
import { AngularMaterialSharedModule } from 'src/app/common/shared/angular-material-shared.module';
import { SharedModule } from 'src/app/common/shared/shared.module';
import { EftChangeRequestFormModule } from '../eft-change-request-form.module';

import { EftProviderInformationFormComponent } from './eft-provider-information-form.component';

xdescribe('EftProviderInformationFormComponent', () => {
  let component: EftProviderInformationFormComponent;
  let fixture: ComponentFixture<EftProviderInformationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EftProviderInformationFormComponent ],
      imports: [ SharedModule, AngularMaterialSharedModule, FormsModule, EftChangeRequestFormModule ],
      providers: [ FormBuilder]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EftProviderInformationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
