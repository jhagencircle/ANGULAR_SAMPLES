export interface IEnrollmentProviderInformation
{
    eftUserProfile: 
    {
      requestId: 0,
      userId: string,
      firstName: string,
      middleInitial: string,
      lastName: string,
      dateOfBirth: string,
      ipAddress: string,
      insertDate: string
      filePath: string

    }
  }