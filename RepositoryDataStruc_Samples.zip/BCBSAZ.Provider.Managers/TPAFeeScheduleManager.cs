﻿using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Managers.RequestValidators.TPA;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.TPA;
using BCBSAZ.Provider.Models.Requests.TPA;
using BCBSAZ.Provider.Models.Responses.Common;
using BCBSAZ.Provider.Models.Responses.TPA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Managers
{
	public class TPAFeeScheduleManager : ITPAFeeScheduleManager
	{
		private readonly ITPAFeeScheduleRepository _tpaFeeScheduleRepository;

		public TPAFeeScheduleManager(ITPAFeeScheduleRepository tpaFeeScheduleRepository)
		{
			_tpaFeeScheduleRepository = tpaFeeScheduleRepository;
		}


		public Select2Response GetTpaPlaceOfService(TPAPlaceOfServiceRequest request)
		{
			var placesOfService = _tpaFeeScheduleRepository.GetPlaceOfService(request.DateOfService, request.Query, request.PageSize, request.PageNumber, out int totalCount);

			return new Select2Response()
			{
				Results = (
					from item in placesOfService
					select new Select2Item()
					{
						Id = item.DisplayCode.ToString() + "-" + item.Code.ToString(),
						Text = item.DisplayName
					}),
				TotalCount = totalCount
			};
		}

		public TPAFeeScheduleResponse GetTpaFeeScheduleDetail(TPAFeeScheduleRequest request)
		{
			request.Validate();

			return new TPAFeeScheduleResponse()
			{
				FeeDetails = _tpaFeeScheduleRepository.GetTpaFeeScheduleDetail(request.ProviderId, request.TaxId, request.ProcCodes)
			};
		}

		public async Task<TpaProviderInstitutionResponse> GetTpaProviderInstitutionAsync(TpaProviderInstitutionRequest request)
		{
			request.Validate();

			return new TpaProviderInstitutionResponse()
			{
				IsInstitution = await _tpaFeeScheduleRepository.IsProviderInstitutionAsync(request.TaxId, request.Npi)
			};
		}
	}
}
