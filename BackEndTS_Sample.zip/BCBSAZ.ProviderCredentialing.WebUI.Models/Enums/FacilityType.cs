﻿using System.ComponentModel.DataAnnotations;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Enums
{
	public enum FacilityType
	{
		Active,
		Courtesy,
		Delivery,
		Provisional
	}
}
