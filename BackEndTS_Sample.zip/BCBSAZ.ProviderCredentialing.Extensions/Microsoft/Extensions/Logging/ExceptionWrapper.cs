﻿using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Http;

namespace Microsoft.Extensions.Logging
{
	[SuppressMessage("Naming", "CA1710:Identifiers should have correct suffix", Justification = "This is a wrapper class only used to pass HttpContext to loggers.")]
	[SuppressMessage("Design", "CA1032:Implement standard exception constructors", Justification = "This is a wrapper class only used to pass HttpContext to loggers.")]
	public class ExceptionWrapper : Exception
	{
		public ExceptionWrapper(Exception exception, HttpContext httpContext)
		{
			Exception = exception;
			HttpContext = httpContext;
		}

		public Exception Exception { get; }
		public HttpContext HttpContext { get; }
	}
}
