﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.TPA;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Repositories
{
	public class TPAFeeScheduleRepository : ITPAFeeScheduleRepository
	{
		private readonly IProviderInetContext _providerInetContext;
		private readonly IFeeSchedContext _feeSchedContext;
		private readonly ILogger _logger;
		private readonly IHttpContextAccessor _contextAccessor;

		public TPAFeeScheduleRepository(IProviderInetContext provInetContext, IFeeSchedContext feeSchedContext, ILogger<TPAFeeScheduleRepository> logger, IHttpContextAccessor contextAccessor)
		{
			_providerInetContext = provInetContext;
			_feeSchedContext = feeSchedContext;
			_logger = logger;
			_contextAccessor = contextAccessor;
		}

		public TPAPlaceOfService[] GetPlaceOfService(DateTime dateOfService, string query, int pageSize, int pageNumber, out int totalCount)
		{
			// NOTE: Because we are dealing with a Stored Proc which uses an Output Parameter, we must use SqlParameters

			var totalCountParam = new SqlParameter()
			{
				ParameterName = "@TotalCount",
				DbType = DbType.Int32,
				Size = 4,
				Direction = ParameterDirection.Output
			};
			var beginsWithParam = new SqlParameter("@dateOfService", dateOfService);
			var queryParam = new SqlParameter("@query", query);
			var pageSizeParam = new SqlParameter("@PageSize", pageSize);
			var pageNumberParam = new SqlParameter("@PageNumber", pageNumber);

			var pos = _providerInetContext.TPAPlacesOfService.FromSqlRaw(DB.ProviderInet.StoredProcs.TpaGetPlaceOfService, beginsWithParam, queryParam, pageSizeParam, pageNumberParam, totalCountParam).AsEnumerable().ToArray();

			totalCount = (int)totalCountParam.Value;

			return pos;
		}

		public IEnumerable<TpaFeeDetail> GetTpaFeeScheduleDetail(string providerId, string taxId, IEnumerable<ProcedureCode> rows)
		{
			var procCodeRows = string.Join(",", rows.Select(GetProcCodeRow));
			return _feeSchedContext.TpaFeeDetail.FromSqlRaw(DB.FeeSched.StoredProcs.TpaGetFeeDetail, providerId, taxId, procCodeRows).AsEnumerable().ToArray();
		}

		public async Task<bool> IsProviderInstitutionAsync(string taxId, string provId)
		{
			var institutionCountParam = new SqlParameter()
			{
				ParameterName = "@institutionCount",
				DbType = DbType.Boolean,
				Size = 1,
				Direction = ParameterDirection.Output
			};

			var taxIdParam = new SqlParameter("@pdTaxId", taxId);
			var provIdParam = new SqlParameter("@pdProvId", provId);

			await _providerInetContext.Database.ExecuteSqlRawAsync(DB.ProviderInet.StoredProcs.GetInstitutionCount, taxIdParam, provIdParam, institutionCountParam);

			return !(bool)institutionCountParam.Value;
		}

		private string GetProcCodeRow(ProcedureCode row)
		{
			var POSCode = row.PlaceOfService.Substring(row.PlaceOfService.IndexOf("-") + 1);
			return $"{row.Code}|{POSCode}|{row.DateOfService:MM/dd/yyyy}";
		}
	}
}
