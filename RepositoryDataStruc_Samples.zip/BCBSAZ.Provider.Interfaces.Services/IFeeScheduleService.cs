﻿using BCBSAZ.Provider.Models.Data.FeeSchedule;
using BCBSAZ.Provider.Models.Responses.FeeSchedule;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.Services
{
	public interface IFeeScheduleService
	{
		Task<ProfessionalFeesResponse> SearchProfessionalFeesAsync(Filter filter);
		Task<OutpatientFeesResponse> SearchOutpatientFeesAsync(Filter filter);
		Task<ASCFeesResponse> SearchASCFeesAsync(Filter filter);
		Task<SpecialtiesResponse> GetSpecialtiesAsync();
		Task<TaxIdsForProviderResponse> GetTaxIdsForProviderAsync(string providerId);
	}
}
