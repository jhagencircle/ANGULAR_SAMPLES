﻿# Using Moq
See: https://github.com/Moq/moq4/wiki/Quickstart
