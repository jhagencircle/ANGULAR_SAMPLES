import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { OktaAuthService } from "@okta/okta-angular";
import { Observable, throwError } from "rxjs";
import { tap, catchError, finalize } from 'rxjs/operators';
import { LoggerService } from "../services/logger.service";

@Injectable()
export class HttpMiddleware implements HttpInterceptor {
    constructor(public oktaAuth: OktaAuthService, private logger: LoggerService) {

    }
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const accessToken = this.oktaAuth.getAccessToken();
        const modified = req.clone({ setHeaders: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` } });

        if (modified.url.includes("/api/splunk"))
            return next.handle(modified);

        const t0 = performance.now();

        return next.handle(modified).pipe(
            tap((event: HttpEvent<any>) => {
                if (event instanceof HttpResponse) {
                    let response = {
                        status: event.status,
                        statusText: event.statusText,
                        type: event.type,
                        url: event.url,
                        ok: event.ok,
                        body: event.body
                    };
                    this.logger.logInformation("Response received", response);
                }
            }),
            catchError((err) => {
                let error = {
                    error: err.error.message,
                    message: err.message,
                    name: err.name,
                    ok: err.ok,
                    status: err.status,
                    statusText: err.statusText,
                    url: err.url
                };

                this.logger.logError("Error calling Api", error);
                return throwError(err);
            }),
            finalize(() => {
                const t1 = performance.now();
                const totalResponseTime = (t1 - t0) / 1000;

                let request = {
                    url: modified.url,
                    urlWithParameters: modified.urlWithParams,
                    responseType: modified.responseType,
                    method: modified.method,
                    timeInMiliseconds: totalResponseTime
                };

                this.logger.logInformation("Call to Api", request);
            }),
        );
    }
}
