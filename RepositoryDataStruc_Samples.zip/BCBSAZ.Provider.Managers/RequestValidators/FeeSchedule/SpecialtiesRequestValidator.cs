﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.FeeSchedule;

namespace BCBSAZ.Provider.Managers.RequestValidators.FeeSchedule
{
	internal static class SpecialtiesRequestValidator
	{
		public static void Validate(this SpecialtiesRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(SpecialtiesRequest request)
		{
			return Enumerable.Empty<InvalidModelExceptionDetail>();
		}
	}
}
