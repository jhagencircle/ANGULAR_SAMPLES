﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Enums;
using Newtonsoft.Json;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class ProviderCredentialForm
	{

		#region Addresses
		public ICollection<IAddress> Addresses { get; set; } = new List<IAddress>();

		private IAddress GetAddress(AddressType addressType)
		{
			return FindAddressByType(addressType);
		}

		private IAddress FindAddressByType(AddressType addressType) =>
			(from address in Addresses
			 where address.Types.Contains(addressType)
			 select address).FirstOrDefault();

		private IAddress FindAddressByValue(IAddress value) =>
			(from address in Addresses
			 where address.IsMatch(value)
			 select address).FirstOrDefault();

		private void SetAddress(IAddress value, AddressType addressType)
		{
			if (!value.Types.Contains(addressType))
				value.Types.Add(addressType);

			RemoveExistingAddresses(value);

			var existing = FindAddressByValue(value);

			if (existing == null)
			{
				Addresses.Add(value);
			}
			else
			{
				foreach (var type in value.Types)
				{
					if (!existing.Types.Contains(type))
						existing.Types.Add(type);
				}
			}
		}

		private void RemoveExistingAddresses(IAddress value)
		{
			foreach (var addressType in value.Types)
			{
				var existing = FindAddressByType(addressType);

				if (existing != null)
				{
					existing.Types.Remove(addressType);

					if (existing.Types.Count == 0)
						Addresses.Remove(existing);
				}
			}
		}
		#endregion

		#region Names
		public ICollection<IName> Names { get; set; } = new List<IName>();

		private IName GetName(NameType nameType) =>
			FindNameByType(nameType);

		private IName FindNameByType(NameType nameType) =>
			(from Name in Names
			 where Name.Types.Contains(nameType)
			 select Name).FirstOrDefault();

		private IName FindNameByValue(IName value) =>
			(from name in Names
			 where name.IsMatch(value)
			 select name).FirstOrDefault();

		private void SetName(IName value, NameType nameType)
		{
			if (!value.Types.Contains(nameType))
				value.Types.Add(nameType);

			if (nameType != NameType.Additional)
				RemoveExistingNames(value.Types.ToArray());

			var existing = FindNameByValue(value);

			if (existing == null)
			{
				Names.Add(value);
			}
			else
			{
				foreach (var type in value.Types)
				{
					if (!existing.Types.Contains(type))
						existing.Types.Add(type);
				}
			}
		}

		private void RemoveExistingNames(params NameType[] nameTypes)
		{
			foreach (var nameType in nameTypes)
			{
				var existing = FindNameByType(nameType);

				if (existing != null)
				{
					existing.Types.Remove(nameType);

					if (existing.Types.Count == 0)
						Names.Remove(existing);
				}
			}
		}
		#endregion

		#region Email Addresses
		public ICollection<EmailAddress> EmailAddresses { get; set; } = new List<EmailAddress>();

		private EmailAddress GetEmailAddress(EmailAddressType emailAddressType) =>
					FindEmailAddressByType(emailAddressType) ?? new EmailAddress(emailAddressType);

		private EmailAddress FindEmailAddressByType(EmailAddressType emailAddressType) =>
			(from EmailAddress in EmailAddresses
			 where EmailAddress.Types.Contains(emailAddressType)
			 select EmailAddress).FirstOrDefault();

		private EmailAddress FindEmailAddressByValue(EmailAddress value) =>
			(from emailAddress in EmailAddresses
			 where emailAddress.IsMatch(value)
			 select emailAddress).FirstOrDefault();

		private void SetEmailAddress(EmailAddress value, EmailAddressType emailAddressType)
		{
			if (!value.Types.Contains(emailAddressType))
				value.Types.Add(emailAddressType);

			RemoveExistingEmailAddresses(value);

			var existing = FindEmailAddressByValue(value);

			if (existing == null)
			{
				EmailAddresses.Add(value);
			}
			else
			{
				foreach (var type in value.Types)
				{
					if (!existing.Types.Contains(type))
						existing.Types.Add(type);
				}
			}
		}

		private void RemoveExistingEmailAddresses(EmailAddress value)
		{
			foreach (var EmailAddressType in value.Types)
			{
				var existing = FindEmailAddressByType(EmailAddressType);

				if (existing != null)
				{
					existing.Types.Remove(EmailAddressType);

					if (existing.Types.Count == 0)
						EmailAddresses.Remove(existing);
				}
			}
		}
		#endregion

		#region CAQH Information

		public bool IsRegisteredWithCaqh { get; set; } = true;

		[DisplayName("CAQH Provider ID")]
		[Required(ErrorMessage = "CAQH Provider ID is required")]
		[RegularExpression("^[0-9]{8}$", ErrorMessage = "Please enter a valid CAQH Provider ID")]
		[MaxLength(8)]
		public string CaqhProviderId { get; set; }

		[Display(Name = "Uploaded supporting documentation in the CAQH profile/application")]
		public bool UploadedSupportedDocumentInCaqhApplication { get; set; }

		[DisplayName("Confirmed that my certificate is current and will not expire in the next 30 days")]
		public bool ConfirmedMyCertificateInCurrent { get; set; }

		[DisplayName("Attested to the CAQH Application")]
		public bool AttestedToCaqhApplication { get; set; }

		[DisplayName("Verified that my credentialing information, including the current practice address, is current")]
		public bool VerifiedMyCredentialingInformation { get; set; }

		[DisplayName("Authorized BCBSAZ to access my CAQH application")]
		public bool AuthorizedBcbsazAccessToCaqh { get; set; }

		[JsonIgnore]
		public Name ContactName
		{
			get => (GetName(NameType.ApplicationContactInformation) as Name) ?? new Name(NameType.ApplicationContactInformation);
			set => SetName(value, NameType.ApplicationContactInformation);
		}

		[Required(ErrorMessage = "Phone Number is required")]
		[DisplayName("Phone Number")]
		[InputMask("'mask': '999-999-9999'")]
		[RegularExpression("^[0-9]{3}-[0-9]{3}-[0-9]{4}", ErrorMessage = "Please enter a valid Phone Number")]
		[DataType(DataType.PhoneNumber)]
		public string ContactPhoneNumber { get; set; }

		[DisplayName("Ext.")]
		[RegularExpression("^\\d+", ErrorMessage = "Please enter a valid Phone Extension")]
		public string ContactPhoneNumberExtension { get; set; }

		[JsonIgnore]
		public EmailAddress ContactEmailAddress
		{
			get => GetEmailAddress(EmailAddressType.ApplicationContactInformation);
			set => SetEmailAddress(value, EmailAddressType.ApplicationContactInformation);
		}

		[DisplayName("Preferred way to contact")]
		public bool IsPhonePreferredContact { get; set; } = true;

		[DisplayName("Preferred way to contact")]
		public bool IsEmailPreferredContact { get; set; } = false;
		#endregion

		#region Provider Information

		[JsonIgnore]
		public Name ProviderInformationName
		{
			get => (GetName(NameType.ProviderInformation) as Name) ?? new Name(NameType.ProviderInformation);
			set => SetName(value, NameType.ProviderInformation);
		}

		[JsonIgnore]
		public AdditionalName[] AdditionalNames
		{
			get
			{
				var returnVal = (
					from n in Names
					where n.Types.Contains(NameType.Additional)
					select (n as AdditionalName) ?? new AdditionalName()
					).ToArray();

				return returnVal.Length == 0 ? new[] { new AdditionalName() } : returnVal;
			}
			set
			{
				RemoveExistingNames(NameType.Additional);
				value.ForEach(SetName, NameType.Additional);
			}
		}

		[Required(ErrorMessage = "Date of Birth is required")]
		[DataType(DataType.Text)]
		[DisplayName("Date of Birth")]
		[DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
		public DateTime? DateOfBirth { get; set; }

		[Required(ErrorMessage = "Social Security Number is required")]
		[DisplayName("Social Security Number")]
		[RegularExpression("^[[0-9]{3}-[0-9]{2}-[0-9]{4}", ErrorMessage = "Please enter a valid Social Security Number")]
		[InputMask("'mask' : '999-99-9999'")]
		public string SocialSecurityNumber { get; set; }

		[Required(ErrorMessage = "This is a required field")]
		public string Gender { get; set; } 

		[Required(ErrorMessage = "Degree is Required")]
		[DisplayName("Degree (MD, DO, etc.)")]
		public string Degree { get; set; }


		public string OtherDegree { get; set; }

		[JsonIgnore]
		public AdditionalName SupervisingPhysicianName
		{
			get => (GetName(NameType.SupervisingPhysician) as AdditionalName) ?? new AdditionalName(NameType.SupervisingPhysician);
			set => SetName(value, NameType.SupervisingPhysician);
		}

		[DisplayName("Degree (MD, DO, etc.)")]
		//[Required(ErrorMessage = "Degree is required")]
		public string SupervisingPhysicianDegree { get; set; }

		public string SupervisingPhysicianOtherDegree { get; set; }

		[DisplayName("Individual NPI")]
		[Required(ErrorMessage = "NPI is required")]
		[DataType(DataType.Text)]
		[RegularExpression("^[0-9]{10}$", ErrorMessage = "Please enter a valid NPI")]
		[MaxLength(10)]
		public string IndividualNpi { get; set; }

		[DisplayName("Effective Date")]
		[Required(ErrorMessage = "Effective Date is required")]
		[DataType(DataType.Text)]
		[DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
		public DateTime? EffectiveDate { get; set; }

		[DisplayName("Tax ID")]
		[Required(ErrorMessage = "Tax ID is required")]
		[RegularExpression("^[0-9]{9}$", ErrorMessage = "Please enter a valid Tax ID")]
		[MaxLength(9)]
		public string TaxId { get; set; }

		[DisplayName("Date You Started Billing With This Tax ID")]
		[DataType(DataType.Text)]
		[DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
		[Required(ErrorMessage = "Billing Date is required")]
		public DateTime? DateStartedBillingWithTaxId { get; set; }

		[DisplayName("License")]
		[Required(ErrorMessage = "License is required")]
		[RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Please enter a valid License")]
		[MaxLength(20)]
		public string License { get; set; }

		[DisplayName("Date You Were Licensed to Practice in AZ")]
		[Required(ErrorMessage = "Licensed Date is required")]
		[DataType(DataType.Text)]
		[DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
		public DateTime? DateLicensedWithAz { get; set; }

		[DisplayName("Do you have an active DEA Registration Number?")]
		public bool HasDeaRegistrationNumber { get; set; } = true;

		public DeaRegistration DeaRegistration { get; set; }

		[Required(ErrorMessage = "Primary Practicing Specialty is required")]
		[DisplayName("Primary Practicing Specialty")]
		public string PracticingSpecialty { get; set; }


		[DisplayName("Other Practicing Specialty(s), as Applicable")]
		public string[] OtherPracticingSpecialties { get; set; }


		[DisplayName("Are you accepting new patients?")]
		[Required(ErrorMessage = "This is a required field")]
		public bool? IsAcceptingNewPatients { get; set; }

		[DisplayName("Are you participating as a PCP under the above tax ID?")]
		[Required(ErrorMessage = "This is a required field")]
		public bool? IsPcpUnderTaxId { get; set; }

		[DisplayName("Are you Medication-assisted Treatment (MAT) Certified?")]
		[Required(ErrorMessage = "This is a required field")]

		public bool? IsMedicationAssistedTreatmentCertified { get; set; }

		[DisplayName("Are you interested in participating in our Medicare Advantage network?")]
		[Required(ErrorMessage = "This is a required field")]

		public bool? IsParticipatingMedicareAdvantageNetwork { get; set; }

		[DisplayName("Are you an Indian health service provider with the federal health program for American Indians and Alaska Natives?")]
		[Required(ErrorMessage = "This is a required field")]

		public bool? IsIndianHealthProvider { get; set; }

		[DisplayName("Do you (physician, not the staff) speak any languages other than English?")]
		public bool IsBilingual { get; set; } = true;

		public Language[] Languages { get; set; } = new Language[] { new Language() };
		#endregion

		#region Practice Information
		public Facility[] Facilities { get; set; } = new Facility[] { new Facility() };

		[DisplayName("Group's Legal Name")]
		[Required(ErrorMessage = "Group's Legal Name is required")]
		[RegularExpression("[A-Za-z0-9 -]*", ErrorMessage = "Please enter a valid Group Legal Name")]
		[MaxLength(50)]
		public string GroupsLegalName { get; set; }

		[DisplayName("Group's Doing-Business-As (DBA) Name")]
		[RegularExpression("[A-Za-z0-9 -]*", ErrorMessage = "Please enter a valid Group Doing Business As Name")]
		[MaxLength(50)]
		public string GroupsDoingBusinessAsName { get; set; }

		[DisplayName("Group/Organization NPI")]
		[Required(ErrorMessage = "NPI is required")]
		[DataType(DataType.Text)]
		[RegularExpression("^[0-9]{10}$", ErrorMessage = "Please enter a valid NPI")]
		[MaxLength(10, ErrorMessage = "Please enter a valid NPI")]
		public string GroupNpi { get; set; }

		[Required(ErrorMessage = "Effective Date is required")]
		[DataType(DataType.Text)]
		[DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
		[DisplayName("Effective Date")]
		public DateTime? GroupEffectiveDate { get; set; }

		[Required(ErrorMessage = "Licensed Date is required")]
		[DataType(DataType.Text)]
		[DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
		[DisplayName("Date You Were Licensed to Practice in AZ")]
		public DateTime? GroupDateLicensedInAz { get; set; }

		[Required(ErrorMessage = "This is a required field")]
		public bool? HasConciergePractice { get; set; }

		[DisplayName("Name")]
		[Required(ErrorMessage = "Name is required")]
		[RegularExpression("^[A-Za-z-A-Za-zA-Za-z A-Za-zA-Za-z'A-Za-z]*[A-Za-z]+$", ErrorMessage = "Please enter a valid Name")]
		[MaxLength(50)]
		public string BusinessCorrespondenceContactName { get; set; }

		[JsonIgnore]
		public EmailAddress BusinessCorrespondenceEmail
		{
			get => GetEmailAddress(EmailAddressType.BusinessCorrespondence);
			set => SetEmailAddress(value, EmailAddressType.BusinessCorrespondence);
		}

		[Required(ErrorMessage = "Phone is required")]
		[DisplayName("Phone")]
		[DataType(DataType.PhoneNumber)]
		[InputMask("'mask': '999-999-9999'")]
		[RegularExpression("^[0-9]{3}-[0-9]{3}-[0-9]{4}", ErrorMessage = "Please enter a valid Phone")]
		public string BusinessCorrespondencePhoneNumber { get; set; }

		[DisplayName("Fax")]
		[DataType(DataType.PhoneNumber)]
		[InputMask("'mask': '999-999-9999'")]
		[RegularExpression("^[0-9]{3}-[0-9]{3}-[0-9]{4}", ErrorMessage = "Please enter a valid Fax")]
		public string BusinessCorrespondenceFaxNumber { get; set; }

		[Required(ErrorMessage = "Business Website Address is required")]
		[DisplayName("Business Website Address")]
		[MaxLength(50)]
		public string WebsiteAddress { get; set; }

		[JsonIgnore]
		public EmailAddress BusinessEmailAddress
		{
			get => GetEmailAddress(EmailAddressType.BusinessEmail);
			set => SetEmailAddress(value, EmailAddressType.BusinessEmail);
		}
		#endregion

		#region Primary Office Information
		[JsonIgnore]
		public Address PrimaryOfficeAddress
		{
			get => (GetAddress(AddressType.OfficeAddress) as Address) ?? new Address(AddressType.OfficeAddress);
			set => SetAddress(value, AddressType.OfficeAddress);
		}

		public OfficeHour[] OfficeHours { get; set; }
		#endregion

		#region Other Addresses
		[JsonIgnore]
		public Address BillingAddress
		{
			get => (GetAddress(AddressType.BillingAddress) as Address) ?? new Address(AddressType.BillingAddress);
			set => SetAddress(value, AddressType.BillingAddress);
		}

		[JsonIgnore]
		public Address MailingAddress
		{
			get => (GetAddress(AddressType.MailingAddress) as Address) ?? new Address(AddressType.MailingAddress);
			set => SetAddress(value, AddressType.MailingAddress);
		}

		[JsonIgnore]
		public Address MedicalRecordsAddress
		{
			get => (GetAddress(AddressType.MedicalRecords) as Address) ?? new Address(AddressType.MedicalRecords);
			set => SetAddress(value, AddressType.MedicalRecords);
		}

		[JsonIgnore]
		public Address CredentialingAddress
		{
			get => (GetAddress(AddressType.Credentialing) as Address) ?? new Address(AddressType.Credentialing);
			set => SetAddress(value, AddressType.Credentialing);
		}


		[DisplayName("Use same for billing")]
		public bool UseSameForBilling { get; set; }

		[DisplayName("Use same for mailing")]
		public bool UseSameForMailing { get; set; }

		[DisplayName("Use same for medical records")]
		public bool UseSameForMedicalRecords { get; set; }

		[DisplayName("Use same for credentialing")]
		public bool UseSameForCredentialing { get; set; }
		#endregion

		#region Additional Office Information
		public bool HasAdditionalAddress { get; set; } = true;

		public AdditionalAddress AdditionalAddress
		{
			get => (GetAddress(AddressType.Additional) as AdditionalAddress) ?? new AdditionalAddress();
			set => SetAddress(value, AddressType.Additional);
		}

		public OfficeHour[] AdditionalOfficeHours { get; set; }
		#endregion

		[MaxLength(500)]
		[DisplayName("Additional Information/Comments")]
		public string AdditionalInformation { get; set; }

		#region Authorized Provider Signature
		[Required(ErrorMessage = "You must select the checkbox before submitting your request.")]
		public bool HasVerifiedInformation { get; set; }

		[Required(ErrorMessage = "Signature is required")]
		[RegularExpression("^[A-Za-z-A-Za-zA-Za-z A-Za-zA-Za-z'A-Za-z]*[A-Za-z]+$", ErrorMessage = "Please enter a valid Signature")]
		public string Signature { get; set; }

		[DataType(DataType.Text)]
		[DisplayName("Date")]
		public DateTime? DateTimeSigned { get; set; } = DateTime.Now;
		#endregion

		[JsonIgnore]
		public IEnumerable<string> AttachedFileNames { get; set; }

	}
}
