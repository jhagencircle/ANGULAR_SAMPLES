﻿using BCBSAZ.ProviderAuxiliaryPortal.Models.UserProfile;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts
{
    public class ProviderInetContext: DbContext
    {
        public DbSet<UserProfile> UserProfiles { get; protected set; }

        /// <summary>
        /// Creates a new instance of the Email DbContext object.
        /// </summary>
        /// <param name="options"></param>
        public ProviderInetContext(DbContextOptions<ProviderInetContext> options) : base(options) { }

        /// <summary>
        /// Defines custom model binding and configurations for models relating to the Email database
        /// </summary>
        /// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserProfile>().HasNoKey();
        }
    }
}
