﻿using System.Threading.Tasks;
using BCBSAZ.ProviderCredentialing.Interfaces.Managers;
using BCBSAZ.ProviderCredentialing.Interfaces.Repositories;
using BCBSAZ.ProviderCredentialing.Models.Data.Common;
using BCBSAZ.ProviderCredentialing.Models.Requests.Logger;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.ProviderCredentialing.Managers
{
	public class SystemLogsManager : ISystemLogsManager, ILogMessageStorage
	{
		private readonly ISystemLogsRepository _repository;
		private readonly LogMessageQueue _logMessages;

		public SystemLogsManager(ISystemLogsRepository repository, LogMessageQueue logMessages)
		{
			_repository = repository;
			_logMessages = logMessages;
		}

		// Use the LogMessageQueue to avoid issues with multiple threads hitting the SystemLogsDbContext
		public VoidResult InsertLogMessage(InsertLogMessageRequest request)
		{
			_logMessages.Enqueue(request.Message);
			return new VoidResult();
		}

		public Task StoreAsync(LogMessage logMessage)
		{
			try
			{
				return _repository.InsertLogMessageAsync(logMessage);
			}
			catch
			{
				return Task.CompletedTask;
			}
		}
	}
}
