﻿using System;
using System.Threading.Tasks;

namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface IIDNumber : IDisposable
	{
		Task<string> CheckPrefix(string prefix);

	}
}
