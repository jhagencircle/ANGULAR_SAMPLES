﻿using Serilog.Events;
using System;
using System.Net;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;

namespace BCBSAZ.ProviderAuxiliaryPortal.ExceptionHandling.CustomException
{
    public abstract class BaseException:Exception
    {
        private HttpStatusCode _statusCode;
        private LogLevelEnum _eventLevel;

        protected BaseException(HttpStatusCode statusCode, LogLevelEnum eventLevel = LogLevelEnum.Information)
        {
            SetStatusCode(statusCode);
            SetEventLevel(eventLevel);
        }

        protected BaseException(string message, HttpStatusCode statusCode, LogLevelEnum eventLevel = LogLevelEnum.Information) : base(message)
        {
            SetStatusCode(statusCode);
            SetEventLevel(eventLevel);
        }

        protected BaseException(string message, Exception innerException, HttpStatusCode statusCode, LogLevelEnum eventLevel = LogLevelEnum.Information) : base(message, innerException)
        {
            SetStatusCode(statusCode);
            SetEventLevel(eventLevel);
        }

        public int StatusCode => (int) _statusCode;
        public LogLevelEnum EventLevel => _eventLevel;

        private void SetStatusCode(HttpStatusCode statusCode)
        {
            _statusCode = statusCode;
        }

        private void SetEventLevel(LogLevelEnum eventLevel)
        {
            _eventLevel = eventLevel;
        }
    }
}
