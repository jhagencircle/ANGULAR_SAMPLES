import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {
  constructor(private http: HttpClient) {
  }

  url = `${environment.apiUrl}/api/splunk`;

  log(message: string, level: SplunkSourceType, additionalInformation?: any) {
    let request: ISplunkRequest = {
      message: message,
      level: level,
      additionalInformation: this.getAdditionalInformation(additionalInformation)
    };
    this.post(request).subscribe();
  }

  logInformation(message: string, additionalInformation?: any) {
    let request: ISplunkRequest = {
      message: message,
      level: SplunkSourceType.Information,
      additionalInformation: this.getAdditionalInformation(additionalInformation)
    };
    this.post(request).subscribe();
  }

  logWarning(message: string, additionalInformation?: any) {
    let request: ISplunkRequest = {
      message: message,
      level: SplunkSourceType.Warning,
      additionalInformation: this.getAdditionalInformation(additionalInformation)
    };
    this.post(request).subscribe();
  }

  logError(message: string, additionalInformation?: any) {
    let request: ISplunkRequest = {
      message: message,
      level: SplunkSourceType.Error,
      additionalInformation: this.getAdditionalInformation(additionalInformation)
    };
    this.post(request).subscribe();
  }

  logFatal(message: string, additionalInformation?: any) {
    let request: ISplunkRequest = {
      message: message,
      level: SplunkSourceType.Fatal,
      additionalInformation: this.getAdditionalInformation(additionalInformation)
    };
    this.post(request).subscribe();
  }

  private getAdditionalInformation(additionalInformation?: any): string {
    let additional = '';
    if (additionalInformation !== undefined)
      additional = JSON.stringify(additionalInformation);
    return additional;
  }

  post(request: ISplunkRequest): Observable<any> {
    return this.http.post(this.url, request);
  }
}

export interface ISplunkRequest {
  level: SplunkSourceType;
  message: string;
  additionalInformation: string;
}

enum SplunkSourceType {
  Verbose = 0,
  Debug = 1,
  Information = 2,
  Warning = 3,
  Error = 4,
  Fatal = 5
}
