﻿using BCBSAZ.ProviderCredentialing.Models.Data.Email;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	[Table("FileAttachment")]
	public class FileAttachment : IEmailAttachment
	{
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
		public long FileAttachmentId { get; set; }


		[ForeignKey("Application")]
		public long ApplicationId { get; set; }

		[ForeignKey("ApplicationId")]
		public Application Application { get; set; }

		[Required]
		[Column(TypeName = "VarBinary(MAX)")]
		public byte[] Contents { get; set; }

		[Required]
		[MaxLength(200)]
		public string FileName { get; set; }

		[Required]
		[MaxLength(100)] // Longest current MIME type is 65 characters
		public string ContentType { get; set; }
	}
}
