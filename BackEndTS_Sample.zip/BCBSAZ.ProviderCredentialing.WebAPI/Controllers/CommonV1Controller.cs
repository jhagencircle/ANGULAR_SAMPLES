﻿using BCBSAZ.ProviderCredentialing.Interfaces.Processors;
using BCBSAZ.ProviderCredentialing.Models.Data.Applications;
using BCBSAZ.ProviderCredentialing.Models.Data.Email;
using BCBSAZ.ProviderCredentialing.Models.Responses.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;
using System.Reflection;
using System.Text;

namespace BCBSAZ.Provider.WebApi.Controllers
{
	[ApiController]
	[Route("api/v1/Common")]
	public class CommonV1Controller : ControllerBase
	{
		[HttpGet("Test")]
		public TestResponse GetTest([FromServices]IConfiguration config, [FromServices]IHostEnvironment host)
		{
			return new TestResponse()
			{
				ApiEnvironment = host.EnvironmentName,
				ApiDescription = config.GetValue<string>("TestValue"),
				ApiVersion = GetAssemblyVersion()
			};
		}

		private string GetAssemblyVersion()
		{
			var assembly = typeof(CommonV1Controller).Assembly;
			var attr = assembly.GetCustomAttribute<AssemblyFileVersionAttribute>();

			return attr?.Version ?? string.Empty;
		}

		[HttpGet("Fail")]
		public TestResponse GetError()
		{
			throw new InvalidOperationException();
		}

#if DEBUG
		private static IEnumerable<IEmailAttachment> GetTestAttachments()
		{
			yield return new FileAttachment()
			{
				Contents = Encoding.UTF8.GetBytes("This is a text document attachment.\r\nThis is line two.\r\n"),
				FileName = "Test.txt",
				ContentType = "text/text"
			};
		}

		[HttpGet("EMail/{ToAddress}/{FromAddress}/{FirstName}/{LastName}")]
		public TestResponse SendTestEmail(string toAddress, string fromAddress, string firstName, string lastName, [FromServices]IEmailProcessor emailProcessor)
		{
			try
			{
				emailProcessor.SendCredentialingSubmittedAsync(fromAddress, toAddress, firstName, lastName, DateTime.Now, GetTestAttachments());
			}
			catch(Exception ex)
			{
				var sb = new StringBuilder();

				var err = ex;
				while (err != null)
				{
					sb.AppendLine(ex.GetType().FullName);
					sb.AppendLine(ex.Message);
					sb.AppendLine();

					err = err.InnerException;
				}

				return new TestResponse()
				{
					ApiDescription = "Failure",
					ApiEnvironment = sb.ToString(),
					ApiVersion = ex.StackTrace
				};
			}

			return new TestResponse() { ApiDescription = "Successful" };
		}
#endif

	}
}