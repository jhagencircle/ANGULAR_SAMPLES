﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Claims;
using BCBSAZ.Provider.Models.Data.ClaimsDetails;
using BCBSAZ.Provider.Models.Data.Common;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface IClaimsRepository
	{
		Task SaveClaimsRequestAsync(ClaimsRequest request);

		Task SaveClaimsResponseAsync(ClaimsResponse response);

		Task<ClaimsRequest> GetClaimsAsync(long RequestId);

		ClaimStatusMessage[] GetMessages();

		ClaimStatusCode[] GetStatusCodes();

		TPAInfo GetTPAInfo(string TPANumber);

		PatientInfo GetPatientAddress(string SubscriberId, string DOB);

		Task<IEnumerable<ClaimsRequest>> GetClaimsHistoryResultsAsync(string orgId, int days);

		Task<Patient> GetOrCreatePatientAsync(Patient patient);

		Task SaveChangesAsync();

	}
}
