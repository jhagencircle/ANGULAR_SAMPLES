import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, AbstractControl, FormsModule } from '@angular/forms';
import { AngularMaterialSharedModule } from 'src/app/common/shared/angular-material-shared.module';
import { SharedModule } from 'src/app/common/shared/shared.module';

import { EftChangeRequestFormComponent } from './eft-change-request-form.component';

xdescribe('EftChangeRequestFormComponent', () => {
  let component: EftChangeRequestFormComponent;
  let fixture: ComponentFixture<EftChangeRequestFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EftChangeRequestFormComponent ], 
      imports: [ SharedModule, AngularMaterialSharedModule, FormsModule  ],
      providers: [ FormBuilder]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EftChangeRequestFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
