﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.Provider.Managers.ApiClients
{
	public class OktaConfiguration
	{
		public string OktaServiceUrl { get; set; }

		public string GrantType { get; set; }

		public string AuthId { get; set; }

		public string ClientId { get; set; }

		public string ClientSecret { get; set; }
	}
}
