﻿import { OfficeHour } from "./OfficeHour"

export class OfficeHoursComponent {
	officeHours = new Array<OfficeHour>();
	officeHoursContainer: string;
	private readonly mondayNum = 1;
	private readonly fridayNum = 6;
	
	dayOfWeekDisplay = {
		"Sunday": "Sun",
		"Monday": "Mon",
		"Tuesday": "Tues",
		"Wednesday": "Wed",
		"Thursday": "Thurs",
		"Friday": "Fri",
		"Saturday": "Sat",
		"0": "Sun",
		"1": "Mon",
		"2": "Tues",
		"3": "Wed",
		"4": "Thurs",
		"5": "Fri",
		"6": "Sat",
	}

	constructor(officeHoursId: string) {
		this.officeHoursContainer = officeHoursId;
		this.grabCurrentHours();
	}

	addOfficeHour(dayOfWeek: string, startTime: string, closeTime: string, buildRows: boolean = true) {
		var row = new OfficeHour(dayOfWeek, startTime, closeTime);
		this.officeHours.push(row);
		this.officeHours.sort((a, b) => { return parseInt(a.dayOfWeek) - parseInt(b.dayOfWeek) });

		if (buildRows)
			this.buildRows();

		console.log(this.officeHours);
	}

	requireOfficeHours() {
		$(`${this.officeHoursContainer}-error`).text("").removeClass("input-validation-error");

		console.log(this.officeHours.length);
		if (this.officeHours.length == 0) {
			$(`${this.officeHoursContainer}-error`).addClass("input-validation-error").text("You must provide office hours to continue");
			return false;
		}
		return true;
	}

	private grabCurrentHours() {
		var index = 0;
		
		while (true) {
			if ($(`*[data-row-id='${index}']`).length == 0) break;
			var startTime = $(`${this.officeHoursContainer} input[data-row-id='${index}'][name$='OpenTime']`).val() as string;
			var endTime = $(`${this.officeHoursContainer} input[data-row-id='${index}'][name$='CloseTime']`).val() as string;
			var dayOfWeek = $(`${this.officeHoursContainer} input[data-row-id='${index}'][name$='DayOfWeek']`).val() as string;
			this.addOfficeHour(dayOfWeek, startTime, endTime, false);

			index++;
		}
	}

	setOfficeHours(hours: OfficeHour[]) {
		this.officeHours = hours;
		this.buildRows();
	}

	getOfficeHoursForDay(dayOfWeek: number): OfficeHour[] {
		return this.officeHours.filter(obj => parseInt(obj.dayOfWeek) == dayOfWeek); 
	}

	sameHoursMondayThroughFriday() {
		var found: OfficeHour[] = null;

		for (let i = this.mondayNum; i < this.fridayNum; i++) {
			found = this.getOfficeHoursForDay(i);
			if (found != undefined) break;
		}

		this.clearMondayThroughFriday();

		for (let i = this.mondayNum; i < this.fridayNum; i++) {
			found.forEach((hour) => {
				this.addOfficeHour(i.toString(), hour.startTime, hour.closeTime, false);
			});			
		}

		this.buildRows();
	}

	private clearMondayThroughFriday() {
		for (let i = this.mondayNum; i <= this.fridayNum; i++) {
			this.officeHours = this.officeHours.filter(obj => obj.dayOfWeek !== i.toString());
		}
	}

	removeOfficeHour(rowId: string) {
		this.officeHours.splice(parseInt(rowId), 1);
		this.buildRows();
	}

	private buildRows() {
		$(this.officeHoursContainer).html("");

		for (let i = 0; i < 7; i++) {
			var rowsInDay = this.officeHours.filter((x) => {
				return parseInt(x.dayOfWeek) === i
			});

			if (rowsInDay.length == 0) continue;

			var formElement = $(this.officeHoursContainer).siblings(".form-element").val() as string;

			var container = $("<div class='row office-hour-row'></div>");
			container.append(`<div class="roboto-bold day">${this.dayOfWeekAsText(rowsInDay[0].dayOfWeek)}</div>`);
			var hoursRows = $("<div class='hours-container'></div>");

			rowsInDay.forEach((row => {					
				let newHourContainer = $(`<div class="hours d-flex justify-content-between">${row.startTime}  <span class="hyphen">-</span>  ${row.closeTime}</div>`);
				newHourContainer.append(`<div class="remove-hours" title="remove office hours"><img src="/credentialing/images/remove-hours.png" alt="remove hours"/></div>`);
				
				hoursRows.append(newHourContainer);

				var index = this.officeHours.indexOf(row);
				newHourContainer.attr("data-row-id", index);

				var outputHtml = `<input type="hidden" data-row-id="${index}" value="${row.dayOfWeek}" name="${formElement}[${index}].DayOfWeek"/>` +
					`<input type="hidden" data-row-id="${index}" value="${row.startTime}" name="${formElement}[${index}].OpenTime" />` +
					`<input type="hidden" data-row-id="${index}" value="${row.closeTime}" name="${formElement}[${index}].CloseTime" />`;

				$(this.officeHoursContainer).append(outputHtml);
			}));

			container.append(hoursRows);			

			$(this.officeHoursContainer).append(container);
		}
	}

	dayOfWeekAsText(value: string) {
		return this.dayOfWeekDisplay[value];
	}
}