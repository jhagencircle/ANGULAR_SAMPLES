import {
  Component,
  Input,
  OnDestroy,
  OnInit,
  SimpleChange,
} from '@angular/core';
import { Subject } from 'rxjs';
import { SpinnerService } from './spinner.service';
import { takeUntil } from 'rxjs/operators';
import { OverlayStyle } from '../../enums/overlay-style-enum';

@Component({
  selector: 'app-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss'],
})
export class SpinnerComponent implements OnInit {
  @Input() loading: boolean = false;
  overlayStyle: OverlayStyle;

  private _loadingServiceSubject$: Subject<void>;

  public isLoading: boolean = false;

  constructor(private _spinnerService: SpinnerService) {
    this._loadingServiceSubject$ = new Subject<void>();
    this.overlayStyle = OverlayStyle.DIM_LIGHT;
  }

  ngOnInit(): void {
    this._spinnerService
      .onLoaderVisibilityChange()
      .pipe(takeUntil(this._loadingServiceSubject$))
      .subscribe((visible: boolean) => {
        this.isLoading = visible;
      });
  }
}
