export interface IRelationship {
  relationship: string;
}
