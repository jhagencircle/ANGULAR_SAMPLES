﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.API.PlanProfile;

namespace BCBSAZ.Provider.Interfaces.ApiClients
{
	public interface IPlanProfileApiClient
	{
		Task<IEnumerable<PlanPrefix>> GetPrefixesAsync(string planInfoName);
	}
}
