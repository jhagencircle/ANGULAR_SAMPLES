import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SharedModule } from 'src/app/common/shared/shared.module';

import { FinancialManagerUserComponent } from './financial-manager-user.component';

describe('FinancialManagerUserComponent', () => {
  let component: FinancialManagerUserComponent;
  let fixture: ComponentFixture<FinancialManagerUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinancialManagerUserComponent ],
      imports: [ SharedModule ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialManagerUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
