import { from, Observable, of } from 'rxjs';

export class BankAccountMock {
  get(): Observable<any[]> {
    return of([
      {
        accountId: '10000',
        accountNumber: '2019',
        id: '1',
        isForAutopay: false,
        name: 'Bank of America',
        nameOnAccount: 'US',
        nickname: 'boa',
        routingNumber: '9102',
        type: 'savings',
        status: 'Processing',
        isEdit: false,
        isAutopayment: true,
        isPendingPayment: true,
      },
      {
        accountId: '10000',
        accountNumber: '2019',
        id: '2',
        isForAutopay: false,
        name: 'Bank of America',
        nameOnAccount: 'US',
        nickname: 'boa',
        routingNumber: '9102',
        type: 'savings',
        status: '',
        isEdit: false,
        isAutopayment: false,
        isPendingPayment: true,
      },
    ]);
  }
  delete(): Observable<boolean> {
    return of(true);
  }
  update(): Observable<boolean> {
    return of(true);
  }
}
