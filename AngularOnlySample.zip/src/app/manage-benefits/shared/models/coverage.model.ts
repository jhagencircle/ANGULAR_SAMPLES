export interface ICoverage {
  id: string;
  description: string;
}
