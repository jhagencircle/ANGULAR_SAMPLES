﻿using BCBSAZ.ProviderCredentialing.WebAPI.Models.Enums;
using System.Collections.Generic;
using System.ComponentModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel.DataAnnotations;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	public class EmailAddress
	{
		public string Address { get; set; }

		[JsonConverter(typeof(EnumCollectionConverter<EmailAddressType>))]
		public IEnumerable<EmailAddressType> Types { get; set; }
	}
}