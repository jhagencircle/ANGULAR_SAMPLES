﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Remits;
using BCBSAZ.Provider.Models.Requests.Remits;
using BCBSAZ.Provider.Models.Responses.Remits;

namespace BCBSAZ.Provider.Interfaces.WCFClients
{
	public interface IDocumentSearchClient : IDisposable
	{
		
		Task<IEnumerable<ProviderRemittance>> GetRemitDetails(RemitSearchRequest searchCriteria);
		Task<RemitDocument> GetRemitDocument(RemitDocumentRequest request);
	}
}
