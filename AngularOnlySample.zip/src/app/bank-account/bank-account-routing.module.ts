import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BankAccountAddComponent } from './bank-account-add/bank-account-add.component';
import { BankAccountEditComponent } from './bank-account-edit/bank-account-edit.component';
import { BankAccountListComponent } from './bank-account-list/bank-account-list.component';

const routes: Routes = [
  {
    path: '',
    component: BankAccountListComponent,
  },

  {
    path: 'add',
    component: BankAccountAddComponent,
  },
  {
    path: 'edit',
    component: BankAccountEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BankAccountRoutingModule {}
