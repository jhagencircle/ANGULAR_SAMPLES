import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { PaymentsService } from './payments.service';
import { DecimalPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { IScheduledPayment } from './scheduled-payment.model';
import { PaymentServiceMock } from 'src/app/shared/mocks/payment.service.mock';

describe('PaymentsService', () => {
  let service: PaymentsService;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let testUrl: string = '';
  let baseUrl: string = '';
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [DecimalPipe],
    });
    service = TestBed.inject(PaymentsService);
    // Inject the http service and test controller for each test
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
    baseUrl = `${environment.apiUrl}/api`;
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get scheduled payments', () => {
    const testData: IScheduledPayment[] =
      PaymentServiceMock.mockedScheduledPayments;

    let accountId = '000312';
    testUrl = `${baseUrl}/account/${accountId}/scheduled`;

    httpClient
      .get<IScheduledPayment[]>(testUrl)
      .subscribe((data) => expect(data).toEqual(testData));

    const req = httpTestingController.expectOne(testUrl);

    expect(req.request.method).toEqual('GET');

    req.flush(testData);
  });
});
