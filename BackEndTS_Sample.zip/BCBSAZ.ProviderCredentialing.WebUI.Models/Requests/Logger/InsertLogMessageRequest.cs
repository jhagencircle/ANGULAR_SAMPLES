﻿using Microsoft.Extensions.Logging;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Requests.Logger
{
	public class InsertLogMessageRequest
	{
		public LogMessage Message { get; set; }
	}
}
