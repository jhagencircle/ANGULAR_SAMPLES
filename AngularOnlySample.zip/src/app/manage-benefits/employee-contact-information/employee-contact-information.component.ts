import { Component, OnInit, Input } from '@angular/core';
import { IContact } from '../shared/models/contact.model';
import { IPhone } from '../shared/models/phone.model';

@Component({
  selector: 'app-employee-contact-information',
  templateUrl: './employee-contact-information.component.html',
  styleUrls: ['./employee-contact-information.component.scss'],
})
export class EmployeeContactInformationComponent implements OnInit {
  @Input() contactInformation: IContact;
  primaryPhone: IPhone;
  secondaryPhone: IPhone;
  constructor() {}

  ngOnInit(): void {
    this.getPhones();
  }

  getPhones() {
    if (this.contactInformation?.phoneNumbers.length > 0) {
      if (this.contactInformation?.phoneNumbers.length >= 2) {
        this.primaryPhone = this.contactInformation?.phoneNumbers[0];
        this.secondaryPhone = this.contactInformation?.phoneNumbers[1];
      } else {
        this.primaryPhone = this.contactInformation?.phoneNumbers[0];
      }
    }
  }
}
