﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models.Enum
{
    public enum ProviderEftStatusEnum
    {
        NotSaved,
        Saved
    }
}
