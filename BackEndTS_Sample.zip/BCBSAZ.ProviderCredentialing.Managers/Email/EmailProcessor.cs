﻿using BCBSAZ.ProviderCredentialing.Interfaces.Processors;
using BCBSAZ.ProviderCredentialing.Interfaces.Repositories;
using BCBSAZ.ProviderCredentialing.Managers.Email.Templates;
using BCBSAZ.ProviderCredentialing.Models.Data.Email;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.Managers.Email
{
	public class EmailProcessor : IEmailProcessor
	{
		private static class TemplateNames
		{
			public static class Credentialing
			{
				public const string Submitted = "Submitted";
				public const string ThankYou = "ThankYou";
			}
		}

		private const string _configSection = "EmailConfiguration";

		private readonly IEmailRepository _emailRepository;
		private readonly EmailConfiguration _configuration;
		private readonly ILogger<EmailProcessor> _logger;
		private readonly IHttpContextAccessor _contextAccessor;

		public EmailProcessor(IEmailRepository emailRepository, IConfiguration configuration, ILogger<EmailProcessor> logger, IHttpContextAccessor contextAccessor)
		{
			_configuration = configuration.GetSection(_configSection).Get<EmailConfiguration>();
			_logger = logger;
			_emailRepository = emailRepository;
			_contextAccessor = contextAccessor;
		}
		
		private void SendInternalMessage(Template template, string fromAddress, string toAddress, IEnumerable<IEmailAttachment> fileAttachments, IEnumerable<KeyValuePair<string, string>> placeHolderValues = null)
		{
			var streams = new List<MemoryStream>();
			bool createMessage = false;
			try
			{
				using (var client = new SmtpClient(_configuration.SmtpHost, _configuration.SmtpPort) { DeliveryMethod = SmtpDeliveryMethod.Network })
				{
					using (var mailMessage = template.CreateMessage(fromAddress, toAddress, placeHolderValues))
					{
						foreach(var fileAttachment in fileAttachments)
						{
							var stream = new MemoryStream(fileAttachment.Contents);
							streams.Add(stream);
							mailMessage.Attachments.Add(new Attachment(stream, fileAttachment.FileName, fileAttachment.ContentType));
						}
						createMessage = true;
#if !DEBUG
						client.Send(mailMessage);
#endif
					}
				}
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Error sending Email  :  {ex.Message ?? string.Empty}  :  {ex.InnerException?.Message ?? string.Empty} : createMessage : {createMessage} : stmpHost : {_configuration.SmtpHost ?? string.Empty} : stmpPort :  {_configuration.SmtpPort.ToString() ?? string.Empty} : GetHostName : {GetLocalHostName() ?? string.Empty}");
			}
			finally
			{
				streams.ForEach(s => s.Dispose());
				streams.Clear();
			}
		}

		private Task SendExternalMessageAsync(Template template, string fromAddress, string toAddress, IEnumerable<KeyValuePair<string, string>> placeHolderValues = null)
		{
			try
			{
				template.GetSubjectAndBody(placeHolderValues, out var subject, out var body);
				return _emailRepository.QueueEmailAsync(toAddress, fromAddress, subject, body);
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, _contextAccessor?.HttpContext, $"Error sending Email :   {ex.Message ?? string.Empty}  :  {ex.InnerException?.Message ?? string.Empty}");
				return Task.CompletedTask;
			}
		}

		public async Task SendCredentialingSubmittedAsync(string fromAddress, string toAddress, string firstName, string lastName, DateTime dateSubmitted, IEnumerable<IEmailAttachment> fileAttachments)
		{
			var template = await TemplateStore.GetTemplateAsync(TemplateNames.Credentialing.Submitted);
			SendInternalMessage(template, fromAddress, toAddress, fileAttachments, new Dictionary<string, string>()
			{
				{ "%%FIRST_NAME%%", firstName },
				{ "%%LAST_NAME%%", lastName },
				{ "%%DATE_SUBMITTED%%", dateSubmitted.ToString("MM/dd/yy h:mm t.\\m.").ToLowerInvariant() }
			});
		}

		public async Task SendCredentialingThankYouAsync(string fromAddress, string toAddress)
		{
			var template = await TemplateStore.GetTemplateAsync(TemplateNames.Credentialing.ThankYou);
			await SendExternalMessageAsync(template, fromAddress, toAddress, null);
		}

		private static string GetLocalHostName()
		{
			try
			{
				// Get the local computer host name.
				String hostName = Dns.GetHostName();
				return hostName;
			}
			catch (SocketException e)
			{
				return $"SocketException caught from GetHostName  : Source : {e.Source?? string.Empty} : Message : {e.Message ?? string.Empty}";
			}
			catch (Exception e)
			{
				return $"GetHostName caught : Source : {e.Source ?? string.Empty} : Message : {e.Message ?? string.Empty}";
			}
		}
	}
}
