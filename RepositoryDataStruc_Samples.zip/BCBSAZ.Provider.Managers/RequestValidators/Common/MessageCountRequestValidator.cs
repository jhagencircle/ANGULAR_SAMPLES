﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Common;

namespace BCBSAZ.Provider.Managers.RequestValidators.Common
{
	internal static class MessageCountRequestValidator
	{
		public static void Validate(this MessageCountRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(MessageCountRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.UserId))
				yield return new InvalidModelExceptionDetail(nameof(MessageCountRequest.UserId), new ArgumentException("User Id is missing."));
		}
	}
}
