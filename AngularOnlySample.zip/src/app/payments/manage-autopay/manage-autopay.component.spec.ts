import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAutopayComponent } from './manage-autopay.component';

describe('ManageAutopayComponent', () => {
  let component: ManageAutopayComponent;
  let fixture: ComponentFixture<ManageAutopayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageAutopayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAutopayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
