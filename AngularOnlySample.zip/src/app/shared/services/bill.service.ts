import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ICurrentBill } from '../models/current-bill.model';

@Injectable({
  providedIn: 'root',
})
export class BillService {
  private url = `${environment.apiUrl}/api`;
  constructor(private http: HttpClient) {}

  get(accountId: string): Observable<ICurrentBill> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };

    return this.http.get<ICurrentBill>(
      `${this.url}/Employer/${accountId}/currentbill`,
      httpOptions
    );
  }
  recalculate(accountId: string, billId: string): Observable<any> {
    return this.http.post<number>(
      `${this.url}/Employer/${accountId}/${billId}/recalculate`,
      null
    );
  }
}
