﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	[Table("Application")]
	public class Application
	{
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
		public long ApplicationId { get; set; }

		[Required]
		[MaxLength(50)]
		public string FirstName { get; set; }

		[Required]
		[MaxLength(50)]
		public string LastName { get; set; }

		public DateTime InsertDate { get; set; } = DateTime.Now;

		[Required]
		public string JsonData { get; set; }

		public ICollection<FileAttachment> Attachments { get; set; }

	}
}
