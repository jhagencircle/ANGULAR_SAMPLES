import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ChangeDetectorRef,
  OnDestroy,
} from '@angular/core';
import {
  Validators,
  AbstractControl,
  FormBuilder,
  FormGroup,
} from '@angular/forms';
import { Subscription } from 'rxjs';
import { AccountNumberMaskPipe } from '../shared/account-number-mask.pipe';
import { BankAccountTypeEnum } from '../shared/bank-account-type.enum';
import { BankAccount } from '../shared/bank-account.model';
import { BankAccountService } from '../shared/bank-account.service';

@Component({
  selector: 'app-bank-account-edit',
  templateUrl: './bank-account-edit.component.html',
  styleUrls: ['./bank-account-edit.component.scss'],
})
export class BankAccountEditComponent implements OnInit, OnDestroy {
  @Input() bankAccount: BankAccount;
  @Output() showEditForm = new EventEmitter<boolean>();

  accountTypes = BankAccountTypeEnum;
  loading: boolean = false;
  subscriptions: Subscription[] = [];
  form: FormGroup;

  get f() {
    return this.form.controls;
  }

  constructor(
    private bankAccountService: BankAccountService,
    public accountNumberMask: AccountNumberMaskPipe,
    public fb: FormBuilder,
    private ref: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.setFormValues();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  createForm() {
    this.form = this.fb.group({
      bankName: ['', [Validators.required, Validators.maxLength(32)]],
      nameOnAccount: ['', Validators.required],
      nickname: ['', Validators.required],
      type: [{ value: '', disabled: true }],
      routingNumber: [{ value: '', disabled: true }],
      number: [{ value: '', disabled: true }],
    });
  }

  close() {
    this.showEditForm.emit(false);
  }

  save() {
    if (this.form.valid) {
      //display spinner
      this.loading = true;
      this.setBankAccountChanges();
      let subscription = this.bankAccountService
        .update(this.bankAccount)
        .subscribe(
          () => {
            //hide spinner
            this.loading = false;
            this.bankAccount.isEdit = false;
          },
          (error: HttpErrorResponse) => {
            //hide spinner
            this.loading = false;
            //show error message
          }
        );
      this.subscriptions.push(subscription);
    }
  }

  cancel() {
    this.bankAccount.isEdit = false;
  }

  setFormValues() {
    this.form.setValue({
      bankName: this.bankAccount.name,
      nameOnAccount: this.bankAccount.nameOnAccount
        ? this.bankAccount.nameOnAccount
        : '',
      nickname: this.bankAccount.nickname,
      type: this.bankAccount.type,
      routingNumber: this.accountNumberMask.transform(
        this.bankAccount.routingNumber,
        4
      ),
      number: this.accountNumberMask.transform(
        this.bankAccount.accountNumber,
        4
      ),
    });
    this.ref.detectChanges();
  }

  setBankAccountChanges() {
    this.bankAccount.name = this.f.bankName.value;
    this.bankAccount.nickname = this.f.nickname.value;
    this.bankAccount.nameOnAccount = this.f.nameOnAccount.value;
  }

  getField(fieldName: string): AbstractControl | null {
    return this.form.get(fieldName);
  }
}
