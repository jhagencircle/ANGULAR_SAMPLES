﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Models.Responses
{
	public class SubmitApplicationResponse
	{
		public long ApplicationId { get; set; }

		public DateTime SubmittedDate { get; set; }
	}
}
