﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using BCBSAZ.Provider.Models.API.Claims.Request;
using BCBSAZ.Provider.Models.API.Claims.Response;
using Microsoft.Extensions.Caching.Memory;
using BCBSAZ.Provider.Models.Responses.Okta;
using BCBSAZ.Provider.Service.WCF.Clients.BizTalk271EDI;
using System.Globalization;

namespace BCBSAZ.Provider.Managers.ApiClients
{
	public class OktaApiClient : HttpClient, IOktaApiClient
	{
		private readonly OktaConfiguration _configuration;
		private readonly IMemoryCache _memoryCache;

		public OktaApiClient(IConfiguration configuration, IMemoryCache memoryCache)
		{
			_memoryCache = memoryCache;
			_configuration = configuration.GetSection(Constants.Configuration.OktaConfig).Get<OktaConfiguration>();

			if (string.IsNullOrWhiteSpace(_configuration.OktaServiceUrl))
				throw new ArgumentException("Invalid Service Url specified for Okta Web API.");

			BaseAddress = new Uri(_configuration.OktaServiceUrl.EnsureEndsWith('/'));

			DefaultRequestHeaders.Clear();
			DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
		}

		public AccessTokenResponse GetApiToken()
		{
			var now = DateTime.Now;

			if (_memoryCache.TryGetValue(Constants.CacheKeys.ClaimsAPIToken, out AccessTokenResponse response))
			{
				if (response.Expires > now)
					return response;
			}

			response = Task.Run(GetApiTokenAsync).GetAwaiter().GetResult();

			if (string.IsNullOrWhiteSpace(response.Token))
			{
				response.Expires = now;
			}
			else
			{
				response.Expires = now.AddSeconds(response.ExpiresIn);
				_memoryCache.Set(Constants.CacheKeys.ClaimsAPIToken, response, Constants.Cache.Absolute(response.Expires.Subtract(now)));
			}

			return response;
		}

		private Task<AccessTokenResponse> GetApiTokenAsync()
		{
			var requestMessage = new HttpRequestMessage(HttpMethod.Post, string.Format(CultureInfo.InvariantCulture, Constants.OktaApiUrls.GetToken, _configuration.AuthId));

			requestMessage.Headers.Authorization = new AuthenticationHeaderValue("Basic", GetBasicCredentials());
			requestMessage.Content = new StringContent($"grant_type={_configuration.GrantType}", Encoding.UTF8, "application/x-www-form-urlencoded");

			return SendRequestAsync<AccessTokenResponse>(requestMessage);
		}

		private string GetBasicCredentials() =>
			Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_configuration.ClientId}:{_configuration.ClientSecret}"));

		/// <summary>
		/// Sends the request provided to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestMessage">The request message for the Provider Web Api method</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		public async Task<TResult> SendRequestAsync<TResult>(HttpRequestMessage requestMessage) where TResult : OktaErrorResponse
		{
			var response = await SendAsync(requestMessage);

			// Shortcut, if the caller is requesting the HttpResponseMessage as the result, just return it
			// (consuming code is responsible for checking status code & response content)
			if (response is TResult)
				return response as TResult;

			var content = await response.Content.ReadAsStringAsync();
			var retVal = JsonConvert.DeserializeObject<TResult>(string.IsNullOrWhiteSpace(content) ? "{ \"error\": \"no content\", \"error_description\": \"No content was returned from the Okta endpoint.\" }" : content);

			retVal.StatusCode = response.StatusCode;

			if (!response.IsSuccessStatusCode)
			{
				retVal.ReasonPhrase = response.ReasonPhrase;
				retVal.ContentType = response.Content.Headers.ContentType;
				retVal.Content = content;

				if (string.IsNullOrWhiteSpace(retVal.Error))
					retVal.Error = $"{response.StatusCode} - {response.ReasonPhrase}";

				if (string.IsNullOrWhiteSpace(retVal.ErrorDescription))
					retVal.ErrorDescription = "Invalid response returned from Okta endpoint.";
			}

			return retVal;
		}

		/// <summary>
		/// Gets the content provided by the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		/// <exception cref="InvalidApiResponseException">If the response from the Web Api is not a Success status code (200) this exception will be thrown containing the details of the non-success response from the WebApi</exception>
		public Task<TResult> GetAsync<TResult>(string requestUri) where TResult : OktaErrorResponse =>
			SendRequestAsync<TResult>(new HttpRequestMessage(HttpMethod.Get, requestUri));

		/// <summary>
		/// Post the content provided by the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		/// <exception cref="InvalidApiResponseException">If the response from the Web Api is not a Success status code (200) this exception will be thrown containing the details of the non-success response from the WebApi</exception>
		public Task<TResult> PostAsync<TResult>(string requestUri, object body) where TResult : OktaErrorResponse
		{
			var requestMessage = new HttpRequestMessage(HttpMethod.Post, requestUri);

			if (body != null)
			{
				var json = JsonConvert.SerializeObject(body);
				requestMessage.Content = new StringContent(json, Encoding.UTF8, "application/json");
			}

			return SendRequestAsync<TResult>(requestMessage);
		}

		/// <summary>
		/// Puts the specified content to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <param name="body">The object to be serialized for the body content of the request, or preserialized data in the form of a string.</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		public Task<TResult> PutAsync<TResult>(string requestUri, object body) where TResult : OktaErrorResponse
		{
			var requestMessage = new HttpRequestMessage(HttpMethod.Put, requestUri);

			if (body != null)
			{
				requestMessage.Content = new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json");
			}

			return SendRequestAsync<TResult>(requestMessage);
		}

		/// <summary>
		/// Submits a Delete Request to the Provider Web Api at the specified Url
		/// </summary>
		/// <typeparam name="TResult">The expected return type from the Provider Web Api method</typeparam>
		/// <param name="requestUri">The url route for the Provider Web Api method (including all route/query-string parameters)</param>
		/// <returns>Returns the deserialized (TResult) response from the Web Api method.</returns>
		/// <remarks>
		/// If TResult is HttpResponseMessage then the raw HttpResponseMessage response will be returned and the consuming code
		/// will be responsible for all validation of the Web Api response.
		/// </remarks>
		public Task<TResult> DeleteAsync<TResult>(string requestUri) where TResult : OktaErrorResponse =>
			SendRequestAsync<TResult>(new HttpRequestMessage(HttpMethod.Delete, requestUri));

	}
}
