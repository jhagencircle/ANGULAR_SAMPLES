import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OktaCallbackComponent } from '@okta/okta-angular';
import { AuthGuard } from './core/auth/auth.guard';
import { LogInCallbackComponent } from './log-in-callback/log-in-callback.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'log-in',
    pathMatch: 'full',
  },

  {
    path: 'landing-page',
    loadChildren: () =>
      import('./landing-page/landing-page.module').then(
        (m) => m.LandingPageModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'historical-statements',
    loadChildren: () =>
      import('./historical-statements/historical-statements.module').then(
        (m) => m.HistoricalStatementsModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'payments',
    loadChildren: () =>
      import('./payments/payments.module').then((m) => m.PaymentsModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'billing-faqs',
    loadChildren: () =>
      import('./billing-faqs/billing-faqs.module').then(
        (m) => m.BillingFaqsModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'log-in',
    loadChildren: () =>
      import('./log-in/log-in.module').then((m) => m.LogInModule),
  },
  {
    path: 'log-in/callback',
    component: LogInCallbackComponent,
  },
  {
    path: 'login/callback',
    component: OktaCallbackComponent,
  },
  {
    path: 'manage-benefits',
    loadChildren: () =>
      import('./manage-benefits/manage-benefits.module').then(
        (m) => m.ManageBenefitsModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'bank-account',
    loadChildren: () =>
      import('./bank-account/bank-account.module').then(
        (m) => m.BankAccountModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: '**',
    pathMatch: 'full',
    component: PageNotFoundComponent,
    canActivate: [AuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
