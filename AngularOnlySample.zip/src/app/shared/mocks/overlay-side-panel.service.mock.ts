import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { ISummary } from '../models/summary.model';
@Injectable({
  providedIn: 'root',
})
export class OverlaySidePanelMock {
  checkForChanges(): Observable<boolean> {
    return of(true);
  }

  show(): Observable<boolean> {
    return of(true);
  }

  setContent(): Observable<boolean> {
    return of(true);
  }

  reportChanges(): Observable<boolean> {
    return of(true);
  }
}
