import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-autopay-card',
  templateUrl: './autopay-card.component.html',
  styleUrls: ['./autopay-card.component.scss'],
})
export class AutopayCardComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit(): void {}

  goToAutopay() {
    this.router.navigate(['/payments/autopay']);
  }
}
