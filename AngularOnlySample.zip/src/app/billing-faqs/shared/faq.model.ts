export interface IFaq {
  question: string;
  answer: string;
  isDisplayed?: boolean;
}
