﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models.UserProfile
{
	public class UserProfile
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Phone { get; set; }
		public string Email { get; set; }
		public string Username { get; set; }
		public string SubOrg { get; set; }
		public string UserRole { get; set; }
		[NotMapped]
		public string Password { get; set; }
		[NotMapped]
		public string ConfirmPassword { get; set; }
		[NotMapped]
		public string SecurityQuestion { get; set; }
		[NotMapped]
		public string SecurityQuestionAnswer { get; set; }
	}
}
