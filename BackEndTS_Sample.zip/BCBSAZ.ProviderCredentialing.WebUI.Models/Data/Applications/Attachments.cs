﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications
{
	public class Attachments
	{
		public FileAttachment[] FileAttachments { get; set; }

		public string AcceptedFileTypes { get; set; }

		public bool AllowMultiple { get; set; }
	}
}
