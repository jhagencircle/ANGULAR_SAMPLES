import { Injectable, NgZone, OnDestroy } from '@angular/core';
import { Observable, interval, BehaviorSubject } from 'rxjs';
import { map, takeWhile } from 'rxjs/operators';

const STORE_KEY = 'userLastAction';

@Injectable()
export class NgIdleService implements OnDestroy {
  public static runTimer: boolean;
  public static runSecondTimer: boolean;
  public USER_IDLE_TIMER_VALUE_IN_MIN: number;
  public FINAL_LEVEL_TIMER_VALUE_IN_MIN: number;
  public userIdlenessChecker: BehaviorSubject<string> | null;
  public secondLevelUserIdleChecker: BehaviorSubject<string> | null;
  public secondTimerStartDate: number;
  private sessionForIdle: Observable<number>;
  private userActivityChangeCallback: ($event: any) => void;

  public clockForIdle: Observable<number>;

  constructor(private zone: NgZone) {
    if (!this.userIdlenessChecker) {
      this.userIdlenessChecker = new BehaviorSubject<string>('INITIATE_TIMER');
    }

    if (!this.secondLevelUserIdleChecker) {
      this.secondLevelUserIdleChecker = new BehaviorSubject<string>(
        'INITIATE_SECOND_TIMER'
      );
    }
  }

  public initilizeSessionTimeout(): void {
    NgIdleService.runTimer = true;

    if (this.USER_IDLE_TIMER_VALUE_IN_MIN === 0) {
      this.userIdlenessChecker?.thrownError(
        'Please provide USER_IDLE_TIMER_VALUE in minuite'
      );
      return;
    }

    this.reset();
    this.initListener();
    this.initInterval();
  }

  get lastAction(): number {
    return parseInt(localStorage.getItem(STORE_KEY) ?? '', 10);
  }

  set lastAction(value) {
    localStorage.setItem(STORE_KEY, value.toString());
  }

  private initListener(): void {
    this.zone.runOutsideAngular(() => {
      this.userActivityChangeCallback = ($event) =>
        this.handleUserActiveState($event);
      window.document.addEventListener(
        'click',
        this.userActivityChangeCallback.bind(this),
        true
      );
    });
  }

  handleUserActiveState(event: any): void {
    this.reset();
  }

  public reset(): void {
    this.lastAction = Date.now();
    if (this.userIdlenessChecker) {
      this.userIdlenessChecker.next('RESET_TIMER');
    }
  }

  private initInterval(): void {
    const intervalDuration = 1000;
    this.sessionForIdle = interval(intervalDuration).pipe(
      map((tick: number) => {
        return tick;
      }),
      takeWhile(() => NgIdleService.runTimer)
    );

    this.check();
  }

  private check(): void {
    this.sessionForIdle.subscribe(() => {
      const now = Date.now();
      const timeleft =
        this.lastAction + this.USER_IDLE_TIMER_VALUE_IN_MIN * 60 * 1000;
      const diff = timeleft - now;
      const isTimeout = diff < 0;

      let s = Math.floor(diff / 1000) % 60;
      let m = Math.floor(diff / 60000) % 60;

      this.userIdlenessChecker?.next(`${m}:${s}`);

      if (isTimeout) {
        window.document.removeEventListener(
          'click',
          this.userActivityChangeCallback,
          true
        );
        this.zone.run(() => {
          if (this.userIdlenessChecker) {
            this.userIdlenessChecker.next('STOPPED_TIMER');

            if (this.FINAL_LEVEL_TIMER_VALUE_IN_MIN > 0) {
              this.secondLevelUserIdleChecker?.next('SECOND_TIMER_STARTED');
              this.executeFinalTimer();
            }
          }
          NgIdleService.runTimer = false;
        });
      }
    });
  }

  public removeActionFromStore(): void {
    localStorage.removeItem(STORE_KEY);
  }

  private executeFinalTimer = () => {
    NgIdleService.runSecondTimer = true;
    this.secondTimerStartDate = Date.now();
    this.initializeFinalTimer();
  };

  private initializeFinalTimer(): void {
    const intervalDuration = 1000;
    this.clockForIdle = interval(intervalDuration).pipe(
      map((tick: number) => {
        return tick;
      }),
      takeWhile(() => NgIdleService.runSecondTimer)
    );

    this.checkUserActionTime();
  }

  private checkUserActionTime(): void {
    this.clockForIdle.subscribe(() => {
      const now = Date.now();
      const timeleft =
        this.secondTimerStartDate +
        this.FINAL_LEVEL_TIMER_VALUE_IN_MIN * 60 * 1000;
      const diff = timeleft - now;

      let timeInSecond = Math.floor(diff / 1000) % 60;
      let timeInMin = Math.floor(diff / 60000) % 60;

      if (timeInSecond <= 0) {
        if (timeInMin === -1 && timeInSecond <= 0) {
          NgIdleService.runSecondTimer = false;

          if (this.secondLevelUserIdleChecker) {
            this.secondLevelUserIdleChecker.next('SECOND_TIMER_STOPPED');
          }
        }
      }
      let auxiliar = '';
      if (timeInSecond < 10) auxiliar = '0';

      this.secondLevelUserIdleChecker?.next(
        `${timeInMin < 0 ? 0 : timeInMin}:${auxiliar}${
          timeInSecond < 0 ? 0 : timeInSecond
        }`
      );
    });
  }

  ngOnDestroy(): void {
    if (this.userIdlenessChecker) {
      this.userIdlenessChecker.unsubscribe();
      this.userIdlenessChecker = null;
    }

    if (this.secondLevelUserIdleChecker) {
      this.secondLevelUserIdleChecker.unsubscribe();
      this.secondLevelUserIdleChecker = null;
    }
  }
}
