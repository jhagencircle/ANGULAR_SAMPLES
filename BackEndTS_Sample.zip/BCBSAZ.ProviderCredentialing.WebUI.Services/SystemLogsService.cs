﻿using BCBSAZ.ProviderCredentialing.WebUI.Interfaces.ApiClients;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Common;
using BCBSAZ.ProviderCredentialing.WebUI.Models.Requests.Logger;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebUI.Services
{
	public class SystemLogsService : ILogMessageStorage
	{
		private readonly IWebApiClient _webApiClient;

		public SystemLogsService(IWebApiClient webApiClient) =>
			_webApiClient = webApiClient;

		public Task StoreAsync(LogMessage logMessage)
		{
			try
			{
				var requestUrl = Constants.WebApiUrls.SystemLogs.Insert;
				var request = new InsertLogMessageRequest() { Message = logMessage };
				return _webApiClient.PostAsync<VoidResult>(requestUrl, request);
			}
			catch
			{
				return Task.CompletedTask;
			}
		}
	}
}
