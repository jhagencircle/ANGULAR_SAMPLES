export interface ITerminationReason {
  terminationReason: string;
}
