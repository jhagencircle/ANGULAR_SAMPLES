export enum OverlayStyle {
  TRANSPARENT = 'overlay-style-transparent',
  DIM_DARK = 'overlay-style-dim-dark',
  DIM_LIGHT = 'overlay-style-dim-light',
}
