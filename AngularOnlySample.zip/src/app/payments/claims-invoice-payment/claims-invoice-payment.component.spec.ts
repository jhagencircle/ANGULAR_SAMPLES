import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsInvoicePaymentComponent } from './claims-invoice-payment.component';

describe('ClaimsInvoicePaymentComponent', () => {
  let component: ClaimsInvoicePaymentComponent;
  let fixture: ComponentFixture<ClaimsInvoicePaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimsInvoicePaymentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsInvoicePaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
