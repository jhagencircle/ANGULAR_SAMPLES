﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.IO;

namespace Newtonsoft.Json.Converters
{
	public class EnumCollectionConverter<TEnum> : JsonConverter where TEnum : struct, IConvertible
	{

		public override bool CanConvert(Type objectType)
		{
			return typeof(IEnumerable<TEnum>).IsAssignableFrom(objectType);
		}

		public override bool CanRead => false;

		public override bool CanWrite => true;

		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			return null;
		}

		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			if (value is IEnumerable<TEnum> collection)
			{
				writer.WriteStartArray();

				foreach (var val in collection)
				{
					writer.WriteValue(val.ToString());
				}

				writer.WriteEndArray();
			}
		}
	}
}
