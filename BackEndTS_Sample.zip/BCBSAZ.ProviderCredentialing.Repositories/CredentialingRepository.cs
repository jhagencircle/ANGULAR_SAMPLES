﻿using BCBSAZ.ProviderCredentialing.Interfaces.Repositories;
using BCBSAZ.ProviderCredentialing.Repositories.DbContexts;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Repositories
{
	public class CredentialingRepository : ICredentialingRepository
	{
		private readonly ICredentialingContext _context;

		public CredentialingRepository(ICredentialingContext context) => _context = context;
	}
}
