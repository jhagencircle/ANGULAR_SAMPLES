import { ISummary } from "./summary.model";

export interface ICurrentBill {
    accountSummary?: ISummary;
    subAccountSummary?: ISummary[];
}