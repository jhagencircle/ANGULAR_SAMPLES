import { Injectable } from '@angular/core';
import { from, Observable, of } from 'rxjs';
import { IScheduledPayment } from 'src/app/payments/shared/scheduled-payment.model';
@Injectable({
  providedIn: 'root',
})
export class PaymentServiceMock {
  constructor() {}
  public static mockedScheduledPayments: IScheduledPayment[] = [
    {
      transactionId: 25084,
      accountName: 'Account A',
      paymentTransactionNumber: 'QTDS6CAQKQQGBP8T',
      paymentAmount: 77,
      paymentTransactionDate: '2021-07-10T07:00:00',
      bankAccountNickname: 'WF',
      statusName: 'Scheduled',
      paymentTokenId: '',
      invoiceNumber: 1,
      transactionOrigin: 'Web',
      isEdit: false,
    },
    {
      transactionId: 15087,
      accountName: 'Account B',
      paymentTransactionNumber: 'QUII49MUKQRL1JSG',
      paymentAmount: 78,
      paymentTransactionDate: '2021-07-09T03:44:17',
      bankAccountNickname: 'WF',
      statusName: 'Scheduled',
      paymentTokenId: '',
      invoiceNumber: 66202,
      transactionOrigin: 'Web',
      isEdit: false,
    },
    {
      transactionId: 15081,
      accountName: 'Account C',
      paymentTransactionNumber: 'QTDS6CAQKQQGBLH7',
      paymentAmount: 79,
      paymentTransactionDate: '2021-07-08T02:46:28',
      bankAccountNickname: 'WF',
      statusName: 'Scheduled',
      paymentTokenId: '',
      invoiceNumber: 66202,
      transactionOrigin: 'Web',
      isEdit: false,
    },
  ];

  getList(): Observable<any[]> {
    return of([
      {
        transactionId: 'string',
        paymentTransactionDate: 'string',
        accountName: 'string',
        bankAccountNickname: 'boa',
        statusName: 'pending',
        paymentAmount: 1100,
        paymentTransactionNumber: 'string',
        invoiceNumber: 'string',
      },
      {
        transactionId: 'string',
        paymentTransactionDate: 'string',
        accountName: 'string',
        bankAccountNickname: 'string',
        statusName: 'string',
        paymentAmount: 100,
        paymentTransactionNumber: 'string',
        invoiceNumber: 'string',
      },
    ]);
  }

  delete(): Observable<boolean> {
    return of(true);
  }

  getScheduledPayments(accountId: string): Observable<IScheduledPayment[]> {
    console.log('in payment service mock getscheduledpayments');
    console.log(PaymentServiceMock.mockedScheduledPayments);
    return of(PaymentServiceMock.mockedScheduledPayments);
  }
}
