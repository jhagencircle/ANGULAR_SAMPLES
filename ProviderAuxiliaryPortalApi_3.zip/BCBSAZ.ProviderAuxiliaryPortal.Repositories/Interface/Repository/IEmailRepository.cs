﻿using System.Collections.Generic;
using System.Net.Mail;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository
{
    public interface IEmailRepository
    {
        Task<bool> SendExternalEmailAsync(string toAddress, string fromAddress, string subject, string body, string cc = null, string bcc = null);
        Task<bool> SendInternalEmailAsync(string toAddress, string fromAddress, string subject, string body, IEnumerable<Attachment> attachments, string cc = null, string bcc = null);
    }
}
