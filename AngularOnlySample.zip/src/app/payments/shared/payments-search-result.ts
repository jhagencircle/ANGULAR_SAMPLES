import { IPaymentHistory } from "./payment-history.model";

export interface IPaymentsSearchResult {
    payments: IPaymentHistory[];
    total: number;
}