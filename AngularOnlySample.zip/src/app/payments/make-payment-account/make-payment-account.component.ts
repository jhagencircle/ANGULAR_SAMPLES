import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ISummary } from 'src/app/shared/models/summary.model';
import { PaymentsService } from '../shared/payments.service';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { BankAccountService } from 'src/app/bank-account/shared/bank-account.service';
import { BankAccount } from 'src/app/bank-account/shared/bank-account.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AccountService } from 'src/app/shared/services/account.service';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-make-payment-account',
  templateUrl: './make-payment-account.component.html',
  styleUrls: ['./make-payment-account.component.scss'],
})
export class MakePaymentAccountComponent implements OnInit {
  adjustmentAmount: string;
  finalPaymentAmount: string;
  billDueDate: Date;
  statementFrom: Date;
  statementTo: Date;
  accountPayment: any = [];
  account: ISummary;
  amount: string;
  bankAccounts: BankAccount[];
  minDate: Date;
  maxDate: Date;
  futureDate: Date;
  accountPaymentForm: FormGroup;
  paymentModel: any;
  subscriptions: Subscription[] = [];

  constructor(
    private router: Router,
    private paymentsService: PaymentsService,
    private accountService: AccountService,
    private bankAccountService: BankAccountService,
    public fb: FormBuilder
  ) {
    this.minDate = new Date();
    this.futureDate = new Date();
    this.futureDate.setDate(
      this.futureDate.getDate() +
        AppConstants.ADD_DAYS_MAX_PAYMENT_DATE_SMALL_ACCOUNT
    );
    this.maxDate = this.futureDate;
    if (!this.account) {
      let subscription = this.accountService
        .get()
        .subscribe((account: ISummary) => {
          if (account) {
            this.account = account;

            if (this.account.asc) {
              this.futureDate = new Date();
              this.futureDate.setDate(
                this.futureDate.getDate() +
                  AppConstants.ADD_DAYS_MAX_PAYMENT_DATE_LARGE_ACCOUNT
              );
              this.maxDate = this.futureDate;
            }
          }
        });
      this.subscriptions.push(subscription);
    }
  }

  get f() {
    return this.accountPaymentForm.controls;
  }

  createForm() {
    this.accountPaymentForm = this.fb.group({
      bankAccount: ['', [Validators.required]],
      date: [new Date(), [Validators.required]],
      amount: ['', [Validators.required]],
    });
  }

  setInitialData() {
    this.statementFrom = new Date(this.account.statementFrom);
    this.statementTo = new Date(this.account.statementTo);
    this.billDueDate = new Date(this.account.dueDate);

    this.amount = this.paymentsService.parseCurrency(
      this.account.totalBilledAmount
    );
  }

  getBankAccounts() {
    let subscription = this.bankAccountService
      .get(this.account.accountId)
      .subscribe((data) => {
        this.bankAccounts = data;
      });
    this.subscriptions.push(subscription);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  setAmount() {
    this.amount = this.paymentsService.parseCurrency(
      this.account.totalBilledAmount
    );
    this.adjustmentAmount = this.paymentsService.parseCurrency(
      this.account.totalAdjustedAmount
    );
    this.finalPaymentAmount = this.paymentsService.parseCurrency(
      this.paymentsService.parseNumber(this.amount) +
        this.paymentsService.parseNumber(this.adjustmentAmount)
    );
  }

  ngOnInit(): void {
    this.getBankAccounts();
    this.createForm();
    this.setInitialData();
    this.setAmount();
  }

  currentBillAmountChange() {
    let currentBillPayment =
      this.paymentsService.parseNumber(this.amount) +
      this.paymentsService.parseNumber(this.adjustmentAmount);
    this.finalPaymentAmount =
      this.paymentsService.parseCurrency(currentBillPayment);
  }

  cancel() {
    this.router.navigate(['/landing-page']);
  }

  onSubmit() {
    if (this.accountPaymentForm.valid) {
      this.setPaymentData();
      let currentAccount = { ...this.account, payment: this.paymentModel };
      this.accountPayment.push(currentAccount);
      localStorage.setItem(
        AppConstants.PAYMENT_CURRENT_ACCOUNTS_LOCAL_STORAGE_KEY,
        JSON.stringify(this.accountPayment)
      );
      this.paymentsService.goToReview();
    }
  }

  setPaymentData() {
    this.paymentModel = {
      amount: this.paymentsService.parseNumber(this.f.amount.value),
      bankAccount: this.bankAccounts.find(
        (element: any) => element.id === parseInt(this.f.bankAccount.value)
      ),
      date: this.f.date.value,
      totalAmount: this.paymentsService.parseNumber(this.finalPaymentAmount),
      accountId: this.account.accountId,
    };
  }

  onInputClick() {
    this.amount = this.paymentsService.parseNumber(this.amount).toString();
  }

  inputAmountFocusOut() {
    let amountFloat = this.paymentsService.parseNumber(this.amount);
    if (amountFloat <= 0 || isNaN(amountFloat)) {
      amountFloat = 1;
    }
    this.amount = this.paymentsService.parseCurrency(amountFloat);
    this.currentBillAmountChange();
  }
}
