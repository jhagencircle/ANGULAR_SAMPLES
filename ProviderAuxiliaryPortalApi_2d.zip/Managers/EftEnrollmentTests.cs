﻿using BCBSAZ.ProviderAuxiliaryPortal.Managers;
using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft;
using BCBSAZ.ProviderAuxiliaryPortal.Models.Enum;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using FluentAssertions;
using NSubstitute;
using Xunit;

namespace BCBSAZ.ProviderAuxiliaryPortal.UnitTests.Managers
{
    public class EftEnrollmentTests
    {
        private readonly IEftEnrollmentRepository _eftEnrollmentRepository;
        private readonly IEftEnrollmentManager _eftEnrollmentManager;

        public EftEnrollmentTests()
        {
            _eftEnrollmentRepository = Substitute.For<IEftEnrollmentRepository>();
            _eftEnrollmentManager = Substitute.For<IEftEnrollmentManager>();
        }

        
        [Fact]
        public void CreateEftRecord_Success()
        {            
            var repository = Substitute.For<IEftEnrollmentRepository>();
            
            //Arrange
            EftEnrollmentRequest getdata = new EftEnrollmentRequest()
            {
                ProviderAddress = "123 Test Address"
            };

            // Act
            var result = _eftEnrollmentRepository.SaveEftEnrollmentRequestAsync(getdata);

            // Assert
            result.Equals(true);
        }

        [Fact]
        public void SaveFinal_Success()
        {
            var repository = Substitute.For<IEftEnrollmentRepository>();

            //Arrange
            EftEnrollmentRequest getdata = new EftEnrollmentRequest()
            {
                ProviderAddress = "123 Test Addres"
            };
            
            var providerIds = new ProviderIdentifier[] 
            { 
                new ProviderIdentifier
                { 
                    NpiNumber = "1234",
                    TinNumber = "321456"                
                }
            };
               
            // Act
            var result = _eftEnrollmentManager.UpdateEftUserProfileAsync( getdata, ProviderEftStatusEnum.Saved); //optional parameter

            // Assert
            Assert.Equal(getdata.Status, ProviderEftStatusEnum.NotSaved);
            
        }
    }
}
