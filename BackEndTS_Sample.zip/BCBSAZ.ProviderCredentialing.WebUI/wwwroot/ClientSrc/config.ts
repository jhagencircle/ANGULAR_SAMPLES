﻿
declare interface Window {
	site: any;
	PopperUtils: any;
	Popper: any;
}

let apiBase: string = null;

require.config({
	baseUrl: "/credentialing/js/",
	paths: {
		"jquery": "/credentialing/lib/jquery/jquery",
		"jquery-ui": "/credentialing/lib/jquery-ui/jquery-ui",
		"inputmask": "/credentialing/lib/inputmask/jquery.inputmask.bundle.min",
		"../global/window": "/credentialing/lib/inputmask/inputmask/global/window.min",
		"inputmask-dependencyLib": "/credentialing/lib/inputmask/inputmask/dependencyLibs/inputmask.dependencyLib.min",
		"jquery-validation": "/credentialing/lib/jquery-validate/jquery.validate",
		"jquery.validate.unobtrusive": "/credentialing/lib/jquery-validation-unobtrusive/jquery.validate.unobtrusive",
		"moment": "/credentialing/lib/moment/moment",
		"select2": "/credentialing/lib/select2/js/select2",
		"timepicker": "/credentialing/lib/timepicker/jquery.timepicker"
	},
	shim: {
		"jquery-ui": ["jquery"],
		"jquery-validation": ["jquery"],
		"jquery.validate.unobtrusive": ["jquery", "jquery-validation"],
		"inputmask": ["jquery"]
	}
});

require(["jquery", "jquery-ui", "jquery-validation", "jquery.validate.unobtrusive", "select2", "inputmask", "timepicker", "Site/Site", "Application/Application"],
	function (_jquery, _jqueryUI, _jqueryValidate, _jqueryValUnobtrusive, _select2, _inputmask, _timepicker, site, application) {

		application.Application.initialize();

		apiBase = `${location.protocol}//${location.host}/credentialing/api/`;

		window.site = site.Site;

		$.validator.addMethod("isdate", site.Site.isValidDate);
		$.validator.addMethod("mindate", site.Site.isMinDateValid); // Requires data-min-date attribute
		$.validator.addMethod("maxdate", site.Site.isMaxDateValid); // Requires data-max-date attribute
		$.validator.addMethod("datebefore", site.Site.dateBefore); //requires data-date-before attribute
		$.validator.addMethod("dateafter", site.Site.dateAfter); //requires data-date-after attribute

		(<any>$.validator).unobtrusive.adapters.addBool("isdate");
		(<any>$.validator).unobtrusive.adapters.addBool("mindate");
		(<any>$.validator).unobtrusive.adapters.addBool("maxdate");
		(<any>$.validator).unobtrusive.adapters.addBool("datebefore");
		(<any>$.validator).unobtrusive.adapters.addBool("dateafter");
	});
