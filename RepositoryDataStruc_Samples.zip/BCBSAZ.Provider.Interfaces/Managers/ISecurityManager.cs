﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Requests.Security;
using BCBSAZ.Provider.Models.Responses.Security;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Managers
{
	public interface ISecurityManager
	{
		AuthenticateUserResponse AuthenticateUser(AuthenticateUserRequest request);

		AuthenticateUserResponse AuthenticateTokenUser(AuthenticateTokenUserRequest request);
		
		RefreshAuthenticationResponse RefreshAuthentication(RefreshAuthenticationRequest request, WebUser user);

		AuthenticateUserResponse AuthenticateUserFromToken(WebUser webUser);

		string HashString(string value);

		string HashPassword(string username, string password);
	}
}
