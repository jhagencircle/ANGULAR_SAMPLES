﻿namespace BCBSAZ.ProviderCredentialing.WebUI.Models.Enums
{
	public enum NameType
	{
		ProviderInformation,
		SupervisingPhysician,
		CAQHName,
		ApplicationContactInformation,
		BusinessCorrespondence,
		Additional
	}
}
