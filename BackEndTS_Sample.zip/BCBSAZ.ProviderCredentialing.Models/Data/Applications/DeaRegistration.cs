﻿using System;
using System.ComponentModel;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	public class DeaRegistration
	{
		public DateTime? ExpirationDate { get; set; }

		public string RegistrationNumber { get; set; }
	}
}
