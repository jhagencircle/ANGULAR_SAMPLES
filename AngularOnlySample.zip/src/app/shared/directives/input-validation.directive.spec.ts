import { InputValidationDirective } from './input-validation.directive';

describe('InputValidationDirective', () => {
  it('should create an instance', () => {
    const directive = new InputValidationDirective();
    expect(directive).toBeTruthy();
  });
});
