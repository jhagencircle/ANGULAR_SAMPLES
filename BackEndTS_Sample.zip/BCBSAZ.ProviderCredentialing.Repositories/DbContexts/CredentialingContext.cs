﻿using BCBSAZ.ProviderCredentialing.Models.Data.Applications;
using BCBSAZ.ProviderCredentialing.Models.Data.Common;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace BCBSAZ.ProviderCredentialing.Repositories.DbContexts
{
	public interface ICredentialingContext : IDbContext
	{
		DbSet<Application> Applications { get; }
	}

	public class CredentialingContext : DbContext, ICredentialingContext
	{
		public CredentialingContext(DbContextOptions<CredentialingContext> options) : base(options) { }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<ConfigSetting>()
				.HasKey(cs => new { cs.Environment, cs.Name });

			/******************** Property Configs ********************/

		}

		public DbSet<Application> Applications { get; protected set; }

	}
}
