﻿import { Site } from "Site/Site"

export module PageSelector {
	export const totalPages = 5;
	export let currentPageNumber = 0;
	let selectorId = "#page-selector-bar";
	let pages: Page[] = [
		{
			title: "CAQH <br> Confirmation",
			id: "#caqh-confirmation",
			active: true,
			completed: false,
			canNavigateTo: true
		},
		{
			title: "Provider <br> Information",
			id: "#provider-information",
			active: false,
			completed: false,
			canNavigateTo: false
		},
		{
			title: "Practice <br> Information",
			id: "#practice-information",
			active: false,
			completed: false,
			canNavigateTo: false
		},
		{
			title: "Primary Office <br> Information",
			id: "#primary-office-information",
			active: false,
			completed: false,
			canNavigateTo: false
		},
		{
			title: "All Other <br> Addresses",
			id: "#all-other-addresses",
			active: false,
			completed: false,
			canNavigateTo: false
		},
		{
			title: "Additional Office <br> Information and Submit",
			id: "#additional-information-and-submit",
			active: false,
			completed: false,
			canNavigateTo: false
		}
	];

	export function initialize() {
		build();
		setupEvents();
		//showPageAtIndex(1);
	}

	function setupEvents() {
		$(`${selectorId} li`).click((event) => {
			var desiredPageId = $(event.target).closest("li").attr("data-page-id");
			var currentPageId = getCurrentPage().id;
			var index = pages.map((e) => { return e.id }).indexOf(desiredPageId);
			var page = pages[index];

			if (page.canNavigateTo !== false && desiredPageId !== currentPageId) {
				if (index < currentPageNumber)
					showPageAtIndex(index);
				else if (index > currentPageNumber && validatePage())
					showPageAtIndex(index);
				else
					console.error(`cannot navigate to page: ${page.id}`);
			}
		});
	}

	export function enableAllPages(pageToShow: number = 0, isError: boolean = false) {
		var firstErrorFound: boolean = false;

		for (var idx = 0; idx < pages.length; idx++) {
			var page = pages[idx];
			page.completed = true;
			page.canNavigateTo = true;

			$(`${selectorId} li[data-page-id='${page.id}']`).addClass("page-completed").removeClass("disabled");

			console.log(page.id);
			console.log($(page.id).find(".field-validation-error"));

			if (!firstErrorFound && $(page.id).find(".field-validation-error").length != 0) {
				firstErrorFound = true;
				pageToShow = idx;
			}
		}

		showPageAtIndex(pageToShow, isError);
	}

	export function isLastPage() {
		return currentPageNumber == totalPages;
	}

	function build() {
		$.each(pages, (index, page) => {
			var outputHtml = `<li class="${page.active ? "active" : ""} ${index == 0 ? "" : "disabled"}" data-page-id="${page.id}">` +
				`<div class="circle-container"></div>` +
				`<div class="page-title">${page.title}</div>` +
				`</li>`;
			$(`${selectorId} ul`).append(outputHtml);
		});
	}

	export function getCurrentPage() {
		return pages[currentPageNumber];
	}

	export function hideCurrentPage() {
		$(pages[currentPageNumber].id).addClass("display-none");
		if (pages[currentPageNumber].completed)
			$(`${selectorId} li[data-page-id='${getCurrentPage().id}']`).removeClass("page-completed-active").addClass("page-completed");
	}

	export function showPreviousPage() {
		if (currentPageNumber > 0) {
			hideCurrentPage();
			$(`${selectorId} li[data-page-id='${getCurrentPage().id}']`).removeClass("active page-completed-active");
			currentPageNumber--;
			showPage();
			Site.scrollToTop();
		}
	}

	export function showNextPage() {
		var currentPage = getCurrentPage();
		var pageSelectorContainer = $(`${selectorId} li[data-page-id='${currentPage.id}']`);
		pageSelectorContainer.removeClass("active disabled");
		currentPage.canNavigateTo = true;
		currentPage.completed = true;

		hideCurrentPage();
		currentPageNumber++;
		showPage();
	}

	export type ExtraValidation = () => boolean;

	export function validatePage(fnExtraValidation: ExtraValidation = null) {
		var isValid = true;
		var extraValidation = true;
		var currentPage = $(getCurrentPage().id);

		var inputElements = currentPage.find("input[data-val='true']").toArray();
		var textareaElements = currentPage.find("textarea[data-val='true']").toArray();
		var selectElements = currentPage.find("select[data-val='true']").toArray();

		var allElements = inputElements.concat(textareaElements, selectElements);

		allElements.forEach((ele) => {
			if (!$(ele).valid())
				isValid = false;
		});

		if (fnExtraValidation != null)
			extraValidation = fnExtraValidation();

		return isValid && extraValidation;
	}

	function showPage() {
		var currentPageObj = pages[currentPageNumber];
		currentPageObj.canNavigateTo = true;
		$(pages[currentPageNumber].id).removeClass("display-none");
		Site.scrollToTop();
		$(`${selectorId} li[data-page-id='${getCurrentPage().id}']`).addClass(currentPageObj.completed ? "page-completed-active" : "active").removeClass("disabled");

		if (isLastPage()) {
			$("#continue-btn").text("Submit");
		}
		else
			$("#continue-btn").text("Continue");
	}

	export function showPageAtIndex(index: number, isError: boolean = false) {
		hideCurrentPage();
		$(`${selectorId} li`).removeClass("active");
		currentPageNumber = index;
		showPage();

		if (isError)
			Site.scrollErrorIntoView(500);
		else
			Site.scrollToTop();
	}
}

export class Page {
	title: string;
	id: string;
	active: boolean;
	completed: boolean;
	canNavigateTo: boolean;
}