﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Security;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.Security
{
	internal static class RefreshAuthenticationRequestValidator
	{
		public static void Validate(this RefreshAuthenticationRequest request, WebUser user)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (user == null)
				throw new ArgumentNullException(nameof(user));

			var violations = GetVoilations(request, user);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetVoilations(RefreshAuthenticationRequest request, WebUser user)
		{
			if (string.IsNullOrWhiteSpace(request.UserId))
				yield return new InvalidModelExceptionDetail(nameof(RefreshAuthenticationRequest.UserId), new ArgumentException("User Id is missing."));

			if (user.UserId != request.UserId)
				yield return new InvalidModelExceptionDetail(nameof(RefreshAuthenticationRequest.UserId), new ArgumentException("User Id mismatch."));
		}
	}
}
