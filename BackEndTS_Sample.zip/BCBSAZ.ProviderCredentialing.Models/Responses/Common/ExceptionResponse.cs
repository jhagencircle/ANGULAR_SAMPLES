﻿using System;
using System.Net;
using Newtonsoft.Json;

namespace BCBSAZ.ProviderCredentialing.Models.Responses.Common
{
	public class ExceptionResponse
	{
		/// <summary>
		/// Default Constructor.
		/// </summary>
		public ExceptionResponse() { }

		/// <summary>
		/// Creates a copy of the Exception Response provided
		/// </summary>
		/// <param name="defaultResponse">The Exception Response to be copied</param>
		public ExceptionResponse(ExceptionResponse defaultResponse) :
			this(defaultResponse?.ExceptionType, (defaultResponse == null ? HttpStatusCode.InternalServerError : defaultResponse.Code), defaultResponse?.Message)
		{ }

		/// <summary>
		/// Creates a new Exception response with the properties set to the parameters provided
		/// </summary>
		/// <param name="exceptionType">The type of the exception which was thrown</param>
		/// <param name="code">The Http Status Code for the exception response</param>
		/// <param name="message">The message to be returned for the exception response</param>
		public ExceptionResponse(Type exceptionType, HttpStatusCode code, string message = null)
		{
			ExceptionType = exceptionType;
			Code = code;
			Message = message;
		}

		/// <summary>
		/// Gets the type of the exception which was thrown
		/// </summary>
		[JsonIgnore]
		public Type ExceptionType { get; set; }
		/// <summary>
		/// Gets or sets the Http Status Code of the exception response
		/// </summary>
		public HttpStatusCode Code { get; set; }
		/// <summary>
		/// Gets or sets the message of the exception response
		/// </summary>
		public string Message { get; set; }
	}
}
