﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderAuxiliaryPortal.Models.DbTables.ProviderEft
{
    public class FileAttachment
    {
        public byte[] Contents { get; set; }

        public string FileName { get; set; }

        public string ContentType { get; set; }
    }
}
