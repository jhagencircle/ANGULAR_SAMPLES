﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Common;

namespace BCBSAZ.Provider.Managers.RequestValidators.Common
{
	internal static class Select2RequestValidator
	{
		public static void ValidateRequest(this Select2Request request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);

		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(Select2Request request)
		{
			if (string.IsNullOrWhiteSpace(request.Query))
				yield return new InvalidModelExceptionDetail(nameof(Select2Request.Query), new ArgumentException("Query Not Specified."));
		}
	}
}
