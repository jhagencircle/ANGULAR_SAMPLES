﻿using BCBSAZ.ProviderCredentialing.Models.Data.Email;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.Interfaces.Processors
{
	public interface IEmailProcessor
	{
		Task SendCredentialingSubmittedAsync(string fromAddress, string toAddress, string firstName, string lastName, DateTime dateSubmitted, IEnumerable<IEmailAttachment> fileAttachments);

		Task SendCredentialingThankYouAsync(string fromAddress, string toAddress);
	}
}
