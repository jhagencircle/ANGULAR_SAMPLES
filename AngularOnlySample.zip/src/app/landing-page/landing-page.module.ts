import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LandingPageRoutingModule } from './landing-page-routing.module';
import { LandingPageComponent } from './landing-page.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxPrintModule } from 'ngx-print';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SpinnerModule } from '../shared/components/spinner/spinner.module';
import { AlertModule } from '../shared/components/alert/alert.module';
import { AccountBannerComponent } from './account-banner/account-banner.component';

@NgModule({
  declarations: [LandingPageComponent, AccountBannerComponent],
  imports: [
    CommonModule,
    NgbModule,
    LandingPageRoutingModule,
    NgxPrintModule,
    FormsModule,
    ReactiveFormsModule,
    SpinnerModule,
    AlertModule,
  ],
})
export class LandingPageModule {}
