﻿using BCBSAZ.ProviderCredentialing.Models.Data.Applications;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Models.Requests
{
	public class SubmitApplicationRequest
	{
		public ProviderCredentialForm Form { get; set; }

		public IEnumerable<FileAttachment> Attachments { get; set; }
	}
}
