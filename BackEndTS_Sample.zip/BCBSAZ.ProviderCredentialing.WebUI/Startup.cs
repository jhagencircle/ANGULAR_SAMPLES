using System;
using System.Net;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using HeaderNames = Microsoft.Net.Http.Headers.HeaderNames;

#if !DEBUG
using BCBSAZ.ProviderCredentialing.WebUI.Services;
using Microsoft.Extensions.Logging;
#endif

namespace BCBSAZ.ProviderCredentialing.WebUI
{
	public class Startup
	{
		public Startup(IConfiguration configuration, IHostEnvironment hostEnvironment)
		{
			Configuration = configuration;
			HostEnvironment = hostEnvironment;
		}

		public IConfiguration Configuration { get; }
		public IHostEnvironment HostEnvironment { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			services.AddControllersWithViews()
#if DEBUG
				.AddRazorRuntimeCompilation()
#endif
				.AddMvcOptions(AddCacheProfiles);

			services.AddWebApiServices(Configuration);
			services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

			services.AddAntiforgery(opt => { opt.Cookie.Expiration = TimeSpan.Zero; });

			services.AddMemoryCache();

#if !DEBUG
			services.AddSingleton<ILogMessageStorage, SystemLogsService>();
#endif

		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}
			else
			{
				app.UseExceptionHandler("/Home/Error");
				app.UseHsts();
			}

			app.UseHttpsRedirection();
			app.UseStaticFiles(new StaticFileOptions()
			{
				OnPrepareResponse = AddCacheControl
			});

			app.UseRouting();

			app.UseMiddleware<WebExceptionHandling>();

			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllerRoute(
					name: "default",
					pattern: "{controller=Home}/{action=Index}/{id?}");
			});
		}

		private static readonly PathString _js = new PathString("/js");
		private static readonly PathString _css = new PathString("/css");

		/// <summary>
		/// This method will allow javascript files under /lib to be cached, and
		/// NOT allow javascript files or css files under /js or /css to be cached.
		/// </summary>
		private void AddCacheControl(StaticFileResponseContext context)
		{
			if ((context.Context.Request.Path.StartsWithSegments(_js)) ||
				(context.Context.Request.Path.StartsWithSegments(_css)))
			{
				context.Context.Response.Headers[HeaderNames.CacheControl] = "no-nache";
				context.Context.Response.Headers[HeaderNames.Pragma] = "no-nache";
			}

			if ((context.File.Name.EndsWith(".ts", StringComparison.OrdinalIgnoreCase)) ||
				(context.File.Name.EndsWith(".map", StringComparison.OrdinalIgnoreCase)))
			{
#if DEBUG
				context.Context.Response.Headers[HeaderNames.CacheControl] = "no-nache";
				context.Context.Response.Headers[HeaderNames.Pragma] = "no-nache";
#else
				context.Context.Response.OnStarting(() =>
				{
					context.Context.Response.Clear();
					context.Context.Response.StatusCode = (int)HttpStatusCode.NotFound;

					return System.Threading.Tasks.Task.CompletedTask;
				});
#endif
			}
		}

		/// <summary>
		/// Adds Cache Profiles for use in defining how long a response should be cached by the client.
		/// </summary>
		private void AddCacheProfiles(MvcOptions options)
		{
			options.CacheProfiles.Add(Constants.Cache.NoCache, new CacheProfile() { Duration = 0, Location = ResponseCacheLocation.None, NoStore = true });

			if (HostEnvironment.IsDevelopment(Configuration))
			{
				options.CacheProfiles.Add(Constants.Cache.HalfHour, new CacheProfile() { Duration = 0, Location = ResponseCacheLocation.None, NoStore = true });
				options.CacheProfiles.Add(Constants.Cache.OneHour, new CacheProfile() { Duration = 0, Location = ResponseCacheLocation.None, NoStore = true });
				options.CacheProfiles.Add(Constants.Cache.FourHours, new CacheProfile() { Duration = 0, Location = ResponseCacheLocation.None, NoStore = true });
				options.CacheProfiles.Add(Constants.Cache.HalfDay, new CacheProfile() { Duration = 0, Location = ResponseCacheLocation.None, NoStore = true });
				options.CacheProfiles.Add(Constants.Cache.OneDay, new CacheProfile() { Duration = 0, Location = ResponseCacheLocation.None, NoStore = true });
			}
			else
			{
				options.CacheProfiles.Add(Constants.Cache.HalfHour, new CacheProfile() { Duration = Constants.Durations.OneMinute * 30 });
				options.CacheProfiles.Add(Constants.Cache.OneHour, new CacheProfile() { Duration = Constants.Durations.OneHour });
				options.CacheProfiles.Add(Constants.Cache.FourHours, new CacheProfile() { Duration = Constants.Durations.OneHour * 4 });
				options.CacheProfiles.Add(Constants.Cache.HalfDay, new CacheProfile() { Duration = Constants.Durations.OneHour * 12 });
				options.CacheProfiles.Add(Constants.Cache.OneDay, new CacheProfile() { Duration = Constants.Durations.OneDay });
			}
		}
	}
}
