﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.PreCert;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.PreCert
{
	internal static class GetMedicalPreCertRequestValidator
	{
		public static void Validate(this GetMedicalPreCertRequest request, WebUser webUser)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (webUser == null)
				throw new ArgumentNullException(nameof(webUser));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(GetMedicalPreCertRequest request)
		{
			if (request.PreCertId <= 0)
				yield return new InvalidModelExceptionDetail(nameof(GetMedicalPreCertRequest.PreCertId), new ArgumentException("PreCert Id is missing."));
		}
	}
}
