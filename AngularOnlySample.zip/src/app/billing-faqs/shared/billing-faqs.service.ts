import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IFaq } from './faq.model';

@Injectable({
  providedIn: 'root',
})
export class BillingFaqsService {
  url = `${environment.apiUrl}/api/FAQs`;
  constructor(private http: HttpClient) {}

  get(): Observable<IFaq[]> {
    return this.http.get<IFaq[]>(this.url);
  }
}
