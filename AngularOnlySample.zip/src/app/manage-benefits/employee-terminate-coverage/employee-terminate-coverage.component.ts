import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { IBenefit } from '../shared/models/benefit.model';
import { EmployeeProfileService } from '../shared/employee-profile.service';
import { IProfileRoster } from '../shared/models/profile-roster.model';
import { ITerminationCoverage } from '../shared/models/termination-coverage.model';
import { IEmployee } from '../shared/models/employee.model';

@Component({
  selector: 'app-employee-terminate-coverage',
  templateUrl: './employee-terminate-coverage.component.html',
  styleUrls: ['./employee-terminate-coverage.component.scss'],
})
export class EmployeeTerminateCoverageComponent implements OnInit, OnDestroy {
  @Input() employeeInformation: IEmployee;
  @Input() benefitSelection: IBenefit;
  terminateCoverage: string;
  terminateCoverageNote: string;
  showEdit: boolean = false;
  membreProfile: IProfileRoster;

  constructor(private employeeProfileService: EmployeeProfileService) {}

  ngOnInit(): void {
    this.terminateCoverage = AppConstants.TERMINATE_COVERAGE_DESCRIPTION;
    this.terminateCoverageNote = AppConstants.TERMINATE_COVERAGE_NOTE;
    this.employeeProfileService.get().subscribe((data) => {
      this.membreProfile = data;
    });
  }

  onCancelChild() {
    this.showEdit = false;
  }

  onSendDataChild(event: ITerminationCoverage) {
    this.membreProfile.terminateCoverage = event;
    this.employeeProfileService.update(this.membreProfile);
  }

  ngOnDestroy() {}
}
