﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Models.API.PlanProfile;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace BCBSAZ.Provider.Managers
{
	public class PlanProfileManager : IPlanProfileManager
	{
		private readonly IPlanProfileApiClient _planProfileApiClient;
		private readonly IMemoryCache _memoryCache;
		private readonly IHttpContextAccessor _contextAccessor;
		private readonly ILogger<PlanProfileManager> _logger;

		public PlanProfileManager(IPlanProfileApiClient planProfileApiClient, IMemoryCache memoryCache, IHttpContextAccessor contextAccessor, ILogger<PlanProfileManager> logger)
		{
			_planProfileApiClient = planProfileApiClient;
			_memoryCache = memoryCache;
			_contextAccessor = contextAccessor;
			_logger = logger;
		}

		#region Prefix Properties
		public Task<IEnumerable<string>> ItsMaLocalPrefixes
		{
			get => _memoryCache.GetOrCreateAsync(Constants.CacheKeys.ItsMaLocal, Constants.Cache.SlidingFourHours(), GetItsMaLocalPrefixesAsync);
		}

		public Task<IEnumerable<string>> ItsMaHostPrefixes
		{
			get => _memoryCache.GetOrCreateAsync(Constants.CacheKeys.ItsMaHost, Constants.Cache.SlidingFourHours(), GetItsMaHostPrefixesAsync);
		}

		public async Task<IEnumerable<string>> GetItsMaAllPrefixes()
		{
			return (await ItsMaLocalPrefixes).Union(await ItsMaHostPrefixes);
		}
		#endregion

		#region Get Prefixes
		private async Task<IEnumerable<string>> GetItsMaLocalPrefixesAsync()
		{
			try
			{
				return (await _planProfileApiClient.GetPrefixesAsync(Constants.PlanProfileApiUrls.Local)).Select(p => p.Prefix);
			}
			catch (Exception ex)
			{
				_logger.LogError(-1, ex, _contextAccessor?.HttpContext, $"Error retrieving ITS MA Local prefixes: {ex.Message}");

				return _defaultItsMaLocal.Select(p => p.Prefix);
			}
		}

		private async Task<IEnumerable<string>> GetItsMaHostPrefixesAsync()
		{
			try
			{
				return (await _planProfileApiClient.GetPrefixesAsync(Constants.PlanProfileApiUrls.Host)).Select(p => p.Prefix);
			}
			catch (Exception ex)
			{
				_logger.LogError(-1, ex, _contextAccessor?.HttpContext, $"Error retrieving ITS MA Host prefixes: {ex.Message}");

				return _defaultItsMaHost.Select(p => p.Prefix);
			}
		}
		#endregion

		#region Defaults
		#region Local ITS MA
		private static readonly IEnumerable<PlanPrefix> _defaultItsMaLocal = JsonConvert.DeserializeObject<IEnumerable<PlanPrefix>>(
@"[
    {
				""prefix"": ""M2K""
		},
    {
        ""prefix"": ""M2O""
    },
    {
        ""prefix"": ""M2V""
    },
    {
        ""prefix"": ""M2Z""
    },
    {
        ""prefix"": ""M3P""
    },
    {
        ""prefix"": ""M3V""
    }
]");
		#endregion

		#region Host ITS MA
		private static readonly IEnumerable<PlanPrefix> _defaultItsMaHost = JsonConvert.DeserializeObject<IEnumerable<PlanPrefix>>(
@"[
    {
        ""prefix"": ""2GJ""
		},
    {
        ""prefix"": ""2H6""
    },
    {
        ""prefix"": ""2HM""
    },
    {
        ""prefix"": ""2S9""
    },
    {
        ""prefix"": ""A26""
    },
    {
        ""prefix"": ""A2M""
    },
    {
        ""prefix"": ""A75""
    },
    {
        ""prefix"": ""A9O""
    },
    {
        ""prefix"": ""AFJ""
    },
    {
        ""prefix"": ""AIP""
    },
    {
        ""prefix"": ""AIW""
    },
    {
        ""prefix"": ""ALZ""
    },
    {
        ""prefix"": ""AMP""
    },
    {
        ""prefix"": ""ANJ""
    },
    {
        ""prefix"": ""ANS""
    },
    {
        ""prefix"": ""AS6""
    },
    {
        ""prefix"": ""ASF""
    },
    {
        ""prefix"": ""ATO""
    },
    {
        ""prefix"": ""BAM""
    },
    {
        ""prefix"": ""BJN""
    },
    {
        ""prefix"": ""BLM""
    },
    {
        ""prefix"": ""BVT""
    },
    {
        ""prefix"": ""CBH""
    },
    {
        ""prefix"": ""CHP""
    },
    {
        ""prefix"": ""CIB""
    },
    {
        ""prefix"": ""CIF""
    },
    {
        ""prefix"": ""CIO""
    },
    {
        ""prefix"": ""CLB""
    },
    {
        ""prefix"": ""DCE""
    },
    {
        ""prefix"": ""DIR""
    },
    {
        ""prefix"": ""DRX""
    },
    {
        ""prefix"": ""EGA""
    },
    {
        ""prefix"": ""EIU""
    },
    {
        ""prefix"": ""EIX""
    },
    {
        ""prefix"": ""EMT""
    },
    {
        ""prefix"": ""EMV""
    },
    {
        ""prefix"": ""EVS""
    },
    {
        ""prefix"": ""FEM""
    },
    {
        ""prefix"": ""FER""
    },
    {
        ""prefix"": ""FHW""
    },
    {
        ""prefix"": ""FOX""
    },
    {
        ""prefix"": ""FUH""
    },
    {
        ""prefix"": ""FUN""
    },
    {
        ""prefix"": ""FWF""
    },
    {
        ""prefix"": ""FYO""
    },
    {
        ""prefix"": ""FZO""
    },
    {
        ""prefix"": ""GAF""
    },
    {
        ""prefix"": ""GLW""
    },
    {
        ""prefix"": ""GRJ""
    },
    {
        ""prefix"": ""GRK""
    },
    {
        ""prefix"": ""HFA""
    },
    {
        ""prefix"": ""HFH""
    },
    {
        ""prefix"": ""HQM""
    },
    {
        ""prefix"": ""HRF""
    },
    {
        ""prefix"": ""HRT""
    },
    {
        ""prefix"": ""HSR""
    },
    {
        ""prefix"": ""IAZ""
    },
    {
        ""prefix"": ""IBE""
    },
    {
        ""prefix"": ""IBG""
    },
    {
        ""prefix"": ""IBT""
    },
    {
        ""prefix"": ""IBW""
    },
    {
        ""prefix"": ""IEW""
    },
    {
        ""prefix"": ""IPT""
    },
    {
        ""prefix"": ""IRK""
    },
    {
        ""prefix"": ""JKW""
    },
    {
        ""prefix"": ""JLA""
    },
    {
        ""prefix"": ""JLH""
    },
    {
        ""prefix"": ""JLX""
    },
    {
        ""prefix"": ""JQB""
    },
    {
        ""prefix"": ""JQF""
    },
    {
        ""prefix"": ""JQI""
    },
    {
        ""prefix"": ""JQQ""
    },
    {
        ""prefix"": ""JQS""
    },
    {
        ""prefix"": ""JQW""
    },
    {
        ""prefix"": ""JRG""
    },
    {
        ""prefix"": ""JRI""
    },
    {
        ""prefix"": ""JRV""
    },
    {
        ""prefix"": ""JTM""
    },
    {
        ""prefix"": ""JWF""
    },
    {
        ""prefix"": ""JWM""
    },
    {
        ""prefix"": ""JWO""
    },
    {
        ""prefix"": ""JWX""
    },
    {
        ""prefix"": ""JYN""
    },
    {
        ""prefix"": ""JZV""
    },
    {
        ""prefix"": ""KHC""
    },
    {
        ""prefix"": ""LAR""
    },
    {
        ""prefix"": ""M4V""
    },
    {
        ""prefix"": ""MAG""
    },
    {
        ""prefix"": ""MAP""
    },
    {
        ""prefix"": ""MBB""
    },
    {
        ""prefix"": ""MBG""
    },
    {
        ""prefix"": ""MBL""
    },
    {
        ""prefix"": ""MEW""
    },
    {
        ""prefix"": ""MHG""
    },
    {
        ""prefix"": ""MMY""
    },
    {
        ""prefix"": ""MOE""
    },
    {
        ""prefix"": ""MWF""
    },
    {
        ""prefix"": ""NCB""
    },
    {
        ""prefix"": ""NCI""
    },
    {
        ""prefix"": ""NDA""
    },
    {
        ""prefix"": ""NEC""
    },
    {
        ""prefix"": ""NJN""
    },
    {
        ""prefix"": ""PAN""
    },
    {
        ""prefix"": ""PDO""
    },
    {
        ""prefix"": ""PDZ""
    },
    {
        ""prefix"": ""PLU""
    },
    {
        ""prefix"": ""PPF""
    },
    {
        ""prefix"": ""PPP""
    },
    {
        ""prefix"": ""QCI""
    },
    {
        ""prefix"": ""QCK""
    },
    {
        ""prefix"": ""QCS""
    },
    {
        ""prefix"": ""QCX""
    },
    {
        ""prefix"": ""QDS""
    },
    {
        ""prefix"": ""QDX""
    },
    {
        ""prefix"": ""QES""
    },
    {
        ""prefix"": ""QEX""
    },
    {
        ""prefix"": ""QLS""
    },
    {
        ""prefix"": ""QMV""
    },
    {
        ""prefix"": ""RBE""
    },
    {
        ""prefix"": ""RKC""
    },
    {
        ""prefix"": ""RKQ""
    },
    {
        ""prefix"": ""RKR""
    },
    {
        ""prefix"": ""ROF""
    },
    {
        ""prefix"": ""RQR""
    },
    {
        ""prefix"": ""SBF""
    },
    {
        ""prefix"": ""SDR""
    },
    {
        ""prefix"": ""SDZ""
    },
    {
        ""prefix"": ""SIW""
    },
    {
        ""prefix"": ""SML""
    },
    {
        ""prefix"": ""SMW""
    },
    {
        ""prefix"": ""SOE""
    },
    {
        ""prefix"": ""TAJ""
    },
    {
        ""prefix"": ""TDM""
    },
    {
        ""prefix"": ""TEA""
    },
    {
        ""prefix"": ""THM""
    },
    {
        ""prefix"": ""TJZ""
    },
    {
        ""prefix"": ""TLO""
    },
    {
        ""prefix"": ""TLU""
    },
    {
        ""prefix"": ""TLZ""
    },
    {
        ""prefix"": ""TML""
    },
    {
        ""prefix"": ""TMS""
    },
    {
        ""prefix"": ""TSI""
    },
    {
        ""prefix"": ""TUK""
    },
    {
        ""prefix"": ""TVS""
    },
    {
        ""prefix"": ""UGT""
    },
    {
        ""prefix"": ""UHS""
    },
    {
        ""prefix"": ""UOE""
    },
    {
        ""prefix"": ""USK""
    },
    {
        ""prefix"": ""V4B""
    },
    {
        ""prefix"": ""VAM""
    },
    {
        ""prefix"": ""VAP""
    },
    {
        ""prefix"": ""VAT""
    },
    {
        ""prefix"": ""VAY""
    },
    {
        ""prefix"": ""VGD""
    },
    {
        ""prefix"": ""VHJ""
    },
    {
        ""prefix"": ""VOA""
    },
    {
        ""prefix"": ""VOB""
    },
    {
        ""prefix"": ""VOC""
    },
    {
        ""prefix"": ""VOD""
    },
    {
        ""prefix"": ""VOE""
    },
    {
        ""prefix"": ""VOF""
    },
    {
        ""prefix"": ""VOG""
    },
    {
        ""prefix"": ""VOH""
    },
    {
        ""prefix"": ""VOI""
    },
    {
        ""prefix"": ""VOJ""
    },
    {
        ""prefix"": ""VOK""
    },
    {
        ""prefix"": ""VOM""
    },
    {
        ""prefix"": ""VON""
    },
    {
        ""prefix"": ""VOP""
    },
    {
        ""prefix"": ""VOQ""
    },
    {
        ""prefix"": ""VOR""
    },
    {
        ""prefix"": ""VOS""
    },
    {
        ""prefix"": ""VOT""
    },
    {
        ""prefix"": ""VOU""
    },
    {
        ""prefix"": ""VXC""
    },
    {
        ""prefix"": ""VYM""
    },
    {
        ""prefix"": ""VYU""
    },
    {
        ""prefix"": ""VYZ""
    },
    {
        ""prefix"": ""VZM""
    },
    {
        ""prefix"": ""VZP""
    },
    {
        ""prefix"": ""WAB""
    },
    {
        ""prefix"": ""WGK""
    },
    {
        ""prefix"": ""WHR""
    },
    {
        ""prefix"": ""WLG""
    },
    {
        ""prefix"": ""WLL""
    },
    {
        ""prefix"": ""WSP""
    },
    {
        ""prefix"": ""WYA""
    },
    {
        ""prefix"": ""WZV""
    },
    {
        ""prefix"": ""XCS""
    },
    {
        ""prefix"": ""XCX""
    },
    {
        ""prefix"": ""XCZ""
    },
    {
        ""prefix"": ""XDG""
    },
    {
        ""prefix"": ""XDK""
    },
    {
        ""prefix"": ""XDT""
    },
    {
        ""prefix"": ""XDY""
    },
    {
        ""prefix"": ""XEE""
    },
    {
        ""prefix"": ""XFQ""
    },
    {
        ""prefix"": ""XFU""
    },
    {
        ""prefix"": ""XGH""
    },
    {
        ""prefix"": ""XGK""
    },
    {
        ""prefix"": ""XJC""
    },
    {
        ""prefix"": ""XJD""
    },
    {
        ""prefix"": ""XJF""
    },
    {
        ""prefix"": ""XJG""
    },
    {
        ""prefix"": ""XJH""
    },
    {
        ""prefix"": ""XJI""
    },
    {
        ""prefix"": ""XJL""
    },
    {
        ""prefix"": ""XJO""
    },
    {
        ""prefix"": ""XJP""
    },
    {
        ""prefix"": ""XJR""
    },
    {
        ""prefix"": ""XJY""
    },
    {
        ""prefix"": ""XJZ""
    },
    {
        ""prefix"": ""XKJ""
    },
    {
        ""prefix"": ""XLK""
    },
    {
        ""prefix"": ""XLL""
    },
    {
        ""prefix"": ""XLM""
    },
    {
        ""prefix"": ""XLU""
    },
    {
        ""prefix"": ""XMA""
    },
    {
        ""prefix"": ""XMI""
    },
    {
        ""prefix"": ""XML""
    },
    {
        ""prefix"": ""XMM""
    },
    {
        ""prefix"": ""XMS""
    },
    {
        ""prefix"": ""XMX""
    },
    {
        ""prefix"": ""XNH""
    },
    {
        ""prefix"": ""XNS""
    },
    {
        ""prefix"": ""XOD""
    },
    {
        ""prefix"": ""XOJ""
    },
    {
        ""prefix"": ""XON""
    },
    {
        ""prefix"": ""XOS""
    },
    {
        ""prefix"": ""XPF""
    },
    {
        ""prefix"": ""XPG""
    },
    {
        ""prefix"": ""XPK""
    },
    {
        ""prefix"": ""XPS""
    },
    {
        ""prefix"": ""XQM""
    },
    {
        ""prefix"": ""XSM""
    },
    {
        ""prefix"": ""XTG""
    },
    {
        ""prefix"": ""XTH""
    },
    {
        ""prefix"": ""XUM""
    },
    {
        ""prefix"": ""XVJ""
    },
    {
        ""prefix"": ""XVL""
    },
    {
        ""prefix"": ""XXC""
    },
    {
        ""prefix"": ""XXL""
    },
    {
        ""prefix"": ""XXU""
    },
    {
        ""prefix"": ""XYK""
    },
    {
        ""prefix"": ""XYL""
    },
    {
        ""prefix"": ""XYO""
    },
    {
        ""prefix"": ""XYP""
    },
    {
        ""prefix"": ""XZH""
    },
    {
        ""prefix"": ""XZL""
    },
    {
        ""prefix"": ""XZS""
    },
    {
        ""prefix"": ""XZV""
    },
    {
        ""prefix"": ""XZW""
    },
    {
        ""prefix"": ""XZY""
    },
    {
        ""prefix"": ""YAG""
    },
    {
        ""prefix"": ""YBF""
    },
    {
        ""prefix"": ""YCG""
    },
    {
        ""prefix"": ""YDJ""
    },
    {
        ""prefix"": ""YDL""
    },
    {
        ""prefix"": ""YDV""
    },
    {
        ""prefix"": ""YEA""
    },
    {
        ""prefix"": ""YFV""
    },
    {
        ""prefix"": ""YGJ""
    },
    {
        ""prefix"": ""YGS""
    },
    {
        ""prefix"": ""YGU""
    },
    {
        ""prefix"": ""YGZ""
    },
    {
        ""prefix"": ""YHR""
    },
    {
        ""prefix"": ""YHT""
    },
    {
        ""prefix"": ""YHV""
    },
    {
        ""prefix"": ""YHZ""
    },
    {
        ""prefix"": ""YIB""
    },
    {
        ""prefix"": ""YIC""
    },
    {
        ""prefix"": ""YID""
    },
    {
        ""prefix"": ""YIJ""
    },
    {
        ""prefix"": ""YIM""
    },
    {
        ""prefix"": ""YIT""
    },
    {
        ""prefix"": ""YJB""
    },
    {
        ""prefix"": ""YJD""
    },
    {
        ""prefix"": ""YJE""
    },
    {
        ""prefix"": ""YJQ""
    },
    {
        ""prefix"": ""YJT""
    },
    {
        ""prefix"": ""YJX""
    },
    {
        ""prefix"": ""YKB""
    },
    {
        ""prefix"": ""YKD""
    },
    {
        ""prefix"": ""YKI""
    },
    {
        ""prefix"": ""YKK""
    },
    {
        ""prefix"": ""YKM""
    },
    {
        ""prefix"": ""YKN""
    },
    {
        ""prefix"": ""YKO""
    },
    {
        ""prefix"": ""YKU""
    },
    {
        ""prefix"": ""YLI""
    },
    {
        ""prefix"": ""YLR""
    },
    {
        ""prefix"": ""YLV""
    },
    {
        ""prefix"": ""YMA""
    },
    {
        ""prefix"": ""YNM""
    },
    {
        ""prefix"": ""YPF""
    },
    {
        ""prefix"": ""YPW""
    },
    {
        ""prefix"": ""YPZ""
    },
    {
        ""prefix"": ""YQQ""
    },
    {
        ""prefix"": ""YRA""
    },
    {
        ""prefix"": ""YRC""
    },
    {
        ""prefix"": ""YRE""
    },
    {
        ""prefix"": ""YRF""
    },
    {
        ""prefix"": ""YRI""
    },
    {
        ""prefix"": ""YRS""
    },
    {
        ""prefix"": ""YRU""
    },
    {
        ""prefix"": ""YTQ""
    },
    {
        ""prefix"": ""YTW""
    },
    {
        ""prefix"": ""YUA""
    },
    {
        ""prefix"": ""YUB""
    },
    {
        ""prefix"": ""YUW""
    },
    {
        ""prefix"": ""YUX""
    },
    {
        ""prefix"": ""YVH""
    },
    {
        ""prefix"": ""YVK""
    },
    {
        ""prefix"": ""YWK""
    },
    {
        ""prefix"": ""YWM""
    },
    {
        ""prefix"": ""YWW""
    },
    {
        ""prefix"": ""YXC""
    },
    {
        ""prefix"": ""YXI""
    },
    {
        ""prefix"": ""YXK""
    },
    {
        ""prefix"": ""YXS""
    },
    {
        ""prefix"": ""ZAL""
    },
    {
        ""prefix"": ""ZAQ""
    },
    {
        ""prefix"": ""ZAS""
    },
    {
        ""prefix"": ""ZAX""
    },
    {
        ""prefix"": ""ZBM""
    },
    {
        ""prefix"": ""ZCM""
    },
    {
        ""prefix"": ""ZCN""
    },
    {
        ""prefix"": ""ZCP""
    },
    {
        ""prefix"": ""ZCT""
    },
    {
        ""prefix"": ""ZDX""
    },
    {
        ""prefix"": ""ZEC""
    },
    {
        ""prefix"": ""ZEH""
    },
    {
        ""prefix"": ""ZEK""
    },
    {
        ""prefix"": ""ZER""
    },
    {
        ""prefix"": ""ZEU""
    },
    {
        ""prefix"": ""ZEV""
    },
    {
        ""prefix"": ""ZEY""
    },
    {
        ""prefix"": ""ZGD""
    },
    {
        ""prefix"": ""ZGJ""
    },
    {
        ""prefix"": ""ZGM""
    },
    {
        ""prefix"": ""ZGR""
    },
    {
        ""prefix"": ""ZHH""
    },
    {
        ""prefix"": ""ZHP""
    },
    {
        ""prefix"": ""ZIB""
    },
    {
        ""prefix"": ""ZLH""
    },
    {
        ""prefix"": ""ZMX""
    },
    {
        ""prefix"": ""ZNP""
    },
    {
        ""prefix"": ""ZOE""
    },
    {
        ""prefix"": ""ZOH""
    },
    {
        ""prefix"": ""ZOM""
    },
    {
        ""prefix"": ""ZPD""
    },
    {
        ""prefix"": ""ZPM""
    },
    {
        ""prefix"": ""ZRB""
    },
    {
        ""prefix"": ""ZSM""
    },
    {
        ""prefix"": ""ZUH""
    },
    {
        ""prefix"": ""ZUM""
    },
    {
        ""prefix"": ""ZUS""
    },
    {
        ""prefix"": ""ZVG""
    },
    {
        ""prefix"": ""ZVH""
    },
    {
        ""prefix"": ""ZVJ""
    },
    {
        ""prefix"": ""ZVK""
    },
    {
        ""prefix"": ""ZVR""
    },
    {
        ""prefix"": ""ZVU""
    },
    {
        ""prefix"": ""ZVW""
    },
    {
        ""prefix"": ""ZVX""
    },
    {
        ""prefix"": ""ZVY""
    },
    {
        ""prefix"": ""ZVZ""
    },
    {
        ""prefix"": ""ZWD""
    },
    {
        ""prefix"": ""ZWE""
    },
    {
        ""prefix"": ""ZWO""
    },
    {
        ""prefix"": ""ZWW""
    },
    {
        ""prefix"": ""ZXD""
    },
    {
        ""prefix"": ""ZXG""
    },
    {
        ""prefix"": ""ZYM""
    }
]");
		#endregion
		#endregion
	}
}
