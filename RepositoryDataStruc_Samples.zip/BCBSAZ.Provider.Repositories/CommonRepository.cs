﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace BCBSAZ.Provider.Repositories
{
	public class CommonRepository : ICommonRepository
	{
		private readonly IInetSMPContext _inetSMPContext;
		private readonly IApoContext _apoContext;
		private readonly string _apoEnvironment;

		public CommonRepository(IConfiguration configuration, IInetSMPContext inetSMPContext, IApoContext apoContext)
		{
			_inetSMPContext = inetSMPContext;
			_apoContext = apoContext;
			_apoEnvironment = configuration["ApoEnvironment"];
		}

		private static readonly Dictionary<LOB, string> _alphaPrefixSettings = new Dictionary<LOB, string>()
		{
			{ LOB.LCL, "LocalSubscr" },
			{ LOB.MEDICARE, "MedicareSubscr" }
		};

		public string[] GetAlphaPrefixes(LOB areaPrefix)
		{
			if (_alphaPrefixSettings.ContainsKey(areaPrefix))
			{
				var result = GetConfigSetting(_alphaPrefixSettings[areaPrefix]);
				if (result != null)
				{
					return string.IsNullOrWhiteSpace(result.Value) ? new string[0] : result.Value.Split(',', StringSplitOptions.RemoveEmptyEntries);
				}
			}
			throw new InvalidOperationException("No Alpha Prefix configuration setting found for Area Prefix: " + areaPrefix.ToString());
		}

		public ConfigSetting GetConfigSetting(string settingName) =>
			_apoContext.ConfigSettings.FromSqlRaw(DB.Apo.StoredProcs.GetConfigSetting, _apoEnvironment, settingName, 0).AsEnumerable().FirstOrDefault();

		public int GetMessageCount(string userId)
		{
			var result = _inetSMPContext.MessageCounts.FromSqlRaw(DB.InetSMP.StoredProcs.GetMessageCount, userId).AsEnumerable().FirstOrDefault();
			return result == null ? 0 : result.Count;
		}

		public string GetDatabaseServerName() =>
			_apoContext.ServerInfo.FromSqlRaw("SELECT @@SERVERNAME AS ServerName").AsEnumerable().FirstOrDefault()?.ServerName;
	}
}
