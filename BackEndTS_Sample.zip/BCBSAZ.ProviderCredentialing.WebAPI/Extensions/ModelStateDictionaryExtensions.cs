﻿using BCBSAZ.ProviderCredentialing.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderCredentialing.WebAPI
{
	internal static class ModelStateDictionaryExtensions
	{
		public static IEnumerable<InvalidModelExceptionDetail> ToInvalidModelExceptionDetails(this ModelStateDictionary modelState)
		{
			return (
				from item in modelState
				where item.Value != null
				from error in item.Value.Errors
				select new InvalidModelExceptionDetail(item.Key, error.ErrorMessage, error.Exception)
				);
		}
	}
}
