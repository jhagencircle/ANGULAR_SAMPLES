import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeTerminateCoverageEditComponent } from './employee-terminate-coverage-edit.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgSelectModule } from '@ng-select/ng-select';
import { EmployeeServiceMock } from '../../shared/mocks/employee.service.mock';

describe('EmployeeTerminateCoverageEditComponent', () => {
  let component: EmployeeTerminateCoverageEditComponent;
  let fixture: ComponentFixture<EmployeeTerminateCoverageEditComponent>;
  let mockEmployeeService: any = new EmployeeServiceMock();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        NgbModule,
        HttpClientTestingModule,
        NgSelectModule,
      ],
      declarations: [EmployeeTerminateCoverageEditComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeTerminateCoverageEditComponent);
    component = fixture.componentInstance;

    mockEmployeeService.getById().subscribe((employee: any) => {
      component.employee = employee;
      component.benefitSelection = employee.benefitSelection;
    });

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should send data', () => {
    var store = { account: { accountId: '000312' } };
    var storeSintringify = JSON.stringify(store);
    spyOn(localStorage, 'getItem').and.callFake((key: string): any => {
      return storeSintringify;
    });
    spyOn(component.sendForm, 'emit');
    component.sendData();
    expect(component.sendForm.emit).toHaveBeenCalledWith(
      component.terminationCoverage
    );
  });

  it('should cancel', () => {
    spyOn(component.cancelClick, 'emit');
    component.cancel();
    expect(component.cancelClick.emit).toHaveBeenCalled();
  });

  it('should selectAll', () => {
    component.selectAll(true);
    if (component.healthInsuranceBenefit && component.dentalInsuranceBenefit) {
      expect(component.selectedCoverages).toEqual(['Medical', 'Dental']);
    }
    if (component.healthInsuranceBenefit && !component.dentalInsuranceBenefit) {
      expect(component.selectedCoverages).toEqual(['Medical']);
    }
    if (!component.healthInsuranceBenefit && component.dentalInsuranceBenefit) {
      expect(component.selectedCoverages).toEqual(['Dental']);
    }
    component.selectAll(false);
    expect(component.selectedCoverages).toEqual([]);
  });
});
