﻿using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Security;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface ISecurityRepository
	{
		WebUser GetUserAsync(string userId);

		Role[] GetUserRolesAsync(string userId);

		PortalUser SavePortalUserInfoAsync(PortalUser user);
	}
}
