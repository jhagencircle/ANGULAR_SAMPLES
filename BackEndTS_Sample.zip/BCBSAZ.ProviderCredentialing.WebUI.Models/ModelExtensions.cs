﻿using BCBSAZ.ProviderCredentialing.WebUI.Models.Data.Applications;
using System;
using System.Collections.Generic;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.WebUI.Models
{
	public static class ModelExtensions
	{
		public static bool IsMatch(this IAddress source, IAddress target)
		{
			return
				source.GetType() == target.GetType() &&
				source.StreetAddress.EqualsNullable(target.StreetAddress, StringComparison.OrdinalIgnoreCase) &&
				source.City.EqualsNullable(target.City, StringComparison.OrdinalIgnoreCase) &&
				source.State.EqualsNullable(target.State, StringComparison.OrdinalIgnoreCase) &&
				source.ZipCode.EqualsNullable(target.ZipCode, StringComparison.OrdinalIgnoreCase) &&
				source.Phone.EqualsNullable(target.Phone, StringComparison.OrdinalIgnoreCase) &&
				source.Fax.EqualsNullable(target.Fax, StringComparison.OrdinalIgnoreCase) &&
				source.EmailAddress.EqualsNullable(target.EmailAddress, StringComparison.OrdinalIgnoreCase);
		}

		public static bool IsMatch(this IName source, IName target)
		{
			return
				source.GetType() == target.GetType() &&
				source.FirstName.EqualsNullable(target.FirstName, StringComparison.OrdinalIgnoreCase) &&
				source.LastName.EqualsNullable(target.LastName, StringComparison.OrdinalIgnoreCase) &&
				source.MiddleInitial.EqualsNullable(target.MiddleInitial, StringComparison.OrdinalIgnoreCase);
		}

		public static bool IsEmpty(this IName source)
		{
			return
				string.IsNullOrWhiteSpace(source.FirstName) &&
				string.IsNullOrWhiteSpace(source.LastName) &&
				string.IsNullOrWhiteSpace(source.MiddleInitial);
		}
	}
}
