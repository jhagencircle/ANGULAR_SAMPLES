﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Settings;

namespace BCBSAZ.Provider.Managers.RequestValidators.Settings
{
	internal static class AddUserSettingRequestValidator
	{
		public static void Validate(this AddUserSettingRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(AddUserSettingRequest request)
		{
			if (request.UserSetting == null)
				yield return new InvalidModelExceptionDetail(nameof(AddUserSettingRequest.UserSetting), new ArgumentException("UserSetting is missing."));

			if (request.UserSetting.UserSettingId != 0)
				yield return new InvalidModelExceptionDetail(nameof(AddUserSettingRequest.UserSetting.UserSettingId), new ArgumentException("Invalid UserSettingId specified. For insert operation UserSettingId should be 0"));

			if (request.UserSetting.SettingId == 0)
				yield return new InvalidModelExceptionDetail(nameof(AddUserSettingRequest.UserSetting.SettingId), new ArgumentException("Invalid SettingId specified; non-zero parent SettingId expected."));

			var context = new ValidationContext(request.UserSetting);
			var results = new List<ValidationResult>();

			if (!Validator.TryValidateObject(request.UserSetting, context, results))
			{
				foreach (var result in results)
				{
					yield return new InvalidModelExceptionDetail(result.MemberNames.FirstOrDefault() ?? nameof(AddUserSettingRequest.UserSetting), new ArgumentException(result.ErrorMessage));
				}
			}
		}
	}
}
