import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConstants } from 'src/app/shared/constants/app-constants';
import { IPaymentResponse } from '../shared/payment-response.model';
import { PaymentsService } from '../shared/payments.service';
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-payment-confirmation-account',
  templateUrl: './payment-confirmation-account.component.html',
  styleUrls: ['./payment-confirmation-account.component.scss'],
})
export class PaymentConfirmationAccountComponent implements OnInit {
  paymentConfirmation: IPaymentResponse;
  title: string = '';
  message: string = '';
  icon: string = '';
  constructor(
    private paymentsService: PaymentsService,
    private router: Router,
    public sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.setPaymentConfirmation();
  }

  setPaymentConfirmation() {
    this.paymentConfirmation = this.paymentsService.getPaymentConfirmation()[0];
    if (
      this.paymentConfirmation.paymentTransactionNumber == '' ||
      this.paymentConfirmation.statusName == 'ERROR'
    ) {
      this.title = AppConstants.PAYMENT_CONFIRMATION_TITLE_ERROR;
      this.message = AppConstants.PAYMENT_CONFIRMATION_MESSAGE_ERROR;
      this.icon = AppConstants.PAYMENT_CONFIRMATION_ICON_ERROR;
    } else {
      this.title = AppConstants.PAYMENT_CONFIRMATION_TITLE_SUCCESS;
      this.message = AppConstants.PAYMENT_CONFIRMATION_MESSAGE_SUCCESS;
      this.icon = AppConstants.PAYMENT_CONFIRMATION_ICON_SUCCESS;
    }
  }

  goToLandigPage() {
    this.router.navigate(['/landing-page']);
  }

  getStyleName() {
    let styleName: String = '';
    const elements = document.getElementsByTagName('link');
    for (let index = 0; index < elements.length; index++) {
      if (elements[index].href.startsWith(document.baseURI)) {
        styleName += elements[index].href + ',';
      }
    }
    styleName = styleName.slice(0, -1);
    return styleName;
  }
}
