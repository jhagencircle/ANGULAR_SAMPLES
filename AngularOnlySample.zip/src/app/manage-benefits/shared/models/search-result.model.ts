import { IEmployeeRoster } from './employee-roster.model';

export interface ISearchResult {
  employees: IEmployeeRoster[];
  total: number;
}
