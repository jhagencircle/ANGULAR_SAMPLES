import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { MatStepper } from '@angular/material/stepper';
import html2canvas from 'html2canvas';
import jspdf from 'jspdf';
import { of, Subscription } from 'rxjs';
import { FileUpload } from 'src/app/models/data/file-upload.model';
import { FileUploadService } from 'src/app/services/file-upload.service';
import { EftSubmissionInformationFormComponent } from './eft-submission-information-form/eft-submission-information-form.component';


@Component({
  selector: 'app-eft-change-request-form',
  templateUrl: './eft-change-request-form.component.html',
  styleUrls: ['./eft-change-request-form.component.scss']
})
export class EftChangeRequestFormComponent implements OnInit {
  items = ['item1', 'item2', 'item3', 'item4'];
  userSelectedFile : any;
  addItem(newItem: string) {
    this.items.push(newItem);
  }

@ViewChild(EftSubmissionInformationFormComponent ) child: EftSubmissionInformationFormComponent ; 
  @ViewChild('stepper') private eftStepper: MatStepper;
  selected_files: FileUpload[] = [];

  private file_upload_sub!: Subscription;
  
  constructor(private http: HttpClient, private fileUploadService: FileUploadService) { }

  ngOnInit(): void {  
    //this.userSelectedFile=this.fileUploadService.selectedFile;
    
  }

  public isInvalid(control: AbstractControl): boolean{
    if(!control) return false;

    return control.valid && control.touched;
  }
  
  public canSubmit(): boolean{
    this.userSelectedFile=this.fileUploadService.selectedFile;
    
    this.uploadAll();
    this.downloadPageSection();  
    
    if(!this.eftStepper) return false;
    return this.eftStepper.selectedIndex === 3;
  }   

   uploadFile(index: number,formData:any){
    let file_for_upload = this.fileUploadService.selected_files[index];

    const form_data = new FormData();
    formData.append('file', file_for_upload.file);
    
    this.addItem( file_for_upload.file);

    file_for_upload.is_upload_in_progress = true;
    file_for_upload.upload_result = null;

  } 

  private sendFiles(form_data: FormData) {
    this.http.post('https://localhost:44339/api/v1/EftEnrollment/Upload', form_data, { reportProgress: true, observe: 'events' })
      .subscribe(event => {
      });
  }

  uploadAll(){
    const form_data = new FormData();
    let selected_file_count  = this.fileUploadService.selected_files.length;
    for(let i = 0; i < selected_file_count; i++){
      let selected_file = this.fileUploadService.selected_files[i];
        this.uploadFile(i,form_data);         
    }
    this.sendFiles(form_data); 
  }
  
  downloadPageSection()  
  { 
    //const clonedDoc = document.getElementById('pdfHiddenSection') as HTMLCanvasElement;
     html2canvas(document.getElementById("eftContainer") as HTMLCanvasElement, {
      onclone: function (clonedDoc:any) {
        clonedDoc.getElementById('eftContainer').style.visibility = 'visible';
      }
    }).then(canvas => {      
      var pdf = new jspdf('l', 'pt', [canvas.width, canvas.height]);
      var imgData = canvas.toDataURL("PNG", 1.0);
      pdf.addImage(imgData, 0, 0, (canvas.width), (canvas.height));
      pdf.save('converteddoc.pdf');
    }); 

    const data = document.getElementById('pdfSection3') as HTMLCanvasElement; 
     /*  html2canvas(data).then(canvas => {  
      // Few necessary setting options  
      let imgWidth = 208;             
      let imgHeight = canvas.height * imgWidth / canvas.width;       
  
      const contentDataURL = canvas.toDataURL('image/png')  
      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF  
      let position = 0;  
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)  
      //pdf.addPage();
      pdf.save('EftSubmissionForm.pdf'); // Generated PDF

    });    */
  
  }  
}
