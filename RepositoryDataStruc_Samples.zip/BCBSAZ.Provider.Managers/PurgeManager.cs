﻿using System;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;

namespace BCBSAZ.Provider.Managers
{
	public class PurgeManager : IPurgeManager
	{
		private readonly IPurgeResultsRepository _purgeRepository;

		public PurgeManager(IPurgeResultsRepository rep) {
			_purgeRepository = rep;
		}

		public Task PurgeClaimsResultsAsync(int days)
		{
			return _purgeRepository.PurgeClaimsResultsAsync(days);
		}

		public Task PurgeEligibilityResultsAsync(int days)
		{
			return _purgeRepository.PurgeEligibilityInquiryResultsAsync(days);
		}
	}
}
