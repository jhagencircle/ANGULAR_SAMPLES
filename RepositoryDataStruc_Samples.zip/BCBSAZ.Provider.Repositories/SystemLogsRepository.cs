﻿using System;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Repositories
{
	public class SystemLogsRepository : ISystemLogsRepository
	{
		private readonly ISystemLogsContext _context;
		private readonly ILogger _logger;

		public SystemLogsRepository(ISystemLogsContext context, ILogger<SystemLogsRepository> logger)
		{
			_context = context;
			_logger = logger;
		}

		public Task InsertLogMessageAsync(LogMessage message) =>
			_context.Database.ExecuteSqlRawAsync(
				DB.SystemLogs.StoredProcs.LogException,
				message.ParentException,
				message.IsHandled,
				message.UserId,
				message.SessionId,
				message.Source,
				message.Member,
				message.Url,
				message.RefererUrl,
				message.HttpUserAgent,
				message.Form,
				message.QueryString,
				message.Message,
				message.StackTrace,
				message.AdditionalInfo);

		public async Task LogTransactionAsync(string systemName, string transactionType, string requestBuffer, string errorCode, DateTime endProcess, double totalProcessTime, double totalEdiProcessTime, double postProcessTime, string userId, string info)
		{
			try
			{
				await _context.Database.ExecuteSqlRawAsync(
					DB.SystemLogs.StoredProcs.LogTransaction,
					endProcess,
					transactionType,
					systemName,
					requestBuffer,
					errorCode,
					totalProcessTime,
					totalEdiProcessTime,
					postProcessTime,
					userId,
					info);
			}
			catch(Exception ex)
			{
				_logger.LogError(ex, "Error writing to Transaction Log");
			}
		}
	}
}
