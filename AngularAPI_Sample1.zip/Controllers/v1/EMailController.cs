﻿using BCBSAZ.ProviderAuxiliaryPortal.Managers.Interface;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace BCBSAZ.ProviderAuxiliaryPortal.WebAPI.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private readonly IEmailManager _emailManager;

        public EmailController(IEmailManager emailManager)
        {
            _emailManager = emailManager;
        }

        /// <summary>
        /// Sends both internal and external email
        /// </summary>
        /// <param name="fromAddress"></param>
        /// <param name="toAddress"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <response code="200">Email Successfully sent</response>
        /// <response code="400">Invalid parameters</response>
        /// <response code="500">Server error</response>
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        [HttpPost("Send/{toAddress}/{fromAddress}/{subject}/{body}")]
        public async Task<ActionResult> SendEmailAsync(string fromAddress, string toAddress, string subject, string body)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(fromAddress) || string.IsNullOrWhiteSpace(toAddress) || string.IsNullOrWhiteSpace(subject) || string.IsNullOrWhiteSpace(body))
                    return BadRequest("Invalid parameters");

                //TODO: Temporary use for testing
                List<Attachment> attachments = new List<Attachment>();

                using var stream = new MemoryStream(Encoding.ASCII.GetBytes("This is test attachment"));
                attachments.Add(new Attachment(stream, "Test attachment", "text/text"));

                var externalEmailTask = _emailManager.SendExternalMessageAsync(fromAddress, toAddress, subject, body);
                var internalEmailTask = _emailManager.SendInternalMessageAsync(fromAddress, toAddress, subject, body, attachments);
                await Task.WhenAll(externalEmailTask, internalEmailTask);

                return Ok("Emails successfully sent");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }
    }
}
