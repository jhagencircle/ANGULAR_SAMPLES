﻿using BCBSAZ.ProviderAuxiliaryPortal.Repositories;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.DbContexts;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.ApiClient;
using BCBSAZ.ProviderAuxiliaryPortal.Repositories.Interface.Repository;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using NSubstitute;
using Xunit;

namespace BCBSAZ.ProviderAuxiliaryPortal.UnitTests.Repositories
{
    public class EmailRepositoryTests
    {
        private readonly IEmailRepository _emailRepository;
        private readonly EmailContext _emailContext;
        private readonly IEmailClient _emailClient;

        public EmailRepositoryTests()
        {

            var option = new DbContextOptionsBuilder<EmailContext>()
              .UseInMemoryDatabase("Test.DB").Options;


            _emailClient = Substitute.For<IEmailClient>();
            _emailContext = Substitute.For<EmailContext>(option);
            _emailRepository = new EmailRepository(_emailContext, _emailClient);
        }

        [Theory]
        [InlineData("test@test.com", "test@test.com", "subject", "body")]
        [InlineData("test@test.com", "test@test.com", "subject", "")]
        [InlineData("test@test.com", "test@test.com", "", "body")]
        public async void SendInternalEmail_Success(string toAddress, string fromAddress, string subject, string body)
        {
            //Arrange
            _emailClient.SendEmailAsync(toAddress, fromAddress, subject, body, null).Returns(true);

            // Act
            var result = await _emailRepository.SendInternalEmailAsync(toAddress, fromAddress, subject, body, null);

            // Assert
            result.Should().Be(true);
        }

        [Theory(Skip = "Need to fix unit test")]
        [InlineData("test@test.com", "test@test.com", "subject", "body")]
        [InlineData("test@test.com", "test@test.com", "subject", "")]
        [InlineData("test@test.com", "test@test.com", "", "body")]
        public async void SendExternalEmail_Success(string toAddress, string fromAddress, string subject, string body)
        {
            //Arrange
            _emailContext.Database.ExecuteSqlRawAsync(toAddress, fromAddress, subject, body).Returns(1);

            // Act
            var result = await _emailRepository.SendExternalEmailAsync(toAddress, fromAddress, subject, body);

            // Assert
            result.Should().Be(true);
        }
    }
}
