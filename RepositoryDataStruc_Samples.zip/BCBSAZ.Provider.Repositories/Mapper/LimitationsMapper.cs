﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCBSAZ.Provider.Models.Data.Eligibility;
using BCBSAZ.Provider.Models.Data.Eligibility.Details;
using BCBSAZ.Provider.Models.Enums;
using BCBSAZ.Provider.Models.Xml271Processor.Codes;
using BCBSAZ.Provider.Models.Xml271Processor.Interfaces;
namespace BCBSAZ.Provider.Repositories.Mapper
{
	internal class LimitationsMapper : IBenefitMapper<Limitation>
	{
		public IEnumerable<Limitation> Map(IEligibilityBenefit[] limitArr, IEligibilityBenefit[] remainingArr)
		{
			for (var i = 0; i < limitArr.Length; i++)
			{
				var limit = limitArr.ElementAt(i);
				var limitAdditionalBenefitInfo = limitArr.ElementAtOrDefault(i)?.AdditionalBenefitInformation;
				var remaining = remainingArr.ElementAtOrDefault(i);
				var messages = new List<string>(from x in limit.Messages select x.Text);

				var isHealthBenefitPlanCoverage = limit.BenefitInformation.ServiceTypeCodes.Contains(ServiceTypes.Health_Benefit_Plan_Coverage, StringComparer.OrdinalIgnoreCase);
				var hasBenefitAmount = String.IsNullOrEmpty(limit.BenefitInformation?.BenefitAmount) ? false : true;

				if (remaining != null)
					messages.AddRangeIfNotNullOrEmpty(from x in remaining.Messages select x.Text);
				yield return new Limitation()
				{
#if DEBUG
					EbLoopSegment = limit.BenefitInformation.EligibilityOrBenefitInformation,
#endif
					CoverageLevel = CoverageLevel.I.Find(x => x.Code.Equals(limit.BenefitInformation?.CoverageLevel, StringComparison.OrdinalIgnoreCase))?.Name ?? "N/A",
					PlaceOfService = limitAdditionalBenefitInfo.GetPlaceOfService(),
					TimePeriod = (limit.BenefitInformation.TimePeriodQualifier != null) ? TimePeriod.I.Find(x => x.Code == limit.BenefitInformation.TimePeriodQualifier).Name : "N/A",
					Limit = new Limit
					{
						// Note: this need to be verified but for now here i made an assumption bases on my observation over couple tests cases, 
						// the amount is either BenefitInformation?.BenefitQuanity or BenefitInformation?.BenefitAmount or none. (it can't be both)
						IsLimitCurrency = hasBenefitAmount,
						Amount = decimal.TryParse(hasBenefitAmount ? limit.BenefitInformation?.BenefitAmount: limit.BenefitInformation?.BenefitQuantity , out var limitAmt) ? (decimal?)limitAmt : null,
						LimitDescription = QuantityQualifier.I.Find(x => x.Code.Equals(limit?.BenefitInformation?.QuantityQualifier, StringComparison.OrdinalIgnoreCase))?.Name,

						AuthorizationStatus = limit.BenefitInformation.GetAuthorizationStatus()
					},
					Remaining = new Remaining
					{
						Amount = decimal.TryParse( remaining?.BenefitInformation?.BenefitQuantity, out var remainingAmt) ? (decimal?)remainingAmt : null,
						AuthorizationStatus = remaining?.BenefitInformation.GetAuthorizationStatus()
					},					
					AdditionalInformation = new AdditionalInformation
					{
						HealthCareServiceDeliveries = limit.GetHealthCareServicesDelivery(),
						Other = messages.Distinct()
					}
				};
			}
		}
	}
}
