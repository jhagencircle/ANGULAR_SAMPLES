#
# IIS Reset Script
# DMcDermott
# 10/2017
#

Param
(
    [Parameter(Mandatory = $True)]
    [String]
    $Server,
        
    [Parameter(Mandatory = $True)]
    [String]
    $Command,
    
    [String]
    $Attempts = 3,
	
	[String]
	$Seconds = 1

)

$Outcome = $False
$i = 1

# Configure command
Switch ($Command)
{
    "Stop"
    {
        "Command selected: $Command"
        $ScriptBlock = {IISReset $Server /Stop}
        $Message = 'Internet services successfully stopped'
    }

    "Start"
    {
        "Command selected: $Command"
        $ScriptBlock = {IISReset $Server /Start}
        $Message = 'Internet services successfully started'
    }
    
    default
    {
        "WARNING: Invalid or missing command parameter.  Script will now end..."
        Exit 1
    }
}

# Processing Loop-de-Loop
"Starting loop with $Attempts attempts."
While ($i -le $Attempts)
{
    # Run the command.
    "Executing Command: $ScriptBlock"
    $Output = Invoke-Command -ScriptBlock $ScriptBlock

    # Did it worked?
    If($Output -contains $Message)
    {
        # Yes it worked:  Flip flag to true and break the loop
        $Outcome = $True
        Break
    }
        
    # Iterate counter and loop (try the command again)
    $i++

    "Attempt $i of $Attempts didnt work this time, trying again."
}

# Wrapup:  Were we successful?
Switch ($Outcome)
{
    $True
    {
        "Script completed successfully after $i attempt(s)."
		
			# Time Delay for IIS commands to take effect
			Write-Host "Waiting for a delay of $Seconds seconds for IIS."
				Start-Sleep -s $Seconds
			Write-Host "Time delay complete."
		
        Exit 0
    }

    $False
    {
        "Script ended in Error after $i attempt(s)."
        Exit 1
    }
}