import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserMock {
  constructor() {}
  public static mockedUser: any = {
    name: 'string',
    accountId: 'string',
    isAuthenthicated: true,
  };

  public get(): Observable<any> {
    return of(UserMock.mockedUser);
  }
}
