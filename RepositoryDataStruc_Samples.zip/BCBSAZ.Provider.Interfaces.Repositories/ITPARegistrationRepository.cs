﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.TPA;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface ITPARegistrationRepository
	{
		Task AddTpaRegistrationAsync(TpaRegistration tpaRegistration);
	}
}
