﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.FeeSchedule;

namespace BCBSAZ.Provider.Managers.RequestValidators.FeeSchedule
{
	internal static class OutpatientFeesRequestValidator
	{
		public static void Validate(this OutpatientFeesRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var baseViolations = BaseRequestValidator.GetViolations(request);
			var violations = GetViolations(request);

			if (baseViolations.Any() || violations.Any())
				throw new InvalidRequestException(baseViolations.Union(violations));
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(OutpatientFeesRequest request)
		{
			const string _invalidSiteMessage = "One or more of the Site of Service codes are not valid.";

			if (!string.IsNullOrWhiteSpace(request.SiteOfServiceCodes))
			{
				var siteCodes = request.SiteOfServiceCodes.Split(ManagerConstants.CSV, StringSplitOptions.RemoveEmptyEntries);
				foreach (var siteCode in siteCodes)
				{
					if (!ManagerConstants.FeeSchedule.OutpatientSOSCodes.Contains(siteCode.ToUpperInvariant()))
					{
						yield return new InvalidModelExceptionDetail(nameof(OutpatientFeesRequest.SiteOfServiceCodes),
							_invalidSiteMessage, new ArgumentOutOfRangeException(nameof(OutpatientFeesRequest.SiteOfServiceCodes)));
						break;
					}
				}
			}
		}
	}
}
