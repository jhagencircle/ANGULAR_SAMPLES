﻿//#define DEBUG_CONTEXT
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Models.Data.Common;
using BCBSAZ.Provider.Models.Data.Settings;
using BCBSAZ.Provider.Models.Data.Subscriber;
using BCBSAZ.Provider.Repositories.DbContexts;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories
{
	public class ProviderRepository : IProviderRepository
	{
#if DEBUG && DEBUG_CONTEXT
		private IProviderInetContext __providerInetContext;
		private IProviderInetContext _providerInetContext
		{
			get
			{
				Debug.WriteLine(string.Empty);
				Debug.WriteLine(string.Empty);
				Debug.WriteLine(__providerInetContext.ContextId);

				string[] innerMethods = new string[] { "MoveNext", "Start" };

				var frame = 1;
				string method = null;

				while (method == null || innerMethods.Contains(method, StringComparer.OrdinalIgnoreCase))
				{
					var sf = new StackFrame(frame++);
					method = sf.GetMethod().Name;
					Debug.WriteLine(method);
				}

				Debug.WriteLine(string.Empty);
				Debug.WriteLine(string.Empty);

				return __providerInetContext;
			}
			set
			{
				__providerInetContext = value;
			}
		}
#else
		private readonly IProviderInetContext _providerInetContext;
#endif

		public ProviderRepository(IProviderInetContext providerInetContext)
		{
			_providerInetContext = providerInetContext;
		}

		public ProviderTaxId[] GetTaxIdsForOrg(string orgId) =>
			_providerInetContext.ProviderTaxIds.FromSqlRaw(DB.ProviderInet.StoredProcs.GetTaxIdsForOrgId, orgId).AsEnumerable().ToArray();

		public ServiceType[] GetServiceTypes() =>
			_providerInetContext.ServiceTypes.FromSqlRaw(DB.ProviderInet.StoredProcs.GetServicetypes)
				.AsEnumerable()
				.Distinct()
				.OrderBy(x => x.Description)
				.ToArray();

		public NPI[] GetNpisByOrg(string orgId, string userId, string query, int pageNumber, int pageSize, out int totalCount)
		{
			var orgIdParam = new SqlParameter("@orgID", orgId);
			var userIdParam = new SqlParameter("@userID", userId);
			var queryParam = new SqlParameter("@beginsWith", query);
			var pageSizeParam = new SqlParameter("@PageSize", pageSize);
			var pageNumberParam = new SqlParameter("@PageNumber", pageNumber);

			var totalCountParam = new SqlParameter()
			{
				ParameterName = "@TotalCount",
				DbType = System.Data.DbType.Int32,
				Size = 4,
				Direction = System.Data.ParameterDirection.Output
			};

			var returnValue = _providerInetContext.NPIs.FromSqlRaw(DB.ProviderInet.StoredProcs.GetNPIs, orgIdParam, userIdParam, queryParam, pageSizeParam, pageNumberParam, totalCountParam).AsEnumerable().ToArray();

			totalCount = (int)totalCountParam.Value;

			return returnValue;
		}

		public NPI[] GetNpisByOrgForTPA(string query, int pageNumber, int pageSize, out int totalCount)
		{
			//change to match new sp (GetNPIsForTpa) params.
			var queryParam = new SqlParameter("@beginsWith", query);
			var pageSizeParam = new SqlParameter("@PageSize", pageSize);
			var pageNumberParam = new SqlParameter("@PageNumber", pageNumber);

			var totalCountParam = new SqlParameter()
			{
				ParameterName = "@TotalCount",
				DbType = System.Data.DbType.Int32,
				Size = 4,
				Direction = System.Data.ParameterDirection.Output
			};

			var returnValue = _providerInetContext.NPIs.FromSqlRaw(DB.ProviderInet.StoredProcs.GetNPIsForTpa, queryParam, pageSizeParam, pageNumberParam, totalCountParam).AsEnumerable().ToArray();

			totalCount = (int)totalCountParam.Value;

			return returnValue;
		}

		public PreviouslySelectedServiceType[] GetPreviouslySelectedServiceTypes(string userId) =>
			_providerInetContext.SavedServiceTypes.FromSqlRaw(DB.ProviderInet.StoredProcs.GetPreviouslySelectedServiceTypes, userId).AsEnumerable().ToArray();


		public async Task<bool> DoesMemberExistAsync(string subscriberId, DateTime dateOfBirth)
		{
			// NOTE: Because we are dealing with a Stored Proc which uses an Output Parameter, we must use SqlParameters
			var subscriberIdParam = new SqlParameter("@SubscriberId", subscriberId);
			var dateOfBirthParam = new SqlParameter("@DateOfBirth", dateOfBirth);

			var returnValueParam = new SqlParameter()
			{
				ParameterName = "@ReturnValue",
				DbType = System.Data.DbType.Boolean,
				Size = 1,
				Direction = System.Data.ParameterDirection.Output
			};

			await _providerInetContext.Database.ExecuteSqlRawAsync(DB.ProviderInet.StoredProcs.DoesMemberExist, subscriberIdParam, dateOfBirthParam, returnValueParam);

			return Convert.ToBoolean(returnValueParam.Value);
		}

		public async Task UpdateSelectedServiceTypeAsync(string uid, string selectedServiceTypeIds)
		{
			await _providerInetContext.Database.ExecuteSqlRawAsync(DB.ProviderInet.StoredProcs.UpdateSelectedServiceTypes, uid, selectedServiceTypeIds);
		}

		public ProviderInfo GetProviderInfo(string providerId, string taxId, string orgId, string userName)
		{
			return _providerInetContext.Providers.FromSqlRaw(DB.ProviderInet.StoredProcs.GetProviderInfo, providerId, taxId, orgId, userName).AsEnumerable().FirstOrDefault();
		}

		public async Task<bool> DoesUsernameExist(string username)
		{

			var returnCount = new SqlParameter()
			{
				ParameterName = "@count",
				DbType = System.Data.DbType.Int32,
				Size = 255,
				Direction = System.Data.ParameterDirection.Output
			};

			var userIdParam = new SqlParameter("@username", username);

			await _providerInetContext.Database.ExecuteSqlRawAsync(DB.TpaInet.StoredProcs.CheckUsername, returnCount, userIdParam);

			return (returnCount.Value as int?) != 0;
		}

		public DateTime? GetMemberCutoffDate(string prefix)
		{
			var date = _providerInetContext.CutoffDate.FromSqlRaw(DB.ProviderInet.StoredProcs.GetMemberCutoffDate, prefix).AsEnumerable();

			return !date.Any() ? DateTime.MinValue : date.FirstOrDefault().CutoffDate;
		}
	}
}
