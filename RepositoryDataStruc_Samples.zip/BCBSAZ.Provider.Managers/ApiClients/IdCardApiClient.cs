﻿using System;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.ApiClients;
using BCBSAZ.Provider.Models.Exceptions;
using BCBSAZ.Provider.Models.Requests.Eligibility.Details;
using BCBSAZ.Provider.Models.Responses.Eligibility.Details;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace BCBSAZ.Provider.Managers.ApiClients
{
	public class IdCardApiClient : ApiClientBase, IIdCardApiClient
	{
		private readonly ILogger<IdCardApiClient> _logger;

		public IdCardApiClient(IConfiguration configuration, IOktaApiClient oktaClient, ILogger<IdCardApiClient> logger) : base(oktaClient)
		{
			base.Timeout = new TimeSpan(0, 0, configuration.GetValue<int>(Constants.Configuration.Timeouts.IdCardTimeout));
			var serviceUrl = configuration.GetValue<string>(Constants.Configuration.VelocityApiUrl);

			if (string.IsNullOrWhiteSpace(serviceUrl))
				throw new ArgumentException("Invalid Service Url specified for Velocity API.");

			BaseAddress = new Uri(serviceUrl.EnsureEndsWith('/'));

			DefaultRequestHeaders.Clear();
			DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			_logger = logger;
		}

		protected override string Name => "Member Id Card API";

		public async Task<VelocityIdCardRawResponse> GetIdCardAsync(VelocityIdCardRequest request)
		{
			try
			{
				var idCard = await GetAsync<VelocityIdCardRawResponse>(string.Format(CultureInfo.InvariantCulture, Constants.VelocityApis.IdCard, request.SubscriberId));
				idCard.IdCardFound = true;

				return idCard;
			}
			catch (InvalidApiResponseException ex)
			{
				if (ex.StatusCode != HttpStatusCode.NotFound) // Only log if it wasn't a 404
					_logger.LogError($"IdCardsApi GetIdCardAsync throw a error: {ex.StatusCode}, with Message: {ex.Message}");

				return new VelocityIdCardRawResponse()
				{
					IdCardFound = false
				};
			}
			catch (RecordNotFoundException ex)
			{
				return new VelocityIdCardRawResponse()
				{
					IdCardFound = false
				};
			}
		}

		public async Task<Byte[]> GetImageDataAsync(string url)
		{
			var response = await GetAsync<HttpResponseMessage>(url);

			if (response.IsSuccessStatusCode)
			{
				return await response.Content.ReadAsByteArrayAsync();
			}
			else
			{
				throw new InvalidApiResponseException(response.StatusCode, response.ReasonPhrase, response.Content.Headers.ContentType, url, this.Name);
			}
		}
	}
}
