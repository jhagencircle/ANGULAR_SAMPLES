﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using BCBSAZ.ProviderCredentialing.WebAPI.Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	public class Name
	{
		public string FirstName { get; set; }

		public string LastName { get; set; }

		public string MiddleInitial { get; set; }

		[JsonConverter(typeof(EnumCollectionConverter<NameType>))]
		public IEnumerable<NameType> Types { get; set; }
	}
}
