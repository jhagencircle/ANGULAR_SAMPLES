﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.OfficeUserManagement;

namespace BCBSAZ.Provider.Managers.RequestValidators.OfficeUserManagement
{
	internal static class SaveSubOrgRequestValidator
	{
		public static void Validate(this SaveSubOrgRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = Violations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> Violations(SaveSubOrgRequest request)
		{
			if (string.IsNullOrWhiteSpace(request.SubOrg.Name))
				yield return new InvalidModelExceptionDetail(nameof(SaveSubOrgRequest.SubOrg.Name), new ArgumentException("Invalid Sub Org specified."));
		}
	}
}
