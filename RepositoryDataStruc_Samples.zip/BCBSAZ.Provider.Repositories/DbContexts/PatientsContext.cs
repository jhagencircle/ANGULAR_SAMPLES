﻿using BCBSAZ.Provider.Models.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.Provider.Repositories.DbContexts
{
	public interface IPatientsContext : IDbContext
	{

		DbSet<PatientOrg> PatientOrg { get; set; }

		DbSet<PatientUser> PatientUser { get; set; }

		DbSet<Patient> Patients { get; set; }

	}
	public class PatientsContext : DbContext, IPatientsContext
	{
		/// <summary>
		/// Creates a new instance of the Patients DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public PatientsContext(DbContextOptions<PatientsContext> options) : base(options) { }

		public DbSet<PatientOrg> PatientOrg { get; set; }
		public DbSet<PatientUser> PatientUser { get; set; }
		public DbSet<Patient> Patients { get; set; }


		/// <summary>
		/// Defines custom model binding and configurations for models relating to the PreCert database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{

		}

	}
}
