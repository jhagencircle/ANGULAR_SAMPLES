import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { IPlan } from 'src/app/manage-benefits/shared/models';

@Injectable({
  providedIn: 'root',
})
export class PlanServiceMock {
  constructor() {}
  public static mockedPlans: IPlan[] = [
    {
      id: 'BP202101080355HDHP',
      name: '202101 030855 NGF BluePreferred HDHP',
      type: 'High Deductible Health Plan',
    },
    {
      id: 'BP2021010803553TIER',
      name: '202101 030855 NGF Triple Choice',
      type: 'Triple Choice Plan BluePreferred Care',
    },
    {
      id: 'ZZZZBP2021010803553TIER',
      name: 'ZZZZ202101 030855 NGF Triple Choice',
      type: 'ZZZZTriple Choice Plan BluePreferred Care',
    },
    {
      id: 'BP202101080355HDHP',
      name: '202101 030855 NGF BluePreferred HDHP',
      type: 'High Deductible Health Plan',
    },
    {
      id: 'BP2021010803553TIER',
      name: '202101 030855 NGF Triple Choice',
      type: 'Triple Choice Plan BluePreferred Care',
    },
    {
      id: 'ZZZZBP2021010803553TIER',
      name: 'ZZZZ202101 030855 NGF Triple Choice',
      type: 'ZZZZTriple Choice Plan BluePreferred Care',
    },
    {
      id: 'BP202101080355HDHP',
      name: '202101 030855 NGF BluePreferred HDHP',
      type: 'High Deductible Health Plan',
    },
    {
      id: 'BP2021010803553TIER',
      name: '202101 030855 NGF Triple Choice',
      type: 'Triple Choice Plan BluePreferred Care',
    },
    {
      id: 'ZZZZBP2021010803553TIER',
      name: 'ZZZZ202101 030855 NGF Triple Choice',
      type: 'ZZZZTriple Choice Plan BluePreferred Care',
    },
    {
      id: 'MVB1HIR109INDU65',
      name: '202101 IU65 ACA EDH HMO 4000 On Ex MarFocus',
      type: 'EverydayHealth HMO $4000 Silver On Exchange MaricopaFocus',
    },
    {
      id: 'BP202101080355HDHP',
      name: '202101 030855 NGF BluePreferred HDHP',
      type: 'High Deductible Health Plan',
    },
    {
      id: 'BP2021010803553TIER',
      name: '202101 030855 NGF Triple Choice',
      type: 'Triple Choice Plan BluePreferred Care',
    },
    {
      id: 'MVB0VIF106INDU65',
      name: '202001 IU65 ACA TH HMO 6000 94AV On Ex PimaFocus',
      type: 'TrueHealth HMO $6000 Silver 94AV On Exchange PimaFocus',
    },
    {
      id: 'ZZZZBP2021010803553TIER',
      name: 'ZZZZ202101 030855 NGF Triple Choice',
      type: 'ZZZZTriple Choice Plan BluePreferred Care',
    },
    {
      id: 'MVB0HDR109INDU65',
      name: '202001 IU65 ACA EDH HMO 4000 Off Ex MarFocus',
      type: 'EverydayHealth HMO $4000 Silver Off Exchange MaricopaFocus',
    },
    {
      id: 'BP202101080355HDHP',
      name: '202101 030855 NGF BluePreferred HDHP',
      type: 'High Deductible Health Plan',
    },
    {
      id: 'BP2021010803553TIER',
      name: '202101 030855 NGF Triple Choice',
      type: 'Triple Choice Plan BluePreferred Care',
    },
    {
      id: 'ZZZZBP2021010803553TIER',
      name: 'ZZZZ202101 030855 NGF Triple Choice',
      type: 'ZZZZTriple Choice Plan BluePreferred Care',
    },
    {
      id: 'BP2021010803553TIER',
      name: '202101 030855 NGF Triple Choice',
      type: 'Triple Choice Plan BluePreferred Care',
    },
    {
      id: 'ZZZZBP2021010803553TIER',
      name: 'ZZZZ202101 030855 NGF Triple Choice',
      type: 'ZZZZTriple Choice Plan BluePreferred Care',
    },
    {
      id: 'BP2021010803553TIER',
      name: '202101 030855 NGF Triple Choice',
      type: 'Triple Choice Plan BluePreferred Care',
    },
    {
      id: 'ZZZZBP2021010803553TIER',
      name: 'ZZZZ202101 030855 NGF Triple Choice',
      type: 'ZZZZTriple Choice Plan BluePreferred Care',
    },
  ];
  getByAccountPlanType() {
    return of(PlanServiceMock.mockedPlans);
  }
}
