﻿using Microsoft.EntityFrameworkCore;

namespace BCBSAZ.ProviderCredentialing.Repositories.DbContexts
{
	public interface ISystemLogsContext : IDbContext
	{
	}

	public class SystemLogsContext : DbContext, ISystemLogsContext
	{
		/// <summary>
		/// Creates a new instance of the SystemLogs DbContext object.
		/// </summary>
		/// <param name="options"></param>
		public SystemLogsContext(DbContextOptions<SystemLogsContext> options) : base(options) { }

		/// <summary>
		/// Defines custom model binding and configurations for models relating to the SystemLogs database
		/// </summary>
		/// <param name="modelBuilder">The builder being used to construct the models for this context.</param>
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			/******************** Property Configs ********************/
		}

	}
}
