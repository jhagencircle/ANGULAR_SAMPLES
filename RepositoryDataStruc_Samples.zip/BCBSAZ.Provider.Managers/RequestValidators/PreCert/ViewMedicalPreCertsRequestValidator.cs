﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Data.PreCert;
using BCBSAZ.Provider.Models.Requests.PreCert;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers.RequestValidators.PreCert
{
	internal static class ViewMedicalPreCertsRequestValidator
	{
		public static void Validate(this ViewMedicalPreCertsRequest request, WebUser webUser)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			if (webUser == null)
				throw new ArgumentNullException(nameof(webUser));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(ViewMedicalPreCertsRequest request)
		{
			if (request.FromDate < new DateTime(2017, 1, 1)) // This matches what is currently in ViewMedical.TS in WebUI
				yield return new InvalidModelExceptionDetail(nameof(ViewMedicalPreCertsRequest.FromDate), new ArgumentException("Invalid From Date specified."));

			if (request.ToDate > DateTime.Today)
				yield return new InvalidModelExceptionDetail(nameof(ViewMedicalPreCertsRequest.ToDate), new ArgumentException("Invalid To Date specified."));

			if (!Enum.IsDefined(typeof(PreCertStatus), request.Status))
				yield return new InvalidModelExceptionDetail(nameof(ViewMedicalPreCertsRequest.Status), new ArgumentException("Invalid Status specified."));
		}
	}
}
