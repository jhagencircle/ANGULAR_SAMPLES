import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FinancialManagerUserRoutingModule } from './financial-manager-user-routing.module';
import { FinancialManagerUserComponent } from './financial-manager-user.component';
import { SharedModule } from './../../common/shared/shared.module';
import { SortableDirective } from 'src/app/common/directives/sortable.directive';
import { FinancialManagerUserDeleteConfirmationComponent } from './financial-manager-user-delete-confirmation/financial-manager-user-delete-confirmation.component';

@NgModule({
  declarations: [
    FinancialManagerUserComponent, SortableDirective, FinancialManagerUserDeleteConfirmationComponent
  ],
  imports: [
    CommonModule,
    FinancialManagerUserRoutingModule,
    SharedModule
  ],
  exports: [FinancialManagerUserComponent]
})
export class FinancialManagerUserModule { }
