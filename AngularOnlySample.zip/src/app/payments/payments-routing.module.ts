import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PaymentsComponent } from './payments.component';
import { MakePaymentComponent } from './make-payment/make-payment.component';
import { PaymentActivityComponent } from './payment-activity/payment-activity.component';
import { ManageBankAccountsComponent } from './manage-bank-accounts/manage-bank-accounts.component';
import { ClaimsInvoicePaymentComponent } from './claims-invoice-payment/claims-invoice-payment.component';
import { AuthGuard } from '../core/auth/auth.guard';
import { PaymentConfirmationComponent } from './payment-confirmation/payment-confirmation.component';
import { ManageAutopayComponent } from './manage-autopay/manage-autopay.component';

const routes: Routes = [
  {
    path: '',
    component: PaymentsComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', component: MakePaymentComponent, pathMatch: 'full' },
      { path: 'payment-activity', component: PaymentActivityComponent },
      { path: 'autopay', component: ManageAutopayComponent },
      {
        path: 'manage-bank-accounts',
        component: ManageBankAccountsComponent,
      },
      {
        path: 'payment-confirmation',
        component: PaymentConfirmationComponent,
      },
    ],
  },
  {
    path: 'asc',
    component: PaymentsComponent,
    canActivateChild: [AuthGuard],
    children: [
      {
        path: 'claims-invoice-payment',
        component: ClaimsInvoicePaymentComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PaymentsRoutingModule {}
