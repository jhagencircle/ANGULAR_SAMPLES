﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Logger;

namespace BCBSAZ.Provider.Managers.RequestValidators.SystemLogsManager
{
	internal static class InsertLogMessageRequestValidator
	{
		public static void Validate(this InsertLogMessageRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetVoilations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetVoilations(InsertLogMessageRequest request)
		{
			if (request.Message == null)
			{
				yield return new InvalidModelExceptionDetail(nameof(InsertLogMessageRequest.Message), new ArgumentException("Log Message is missing."));
			}
			else
			{
				if (string.IsNullOrWhiteSpace(request.Message.Message))
					yield return new InvalidModelExceptionDetail(nameof(InsertLogMessageRequest.Message.Message), new ArgumentException("Log Message - Message is missing."));
			}
		}
	}
}
