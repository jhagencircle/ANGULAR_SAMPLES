import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { BillingFaqsService } from './billing-faqs.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { IFaq } from './faq.model';
import { BillingFaqMock } from 'src/app/shared/mocks/billing-faq.mock';

describe('BillingFaqsService', () => {
  let service: BillingFaqsService;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let testUrl: string = '';
  let baseUrl: string = '';

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [HttpClientTestingModule] });
    service = TestBed.inject(BillingFaqsService);
    // Inject the http service and test controller for each test
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
    baseUrl = `${environment.apiUrl}/api`;
  });
  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get billing FAQs', () => {
    const testData: IFaq[] = BillingFaqMock.mockedBillingFAQ;

    testUrl = `${baseUrl}/FAQs`;

    httpClient
      .get<IFaq[]>(testUrl)
      .subscribe((data) => expect(data).toEqual(testData));

    const req = httpTestingController.expectOne(testUrl);

    expect(req.request.method).toEqual('GET');

    req.flush(testData);
  });
});
