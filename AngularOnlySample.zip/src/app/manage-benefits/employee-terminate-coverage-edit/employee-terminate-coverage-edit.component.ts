import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  OnDestroy,
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { TerminationReasonService } from '../shared/termination-reason.service';
import { IEmployee } from '../shared/models/employee.model';
import {
  IBenefit,
  IPlan,
  ITerminationReason,
  ITerminationCoverage,
  IProducts,
} from '../shared/models';
import { AppConstants } from '../../shared/constants/app-constants';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-employee-terminate-coverage-edit',
  templateUrl: './employee-terminate-coverage-edit.component.html',
  styleUrls: ['./employee-terminate-coverage-edit.component.scss'],
})
export class EmployeeTerminateCoverageEditComponent
  implements OnInit, OnDestroy
{
  @Input() benefitSelection: IBenefit;
  @Input() terminateCoverage: string;
  @Input() terminateCoverageNote: string;
  @Output() sendForm = new EventEmitter<any>();
  @Output() cancelClick = new EventEmitter<any>();
  @Input() employee: IEmployee;

  terminationCoverage: ITerminationCoverage;
  activeSave: boolean = false;
  terminationReasonList: ITerminationReason[];
  coverages: any = [];
  selectedCoverages: string[] = [];
  healthInsuranceBenefit: IPlan | undefined;
  dentalInsuranceBenefit: IPlan | undefined;
  products: IProducts[] = [];
  subscriptions: Subscription[] = [];
  form: FormGroup;

  get f() {
    return this.form.controls;
  }

  constructor(
    public fb: FormBuilder,
    private terminationReasonService: TerminationReasonService
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.getBenefitPlans();
    this.getReasonsForRemoval();
    this.onChanges();
    this.setInitialValues();
  }

  onChanges(): void {
    this.form.valueChanges.subscribe((val) => {
      this.activeSave = true;
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  createForm() {
    this.form = this.fb.group({
      reason: [''],
      date: [''],
    });
  }

  setInitialValues() {
    if (this.healthInsuranceBenefit) {
      this.coverages.push({ description: 'Medical', groupType: 'Select all' });
    }
    if (this.dentalInsuranceBenefit) {
      this.coverages.push({ description: 'Dental', groupType: 'Select all' });
    }

    if (this.employee.terminateCoverage) {
      this.f.reason.setValue(this.employee.terminateCoverage.terminationReason);
      this.f.date.setValue(this.employee.terminateCoverage.receivedDate);
      this.employee.terminateCoverage.products.map((item) => {
        this.selectedCoverages.push(item.planType);
      });
    }
  }

  getReasonsForRemoval() {
    let subscription = this.terminationReasonService.get().subscribe((data) => {
      this.terminationReasonList = data;
    });
    this.subscriptions.push(subscription);
  }

  sendData(): void {
    if (this.form.valid) {
      if (this.selectedCoverages.length > 0) {
        let subAccount = JSON.parse(
          localStorage.getItem(
            AppConstants.EMPLOYEE_ROSTER_ACCOUNT_LOCAL_STORAGE_KEY
          ) || ''
        );
        this.selectedCoverages.map((element) => {
          if (element.toLowerCase() == 'select all') {
            if (this.healthInsuranceBenefit) {
              this.products.push({
                effectiveDate: new Date(),
                planType: this.healthInsuranceBenefit.type,
                hccPlanId: null,
                subAccountNumber: subAccount.accountId,
                requiredStartDate: new Date(),
              });
            }
            if (this.dentalInsuranceBenefit) {
              this.products.push({
                effectiveDate: new Date(),
                planType: this.dentalInsuranceBenefit.type,
                hccPlanId: null,
                subAccountNumber: subAccount.accountId,
                requiredStartDate: new Date(),
              });
            }
          } else {
            if (
              element.toLowerCase() == 'medical' &&
              this.healthInsuranceBenefit
            ) {
              this.products.push({
                effectiveDate: new Date(),
                planType: this.healthInsuranceBenefit.type,
                hccPlanId: null,
                subAccountNumber: subAccount.accountId,
                requiredStartDate: new Date(),
              });
            }
            if (
              element.toLowerCase() === 'dental' &&
              this.dentalInsuranceBenefit
            ) {
              this.products.push({
                effectiveDate: new Date(),
                planType: this.dentalInsuranceBenefit.type,
                hccPlanId: null,
                subAccountNumber: subAccount.accountId,
                requiredStartDate: new Date(),
              });
            }
          }
        });

        this.setTerminationCoverageModel();
        this.sendForm.emit(this.terminationCoverage);
        this.activeSave = false;
        this.cancelClick.emit();
      }
    }
  }

  setTerminationCoverageModel() {
    this.terminationCoverage = {
      accountNumber: this.employee.accountId,
      subscriberId: this.employee.subscriberId,
      products: this.products,
      terminationReason: this.f.reason?.value,
      receivedDate: this.f.date?.value,
    };
    this.employee.terminateCoverage = this.terminationCoverage;
  }

  cancel(): void {
    this.form.reset({
      reason: '',
      date: '',
    });
    this.cancelClick.emit();
  }

  selectAll(val: boolean) {
    if (val) {
      this.selectedCoverages = this.coverages.map((c: any) => c.description);
    } else {
      this.selectedCoverages = [];
    }
  }

  getBenefitPlans() {
    this.healthInsuranceBenefit = this.benefitSelection?.planSelection.find(
      (p) => {
        if (p.type.toLowerCase().includes('medical')) {
          return p;
        } else return null;
      }
    );
    this.dentalInsuranceBenefit = this.benefitSelection?.planSelection.find(
      (p) => {
        if (p.type.toLowerCase().includes('dental')) {
          return p;
        } else return null;
      }
    );
  }
}
