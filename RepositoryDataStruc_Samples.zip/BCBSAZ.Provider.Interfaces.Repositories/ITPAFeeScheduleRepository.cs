﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BCBSAZ.Provider.Models.Data.TPA;

namespace BCBSAZ.Provider.Interfaces.Repositories
{
	public interface ITPAFeeScheduleRepository
	{
		public TPAPlaceOfService[] GetPlaceOfService(DateTime dateOfService, string query, int pageSize, int pageNumber, out int totalCount);

		public IEnumerable<TpaFeeDetail> GetTpaFeeScheduleDetail(string providerId, string taxId, IEnumerable<ProcedureCode> rows);

		public Task<bool> IsProviderInstitutionAsync(string taxId, string npi);
	}
}
