import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { IPaymentHistory } from 'src/app/payments/shared/payment-history.model';
import { PaymentsService } from 'src/app/payments/shared/payments.service';
import { ConfirmationDialogService } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.service';
import { ISummary } from 'src/app/shared/models/summary.model';
import { AccountService } from 'src/app/shared/services/account.service';
import { BankAccount } from '../shared/bank-account.model';
import { BankAccountService } from '../shared/bank-account.service';
import { AutopaymentService } from '../../autopay/shared/autopayment.service';
import { SpinnerService } from 'src/app/shared/components/spinner/spinner.service';
import { ModalSize } from 'src/app/shared/enums/modal-size-enum';
import { AppConstants } from '../../shared/constants/app-constants';
import { PaymentStatusEnum } from '../../shared/enums/payment-status-enum';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
@Component({
  selector: 'app-bank-account-list',
  templateUrl: './bank-account-list.component.html',
  styleUrls: ['./bank-account-list.component.scss'],
})
export class BankAccountListComponent implements OnInit, OnDestroy {
  bankAccounts: BankAccount[];
  isAddFormVisible: boolean;
  isEditFormVisible: boolean = false;
  currentRow: any;
  bankAccountSelected: BankAccount;
  account: ISummary;
  hasBankAccounts: boolean = false;
  payments: IPaymentHistory[];
  autopayList: any[];
  subscriptions: Subscription[] = [];

  constructor(
    private bankAccountService: BankAccountService,
    private confirmationDialogService: ConfirmationDialogService,
    private accountService: AccountService,
    private paymentsService: PaymentsService,
    private autopayService: AutopaymentService,
    public spinnerService: SpinnerService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadAccounts(true);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  showAddForm() {
    this.isAddFormVisible = true;
  }

  hideAddForm() {
    if (!this.hasBankAccounts) {
      this.router.navigate(['/landing-page']);
    } else {
      this.isAddFormVisible = false;
    }
  }

  loadAccounts(loadList: boolean) {
    if (loadList) {
      this.spinnerService.show(true);
      this.accountService.get().subscribe((account: ISummary) => {
        if (account) {
          this.account = account;
          this.paymentsService.getList(account.accountId).subscribe(
            (payments: IPaymentHistory[]) => {
              this.payments = payments;

              this.autopayService
                .getList(account.accountId)
                .subscribe((data) => {
                  this.autopayList = data || new Array<any>();
                  this.bankAccountService
                    .get(this.account.accountId)
                    .subscribe((data) => {
                      this.bankAccounts = data.map((d) => ({
                        isEdit: false,
                        isAutopayment:
                          this.autopayList.find(
                            (payment) => payment.bankName === d.name
                          ) !== undefined,
                        isPendingPayment:
                          this.payments.find(
                            (payment) =>
                              payment.bankAccountNickname === d.nickname &&
                              payment.statusName.toLocaleLowerCase() ===
                                PaymentStatusEnum.Pending.toLocaleLowerCase()
                          ) !== undefined,
                        ...d,
                      }));
                      this.spinnerService.show(false);
                      if (
                        this.bankAccounts === undefined ||
                        (this.bankAccounts !== undefined &&
                          this.bankAccounts.length == 0)
                      ) {
                        this.isAddFormVisible = true;
                        this.hasBankAccounts = false;
                      } else {
                        this.isAddFormVisible = false;
                        this.hasBankAccounts = true;
                      }
                    });
                });
            },
            (error: HttpErrorResponse) => {
              this.spinnerService.show(false);
              if (error.status == 404) {
                //There isn't bank accounts for the account
                this.isAddFormVisible = true;
              } else {
                this.isAddFormVisible = false;
              }
            }
          );
        }
      });
    }
  }

  onAddBankAccount(bankAccount: BankAccount) {
    this.bankAccounts.push(bankAccount);
  }

  onEditBankAccount(bankAccount: BankAccount) {
    let updateItem = this.bankAccounts!.find(
      (element) => element.id === bankAccount.id
    );
    let index = this.bankAccounts!.indexOf(updateItem || bankAccount);
    this.bankAccounts![index] = bankAccount;
  }

  showEditForm() {
    this.isEditFormVisible = true;
  }

  hideEditForm(isDisplayed: boolean) {
    this.isEditFormVisible = isDisplayed;
  }

  onClickEditCell(bankAccount: BankAccount) {
    bankAccount.isEdit = !bankAccount.isEdit;
  }

  public openConfirmationDialog(bankAccount: BankAccount) {
    let modalHeader: string = AppConstants.BANK_ACCOUNT_DELETE_ALERT_TITLE;
    let modalbody: string =
      this.bankAccounts.length == 1
        ? AppConstants.BANK_ACCOUNT_SINGLE_DELETE_ALERT_TEXT.replace(
            '${bankAccountName}',
            bankAccount.name
          )
        : AppConstants.BANK_ACCOUNT_DELETE_ALERT_TEXT.replace(
            '${bankAccountName}',
            bankAccount.name
          );
    let btnOkText: string = AppConstants.BANK_ACCOUNT_DELETE_BUTTON_OK_TEXT;
    let btnCancelText: string = AppConstants.BANK_ACCOUNT_DELETE_CANCEL_TEXT;
    let modalSize: string = ModalSize.MEDIUM;
    this.confirmationDialogService
      .confirm(modalHeader, modalbody, btnOkText, btnCancelText, modalSize)
      .then((confirmed) => {
        if (confirmed) {
          this.deleteBankAccount(bankAccount);
        }
      });
  }
  deleteBankAccount(bankAccount: BankAccount) {
    this.bankAccountService
      .delete(bankAccount.accountId, bankAccount.id)
      .subscribe(
        () => {
          //hide spinner
          //show success message
          this.loadAccounts(true);
        },
        (error: HttpErrorResponse) => {
          //hide spinner
          //show error message
        }
      );
  }
}
