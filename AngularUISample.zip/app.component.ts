import { Component, OnInit } from '@angular/core';
import { AuthService } from './core/auth.service';
import { CommonService } from './services/common.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'ProviderAuxiliaryPortalWeb';
  time?: Date;
  constructor(protected commonService: CommonService, public authService: AuthService) {
  }

  ngOnInit(): void {
    this.commonService.getTime().subscribe((result: Date) => {
      this.time = result;
    });
  }
}
