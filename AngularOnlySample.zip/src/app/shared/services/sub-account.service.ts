import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { AppConstants } from '../constants/app-constants';
import { ISummary } from '../models/summary.model';

@Injectable({
  providedIn: 'root',
})
export class SubAccountService {
  private subAccount = new BehaviorSubject<any>(null);
  private subAccountList = new BehaviorSubject<any>(null); //persist subAccountSummary from current bill endpoint
  constructor() {
    const subAccount = localStorage.getItem(
      AppConstants.SUB_ACCOUNT_LOCAL_STORAGE_KEY
    );
    const subAccountList = localStorage.getItem(
      AppConstants.SUB_ACCOUNT_LIST_LOCAL_STORAGE_KEY
    );
    if (subAccount) {
      this.subAccount.next(JSON.parse(subAccount));
    }
    if (subAccountList) {
      this.subAccountList.next(JSON.parse(subAccountList));
    }
  }

  update(subAccount: ISummary) {
    localStorage.setItem(
      AppConstants.SUB_ACCOUNT_LOCAL_STORAGE_KEY,
      JSON.stringify(subAccount)
    );
    this.subAccount.next(subAccount);
  }

  get(): Observable<ISummary> {
    return this.subAccount.asObservable();
  }

  updateList(subAccountList: ISummary[]) {
    localStorage.setItem(
      AppConstants.SUB_ACCOUNT_LIST_LOCAL_STORAGE_KEY,
      JSON.stringify(subAccountList)
    );
    this.subAccountList.next(subAccountList);
  }

  getList(): Observable<ISummary[]> {
    return this.subAccountList.asObservable();
  }
}
