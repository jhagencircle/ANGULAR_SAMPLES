﻿using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using BCBSAZ.Provider.Interfaces.Managers;
using BCBSAZ.Provider.Interfaces.Repositories;
using BCBSAZ.Provider.Interfaces.Services;
using BCBSAZ.Provider.Managers.RequestValidators.Security;
using BCBSAZ.Provider.Models.Requests.Security;
using BCBSAZ.Provider.Models.Responses.Security;
using Microsoft.AspNetCore.Http;

namespace BCBSAZ.Provider.Managers
{
	public class SecurityManager : ISecurityManager
	{
		private const string TokenType = "bearer";

		private readonly ISecurityTokenProvider _tokenProvider;
		private readonly ISecurityRepository _securityRepository;
		private readonly IActiveDirectoryService _adService;

		public SecurityManager(ISecurityTokenProvider tokenProvider, ISecurityRepository securityRepository, IActiveDirectoryService adService)
		{
			_tokenProvider = tokenProvider;
			_securityRepository = securityRepository;
			_adService = adService;
		}

		public AuthenticateUserResponse AuthenticateUser(AuthenticateUserRequest request)
		{
			request.Validate();

			var apiUser = _securityRepository.GetUserAsync(request.UserId);

			if (apiUser == null)
			{
				return new AuthenticateUserResponse()
				{
					User = null,
					TokenType = null,
					Token = null
				};
			}
			else
			{
				apiUser.Roles = _securityRepository.GetUserRolesAsync(request.UserId);

				var identity = _tokenProvider.GenerateClaimsIdentity(apiUser);
				var token = _tokenProvider.GenerateEncodedToken(identity);

				return new AuthenticateUserResponse()
				{
					User = apiUser,
					TokenType = TokenType,
					Token = token
				};
			}
		}

		public AuthenticateUserResponse AuthenticateTokenUser(AuthenticateTokenUserRequest request)
		{
			request.Validate();

			request.PortalUser.UserId = request.PortalUser.UserId.Replace('/', '\\');

			var webUser = new WebUser()
			{
				UserId = request.PortalUser.UserId,
				FirstName = request.PortalUser.FirstName,
				LastName = request.PortalUser.LastName,
				UserType = request.PortalUser.Isinternal ? UserType.Internal : UserType.External,
				OrgId = request.PortalUser.Isinternal ? "BCBSAZ" : string.Empty,
				OrgName = request.PortalUser.Isinternal ? "Blue Cross/Blue Shield of Arizona" : request.PortalUser.OrgName
			};

			if (request.PortalUser.Isinternal)
			{
				var email = request.PortalUser.EmailAddress;
				webUser.Roles = _adService.GetInternalUserInfoAndRoles(webUser, ref email);
				request.PortalUser.FirstName = webUser.FirstName;
				request.PortalUser.LastName = webUser.LastName;
				request.PortalUser.EmailAddress = email;
			}

			_securityRepository.SavePortalUserInfoAsync(request.PortalUser);

			var identity = _tokenProvider.GenerateClaimsIdentity(webUser);
			var token = _tokenProvider.GenerateEncodedToken(identity);

			return new AuthenticateUserResponse
			{
				User = webUser,
				Token = token,
				TokenType = TokenType
			};
		}

		public AuthenticateUserResponse AuthenticateUserFromToken(WebUser webUser)
		{
			webUser.Validate();

			var identity = _tokenProvider.GenerateClaimsIdentity(webUser);
			var token = _tokenProvider.GenerateEncodedToken(identity);

			return new AuthenticateUserResponse
			{
				User = webUser,
				Token = token,
				TokenType = TokenType
			};
		}

		public RefreshAuthenticationResponse RefreshAuthentication(RefreshAuthenticationRequest request, WebUser apiUser)
		{
			request.Validate(apiUser);

			var identity = _tokenProvider.GenerateClaimsIdentity(apiUser);
			var token = _tokenProvider.GenerateEncodedToken(identity);

			return new RefreshAuthenticationResponse()
			{
				TokenType = TokenType,
				Token = token
			};
		}

		public string HashString(string value)
		{
			using (var hash = new SHA256Managed())
			{
				var bytes = hash.ComputeHash(Encoding.Unicode.GetBytes(value));
				return string.Join(string.Empty, bytes.Select(b => b.ToString("x2")));
			}
		}

		public string HashPassword(string username, string password) =>
			HashString(password.Trim() + username.ToLower().Trim());
	}
}
