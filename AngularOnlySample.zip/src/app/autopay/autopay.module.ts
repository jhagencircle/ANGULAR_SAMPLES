import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConfirmationDialogModule } from '../shared/components/confirmation-dialog/confirmation-dialog.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { AlertModule } from '../shared/components/alert/alert.module';
import { TooltipModule, TooltipOptions } from 'ng2-tooltip-directive';
import { TooltipDefaultOptions } from '../shared/providers/tooltipDefaultOptions';
import { AutopayListComponent } from './autopay-list/autopay-list.component';
import { AutopayAddComponent } from './autopay-add/autopay-add.component';
import { RouterModule } from '@angular/router';
import { SpinnerModule } from '../shared/components/spinner/spinner.module';

@NgModule({
  declarations: [AutopayListComponent, AutopayAddComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    ConfirmationDialogModule,
    NgSelectModule,
    AlertModule,
    TooltipModule.forRoot(TooltipDefaultOptions as TooltipOptions),
    RouterModule.forChild([]),
    SpinnerModule,
  ],
  exports: [AutopayListComponent],
  providers: [],
})
export class AutopayModule {}
