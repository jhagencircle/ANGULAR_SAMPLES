﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BCBSAZ.ProviderCredentialing.Models.Data.Applications
{
	public class Language
	{
		public string Name { get; set; }
	}
}
