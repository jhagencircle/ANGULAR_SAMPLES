﻿using System.Globalization;

namespace System
{
	/// <summary>
	/// Global Shortcuts
	/// </summary>
	public static class G
	{
		/// <summary>
		/// CultureInfo.InvariantCulture
		/// </summary>
		public static readonly CultureInfo IC = CultureInfo.InvariantCulture;
	}
}
