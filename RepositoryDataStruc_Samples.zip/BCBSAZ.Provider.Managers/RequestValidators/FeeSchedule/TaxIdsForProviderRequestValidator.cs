﻿using System;
using System.Collections.Generic;
using System.Linq;
using BCBSAZ.Provider.Models;
using BCBSAZ.Provider.Models.Requests.Common;

namespace BCBSAZ.Provider.Managers.RequestValidators.FeeSchedule
{
	internal static class TaxIdsForProviderRequestValidator
	{
		public static void Validate(this TaxIdsForProviderRequest request)
		{
			if (request == null)
				throw new ArgumentNullException(nameof(request));

			var violations = GetViolations(request);

			if (violations.Any())
				throw new InvalidRequestException(violations);
		}

		private static IEnumerable<InvalidModelExceptionDetail> GetViolations(TaxIdsForProviderRequest request)
		{
			const string _missingProviderIdMessage = "ProviderId is required.";
			const string _missingOrgIdMessage = "OrgId is required.";

			if (string.IsNullOrWhiteSpace(request.ProviderId))
				yield return new InvalidModelExceptionDetail(nameof(TaxIdsForProviderRequest.ProviderId), _missingProviderIdMessage, new ArgumentException(_missingProviderIdMessage));

			if (string.IsNullOrWhiteSpace(request.OrgId))
				yield return new InvalidModelExceptionDetail(nameof(TaxIdsForProviderRequest.OrgId), _missingOrgIdMessage, new ArgumentException(_missingOrgIdMessage));
		}
	}
}
