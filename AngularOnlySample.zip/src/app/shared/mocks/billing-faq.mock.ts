import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { IFaq } from 'src/app/billing-faqs/shared/faq.model';

@Injectable({
  providedIn: 'root',
})
export class BillingFaqMock {
  constructor() {}
  public static mockedBillingFAQ: IFaq[] = [
    {
      question: 'How do I check the status of my payments?',
      answer: 'answer 01',
      isDisplayed: false,
    },
    {
      question: 'Can I pay an amount other than what appears on my statement?',
      answer: 'answer 01',
      isDisplayed: false,
    },
    {
      question: 'How do I view payment history?',
      answer: 'answer 01',
      isDisplayed: false,
    },
    {
      question: 'How quickly are payments processed?',
      answer:
        'Payments are processed the next business day when submitted prior to 4:00 p.m. MST. Payments scheduled after 4:00 p.m. MST, or on a weekend or holiday, will be processed the next business day.',
      isDisplayed: false,
    },
    {
      question: 'When will my payments show online?',
      answer: 'answer 01',
      isDisplayed: false,
    },
    {
      question: 'Will I receive a confirmation of payment?',
      answer: 'answer 01',
      isDisplayed: false,
    },
    {
      question: 'How do I cancel a payment?',
      answer: 'answer 01',
      isDisplayed: false,
    },
    {
      question:
        'What will happen if my checking account has insufficient funds at the time of the transaction?',
      answer: 'answer 01',
      isDisplayed: false,
    },
  ];

  public get(): Observable<IFaq[]> {
    return of(BillingFaqMock.mockedBillingFAQ);
  }
}
